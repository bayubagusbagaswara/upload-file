package com.services.billingservice.repository;

import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingNasabahTransferAsset;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingCustomerRepository extends JpaRepository<BillingCustomer, Long> {
    @Query(value = "SELECT * FROM billing_customer where customer_code = :code", nativeQuery = true)
    Optional<BillingCustomer> findByCode(@Param("code")String code);

    @Query(value = "SELECT * FROM billing_customer", nativeQuery = true)
    List<BillingCustomer> findAll();

    @Query(value = "SELECT * FROM billing_customer " +
            "WHERE billing_category = :billingCategory " +
            "AND billing_type = :billingType", nativeQuery = true)
    List<BillingCustomer> findAllByBillingCategoryAndBillingType(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType
    );

    @Query(value = "SELECT * FROM billing_customer " +
            "WHERE ksei_safe_code = :kseiSafeCode", nativeQuery = true)
    Optional<BillingCustomer> findByKseiSafeCode(
            @Param("kseiSafeCode") String kseiSafeCode
    );

    @Query(value = "SELECT * FROM billing_customer " +
            "WHERE billing_category = :billingCategory " +
            "AND billing_type = :billingType " +
            "AND currency = :currency", nativeQuery = true)
    List<BillingCustomer> findAllByBillingCategoryAndBillingTypeAndCurrency(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("currency") String currency
    );
}
