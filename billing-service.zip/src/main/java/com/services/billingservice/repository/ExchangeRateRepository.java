package com.services.billingservice.repository;

import com.services.billingservice.model.ExchangeRate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ExchangeRateRepository extends JpaRepository<ExchangeRate, Long> {

    @Query(value = "SELECT * FROM exchange_rate AS e WHERE e.currency = :currency", nativeQuery = true)
    Optional<ExchangeRate> findByCurrency(@Param("currency") String currency);

    @Query(value = "SELECT e FROM exchange_rate AS e WHERE e.currency = :currency ORDER BY e.date DESC", nativeQuery = true)
    Optional<ExchangeRate> findLatestExchangeRateByCurrency(@Param("currency") String currency);

    @Query(value = "SELECT e FROM exchange_rate AS e ORDER BY e.date DESC", nativeQuery = true)
    Optional<ExchangeRate> findLatestExchangeRate();
}
