package com.services.billingservice.repository;

import com.services.billingservice.model.BillingTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;


@Repository
public interface BillingTemplateRepository extends JpaRepository<BillingTemplate, Long> {
    @Query(value = "SELECT * FROM bill_template WHERE id = :id", nativeQuery = true)
    Optional<BillingTemplate> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM bill_template", nativeQuery = true)
    List<BillingTemplate> findAll();

    @Query(value = "SELECT * FROM bill_template where bill_template_type = :type", nativeQuery = true)
    List<BillingTemplate> findByType(@Param("type") String type);

    @Query(value = "SELECT * FROM bill_template where bill_template_category = :category and bill_template_type = :type", nativeQuery = true)
    List<BillingTemplate> findBycategoryAndType(@Param("category") String category, @Param("type") String type);

}
