package com.services.billingservice.repository;

import com.services.billingservice.model.BillingReportGenerator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingReportGeneratorRepository extends JpaRepository<BillingReportGenerator, Long> {
    @Query(value = "SELECT * FROM billing_report_generator WHERE id = :id", nativeQuery = true)
    Optional<BillingReportGenerator> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM billing_report_generator", nativeQuery = true)
    List<BillingReportGenerator> findAll();
}

