package com.services.billingservice.repository;

import com.services.billingservice.dto.retail.Retail1QueryResultDTO;
import com.services.billingservice.model.RetailAccountBalance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface RetailAccountBalanceRepository extends JpaRepository<RetailAccountBalance, Long> {

    @Query(value = "SELECT NEW com.services.billingservice.dto.retail.Retail1QueryResultDTO(r.securityGroup, SUM(fee))" +
            "FROM RetailAccountBalance r " +
            "WHERE r.sellingAgent = :sellingAgent " +
            "AND r.currency = :currency " +
            "GROUP BY r.securityGroup")
    List<Retail1QueryResultDTO> getSumTotalAmountFeeBySellingAgentAndCurrencyIDR(
            @Param("sellingAgent") String sellingAgent,
            @Param("currency") String currency);

    @Query(nativeQuery = true, value =
            "SELECT " +
                    "YEAR(r.as_of) AS year, " +
                    "FORMAT(CAST(r.as_of AS datetime), 'MMMM') AS month, " +
                    "r.selling_agent AS sellingAgent, " +
                    "SUM(case when as_of = EOMONTH(:dateNow, -1) then balance else 0 end) as lastBalance, " +
                    "SUM(r.fee) AS sumFee " +
                    "FROM rekap_account_balance AS r " +
                    "WHERE r.selling_agent = :sellingAgent " +
                    "AND r.currency = :currency " +
                    "AND FORMAT(CAST(r.as_of AS datetime), 'yyyyMM') = FORMAT(DATEADD(MONTH, -1, :dateNow), 'yyyyMM') " +
                    "GROUP BY YEAR(r.as_of), MONTH(r.as_of), FORMAT(CAST(r.as_of AS datetime), 'MMMM'), r.selling_agent")
    List<Object[]> getRetailDataBySellingAgentAndCurrency(
            @Param("sellingAgent") String sellingAgent,
            @Param("currency") String currency,
            @Param("dateNow") String dateNow
    );

    @Query(value = "SELECT SUM(fee) AS total_amount_fee " +
            "FROM rekap_account_balance " +
            "WHERE selling_agent = :sellingAgent " +
            "AND currency = :currency", nativeQuery = true)
    BigDecimal getSumTotalAmountFeeBySellingAgentAndCurrencyUSD(
            @Param("sellingAgent") String sellingAgent,
            @Param("currency") String currency
    );

}
