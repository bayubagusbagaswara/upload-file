package com.services.billingservice.utils;

import org.apache.commons.io.IOUtils;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigPropertiesUtil {
    String result = "";
    InputStream inputStream;

    public String getPropValues(String data, String propFileName) throws IOException {
        try {
            Properties prop = new Properties();
            inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
            System.out.println(getClass().getClassLoader().getParent());
            if (inputStream != null) {
                prop.load(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }

            String values = prop.getProperty(data);
            result = values;
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            inputStream.close();
        }
        return result;
    }

    public String getPropValues(String propFileName) throws IOException {
        try {
            inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
//            System.out.println(getClass().getClassLoader().getParent());
            String values = "";
            if (inputStream != null) {
                values = IOUtils.toString(inputStream);
            } else {
                throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
            }

            result = values;
        } catch (Exception e) {
            System.out.println("Exception: " + e);
        } finally {
            inputStream.close();
        }
        return result;
    }


    public static String getProperty(String data, String fileName) throws IOException {
        ConfigPropertiesUtil properties = new ConfigPropertiesUtil();
        return properties.getPropValues(data, fileName);
    }

    public static String getAllValue(String fileName) throws IOException {
        ConfigPropertiesUtil properties = new ConfigPropertiesUtil();
        return properties.getPropValues(fileName);
    }


}

