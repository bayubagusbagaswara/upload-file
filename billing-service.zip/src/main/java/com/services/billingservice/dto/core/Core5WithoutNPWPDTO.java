package com.services.billingservice.dto.core;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
public class Core5WithoutNPWPDTO extends BillingCoreBaseDTO {

    private String safekeepingValueFrequency;
    private String safekeepingFee;
    private String safekeepingAmountDue;

    private String kseiTransactionValueFrequency;
    private String kseiTransactionFee;
    private String kseiTransactionAmountDue;

    private String bis4TransactionValueFrequency;
    private String bis4TransactionFee;
    private String bis4TransactionAmountDue;

    private String kseiSafekeepingAmountDue;

    private String totalAmountDue;

}
