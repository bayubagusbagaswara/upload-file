package com.services.billingservice.dto.fund;

import com.services.billingservice.enums.BillingStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.time.Instant;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingFundListProcess {
    private String month;
    private Integer year;
    private Instant createdAt;
    private BillingStatus billingStatus;
}
