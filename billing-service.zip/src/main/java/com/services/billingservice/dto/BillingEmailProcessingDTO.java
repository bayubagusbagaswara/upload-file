package com.services.billingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingEmailProcessingDTO {
    private Long id;

    private String customerCode;

    private String customerName;

    private String customerEmail;

    private String period;

    private String emailStatus;

    private Date sentAt;

    private String desc;
}
