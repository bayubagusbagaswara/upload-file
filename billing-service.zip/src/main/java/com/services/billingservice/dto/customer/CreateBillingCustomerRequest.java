package com.services.billingservice.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateBillingCustomerRequest {

    private String customerCode;
    private String customerName;
    private String customerMinimumFee;
    private String customerSafekeepingFee;

    private String billingCategory;
    private String billingType;
    private String billingTemplate;

    private String investmentManagementName;
    private String investmentManagementAddressBuilding;
    private String investmentManagementAddressStreet;
    private String investmentManagementAddressDistrict;
    private String investmentManagementAddressCity;

    private String debitTransfer;

    private String account;
    private String accountName;
    private String costCenter;

    private double proxyServices;

    private String glAccountHasil;

    private String npwpNumber;
    private String npwpName;
    private String npwpAddress;


    private String kseiSafeCode;
    private String currency;
    private String sellingAgent;

}
