package com.services.billingservice.dto.core;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * cukup menggunakan Core4DTO saja, tidak menggunakan DTO terpisah
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
public class Core4DTO extends BillingCoreBaseDTO {

    // EB
    private String kseiSafekeepingAmountDue;

    private String kseiTransactionValueFrequency;
    private String kseiTransactionFee;
    private String kseiTransactionAmountDue;

    // Itama
    private String safekeepingValueFrequency;
    private String safekeepingFee;
    private String safekeepingAmountDue;

    private String vatFee;
    private String vatAmountDue;

    // EB or ITAMA
    private String totalAmountDue;

}
