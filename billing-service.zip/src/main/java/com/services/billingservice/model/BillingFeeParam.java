package com.services.billingservice.model;


import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_fee_param")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingFeeParam extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "fee_code")
    String feeCode;

    @Column(name = "fee_name")
    String feeName;

    @Column(name = "fee_value")
    BigDecimal feeValue;

    @Column(name = "fee_description")
    String description;
}
