package com.services.billingservice.model.base;

import com.services.billingservice.enums.BillingStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;

@EqualsAndHashCode(callSuper = true)
@MappedSuperclass
@Data
@NoArgsConstructor
@SuperBuilder
public abstract class BaseBilling extends BaseAudit {

    @Enumerated(EnumType.STRING)
    private BillingStatus billingStatus;

    @Column(name = "aid")
    private String aid;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "bill_number")
    private String billingNumber;

    @Column(name = "bill_period")
    private String billingPeriod;

    @Column(name = "bill_statement_date")
    private String billingStatementDate;

    @Column(name = "bill_payment_due_date")
    private String billingPaymentDueDate;

    @Column(name = "bill_category")
    private String billingCategory;

    @Column(name = "bill_type")
    private String billingType;

    @Column(name = "bill_template")
    private String billingTemplate;

    @Column(name = "mi_name")
    private String investmentManagementName;

    @Column(name = "mi_address_building")
    private String investmentManagementAddressBuilding;

    @Column(name = "mi_address_street")
    private String investmentManagementAddressStreet;

    @Column(name = "mi_address_district")
    private String investmentManagementAddressDistrict;

    @Column(name = "mi_address_city")
    private String investmentManagementAddressCity;

    // productName is deleted, because its same accountName (for billing fund)

    @Column(name = "account_name")
    private String accountName; // this is same with GL Name

    @Column(name = "account_number")
    private String accountNumber; // this is same with GL Number (account)

    @Column(name = "cost_center")
    private String costCenter;

    @Column(name = "account_bank")
    private String accountBank; // this is bank name

    @Column(name = "currency")
    private String currency;

}
