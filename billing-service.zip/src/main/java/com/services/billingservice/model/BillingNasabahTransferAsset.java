package com.services.billingservice.model;

import com.services.billingservice.model.base.BaseEntity;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDate;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "bill_nasabah_transfer_asset")
@Data
@SuperBuilder
@NoArgsConstructor
public class BillingNasabahTransferAsset extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_code")
    private String customerCode;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "amount")
    private double amount;

    @Column(name = "effective_date")
    private String effectiveDate;

    @Column(name = "transfer_asset_type")
    private String transferAssetType;

    @Column(name = "isEnable")
    private boolean isEnable;

}
