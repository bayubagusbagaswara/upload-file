package com.services.billingservice.model;

import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_customer")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingCustomer extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "customer_code")
    private String customerCode;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "customer_minimum_fee")
    private BigDecimal customerMinimumFee; // 5.000.000 etc

    @Column(name = "customer_safekeeping_fee")
    private BigDecimal customerSafekeepingFee; // 0.5, 0.3 etc

    @Column(name = "billing_category")
    private String billingCategory;

    @Column(name = "billing_type")
    private String billingType;

    @Column(name = "billing_template")
    private String billingTemplate;

    @Column(name = "mi_name")
    private String miName;

    @Column(name = "mi_address_building")
    private String miAddressBuilding;

    @Column(name = "mi_address_street")
    private String miAddressStreet;

    @Column(name = "mi_address_district")
    private String miAddressDistrict;

    @Column(name = "mi_address_city")
    private String miAddressCity;

    @Column(name = "debit_transfer")
    private String debitTransfer;

    @Column(name = "account_name")
    private String accountName;

    @Column(name = "account")
    private String account;

    @Column(name = "cost_center")
    private String costCenter;

    @Column(name = "gl_account_hasil")
    private String glAccountHasil;

    @Column(name = "npwp_number")
    private String npwpNumber;

    @Column(name = "npwp_name")
    private String npwpName;

    @Column(name = "npwp_address")
    private String npwpAddress;


    @Column(name = "ksei_safe_code")
    private String kseiSafeCode;

    @Column(name = "currency")
    private String currency;

    @Column(name =  "selling_agent")
    private String sellingAgent;

    @Column(name = "swift_code")
    private String swiftCode;

}
