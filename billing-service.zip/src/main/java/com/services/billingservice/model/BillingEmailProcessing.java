package com.services.billingservice.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "billing_email_processing")


public class BillingEmailProcessing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bill_customer_code")
    private String customerCode;

    @Column(name =  "bill_customer_name")
    private String customerName;

    @Column(name = "bill_customer_email")
    private String customerEmail;

    @Column(name = "bill_period")
    private String period;

    @Column(name = "bill_email_status")
    private String emailStatus;

    @Column(name = "bill_sentAt")
    private Date sentAt;

    @Column(name = "bill_desc")
    private String desc;

}
