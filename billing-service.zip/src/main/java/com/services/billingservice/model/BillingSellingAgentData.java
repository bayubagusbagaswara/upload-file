package com.services.billingservice.model;

import com.services.billingservice.model.base.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;


@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "bill_selling_agent_data")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingSellingAgentData extends BaseEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bill_selling_agent_code")
    private String billingSellingAgentCode;

    @Column(name = "bill_selling_agent_name")
    private String billingSellingAgentName;

    @Column(name = "bill_selling_agent_gl")
    private String billingSellingAgentGl;

    @Column(name = "bill_selling_agent_account_name")
    private String billingSellingAgentGlname;

    @Column(name = "bill_selling_agent_account")
    private String billingSellingAgentAccount;

    @Column(name = "bill_selling_agent_gl_account_name")
    private String billingSellingAgentAccountName;

    @Column(name = "bill_selling_agent_email")
    private String billingSellingAgentEmail;

    @Column(name = "bill_selling_agent_alamat")
    private String billingSellingAgentAlamat;

    @Column(name = "bill_selling_agent_desc")
    private String billingSellingAgentDesc;

}
