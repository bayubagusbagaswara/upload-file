package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.kseisafe.CreateKseiSafeRequest;
import com.services.billingservice.model.KseiSafekeepingFee;
import com.services.billingservice.service.KseiSafeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(path = "/api/ksei-safe")
@RequiredArgsConstructor
public class KseiSafeController {

    @Value("${file.path.ksei-safe}")
    private String filePath;

    private final KseiSafeService kseiSafeService;

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert() {

        String status = kseiSafeService.readAndInsertToDB(filePath);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<KseiSafekeepingFee>>> getAll() {

        List<KseiSafekeepingFee> kseiSafeList = kseiSafeService.getAll();

        ResponseDTO<List<KseiSafekeepingFee>> response = ResponseDTO.<List<KseiSafekeepingFee>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(kseiSafeList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/ksei-safe-code")
    public ResponseEntity<ResponseDTO<List<KseiSafekeepingFee>>> getAllByKseiSafeCode(@RequestParam("kseiSafeCode") String kseiSafeCode) {

        List<KseiSafekeepingFee> kseiSafekeepingFeeList = kseiSafeService.getAllByKseiSafeCode(kseiSafeCode);

        ResponseDTO<List<KseiSafekeepingFee>> response = ResponseDTO.<List<KseiSafekeepingFee>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(kseiSafekeepingFeeList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<List<KseiSafekeepingFee>>> create(@RequestBody List<CreateKseiSafeRequest> requestList) {

        List<KseiSafekeepingFee> kseiSafekeepingFeeList = kseiSafeService.createList(requestList);

        ResponseDTO<List<KseiSafekeepingFee>> response = ResponseDTO.<List<KseiSafekeepingFee>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(kseiSafekeepingFeeList)
                .build();

        return ResponseEntity.ok().body(response);

    }

    @GetMapping(path = "/month/year")
    public ResponseEntity<ResponseDTO<List<KseiSafekeepingFee>>> getAllByMonthAndYear(@RequestParam("month") String month,
                                                                                      @RequestParam("year") Integer year) {

        List<KseiSafekeepingFee> kseiSafekeepingFeeList = kseiSafeService.getAllByMonthAndYear(month, year);

        ResponseDTO<List<KseiSafekeepingFee>> response = ResponseDTO.<List<KseiSafekeepingFee>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(kseiSafekeepingFeeList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = kseiSafeService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
