package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.customer.CreateBillingCustomerRequest;
import com.services.billingservice.dto.request.CreateBillingCustomerUploadRequest;
import com.services.billingservice.dto.customer.BillingCustomerDTO;
import com.services.billingservice.service.BillingCustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/customer")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingCustomerController {

    private final BillingCustomerService billingCustomerService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>> create(@RequestBody CreateBillingCustomerRequest request) {

        BillingCustomerDTO billingCustomerDTO = billingCustomerService.create(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload("Successfully created Billing Customer with id : " + billingCustomerDTO.getId())
                .build();

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @PostMapping(path = "/upload")
    public ResponseEntity<ResponseDTO<List<BillingCustomerDTO>>> upload(
            @RequestBody List<CreateBillingCustomerUploadRequest> billingCustomerList) {

        List<BillingCustomerDTO> billingCustomerDTO = billingCustomerService.upload(billingCustomerList);

        ResponseDTO<List<BillingCustomerDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.getReasonPhrase());
        response.setPayload(billingCustomerDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/updateByUpload")
    public ResponseEntity<ResponseDTO<List<BillingCustomerDTO>>> update(
            @RequestBody List<CreateBillingCustomerUploadRequest> billingFeeParamList) {
        List<BillingCustomerDTO> billingCustomerDTOList = billingCustomerService.updateUploadByCustomerCode(billingFeeParamList );

        ResponseDTO<List<BillingCustomerDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.getReasonPhrase());
        response.setPayload(billingCustomerDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);

    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> getById(@RequestParam(name = "id") String id) {
        BillingCustomerDTO billingCustomerDTO = billingCustomerService.getById(id);

        ResponseDTO<BillingCustomerDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingCustomerDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> getByCode(@RequestParam(name = "code") String code) {
        BillingCustomerDTO billingCustomerDTO = billingCustomerService.getByCode(code);

        ResponseDTO<BillingCustomerDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingCustomerDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingCustomerDTO>>> getAll() {
        List<BillingCustomerDTO> billingCustomerDTOList = billingCustomerService.getAll();

        ResponseDTO<List<BillingCustomerDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingCustomerDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> updateByCode(@RequestParam(name = "code") String code,
                                                                        @RequestBody CreateBillingCustomerRequest request) {
        BillingCustomerDTO billingCustomerDTO = billingCustomerService.updateByCode(code, request);
        ResponseDTO<BillingCustomerDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingCustomerDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDTO<BillingCustomerDTO>> updateById(@RequestParam(name = "id") String id,
                                                                        @RequestBody CreateBillingCustomerRequest request) {
        BillingCustomerDTO billingCustomerDTO = billingCustomerService.updateById(id, request);
        ResponseDTO<BillingCustomerDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingCustomerDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(path = "/{id}")
    public ResponseEntity<ResponseDTO<String>> deleteAll(@PathVariable("id") String id) {
        String status = billingCustomerService.deleteById(id);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
