package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.service.SfValRgDailyService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RestController
@RequestMapping(path = "/api/sfval/rg-daily")
public class SfValRgDailyController {

    @Value("${file.path.sf-val-rg-daily}")
    public String filePath;

    private final SfValRgDailyService rgDailyService;

    public SfValRgDailyController(SfValRgDailyService rgDailyService) {
        this.rgDailyService = rgDailyService;
    }

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert() {
        log.info("File Path : {}", filePath);
        String status = rgDailyService.readFileAndInsertToDB(filePath);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAll() {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAll();

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByPeriod(@RequestParam("month") String month,
                                                                          @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByMonthAndYear(month, year);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAid(@RequestParam("aid") String aid) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAid(aid);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndPeriod(@RequestParam("aid") String aid,
                                                                                @RequestParam("month") String month,
                                                                                @RequestParam("year") Integer year) {
            List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByAidAndMonthAndYear(aid, month, year);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/security-name")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndSecurityName(
            @RequestParam("aid") String aid,
            @RequestParam("securityName") String securityName) {

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAidAndSecurityName(aid, securityName);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/security-name/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndSecurityName(
            @RequestParam("aid") String aid,
            @RequestParam("securityName") String securityName,
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByAidAndSecurityNameAndMonthAndYear(aid, securityName, month, year);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/date")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndDate(
            @RequestParam("aid") String aid,
            @RequestParam("date") String date) {

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAidAndDate(aid, date);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = rgDailyService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
