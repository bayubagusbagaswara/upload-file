package com.services.billingservice.controller;


import com.services.billingservice.dto.BillingEmailProcessingDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.service.BillingEmailProcessingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/report-email")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor

public class BillingEmailProcessingController {
    private final BillingEmailProcessingService billingEmailProcessingService;

    @GetMapping(path = "/getByPeriod")
    public ResponseEntity<ResponseDTO<BillingEmailProcessingDTO>>getByPeriod(@RequestParam("period")String period){
        BillingEmailProcessingDTO billingEmailProcessingDTO = billingEmailProcessingService.getByPeriod(period);

        ResponseDTO<BillingEmailProcessingDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingEmailProcessingDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingEmailProcessingDTO>>>getAll(){
        List<BillingEmailProcessingDTO>billingEmailProcessingDTOList = billingEmailProcessingService.getAll();

        ResponseDTO<List<BillingEmailProcessingDTO>>response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingEmailProcessingDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}