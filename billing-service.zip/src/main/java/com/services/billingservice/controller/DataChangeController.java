package com.services.billingservice.controller;

import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/dataChange")
public class DataChangeController {
//    @Autowired
//    DataChangeService dataChangeService;

//    @GetMapping
//    public ResponseEntity<ResponseDTO> getall(){
//        return dataChangeService.getDataChangeAll();
//    }

//    @PutMapping("/approve/{id}")
//    public ResponseEntity<ResponseDTO> doApprove(@PathVariable Long id){
//        return dataChangeService.doApprove(id);
//    }

//    @PutMapping("/reject/{id}")
//    public ResponseEntity<ResponseDTO>  doReject(@PathVariable Long id){
//        return dataChangeService.doReject(id);
//    }



}
