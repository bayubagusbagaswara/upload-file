package com.services.billingservice.controller;


import com.services.billingservice.dto.BillingReportGeneratorDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.service.BillingReportGeneratorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.file.Path;
import java.util.List;

@RestController
@RequestMapping(path = "/report-generator")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor

public class BillingReportGeneratorController {
    private final BillingReportGeneratorService billingReportGeneratorService;

    @GetMapping(path = "/getByPeriod")
    public ResponseEntity<ResponseDTO<BillingReportGeneratorDTO>>getByPeriod(@RequestParam("period")String period){
        BillingReportGeneratorDTO billingReportGeneratorDTO = billingReportGeneratorService.getById(period);

        ResponseDTO<BillingReportGeneratorDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingReportGeneratorDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingReportGeneratorDTO>>>getAll(){
        List<BillingReportGeneratorDTO>billingReportGeneratorDTOList = billingReportGeneratorService.getAll();

        ResponseDTO<List<BillingReportGeneratorDTO>>response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingReportGeneratorDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}