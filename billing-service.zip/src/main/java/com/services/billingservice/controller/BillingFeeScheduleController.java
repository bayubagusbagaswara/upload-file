package com.services.billingservice.controller;

import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.service.BillingFeeScheduleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/fee-schedule")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingFeeScheduleController {

    private final BillingFeeScheduleService billingFeeScheduleService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>> create(@RequestBody BillingFeeScheduleRequest request) {

        System.out.println("request" + request);
        BillingFeeScheduleDTO billingFeeScheduleDTO = billingFeeScheduleService.create(request);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload("Successfully created Fee Schedule with id : " + billingFeeScheduleDTO.getFeeMax());

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BillingFeeScheduleDTO>> getById(@RequestParam(name = "securityCode") String id) {
        BillingFeeScheduleDTO billingFeeScheduleDTO = billingFeeScheduleService.getByCode(id);

        ResponseDTO<BillingFeeScheduleDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeScheduleDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingFeeScheduleDTO>>> getAll() {
        List<BillingFeeScheduleDTO> billingFeeScheduleDTOList = billingFeeScheduleService.getAll();

        ResponseDTO<List<BillingFeeScheduleDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeScheduleDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/code/{code}")
    public ResponseEntity<ResponseDTO<BillingFeeScheduleDTO>> updateById(@PathVariable("code") String id,
                                                                         @RequestBody BillingFeeScheduleRequest request) {
        BillingFeeScheduleDTO billingFeeScheduleDTO = billingFeeScheduleService.updateById(id, request);
        ResponseDTO<BillingFeeScheduleDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeScheduleDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<String>> deleteByCode(@RequestParam("id") String id) {
        String deleteById = billingFeeScheduleService.delete(id);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(deleteById);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
