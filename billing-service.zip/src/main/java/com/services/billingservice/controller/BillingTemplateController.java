package com.services.billingservice.controller;


import com.services.billingservice.dto.BillingTemplateDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.request.BillingTemplateRequest;
import com.services.billingservice.model.BillingTemplate;
import com.services.billingservice.service.BillingTemplateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/bill-template")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingTemplateController {

    private final BillingTemplateService billingTemplateService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>>create(@RequestBody BillingTemplateRequest request){
        BillingTemplateDTO billingTemplateDTO = billingTemplateService.create(request);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload("Succesfully created Billing Template");

        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BillingTemplateDTO>>getById(@RequestParam(name = "id") String id){
        BillingTemplateDTO billingTemplateDTO = billingTemplateService.getById(id);

        ResponseDTO<BillingTemplateDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingTemplateDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingTemplateDTO>>> getAll() {
        List<BillingTemplateDTO> billingTemplateDTOList = billingTemplateService.getAll();

        ResponseDTO<List<BillingTemplateDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingTemplateDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BillingTemplateDTO>> updateById(@RequestParam("id") String id,
                                                                         @RequestBody BillingTemplateRequest request) {
        BillingTemplateDTO billingFeeScheduleDTO = billingTemplateService.updateById(id, request);
        ResponseDTO<BillingTemplateDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingFeeScheduleDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/getByType")
    public ResponseEntity<ResponseDTO<List<BillingTemplateDTO>>> getByType(String type) {
        List<BillingTemplateDTO> billingTemplateDTOList = billingTemplateService.getByType(type);

        ResponseDTO<List<BillingTemplateDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingTemplateDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/getByCategory")
    public ResponseEntity<ResponseDTO<List<BillingTemplateDTO>>> getByCategory(@RequestParam("category") String category, @RequestParam("type") String type) {
        List<BillingTemplateDTO> billingTemplateDTOList = billingTemplateService.getByCategory(category, type);

        ResponseDTO<List<BillingTemplateDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingTemplateDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<String>> deleteById(@RequestParam("id") String id) {
        String deleteById = billingTemplateService.delete(id);

        ResponseDTO<String> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(deleteById);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


}
