package com.services.billingservice.service;

import com.services.billingservice.dto.kseisafe.CreateKseiSafeRequest;
import com.services.billingservice.model.KseiSafekeepingFee;

import java.math.BigDecimal;
import java.util.List;

public interface KseiSafeService {

    List<KseiSafekeepingFee> createList(List<CreateKseiSafeRequest> requestList);

    String readAndInsertToDB(String filePath);

    List<KseiSafekeepingFee> getAll();

    List<KseiSafekeepingFee> getAllByKseiSafeCode(String kseiSafeCode);

    BigDecimal calculateAmountFeeByKseiSafeCodeAndMonthAndYear(String kseiSafeCode, String monthName, int year);

    // BigDecimal calculateAmountFeeForLast3Months(String kseiSafeCode, String monthName, int year);

    String deleteAll();


    // get all by month and year
    List<KseiSafekeepingFee> getAllByMonthAndYear(String month, Integer year);

    // get all by ksei safe code and month and year
    KseiSafekeepingFee getByKseiSafeCodeAndMonthAndYear(String kseiSafeCode, String month, Integer year);

    BigDecimal getAmountFeeByKseiSafeCodeAndMonthAndYear(String kseiSafeCode, String month, Integer year);
}
