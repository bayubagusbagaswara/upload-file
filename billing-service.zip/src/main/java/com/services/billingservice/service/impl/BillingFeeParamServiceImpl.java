package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.request.BillingFeeParamRequest;
import com.services.billingservice.dto.request.BillingFeeParamUploadRequest;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.repository.BillingFeeParamRepository;
import com.services.billingservice.service.BillingFeeParamService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFeeParamServiceImpl implements BillingFeeParamService {

    private final BillingFeeParamRepository billingFeeParamRepository;

    @Override
    public BillingFeeParamDTO create(BillingFeeParamRequest request) {
        String feeCode = request.getFeeCode();
        String feeName = request.getFeeName();
        BigDecimal feeValue = request.getFeeValue();
        String description = request.getDescription();

        BillingFeeParam billingFeeParam = BillingFeeParam.builder()
                .feeCode(feeCode)
                .feeName(feeName)
                .feeValue(feeValue)
                .description(description)
                .build();

        BillingFeeParam dataSaved = billingFeeParamRepository.save(billingFeeParam);
        return mapToDTO(dataSaved);

    }

    @Override
    public BillingFeeParamDTO getById(String id) {
        BillingFeeParam billingFeeParam = billingFeeParamRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

        return mapToDTO(billingFeeParam);
    }

    private BillingFeeParamDTO mapToDTO(BillingFeeParam billingFeeParam) {
        return BillingFeeParamDTO.builder().build().builder()
                .id(String.valueOf(billingFeeParam.getId()))
                .feeCode(billingFeeParam.getFeeCode())
                .feeName(billingFeeParam.getFeeName())
                .feeValue(billingFeeParam.getFeeValue())
                .description(billingFeeParam.getDescription())
                .build();
    }

    private List<BillingFeeParamDTO> mapToFeeParamDTOList(List<BillingFeeParam> feeParamList) {
        return feeParamList.stream()
                .map(this::maptoFeeParamDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<BillingFeeParamDTO> upload(List<BillingFeeParamUploadRequest> request) {
        List<BillingFeeParam> billingFeeParams = mapToFeeParamUploadList(request);
        List<BillingFeeParam> billingFeeParams1 = billingFeeParamRepository.saveAll(billingFeeParams);
        return mapToFeeParamDTOList(billingFeeParams1);
    }


    private List<BillingFeeParam> mapToFeeParamList(List<BillingFeeParamRequest> feeParamList) {
        return feeParamList.stream()
                .map(this::mapToFeeParam)
                .collect(Collectors.toList());

    }

    private List<BillingFeeParam> mapToFeeParamUploadList(List<BillingFeeParamUploadRequest> feeParamList) {
        return feeParamList.stream()
                .map(this::mapToFeeParamUpload)
                .collect(Collectors.toList());

    }

    private BillingFeeParam mapToFeeParam(BillingFeeParamRequest request) {
        return BillingFeeParam.builder()
                .feeCode(request.getFeeCode())
                .feeName(request.getFeeName())
                .feeValue(request.getFeeValue())
                .description(request.getDescription())
                .build();
    }

    private BillingFeeParam mapToFeeParamUpload(BillingFeeParamUploadRequest request) {
        return BillingFeeParam.builder()
                .feeCode(request.getFeeCode())
                .feeName(request.getFeeName())
                .feeValue(request.getFeeValue())
                .description(request.getDescription())
                .build();
    }


    private BillingFeeParamDTO maptoFeeParamDTO(BillingFeeParam feeParam) {
        return BillingFeeParamDTO.builder()
                .id(String.valueOf(feeParam.getId()))
                .feeCode(feeParam.getFeeCode())
                .feeName(feeParam.getFeeName())
                .feeValue(feeParam.getFeeValue())
                .description((feeParam.getDescription()))
                .build();
    }


    @Override
    public BillingFeeParamDTO getByCode(String code) {
       BillingFeeParam billingFeeParam = billingFeeParamRepository.findByCode(code)
               .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

       return mapToDTO(billingFeeParam);
    }

    @Override
    public List<BillingFeeParamDTO> getAll() {
        List<BillingFeeParam> billingFeeParams = billingFeeParamRepository.findAll();

        return mapToFeeParamDTOList(billingFeeParams);
    }


    @Override
    public BillingFeeParamDTO updateByCode(String code, BillingFeeParamRequest request) {


        BillingFeeParam billingFeeParam = billingFeeParamRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException("Data not found"));

        billingFeeParam.setFeeCode(request.getFeeCode());
        billingFeeParam.setFeeName(request.getFeeName());
        billingFeeParam.setFeeValue(request.getFeeValue());
        billingFeeParam.setDescription(request.getDescription());

        BillingFeeParam datasaved = billingFeeParamRepository.save(billingFeeParam);
        return mapToDTO(datasaved);
    }

    @Override
    public BillingFeeParamDTO updateById(String id, BillingFeeParamRequest request) {
        BillingFeeParam billingFeeParam = billingFeeParamRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data not found"));

        billingFeeParam.setFeeCode(request.getFeeCode());
        billingFeeParam.setFeeName(request.getFeeName());
        billingFeeParam.setFeeValue(request.getFeeValue());
        billingFeeParam.setDescription(request.getDescription());

        BillingFeeParam datasaved = billingFeeParamRepository.save(billingFeeParam);
        return mapToDTO(datasaved);
    }

    @Override
    public List<BillingFeeParamDTO> updateUploadByCode(List<BillingFeeParamUploadRequest> request) {
        // code 1, 2, 3, 4, 5
        // checking request is null
        List<BillingFeeParam> feeParamList = new ArrayList<>();

        if (0 == request.size()) {
            // request is null
        } else {
            for (BillingFeeParamUploadRequest billingFeeParamRequest : request) {
                // lakukan update
                BillingFeeParam billingFeeParam = billingFeeParamRepository.findByCode(billingFeeParamRequest.getFeeCode())
                        .orElseThrow(() -> new DataNotFoundException("Data not found"));

//                if (Integer.valueOf(billingFeeParamRequest.getFeeValue()) != 0) {
//                    billingFeeParam.setFeeValue(billingFeeParamRequest.getFeeValue());
//                }
                if (billingFeeParamRequest.getFeeCode() != null) {
                    billingFeeParam.setFeeCode(billingFeeParamRequest.getFeeCode());

                }
                if (billingFeeParamRequest.getDescription() != null) {
                    billingFeeParam.setDescription(billingFeeParamRequest.getDescription());
                }
                // save to the database
                BillingFeeParam save = billingFeeParamRepository.save(billingFeeParam);

                feeParamList.add(save);
            }
        }
        return mapToFeeParamDTOList(feeParamList);
    }

    @Override
    public BigDecimal getValueByName(String name) {
        BillingFeeParam billingFeeParam = billingFeeParamRepository.findByFeeName(name)
                .orElseThrow(() -> new DataNotFoundException("Fee Parameter '" + name + "' is not found"));

        return billingFeeParam.getFeeValue();
    }

    @Override
    public Map<String, BigDecimal> getValueByNameList(List<String> nameList) {
        List<BillingFeeParam> feeParameterList = billingFeeParamRepository.findBillingFeeParamByFeeNameList(nameList);

        Map<String, BigDecimal> collect = feeParameterList.stream()
                .collect(Collectors.toMap(
                        BillingFeeParam::getFeeName,
                        billingFeeParam -> billingFeeParam.getFeeValue()
                ));

        for (String name : nameList) {
            if (!collect.containsKey(name)) {
                throw new DataNotFoundException("Billing Fee Param with name '" + name + "' not found");
            }
        }

        return collect;
    }

    @Override
    public String deleteById(String id) {
        BillingFeeParam billingFeeParam = billingFeeParamRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data not found"));


        billingFeeParamRepository.deleteById(billingFeeParam.getId());

        return "Successfully delete nasabah transfer asset with id : " + billingFeeParam.getId();
    }

}
