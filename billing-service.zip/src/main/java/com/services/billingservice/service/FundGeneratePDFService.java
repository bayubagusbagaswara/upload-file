package com.services.billingservice.service;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.BillingFundListProcessDTO;

import java.util.List;

public interface FundGeneratePDFService {

    List<BillingFundDTO> getAll();

    List<BillingFundListProcessDTO> getAllListProcess();

    List<BillingFundDTO> findByMonthAndYear(String month, Integer year);

    String generatePDF(String category, String monthYear);

    String deleteAll();

}
