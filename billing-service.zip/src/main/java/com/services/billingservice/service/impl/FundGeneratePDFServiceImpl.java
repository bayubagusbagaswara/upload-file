package com.services.billingservice.service.impl;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.BillingFundListProcess;
import com.services.billingservice.dto.fund.BillingFundListProcessDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.exception.UnexpectedException;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.FundGeneratePDFService;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.PdfGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.services.billingservice.constant.FundConstant.*;
import static com.services.billingservice.enums.BillingTemplate.FUND_TEMPLATE;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundGeneratePDFServiceImpl implements FundGeneratePDFService {

    @Value("${base.path.billing.fund}")
    private String basePathBillingFund;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final BillingFundRepository billingFundRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;

    @Override
    public List<BillingFundDTO> getAll() {
        List<BillingFund> billingFundList = billingFundRepository.findAll();
        return mapToDTOList(billingFundList);
    }

    @Override
    public List<BillingFundListProcessDTO> getAllListProcess() {
        BillingFundListProcessDTO temp = new BillingFundListProcessDTO();
        return billingFundRepository.getAllListProcess().stream()
                .map(m -> {
                    BeanUtils.copyProperties(m, temp);
                    temp.setBillingStatus(m.getBillingStatus().getStatus());
                    return temp;
                }).collect(Collectors.toList());
    }

    @Override
    public List<BillingFundDTO> findByMonthAndYear(String month, Integer year) {
        List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYear(month, year);
        return mapToDTOList(billingFundList);
    }

    @Override
    public String generatePDF(String category, String monthYear) {
        log.info("Start generate PDF Billing Fund with month year '{}'", monthYear);
        try {
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(monthYear);
            String month = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // TODO: Update status Approval Status to Approved
            String approvalStatus = ApprovalStatus.Pending.getStatus();

            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatus(
                    category, month, year, approvalStatus
            );

            List<BillingFundDTO> fundDTOList = mapToDTOList(billingFundList);

            generateAndSavePDFStatements(fundDTOList);

            log.info("Finished generate PDF file for Billing Fund");
            return "Successfully created a PDF file for Billing Fund";
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Fund : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public String deleteAll() {
        try {
            billingFundRepository.deleteAll();
            return "Successfully delete all Billing Fund";
        } catch (Exception e) {
            log.error("Error when delete all Billing Funds : " + e.getMessage(), e);
            throw new ConnectionDatabaseException("Error when delete all Billing Funds : " + e.getMessage());
        }
    }

    private void generateAndSavePDFStatements(List<BillingFundDTO> fundDTOList) {
        for (BillingFundDTO fundDTO : fundDTOList) {
            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String htmlContent;
            byte[] pdfBytes;
            String fileName;
            String folderPath;
            String outputPath;

            try {
                monthYearMap = ConvertDateUtil.extractMonthYearInformation(fundDTO.getBillingPeriod());
                yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");

                htmlContent = renderThymeleafTemplate(fundDTO);
                pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);
                fileName = generateFileName(fundDTO.getInvestmentManagementName(), fundDTO.getAid(), yearMonthFormat);

                // TODO: Save file name to the table database with Aid, period, generate date

                folderPath = basePathBillingFund + "/" + yearMonthFormat + "/" +  fundDTO.getInvestmentManagementName();

                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                Path outputPathObj = folderPathObj.resolve(fileName);
                outputPath = outputPathObj.toString();

                pdfGenerator.savePdfToFile(pdfBytes, outputPath);
            } catch (IOException e) {
                log.error("Error creating folder or saving PDF : " + e.getMessage(), e);
                throw new GeneratePDFBillingException("Error creating folder or saving PDF : " + e.getMessage());
            } catch (Exception e) {
                log.error("Unexpected error : " + e.getMessage(), e);
                throw new UnexpectedException("Unexpected error when generate PDF file : " + e.getMessage());
            }
        }
    }


    private String renderThymeleafTemplate(BillingFundDTO fundDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, fundDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, fundDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, fundDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, fundDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, fundDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, fundDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, fundDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, fundDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_BUILDING, fundDTO.getInvestmentManagementAddressBuilding());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_STREET, fundDTO.getInvestmentManagementAddressStreet());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_DISTRICT, fundDTO.getInvestmentManagementAddressDistrict());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_CITY, fundDTO.getInvestmentManagementAddressCity());
        context.setVariable(PRODUCT_NAME, fundDTO.getProductName());
        context.setVariable(ACCOUNT_NAME, fundDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, fundDTO.getAccountNumber());
        context.setVariable(ACCOUNT_BANK, fundDTO.getAccountBank());
        context.setVariable(CUSTOMER_FEE, fundDTO.getCustomerFee());
        context.setVariable(ACCRUAL_CUSTODIAL_FEE, fundDTO.getAccrualCustodialFee());
        context.setVariable(BI_SSSS_VALUE_FREQUENCY, fundDTO.getBis4ValueFrequency());
        context.setVariable(BI_SSSS_TRANSACTION_FEE, fundDTO.getBis4TransactionFee());
        context.setVariable(BI_SSSS_AMOUNT_DUE, fundDTO.getBis4AmountDue());
        context.setVariable(SUB_TOTAL, fundDTO.getSubTotal());
        context.setVariable(VAT_FEE, fundDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, fundDTO.getVatAmountDue());
        context.setVariable(KSEI_VALUE_FREQUENCY, fundDTO.getKseiValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, fundDTO.getKseiTransactionFee());
        context.setVariable(KSEI_AMOUNT_DUE, fundDTO.getKseiAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, fundDTO.getTotalAmountDue());

        // tambahkan Image URL
        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        return templateEngine.process(FUND_TEMPLATE.getValue(), context);
    }

    private String generateFileName(String investmentManagementName, String aid, String yearMonth) {
        return investmentManagementName + "_" + aid + "_" + yearMonth + ".pdf";
    }


    private static BillingFundDTO mapToDTO(BillingFund billingFund) {
        return BillingFundDTO.builder()
                .id(billingFund.getId())
                .createdAt(billingFund.getCreatedAt())
                .updatedAt(billingFund.getUpdatedAt())
                .billingStatus(billingFund.getBillingStatus().getStatus())
                .approvalStatus(billingFund.getApprovalStatus().getStatus())
                .aid(billingFund.getAid())
                .month(billingFund.getMonth())
                .year(String.valueOf(billingFund.getYear()))
                .billingNumber(billingFund.getBillingNumber())
                .billingPeriod(billingFund.getBillingPeriod())
                .billingStatementDate(billingFund.getBillingStatementDate())
                .billingPaymentDueDate(billingFund.getBillingPaymentDueDate())
                .billingCategory(billingFund.getBillingCategory())
                .billingType(billingFund.getBillingType())
                .billingTemplate(billingFund.getBillingTemplate())
                .investmentManagementName(billingFund.getInvestmentManagementName())
                .investmentManagementAddressBuilding(billingFund.getInvestmentManagementAddressBuilding())
                .investmentManagementAddressStreet(billingFund.getInvestmentManagementAddressStreet())
                .investmentManagementAddressDistrict(billingFund.getInvestmentManagementAddressDistrict())
                .investmentManagementAddressCity(billingFund.getInvestmentManagementAddressCity())
                .productName(billingFund.getAccountName())
                .accountName(billingFund.getAccountName())
                .accountNumber(billingFund.getAccountNumber())
                .customerFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getCustomerFee()))
                .accrualCustodialFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getAccrualCustodialFee()))
                .bis4ValueFrequency(String.valueOf(billingFund.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionFee()))
                .bis4AmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getSubTotal()))
                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatAmountDue()))
                .kseiValueFrequency(String.valueOf(billingFund.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionFee()))
                .kseiAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getTotalAmountDue()))
                .build();
    }

    private static List<BillingFundDTO> mapToDTOList(List<BillingFund> billingFundList) {
        return billingFundList.stream()
                .map(FundGeneratePDFServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

}
