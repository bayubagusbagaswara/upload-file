package com.services.billingservice.service;

import com.services.billingservice.dto.exchangerate.CreateExchangeRateRequest;
import com.services.billingservice.dto.exchangerate.ExchangeRateDTO;

import java.util.List;

public interface ExchangeRateService {

    ExchangeRateDTO create(CreateExchangeRateRequest request);

    List<ExchangeRateDTO> getAll();

    ExchangeRateDTO getLatestDataByCurrency(String currency);

    ExchangeRateDTO getLatestData();

    ExchangeRateDTO getByCurrency(String currency);

    ExchangeRateDTO updateById(String id, CreateExchangeRateRequest request);

    ExchangeRateDTO getById(String id);
}
