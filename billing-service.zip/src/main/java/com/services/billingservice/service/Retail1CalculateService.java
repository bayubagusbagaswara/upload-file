package com.services.billingservice.service;

import com.services.billingservice.dto.retail.RetailCalculateRequest;

public interface Retail1CalculateService {

    String calculate(RetailCalculateRequest request);
}
