package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.model.BillingCore;

import java.util.List;

public interface BillingCoreGeneralService {

    void checkingExistingBillingCore(String monthName, Integer year, String aid, String billingCategory, String billingType);

    String deleteAll();

    List<BillingCore> getAll(String categoryUpperCase, String typeUpperCase, String monthName, Integer year);

    String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request);

}
