package com.services.billingservice.service;

import com.services.billingservice.dto.core.Core2DTO;
import com.services.billingservice.dto.core.CoreCalculateRequest;

import java.util.List;

public interface Core4GeneratePDFService {

    List<Core2DTO> getAll();

    String generatePDF(CoreCalculateRequest request);
}
