package com.services.billingservice.service.impl;

import com.services.billingservice.dto.customer.BillingCustomerDTO;
import com.services.billingservice.dto.retail.Retail1QueryResultDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.Currency;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.service.BillingCustomerService;
import com.services.billingservice.service.Retail1CalculateService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.services.billingservice.constant.SecurityGroupConstant.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail1CalculateServiceImpl implements Retail1CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final BillingRetailRepository billingRetailRepository;

    @Override
    public String calculate(RetailCalculateRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            List<BillingRetail> billingRetailList = new ArrayList<>();

            List<BillingCustomerDTO> billingCustomerDTOList = billingCustomerService.getByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomerDTO billingCustomerDTO : billingCustomerDTOList) {
                String sellingAgent = billingCustomerDTO.getSellingAgent();
                BigDecimal customerSafekeepingFee = billingCustomerDTO.getCustomerSafekeepingFee();
                String currency = billingCustomerDTO.getCurrency();
                String billingCategory = billingCustomerDTO.getBillingCategory();
                String billingTemplate = billingCustomerDTO.getBillingTemplate();

                // Create a new BillingRetail object for each customer
                BillingRetail billingRetail = new BillingRetail();

                // Check currency is IDR or USD
                if (currency.equalsIgnoreCase(Currency.IDR.getValue())) {
                    // Calculate Billing IDR
                    List<Retail1QueryResultDTO> retailAccountBalances = retailAccountBalanceRepository.getSumTotalAmountFeeBySellingAgentAndCurrencyIDR(sellingAgent, currency);

                    BigDecimal totalAmountDue = BigDecimal.ZERO; // Initialize totalAmountDue

                    for (Retail1QueryResultDTO accountBalance : retailAccountBalances) {
                        BigDecimal totalAmountFee = accountBalance.getTotalAmountFee();
                        String securityGroup = accountBalance.getSecurityGroup();

                        // Set safekeeping fees based on security group
                        switch (securityGroup.toUpperCase()) {
                            case FR:
                                billingRetail.setSafekeepingFR(totalAmountFee);
                                break;
                            case SR:
                                billingRetail.setSafekeepingSR(totalAmountFee);
                                break;
                            case ST:
                                billingRetail.setSafekeepingST(totalAmountFee);
                                break;
                            case ORI:
                                billingRetail.setSafekeepingORI(totalAmountFee);
                                break;
                            case SBR:
                                billingRetail.setSafekeepingSBR(totalAmountFee);
                                break;
                            case PBS:
                                billingRetail.setSafekeepingPBS(totalAmountFee);
                                break;
                            case CORPORATE_BOND:
                                billingRetail.setSafekeepingCorporateBond(totalAmountFee);
                                break;
                            default:
                                break;
                        }

                        // Accumulate totalAmountFee to calculate totalAmountDue
                        totalAmountDue = totalAmountDue.add(totalAmountFee);
                    }

                    // Add customer safekeeping fee to totalAmountDue for IDR
                    totalAmountDue = totalAmountDue.add(customerSafekeepingFee);

                    // Set the total amount due for IDR
                    billingRetail.setTotalAmountDue(totalAmountDue);
                } else {
                    // Calculate Billing USD
                    BigDecimal totalAmountDue = retailAccountBalanceRepository.getSumTotalAmountFeeBySellingAgentAndCurrencyUSD(sellingAgent, currency);

                    // Add customer safekeeping fee to totalAmountDue for USD
                    totalAmountDue = totalAmountDue.add(customerSafekeepingFee);

                    // Set the total amount due for USD
                    billingRetail.setTotalAmountDue(totalAmountDue);
                }

                // Set the customer safekeeping fee
                billingRetail.setSafekeepingFee(customerSafekeepingFee);

                // Set the billing category dan billing template
                billingRetail.setBillingCategory(billingCategory);
                billingRetail.setBillingTemplate(billingTemplate);

                // Set common properties for both IDR and USD calculations
                billingRetail.setCurrency(currency);
                billingRetailList.add(billingRetail);
            }

            // Save all billing retail records to the database
            List<BillingRetail> billingRetailListSaved = billingRetailRepository.saveAll(billingRetailList);
            log.info("Finished calculate Billing Core type 1 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Retail type 1 with total : " + billingRetailListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Retail type 1 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Retail type 1 : " + e.getMessage());
        }
    }

}
