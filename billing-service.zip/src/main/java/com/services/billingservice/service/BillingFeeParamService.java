package com.services.billingservice.service;

import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.request.BillingFeeParamRequest;
import com.services.billingservice.dto.request.BillingFeeParamUploadRequest;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface BillingFeeParamService {

    //single maintenance
    BillingFeeParamDTO create(BillingFeeParamRequest request);
    BillingFeeParamDTO getById(String id);
    BillingFeeParamDTO getByCode(String code);
    List<BillingFeeParamDTO>getAll();
    BillingFeeParamDTO updateByCode(String code, BillingFeeParamRequest request);
    BillingFeeParamDTO updateById(String id, BillingFeeParamRequest request);

    //upload
    List<BillingFeeParamDTO> upload(List<BillingFeeParamUploadRequest> request);
    List<BillingFeeParamDTO> updateUploadByCode(List<BillingFeeParamUploadRequest> request);

    BigDecimal getValueByName(String name);
    Map<String, BigDecimal> getValueByNameList(List<String> nameList);

    String deleteById(String id);
}
