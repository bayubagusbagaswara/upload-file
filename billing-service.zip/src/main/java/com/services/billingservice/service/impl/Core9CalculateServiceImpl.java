package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.customer.BillingCustomerDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.FeeParameter.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core9CalculateServiceImpl implements Core9CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParamService feeParamService;
    private final SkTranService skTranService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingCoreGeneralService billingCoreGeneralService;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core type 9 with request '{}'", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // Initialization variable
            Integer transactionHandlingValueFrequency;
            BigDecimal transactionHandlingAmountDue;
            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            BigDecimal subTotalAmountDue;
            BigDecimal vatAmountDue;
            BigDecimal totalAmountDue;
            List<BillingCore> billingCoreList = new ArrayList<>();
            Instant dateNow = Instant.now();

            // Get fee parameter
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(TRANSACTION_HANDLING_IDR.getValue());
            feeParamList.add(VAT.getValue());

            Map<String, BigDecimal> feeParameterMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal transactionHandlingFee = feeParameterMap.get(TRANSACTION_HANDLING_IDR.getValue());
            BigDecimal vatFee = feeParameterMap.get(VAT.getValue());

            // Get Billing Customer
            List<BillingCustomerDTO> customerDTOList = billingCustomerService.getByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            // Process calculate billing
            for (BillingCustomerDTO billingCustomerDTO : customerDTOList) {
                String aid = billingCustomerDTO.getCustomerCode();
                BigDecimal customerSafekeepingFee = billingCustomerDTO.getCustomerSafekeepingFee();
                BigDecimal customerMinimumFee = billingCustomerDTO.getCustomerMinimumFee();
                String billingCategory = billingCustomerDTO.getBillingCategory();
                String billingType = billingCustomerDTO.getBillingType();

                List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, monthName, year);

                List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(aid, monthName, year);

                transactionHandlingValueFrequency = calculateTransactionHandlingValueFrequency(aid, skTransactionList);

                transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(aid, transactionHandlingValueFrequency, transactionHandlingFee);

                safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgMonthlyList);

                safekeepingAmountDue = calculateSafekeepingAmountDue(aid, safekeepingValueFrequency, customerSafekeepingFee);

                subTotalAmountDue = calculateSubTotalAmountDue(aid, transactionHandlingAmountDue, safekeepingAmountDue);

                vatAmountDue = calculateVATAmountDue(aid, subTotalAmountDue, vatFee);

                totalAmountDue = calculateTotalAmountDue(aid, subTotalAmountDue, vatAmountDue);

                billingCoreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                BillingCore billingCore = BillingCore.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .aid(aid)
                        .month(monthName)
                        .year(year)
                        .billingPeriod(monthName + " " + year)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCategory)
                        .billingType(billingType)
                        .billingTemplate(billingCustomerDTO.getBillingTemplate())
                        .investmentManagementName(billingCustomerDTO.getInvestmentManagementName())
                        .investmentManagementAddressBuilding(billingCustomerDTO.getInvestmentManagementAddressBuilding())
                        .investmentManagementAddressStreet(billingCustomerDTO.getInvestmentManagementAddressStreet())
                        .investmentManagementAddressDistrict(billingCustomerDTO.getInvestmentManagementAddressDistrict())
                        .investmentManagementAddressCity(billingCustomerDTO.getInvestmentManagementAddressCity())

                        .customerMinimumFee(customerMinimumFee)
                        .customerSafekeepingFee(customerSafekeepingFee)

                        .accountName(billingCustomerDTO.getAccountName())
                        .accountNumber(billingCustomerDTO.getAccount())
                        .costCenter(billingCustomerDTO.getCostCenter())
                        .accountBank(billingCustomerDTO.getAccountBank())
                        .currency(IDR.getValue())

                        .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                        .transactionHandlingFee(transactionHandlingFee)
                        .transactionHandlingAmountDue(transactionHandlingAmountDue)
                        .safekeepingValueFrequency(safekeepingValueFrequency)
                        .safekeepingFee(customerSafekeepingFee)
                        .safekeepingAmountDue(safekeepingAmountDue)
                        .subTotal(subTotalAmountDue)
                        .vatFee(vatFee)
                        .vatAmountDue(vatAmountDue)
                        .totalAmountDue(totalAmountDue)
                        .build();

                billingCoreList.add(billingCore);
            }

            int billingCoreListSize = billingCoreList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingCoreListSize, monthName, year);

            for (int i = 0; i < billingCoreListSize; i++) {
                BillingCore billingCore = billingCoreList.get(i);
                String billingNumber = numberList.get(i);
                billingCore.setBillingNumber(billingNumber);
            }

            List<BillingCore> billingCoreSaved = billingCoreRepository.saveAll(billingCoreList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Core type 9 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Core type 9 with a total : " + billingCoreSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 9 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 9 : " + e.getMessage());
        }
    }


    private static Integer calculateTransactionHandlingValueFrequency(String aid, List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 9] Total transaction handling Aid '{}' is '{}'", aid, totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(String aid, Integer transactionHandlingValueFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = transactionHandlingFee.multiply(new BigDecimal(transactionHandlingValueFrequency).setScale(0, RoundingMode.HALF_UP));
        log.info("[Core Type 9] Transaction handling amount due Aid '{}' is '{}'", aid, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgMonthly> sfValRgMonthlyList) {
        List<SfValRgMonthly> latestEntries = sfValRgMonthlyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgMonthlyList.stream()
                        .map(SfValRgMonthly::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgMonthly latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}'", latestEntry.getDate(), latestEntry.getSecurityName());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgMonthly::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 9] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, BigDecimal safekeepingValueFrequency, BigDecimal customerSafekeepingFee) {
        // customerSafekeepingFee perlu dibagi 100 lagi
        BigDecimal safeKeepingAfterDivide100Percentage = customerSafekeepingFee
                .divide(new BigDecimal(100), 4, RoundingMode.HALF_UP);

        BigDecimal safekeepingAmountDue = safekeepingValueFrequency
                .multiply(safeKeepingAfterDivide100Percentage)
                .divide(new BigDecimal(12), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 9] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateSubTotalAmountDue(String aid, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotalAmountDue = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Core Type 9] Sub total amount due Aid '{}' is '{}'", aid, subTotalAmountDue);
        return subTotalAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotalAmountDue.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 9] VAT amount due Aid '{}' is '{}'", aid, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotalAmountDue.add(vatAmountDue);
        log.info("[Core Type 9] Total amount due '{}' is '{}'", aid, totalAmountDue);
        return totalAmountDue;
    }

}
