package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.customer.BillingCustomerDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.*;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.repository.BillingFeeScheduleRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core7CalculateServiceImpl implements Core7CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParamService feeParamService;
    private final SkTranService skTranService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final KseiSafeService kseiSafeService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingFeeScheduleRepository feeScheduleRepository;
    private final BillingCoreGeneralService billingCoreGeneralService;

    @Override
    public String calculate(CoreCalculateRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // get previous month and year
            String[][] previousMonthsAndYears = ConvertDateUtil.getPreviousMonthsAndYears(monthName, year);

            // Initialization variable
            BigDecimal safekeepingAmountDue;
            BigDecimal subTotal;
            BigDecimal vatAmountDue;
            BigDecimal kseiSafeFeeAmountDue;
            Integer kseiTransactionValueFrequency;
            BigDecimal kseiTransactionAmountDue;
            BigDecimal totalAmountDue;
            Instant dateNow = Instant.now();

            List<List<SkTransaction>> skTransactionsList = new ArrayList<>();
            List<List<SfValRgMonthly>> sfValRgMonthliesList = new ArrayList<>();
            List<BigDecimal> kseiAmountFeeList = new ArrayList<>();
            List<BillingCore> billingCoreList = new ArrayList<>();

            // Get Fee Parameter
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(VAT.getValue());
            feeParamList.add(KSEI.getValue());

            Map<String, BigDecimal> feeParamMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal vatFee = feeParamMap.get(VAT.getValue());
            BigDecimal kseiTransactionFee = feeParamMap.get(KSEI.getValue());

            // Get Billing Customer
            List<BillingCustomerDTO> billingCustomerDTOList = billingCustomerService.getByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomerDTO billingCustomerDTO : billingCustomerDTOList) {
                // TODO: Misalnya perulangan pertama kita proses untuk AID 12MUFG, maka data 12MUFG untuk bulan pertama akan dicari semua
                // TODO: Lalu masukkan kedalam List
                String aid = billingCustomerDTO.getCustomerCode();
                String kseiSafeCode = billingCustomerDTO.getKseiSafeCode();

                log.info("[Core Type 7] Aid '{}' and Ksei Safe Code '{}'", aid, kseiSafeCode);

                for (String[] previousMonthsAndYear : previousMonthsAndYears) {
                    String monthInput = previousMonthsAndYear[0];
                    Integer yearInput = Integer.parseInt(previousMonthsAndYear[1]);

                    log.info("Month Input : {}, Year : {}", monthInput, year);
                    // TODO: GetSfValRgMonthly Month [i] and Year [i]
                    List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(aid, monthInput, yearInput);
                    sfValRgMonthliesList.add(sfValRgMonthlyList);

                    // TODO: Get KSEI Safe Fee Month [i] and Year [i]
                    KseiSafekeepingFee kseiSafekeepingFee = kseiSafeService.getByKseiSafeCodeAndMonthAndYear(kseiSafeCode, monthInput, yearInput);
                    kseiAmountFeeList.add(kseiSafekeepingFee.getAmountFee());

                    // TODO: Get SK Transaction Month [i] and Year [i]
                    List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, monthInput, yearInput);
                    skTransactionsList.add(skTransactionList);
                }
            }

            // TODO: calculate Safekeeping Value Frequency and checking with Fee Schedule dari List<List<SfValRgMonthly>>
            safekeepingAmountDue = calculateSafekeepingAmountDue(sfValRgMonthliesList);

            // TODO: calculate Sub total
            subTotal = calculateSubTotal(safekeepingAmountDue);

            // TODO: calculate VAT Amount Due
            vatAmountDue = calculateVATAmountDue(safekeepingAmountDue, vatFee);

            // TODO: calculate semua KSEI Safe Amount Fee dari List<BigDecimal> kseiAmountFeeList
            kseiSafeFeeAmountDue = calculateKseiSafeFeeAmountDue(vatFee, kseiAmountFeeList);

            // TODO: calculate total transaction KSEI dari List<List<SKTransaction>>
            kseiTransactionValueFrequency = calculateKseiTransactionValueFrequency(skTransactionsList);

            // TODO: calculate KSEI safekeeping amount due
            kseiTransactionAmountDue = calculateKseiSafekeepingAmountDue(kseiTransactionValueFrequency, kseiTransactionFee);

            // TODO: calculate Total Amount Due
            totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue, kseiSafeFeeAmountDue, kseiTransactionAmountDue);

            billingCoreGeneralService.checkingExistingBillingCore(monthName, year, "12MUFG", "CORE", "TYPE_7");

            BillingCore billingCore = BillingCore.builder()
                    .createdAt(dateNow)
                    .updatedAt(dateNow)
                    .approvalStatus(ApprovalStatus.Pending)
                    .aid("12MUFG")
                    .month(monthName)
                    .year(year)

                    .billingPeriod(ConvertDateUtil.convertToRange3Months(previousMonthsAndYears))
                    .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                    .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                    .billingCategory("CORE")
                    .billingType("TYPE_7")
                    .billingTemplate("TEMPLATE_2")
                    .investmentManagementName("MUFG Bank, Ltd")
//                    .investmentManagementAddress("2-7-1, Marunouchi, Chiyoda-Ku Tokyo, Japan Attn: Global Commercial Banking Planning Division")

                    .customerMinimumFee(BigDecimal.ZERO)
                    .customerSafekeepingFee(BigDecimal.ZERO)

                    .accountName("MUFG Bank Ltd Tokyo")
                    .accountNumber("3636441234 (IDR)")
                    .costCenter("")
                    .accountBank("PT Bank Danamon Indonesia")
                    .swiftCode("BDINIDJA")
                    .currency(IDR.getValue())

                    .safekeepingAmountDue(safekeepingAmountDue)
                    .subTotal(subTotal)
                    .vatFee(vatFee)
                    .vatAmountDue(vatAmountDue)
                    .kseiSafekeepingAmountDue(kseiSafeFeeAmountDue)
                    .kseiTransactionValueFrequency(kseiTransactionValueFrequency)
                    .kseiTransactionFee(kseiTransactionFee)
                    .kseiTransactionAmountDue(kseiTransactionAmountDue)
                    .totalAmountDue(totalAmountDue)
                    .build();

            billingCoreList.add(billingCore);

            int billingCoreListSize = billingCoreList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingCoreListSize, monthName, year);

            for (int i = 0; i < billingCoreListSize; i++) {
                billingCore = billingCoreList.get(i);
                String number = numberList.get(i);
                billingCore.setBillingNumber(number);
            }

            List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Core type 7 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Core type 7 with a total : " + billingCoreListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 7 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 7 : " + e.getMessage());
        }
    }

    private BigDecimal calculateSafekeepingAmountDue(List<List<SfValRgMonthly>> sfValRgMonthliesList) {
        List<BigDecimal> safekeepingValueFrequencyList = new ArrayList<>();
        List<SfValRgMonthly> rawList = new ArrayList<>();

        for (List<SfValRgMonthly> sfValRgMonthlyList : sfValRgMonthliesList) {
            rawList.addAll(sfValRgMonthlyList);
        }

        List<SfValRgMonthly> sorted = rawList.stream()
                .sorted(Comparator.comparing(SfValRgMonthly::getDate).reversed())
                .collect(Collectors.toList());

        // Grouping by month and year
        Map<String, List<SfValRgMonthly>> groupedByMonthAndYear = new HashMap<>();
        for (SfValRgMonthly sf : sorted) {
            String key = sf.getDate().getYear() + "-" + sf.getDate().getMonthValue(); // Forming key as "YYYY-MM"
            groupedByMonthAndYear.computeIfAbsent(key, k -> new ArrayList<>()).add(sf);
        }

        // Adding the grouped lists to the 'lists' list
        List<List<SfValRgMonthly>> lists = new ArrayList<>(groupedByMonthAndYear.values());

        for (List<SfValRgMonthly> list : lists) {
            List<SfValRgMonthly> latestEntries = list.stream()
                    .filter(entry -> entry.getDate().equals(list.stream()
                            .map(SfValRgMonthly::getDate)
                            .max(Comparator.naturalOrder())
                            .orElse(null)))
                    .collect(Collectors.toList());

            BigDecimal safekeepingValueFrequency = latestEntries.stream()
                    .map(SfValRgMonthly::getMarketValue)
                    .filter(Objects::nonNull)
                    .reduce(BigDecimal.ZERO, BigDecimal::add)
                    .setScale(0, RoundingMode.HALF_UP);

            log.info("Safekeeping Value Frequency : {}", safekeepingValueFrequency);

            // TODO: check with fee schedule
            double value = feeScheduleRepository.checkFeeScheduleAndGetFeeValue(safekeepingValueFrequency);
            BigDecimal bigDecimal = new BigDecimal(value);
            log.info("Big Decimal : {}", bigDecimal);

            // TODO: divide with 12
            BigDecimal divide = bigDecimal.divide(new BigDecimal(12), 0, RoundingMode.HALF_UP);

            safekeepingValueFrequencyList.add(divide);
        }

        // Ini sudah total dalam 3 bulan
        BigDecimal safekeepingValueFrequency3Months = safekeepingValueFrequencyList.stream()
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 7] Safekeeping value frequency 3 months (-PPn) : '{}'", safekeepingValueFrequency3Months);
        return safekeepingValueFrequency3Months;
    }


    private static Integer calculateKseiTransactionValueFrequency(List<List<SkTransaction>> skTransactionsList) {
        List<Integer> kseiTransactionValueFrequency = new ArrayList<>();

        for (List<SkTransaction> skTransactions : skTransactionsList) {
            int size = skTransactions.size();
            kseiTransactionValueFrequency.add(size);
        }

        int sum = kseiTransactionValueFrequency.stream()
                .mapToInt(Integer::intValue)
                .sum();

        log.info("[Core Type 7] Total KSEI transaction frequency '{}'", sum);
        return sum;
    }

    private static BigDecimal calculateKseiSafekeepingAmountDue(Integer kseiTransactionValueFrequency, BigDecimal kseiTransactionFee) {
        BigDecimal kseiSafekeepingAmountDue = new BigDecimal(kseiTransactionValueFrequency)
                .multiply(kseiTransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 7] Ksei safekeeping amount due '{}'", kseiSafekeepingAmountDue);
        return kseiSafekeepingAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal safekeepingAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = safekeepingAmountDue
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 7] VAT amount due '{}'", vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateKseiSafeFeeAmountDue(BigDecimal vatFee, List<BigDecimal> kseiAmountFeeList) {
        BigDecimal kseiSafeFeeAmountDue = kseiAmountFeeList.stream()
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        BigDecimal result = kseiSafeFeeAmountDue.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP);

        BigDecimal add = kseiSafeFeeAmountDue.add(result);

        log.info("[Core Type 7] Ksei Safe fee amount due '{}'", add);
        return add;
    }

    private static BigDecimal calculateSubTotal(BigDecimal safekeepingAmountDue) {
        log.info("[Core Type 7] Sub total '{}'", safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue, BigDecimal kseiSafeFeeAmountDue, BigDecimal kseiTransactionAmountDue) {
        BigDecimal totalAmountDue = subTotal
                .add(vatAmountDue)
                .add(kseiSafeFeeAmountDue)
                .add(kseiTransactionAmountDue).setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 7] Total amount due '{}'", totalAmountDue);
        return totalAmountDue;
    }

}
