package com.services.billingservice.service;

import com.services.billingservice.dto.BillingEmailProcessingDTO;
import com.services.billingservice.dto.BillingReportGeneratorDTO;

import java.util.List;

public interface BillingEmailProcessingService {

    BillingEmailProcessingDTO getByPeriod(String period);

    List<BillingEmailProcessingDTO>getAll();

}
