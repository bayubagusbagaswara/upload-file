package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingReportGeneratorDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingReportGeneratorRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor

public class BillingReportGeneratorServiceImpl implements BillingReportGeneratorService {

    private final BillingReportGeneratorRepository billingReportGeneratorRepository;

    @Override
    public BillingReportGeneratorDTO getById(String id) {
        BillingReportGenerator billingReportGenerator = billingReportGeneratorRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException("data not found"));
        return mapToDTO(billingReportGenerator);
    }

    @Override
    public List<BillingReportGeneratorDTO> getAll() {
        List<BillingReportGenerator>billingReportList = billingReportGeneratorRepository.findAll();

        return mapToDTOList(billingReportList);
    }

    private BillingReportGeneratorDTO mapToDTO(BillingReportGenerator billingReportGenerator){
        return BillingReportGeneratorDTO.builder()
                .customerCode(billingReportGenerator.getCustomerCode())
                .customerName(billingReportGenerator.getCustomerName())
                .type((billingReportGenerator.getType()))
                .fileName(billingReportGenerator.getFileName())
                .filePath(billingReportGenerator.getFilePath())
                .period(billingReportGenerator.getPeriod())
                .status(billingReportGenerator.getStatus())
                .desc(billingReportGenerator.getStatus())
                .build();
    }

    private List<BillingReportGeneratorDTO> mapToDTOList(List<BillingReportGenerator> billingReportGeneratorList){
        return billingReportGeneratorList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
