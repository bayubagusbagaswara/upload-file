package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.Core1GeneratePDFService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core1GeneratePDFServiceImpl implements Core1GeneratePDFService {

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final BillingCoreRepository billingCoreRepository;
    private final BillingCoreGeneratePDFService billingCoreGeneratePDFService;

    @Override
    public List<BillingCore> getAll(String category, String type, String monthName, Integer year) {
        List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
                category, type, monthName, year
        );
        return billingCoreList;
    }

    @Override
    public String generatePDF(CoreCalculateRequest request) {
        try {
            log.info("Start generate PDF Billing Core type 1");
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // TODO: Change Approval Status to Approved
            String approvalStatus = ApprovalStatus.Pending.getStatus();

            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            billingCoreGeneratePDFService.generateAndSavePdfStatements(billingCoreList);
            log.info("Finished generate PDF Billing Core type 1");
            return "Successfully created a PDF file for Billing Core type 1";
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Core type 1 : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Core type 1 : " + e.getMessage());
        }
    }



}
