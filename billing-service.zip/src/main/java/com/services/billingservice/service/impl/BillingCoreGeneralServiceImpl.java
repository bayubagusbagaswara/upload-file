package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.BillingCoreGeneralService;
import com.services.billingservice.service.BillingNumberService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingCoreGeneralServiceImpl implements BillingCoreGeneralService {

    private final BillingCoreRepository billingCoreRepository;
    private final BillingNumberService billingNumberService;

    @Override
    public void checkingExistingBillingCore(String monthName, Integer year, String aid, String billingCategory, String billingType) {

        List<BillingCore> existingBillingCores = billingCoreRepository.findByAidAndBillingCategoryAndBillingTypeAndMonthAndYear(aid, billingCategory, billingType, monthName, year);

        for (BillingCore existingBillingCore : existingBillingCores) {
            String billingNumber = existingBillingCore.getBillingNumber();
            billingCoreRepository.delete(existingBillingCore);
            billingNumberService.deleteByBillingNumber(billingNumber);
        }
    }

    @Override
    public String deleteAll() {
        try {
            billingCoreRepository.deleteAll();
            return "Successfully deleted all Billing Core";
        } catch (Exception e) {
            log.error("Error when delete all Billing Core : " + e.getMessage(), e);
            throw new RuntimeException("Error when delete all Billing Core");
        }
    }

    @Override
    public List<BillingCore> getAll(String categoryUpperCase, String typeUpperCase, String monthName, Integer year) {
        return billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(
                categoryUpperCase, typeUpperCase, monthName, year
        );
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingCore billingCore : billingCoreList) {
                billingCoreRepository.delete(billingCore);
            }

            return "Successfully delete Billing Core with total : " + billingCoreList.size();
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when delete Billing Core : " + e.getMessage());
        }
    }
}
