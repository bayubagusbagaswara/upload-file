package com.services.billingservice.service.impl;

import com.services.billingservice.dto.exchangerate.CreateExchangeRateRequest;
import com.services.billingservice.dto.exchangerate.ExchangeRateDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.ExchangeRate;
import com.services.billingservice.repository.ExchangeRateRepository;
import com.services.billingservice.service.ExchangeRateService;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExchangeRateServiceImpl implements ExchangeRateService {

    private static final DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final ExchangeRateRepository exchangeRateRepository;

    @Override
    public ExchangeRateDTO create(CreateExchangeRateRequest request) {
        String currency = request.getCurrency();
        LocalDate date = ConvertDateUtil.parseDateOrDefault(request.getDate(), formatter);
        BigDecimal value = ConvertBigDecimalUtil.parseBigDecimalOrDefault(request.getValue());

        ExchangeRate exchangeRate = ExchangeRate.builder()
                .date(date)
                .currency(currency)
                .value(value)
                .build();

        return mapToDTO(exchangeRateRepository.save(exchangeRate));
    }

    @Override
    public List<ExchangeRateDTO> getAll() {
        return mapToDTOList(exchangeRateRepository.findAll());
    }

    @Override
    public ExchangeRateDTO getLatestDataByCurrency(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findLatestExchangeRateByCurrency(currency)
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate with currency '" + currency + "' not found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO getLatestData() {
        ExchangeRate exchangeRate = exchangeRateRepository.findLatestExchangeRate()
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate not found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO getByCurrency(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findByCurrency(currency)
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate with currency '" + currency + "' not found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO updateById(String id, CreateExchangeRateRequest request) {
        LocalDate date = ConvertDateUtil.parseDateOrDefault(request.getDate(), formatter);
        BigDecimal value = ConvertBigDecimalUtil.parseBigDecimalOrDefault(request.getValue());

        ExchangeRate exchangeRate = exchangeRateRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

        if (request.getDate() != null) {
            exchangeRate.setDate(date);
        }

        if (request.getValue() != null) {
            exchangeRate.setValue(value);
        }

        ExchangeRate dataSaved = exchangeRateRepository.save(exchangeRate);
        return mapToDTO(dataSaved);
    }

    @Override
    public ExchangeRateDTO getById(String id) {
        ExchangeRate exchangeRate = exchangeRateRepository.findById(Long.valueOf(id))
                .orElseThrow(() ->new DataNotFoundException("Data Not Found"));
        return mapToDTO(exchangeRate);
    }



    private static ExchangeRateDTO mapToDTO(ExchangeRate exchangeRate) {
        return ExchangeRateDTO.builder()
                .id(String.valueOf(exchangeRate.getId()))
                .date(String.valueOf(exchangeRate.getDate()))
                .currency(exchangeRate.getCurrency())
                .value(String.valueOf(exchangeRate.getValue()))
                .build();
    }

    private static List<ExchangeRateDTO> mapToDTOList(List<ExchangeRate> exchangeRateList) {
        return exchangeRateList.stream()
                .map(ExchangeRateServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

}
