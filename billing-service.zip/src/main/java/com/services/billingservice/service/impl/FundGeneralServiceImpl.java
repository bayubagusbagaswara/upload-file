package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.UpdateApprovalStatusRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.FundGeneralService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundGeneralServiceImpl implements FundGeneralService {

    private final BillingFundRepository billingFundRepository;

    @Override
    public String updateApprovalStatus(UpdateApprovalStatusRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
            //String approvalStatus = request.getApprovalStatus();
            //String billingStatus = request.getBillingStatus();

            String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            ApprovalStatus approvalStatus;
            BillingStatus billingStatus;

            if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Approved.getStatus())) {
                approvalStatus = ApprovalStatus.Approved;
            } else if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Rejected.getStatus())) {
                approvalStatus = ApprovalStatus.Rejected;
            } else {
                approvalStatus = ApprovalStatus.Pending;
            }

            if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Reviewed.getStatus())) {
                billingStatus = BillingStatus.Reviewed;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Approved.getStatus())) {
                billingStatus = BillingStatus.Approved;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Rejected.getStatus())) {
                billingStatus = BillingStatus.Rejected;
            } else {
                billingStatus = BillingStatus.Generated;
            }

            List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYear(monthName, year);

            for (BillingFund billingFund : billingFundList) {
                billingFund.setApprovalStatus(approvalStatus);
                billingFund.setBillingStatus(billingStatus);
            }

            billingFundRepository.saveAll(billingFundList);

            return "Successfully update approval status '" + approvalStatus + "' and billing status '" + billingStatus;
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when update approval status Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = ConvertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingFund billingFund : billingFundList) {
                billingFundRepository.delete(billingFund);
            }

            return "Successfully delete Billing Fund with total : " + billingFundList.size();
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when delete Billing Fund : " + e.getMessage());
        }
    }

}
