package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingSellingAgentDataDTO;
import com.services.billingservice.dto.request.BillingSellingAgentDataRequest;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingSellingAgentData;
import com.services.billingservice.repository.BillingSellingAgentDataRepository;
import com.services.billingservice.service.BillingSellingAgentDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BillingSellingAgentDataImpl implements BillingSellingAgentDataService {

    private final BillingSellingAgentDataRepository billingSellingAgentDataRepository;

    public BillingSellingAgentDataImpl(BillingSellingAgentDataRepository billingSellingAgentDataRepository) {
        this.billingSellingAgentDataRepository = billingSellingAgentDataRepository;
    }


    @Override
    public BillingSellingAgentDataDTO create(BillingSellingAgentDataRequest request) {

        BillingSellingAgentData billingSellingAgentData = BillingSellingAgentData.builder()
                .billingSellingAgentCode(request.getBillingSellingAgentCode())
                .billingSellingAgentName(request.getBillingSellingAgentName())
                .billingSellingAgentGl(request.getBillingSellingAgentGl())
                .billingSellingAgentGlname(request.getBillingSellingAgentGlname())
                .billingSellingAgentAccount(request.getBillingSellingAgentAccount())
                .billingSellingAgentAccountName(request.getBillingSellingAgentAccountName())
                .billingSellingAgentEmail(request.getBillingSellingAgentEmail())
                .billingSellingAgentAlamat(request.getBillingSellingAgentAlamat())
                .billingSellingAgentDesc(request.getBillingSellingAgentDesc())
                .build();

        BillingSellingAgentData dataSaved = billingSellingAgentDataRepository.save(billingSellingAgentData);


        return mapToDTO(dataSaved);
    }

    @Override
    public BillingSellingAgentDataDTO getByCode(String id) {
        BillingSellingAgentData billingSellingAgentData = billingSellingAgentDataRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));
        return mapToDTO(billingSellingAgentData);
    }

    @Override
    public List<BillingSellingAgentDataDTO> getAll() {
        List<BillingSellingAgentData> billingSellingAgentData = billingSellingAgentDataRepository.findAll();

        return mapToDTOList(billingSellingAgentData);
    }

    @Override
    public BillingSellingAgentDataDTO updateById(String id, BillingSellingAgentDataRequest request) {
        BillingSellingAgentData billingSellingAgentData = billingSellingAgentDataRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

        if (request.getBillingSellingAgentAccount() != null) {
            billingSellingAgentData.setBillingSellingAgentAccount(request.getBillingSellingAgentAccount());
        }

        if (request.getBillingSellingAgentAccountName() != null) {
            billingSellingAgentData.setBillingSellingAgentAccount(request.getBillingSellingAgentAccountName());
        }

        if (request.getBillingSellingAgentGl() != null) {
            billingSellingAgentData.setBillingSellingAgentGl(request.getBillingSellingAgentGl());
        }
        if (request.getBillingSellingAgentGlname() != null) {
            billingSellingAgentData.setBillingSellingAgentGlname(request.getBillingSellingAgentGlname());
        }
        if (request.getBillingSellingAgentEmail() != null) {
            billingSellingAgentData.setBillingSellingAgentEmail(request.getBillingSellingAgentEmail());
        }
        if (request.getBillingSellingAgentAlamat() != null) {
            billingSellingAgentData.setBillingSellingAgentAlamat(request.getBillingSellingAgentAlamat());
        }


        BillingSellingAgentData dataSaved = billingSellingAgentDataRepository.save(billingSellingAgentData);
        return mapToDTO(dataSaved);
    }

    @Override
    public String delete(String id) {
        BillingSellingAgentData billingSellingAgentData = billingSellingAgentDataRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("data not found"));

        billingSellingAgentDataRepository.deleteById(billingSellingAgentData.getId());

        return "Successfully delete Selling Agent with id : " + billingSellingAgentData.getId();
    }


    private BillingSellingAgentDataDTO mapToDTO(BillingSellingAgentData billingSellingAgentData) {
        return BillingSellingAgentDataDTO.builder()
                .id(billingSellingAgentData.getId())
                .billingSellingAgentCode(billingSellingAgentData.getBillingSellingAgentCode())
                .billingSellingAgentName(billingSellingAgentData.getBillingSellingAgentName())
                .billingSellingAgentGl(billingSellingAgentData.getBillingSellingAgentGl())
                .billingSellingAgentGlname(billingSellingAgentData.getBillingSellingAgentGlname())
                .billingSellingAgentAccount(billingSellingAgentData.getBillingSellingAgentAccount())
                .billingSellingAgentAccountName(billingSellingAgentData.getBillingSellingAgentAccountName())
                .billingSellingAgentEmail(billingSellingAgentData.getBillingSellingAgentEmail())
                .billingSellingAgentAlamat(billingSellingAgentData.getBillingSellingAgentAlamat())
                .billingSellingAgentDesc(billingSellingAgentData.getBillingSellingAgentDesc())
                .build();

    }

    private List<BillingSellingAgentDataDTO> mapToDTOList(List<BillingSellingAgentData> billingSellingAgentDataList) {
        return billingSellingAgentDataList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
