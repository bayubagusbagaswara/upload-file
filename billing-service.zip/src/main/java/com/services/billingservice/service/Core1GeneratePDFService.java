package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.model.BillingCore;

import java.util.List;

public interface Core1GeneratePDFService {

    List<BillingCore> getAll(String category, String type, String monthName, Integer year);

    String generatePDF(CoreCalculateRequest request);

}
