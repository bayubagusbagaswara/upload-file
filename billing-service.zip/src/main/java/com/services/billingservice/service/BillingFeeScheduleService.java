package com.services.billingservice.service;

import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.request.BillingFeeParamRequest;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.model.BillingFeeSchedule;

import java.util.List;

public interface BillingFeeScheduleService {

    //single maintenance
    BillingFeeScheduleDTO create(BillingFeeScheduleRequest request);

    BillingFeeScheduleDTO getByCode(String id);
    List<BillingFeeScheduleDTO>getAll();
    BillingFeeScheduleDTO updateById(String id, BillingFeeScheduleRequest request);
    String delete(String id);

}
