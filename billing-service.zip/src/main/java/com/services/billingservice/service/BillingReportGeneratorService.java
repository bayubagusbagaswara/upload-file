package com.services.billingservice.service;

import com.services.billingservice.dto.BillingReportGeneratorDTO;

import java.util.List;

public interface BillingReportGeneratorService {

    BillingReportGeneratorDTO getById(String id);

    List<BillingReportGeneratorDTO>getAll();

}
