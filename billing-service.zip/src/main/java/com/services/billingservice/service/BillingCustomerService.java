package com.services.billingservice.service;

import com.services.billingservice.dto.customer.CreateBillingCustomerRequest;
import com.services.billingservice.dto.request.CreateBillingCustomerUploadRequest;
import com.services.billingservice.dto.customer.BillingCustomerDTO;

import java.util.List;

public interface BillingCustomerService {

    BillingCustomerDTO create(CreateBillingCustomerRequest request);
    BillingCustomerDTO updateByCode(String code, CreateBillingCustomerRequest request);
    BillingCustomerDTO updateById(String id, CreateBillingCustomerRequest request);
    List<BillingCustomerDTO> upload(List<CreateBillingCustomerUploadRequest> request);
    List<BillingCustomerDTO>updateUploadByCustomerCode(List<CreateBillingCustomerUploadRequest> request);
    BillingCustomerDTO getByCode (String code);
    BillingCustomerDTO getById (String id);
    List<BillingCustomerDTO>getAll();

    List<BillingCustomerDTO> getByBillingCategoryAndBillingType(
            String billingCategory,
            String billingType
    );

    List<BillingCustomerDTO> getByBillingCategoryAndBillingTypeAndCurrency(
            String billingCategory,
            String billingType,
            String currency
    );

    String deleteById(String id);

    // String deleteAll();

}
