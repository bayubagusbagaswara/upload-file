package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;

public interface Core2GeneratePDFService {

    String generatePDF(CoreCalculateRequest request);

}
