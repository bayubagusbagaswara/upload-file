package com.services.billingservice.service.impl;

import com.services.billingservice.dto.customer.CreateBillingCustomerRequest;
import com.services.billingservice.dto.request.CreateBillingCustomerUploadRequest;
import com.services.billingservice.dto.customer.BillingCustomerDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.repository.BillingCustomerRepository;
import com.services.billingservice.service.BillingCustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingCustomerServiceImpl implements BillingCustomerService {

    private final BillingCustomerRepository billingCustomerRepository;

    @Override
    public BillingCustomerDTO create(CreateBillingCustomerRequest request) {
        String customerCode = request.getCustomerCode();
        String customerName = request.getCustomerName();
        BigDecimal customerMinimumFee = request.getCustomerMinimumFee().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getCustomerMinimumFee());
        BigDecimal customerSafekeepingFee = request.getCustomerSafekeepingFee().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getCustomerSafekeepingFee());

        String billingCategory = request.getBillingCategory();
        String billingType = request.getBillingType();
        String billingTemplate = request.getBillingTemplate();

        String investmentManagementName = request.getInvestmentManagementName();

        String debitTransfer = request.getDebitTransfer();

        String account = request.getAccount();
        String accountName = request.getAccountName();
        String costCenter = request.getCostCenter();
        String glAccountHasil = request.getGlAccountHasil();

        String npwpNumber = request.getNpwpNumber();
        String npwpName = request.getNpwpName();
        String npwpAddress = request.getNpwpAddress();

        String kseisafeCode = request.getKseiSafeCode();
        String currency = request.getCurrency();
        String sellingAgent = request.getSellingAgent();

        BillingCustomer billingCustomer = BillingCustomer.builder()
                .customerCode(customerCode)
                .customerName(customerName)
                .customerMinimumFee(customerMinimumFee)
                .customerSafekeepingFee(customerSafekeepingFee)
                .billingCategory(billingCategory)
                .billingType(billingType)
                .billingTemplate(billingTemplate)
                .miName(investmentManagementName)
                .miAddressBuilding(request.getInvestmentManagementAddressBuilding())
                .miAddressStreet(request.getInvestmentManagementAddressStreet())
                .miAddressCity(request.getInvestmentManagementAddressCity())
                .miAddressDistrict(request.getInvestmentManagementAddressDistrict())

                .debitTransfer(debitTransfer)
                .accountName(accountName)
                .account(account)
                .costCenter(costCenter)
                .glAccountHasil(glAccountHasil)
                .npwpNumber(npwpNumber)
                .npwpName(npwpName)
                .npwpAddress(npwpAddress)
                .kseiSafeCode(kseisafeCode)
                .currency(currency)
                .sellingAgent(sellingAgent)
                .build();

        BillingCustomer dataSaved = billingCustomerRepository.save(billingCustomer);
        return mapToDTO(dataSaved);
    }

    @Override
    public BillingCustomerDTO updateByCode(String code, CreateBillingCustomerRequest request) {
        BillingCustomer billingCustomer = billingCustomerRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException("Data not found"));

        if (billingCustomer.getAccountName() != null) {
            billingCustomer.setAccountName(request.getAccountName());
        }
        if(billingCustomer.getDebitTransfer() != null){
            billingCustomer.setDebitTransfer(request.getDebitTransfer());
        }
        if(billingCustomer.getGlAccountHasil() != null){
            billingCustomer.setGlAccountHasil(request.getGlAccountHasil());
        }


        if(billingCustomer.getMiAddressBuilding() != null){
            billingCustomer.setMiAddressBuilding(request.getInvestmentManagementAddressBuilding());
        }

        if(billingCustomer.getNpwpNumber() != null){
            billingCustomer.setNpwpNumber(request.getNpwpNumber());
        }

        return mapToDTO(billingCustomerRepository.save(billingCustomer));
    }

    @Override
    public BillingCustomerDTO updateById(String id, CreateBillingCustomerRequest request) {
        BillingCustomer billingCustomer = billingCustomerRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data not found"));

        if (billingCustomer.getAccountName() != null) {
            billingCustomer.setAccountName(request.getAccountName());
        }

        if (billingCustomer.getDebitTransfer() != null){
            billingCustomer.setDebitTransfer(request.getDebitTransfer());
        }

        if (billingCustomer.getGlAccountHasil() != null){
            billingCustomer.setGlAccountHasil(request.getGlAccountHasil());
        }

        if (billingCustomer.getMiAddressBuilding() != null){
            billingCustomer.setMiAddressBuilding(request.getInvestmentManagementAddressBuilding());
        }

        if (billingCustomer.getNpwpNumber() != null){
            billingCustomer.setNpwpNumber(request.getNpwpNumber());
        }

        return mapToDTO(billingCustomerRepository.save(billingCustomer));
    }

    @Override
    public List<BillingCustomerDTO> upload(List<CreateBillingCustomerUploadRequest> request) {
        List<BillingCustomer> billingCustomerList = billingCustomerRepository.saveAll(mapToModelListUpload(request));
        return mapToDTOList(billingCustomerList);
    }

    @Override
    public List<BillingCustomerDTO> updateUploadByCustomerCode(List<CreateBillingCustomerUploadRequest> request) {
        // code 1, 2, 3, 4, 5
        // checking request is null
        List<BillingCustomer> customerList = new ArrayList<>();

        if (0 == request.size()) {
            // request is null
        } else {
            for (CreateBillingCustomerUploadRequest billingCustomerRequest : request) {
                // lakukan update
                BillingCustomer billingCustomer = billingCustomerRepository.findByCode(billingCustomerRequest.getCustomerCode())
                        .orElseThrow(() -> new DataNotFoundException("Data not found"));

                if (billingCustomer.getAccountName() != null) {
                    billingCustomer.setAccountName(billingCustomerRequest.getAccountName());
                }
                if(billingCustomer.getDebitTransfer() != null){
                    billingCustomer.setDebitTransfer(billingCustomerRequest.getDebitTransfer());
                }
                if(billingCustomer.getGlAccountHasil() != null){
                    billingCustomer.setGlAccountHasil(billingCustomerRequest.getGlAccountHasil());
                }


                if(billingCustomer.getMiAddressBuilding() != null){
                    billingCustomer.setMiAddressBuilding(billingCustomerRequest.getMiAddressBuilding());
                }

                if(billingCustomer.getNpwpNumber() != null){
                    billingCustomer.setNpwpAddress(billingCustomerRequest.getNpwpNumber());
                }


                // save to database
                BillingCustomer save = billingCustomerRepository.save(billingCustomer);

                customerList.add(save);
            }
        }
        return mapToDTOList(customerList);
    }

    @Override
    public BillingCustomerDTO getById(String id) {
        BillingCustomer billingCustomer = billingCustomerRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));
        return mapToDTO(billingCustomer);
    }

    @Override
    public BillingCustomerDTO getByCode(String code) {
        BillingCustomer billingCustomer = billingCustomerRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));
        return mapToDTO(billingCustomer);
    }

    @Override
    public List<BillingCustomerDTO> getAll() {
        List<BillingCustomer> billingCustomers = billingCustomerRepository.findAll();

        return mapToDTOList(billingCustomers);
    }

    @Override
    public List<BillingCustomerDTO> getByBillingCategoryAndBillingType(String billingCategory, String billingType) {
        log.info("Start get all Billing Customer by billing category '{}' and billing type '{}'", billingCategory, billingType);
        List<BillingCustomer> customerList = billingCustomerRepository.findAllByBillingCategoryAndBillingType(billingCategory, billingType);
        return mapToDTOList(customerList);
    }

    @Override
    public List<BillingCustomerDTO> getByBillingCategoryAndBillingTypeAndCurrency(String billingCategory, String billingType, String currency) {
        log.info("Start get all Billing Customer by billing category '{}', billing type '{}' and currency '{}'", billingCategory, billingType, currency);
        List<BillingCustomer> billingCustomerList = billingCustomerRepository.findAllByBillingCategoryAndBillingTypeAndCurrency(billingCategory, billingType, currency);
        return mapToDTOList(billingCustomerList);
    }

    //    @Override
//    public String deleteAll() {
//        try {
//            billingCustomerRepository.deleteAll();
//            return "Successfully delete all Billing Customer";
//        } catch (Exception e) {
//            log.error("Error when delete all Billing Customer : " + e.getMessage(), e);
//            throw new ConnectionDatabaseException("Error when delete all Billing Customer : " + e.getMessage());
//        }
//    }


    @Override
    public String deleteById(String id) {
        BillingCustomer billingCustomer = billingCustomerRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Billing Customer with id '" + id + "' is not found"));
        billingCustomerRepository.delete(billingCustomer);
        return "Successfully delete billing customer by id : " + id;
    }

    private static BillingCustomerDTO mapToDTO(BillingCustomer customer) {
        return BillingCustomerDTO.builder()
                .id(String.valueOf(customer.getId()))
                .customerCode(customer.getCustomerCode())
                .customerName(customer.getCustomerName())
                .customerMinimumFee(customer.getCustomerMinimumFee())
                .customerSafekeepingFee(customer.getCustomerSafekeepingFee())
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())

                .investmentManagementName(customer.getMiName())
                .investmentManagementAddressBuilding(customer.getMiAddressBuilding())
                .investmentManagementAddressStreet(customer.getMiAddressStreet())
                .investmentManagementAddressDistrict(customer.getMiAddressDistrict())
                .investmentManagementAddressCity(customer.getMiAddressCity())

                .debitTransfer(customer.getDebitTransfer())
                .accountName(customer.getAccountName())
                .account(customer.getAccount())
                .costCenter(customer.getCostCenter())
                .glAccountHasil(customer.getGlAccountHasil())

                .npwpNumber(customer.getNpwpNumber())
                .npwpName(customer.getNpwpName())
                .npwpAddress(customer.getNpwpAddress())
                .kseiSafeCode(customer.getKseiSafeCode())
                .currency(customer.getCurrency())
                .sellingAgent(customer.getSellingAgent())

                .build(); }

    private static List<BillingCustomerDTO> mapToDTOList(List<BillingCustomer> customerList) {
        return customerList.stream()
                .map(BillingCustomerServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

    private static BillingCustomer mapToModel(CreateBillingCustomerRequest request) {
        return BillingCustomer.builder()
                .customerCode(request.getCustomerCode())
                .customerName(request.getCustomerName())
                .billingCategory(request.getBillingCategory())
                .billingType(request.getBillingType())
                .miName(request.getInvestmentManagementName())
                .miAddressBuilding(request.getInvestmentManagementAddressBuilding())
                .miAddressStreet(request.getInvestmentManagementAddressStreet())
                .miAddressDistrict(request.getInvestmentManagementAddressDistrict())
                .miAddressCity(request.getInvestmentManagementAddressCity())
                .debitTransfer(request.getDebitTransfer())
                .account(request.getAccount())
                .accountName(request.getAccountName())
                .costCenter(request.getCostCenter())
                .glAccountHasil(request.getGlAccountHasil())
                .npwpNumber(request.getNpwpNumber())
                .npwpName(request.getNpwpName())
                .npwpAddress(request.getNpwpAddress())
                .kseiSafeCode(request.getKseiSafeCode())
                .currency(request.getCurrency())
                .sellingAgent(request.getSellingAgent())
                .build();
    }

    private static BillingCustomer mapToModelUpload(CreateBillingCustomerUploadRequest request) {
        return BillingCustomer.builder()
                .customerCode(request.getCustomerCode())
                .customerName(request.getCustomerName())
                .billingCategory(request.getBillingCategory())
                .billingType(request.getBillingType())
                .miName(request.getMiName())
                .miAddressBuilding(request.getMiAddressBuilding())
                .miAddressStreet(request.getMiAddressStreet())
                .miAddressDistrict(request.getMiAddressDistrict())
                .miAddressCity(request.getMiAddressCity())
                .debitTransfer(request.getDebitTransfer())
                .account(request.getAccount())
                .accountName(request.getAccountName())
                .costCenter(request.getCostCenter())
                .glAccountHasil(request.getGlAccountHasil())
                .npwpNumber(request.getNpwpNumber())
                .npwpName(request.getNpwpName())
                .npwpAddress(request.getNpwpAddress())
                .kseiSafeCode(request.getKseiSafeCode())
                .currency(request.getCurrency())
                .sellingAgent(request.getSellingAgent())
                .build();
    }

    private static List<BillingCustomer> mapToModelList(List<CreateBillingCustomerRequest> requests) {
        return requests.stream()
                .map(BillingCustomerServiceImpl::mapToModel)
                .collect(Collectors.toList());
    }

    private static List<BillingCustomer> mapToModelListUpload(List<CreateBillingCustomerUploadRequest> requests) {
        return requests.stream()
                .map(BillingCustomerServiceImpl::mapToModelUpload)
                .collect(Collectors.toList());
    }


}
