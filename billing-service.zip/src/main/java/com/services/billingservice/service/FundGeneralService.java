package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.UpdateApprovalStatusRequest;

public interface FundGeneralService {

    String updateApprovalStatus(UpdateApprovalStatusRequest request);

    String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request);
}
