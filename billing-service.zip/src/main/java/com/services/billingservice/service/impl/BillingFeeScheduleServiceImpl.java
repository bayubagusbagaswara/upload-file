package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingFeeScheduleDTO;
import com.services.billingservice.dto.request.BillingFeeScheduleRequest;
import com.services.billingservice.dto.request.CreateNasabahTransferAssetRequest;
import com.services.billingservice.dto.request.UpdateNasabahTransferAssetRequest;
import com.services.billingservice.dto.response.NasabahTransferAssetDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingFeeSchedule;
import com.services.billingservice.model.BillingNasabahTransferAsset;
import com.services.billingservice.repository.BillingFeeScheduleRepository;
import com.services.billingservice.repository.BillingNasabahTransferAssetRepository;
import com.services.billingservice.service.BillingFeeScheduleService;
import com.services.billingservice.service.BillingNasabahTransferAssetService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BillingFeeScheduleServiceImpl implements BillingFeeScheduleService {

    private final BillingFeeScheduleRepository billingFeeScheduleRepository;

    public BillingFeeScheduleServiceImpl(BillingFeeScheduleRepository billingFeeScheduleRepository) {
        this.billingFeeScheduleRepository = billingFeeScheduleRepository;
    }

    @Override
    public BillingFeeScheduleDTO create(BillingFeeScheduleRequest request) {

        BillingFeeSchedule billingFeeSchedule = BillingFeeSchedule.builder()
                .feeMin(request.getFeeMin())
                .feeMax(request.getFeeMax())
                .feeAmount(request.getFeeAmount())
                .build();

        BillingFeeSchedule dataSaved = billingFeeScheduleRepository.save(billingFeeSchedule);


        return mapToDTO(dataSaved);
    }

    @Override
    public BillingFeeScheduleDTO getByCode(String id) {
        BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));
        return mapToDTO(billingFeeSchedule);
    }

    @Override
    public List<BillingFeeScheduleDTO> getAll() {
        List<BillingFeeSchedule> billingFeeSchedules = billingFeeScheduleRepository.findAll();

        return mapToDTOList(billingFeeSchedules);
    }

    @Override
    public BillingFeeScheduleDTO updateById(String id, BillingFeeScheduleRequest request) {
        BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

        if (request.getFeeAmount() != null) {
            billingFeeSchedule.setFeeAmount(request.getFeeAmount());
        }

        if (request.getFeeMax() != null) {
            billingFeeSchedule.setFeeMax(request.getFeeMax());
        }

        if (request.getFeeMin() != null) {
            billingFeeSchedule.setFeeMin(request.getFeeMin());
        }


        BillingFeeSchedule dataSaved = billingFeeScheduleRepository.save(billingFeeSchedule);
        return mapToDTO(dataSaved);
    }

    @Override
    public String delete(String id) {
        BillingFeeSchedule billingFeeSchedule = billingFeeScheduleRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("data not found"));

        billingFeeScheduleRepository.deleteById(billingFeeSchedule.getId());

        return "Successfully delete nasabah transfer asset with id : " + billingFeeSchedule.getId();
    }


    private BillingFeeScheduleDTO mapToDTO(BillingFeeSchedule billingFeeSchedule) {
        return BillingFeeScheduleDTO.builder()
                .id(String.valueOf(billingFeeSchedule.getId()))
                .feeMin(billingFeeSchedule.getFeeMin())
                .feeMax(billingFeeSchedule.getFeeMax())
                .amount(billingFeeSchedule.getFeeAmount())
                .build();

    }

    private List<BillingFeeScheduleDTO> mapToDTOList(List<BillingFeeSchedule> billingFeeScheduleList) {
        return billingFeeScheduleList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
