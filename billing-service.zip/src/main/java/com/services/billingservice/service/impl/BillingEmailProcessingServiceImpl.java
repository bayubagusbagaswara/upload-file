package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingEmailProcessingDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingEmailProcessing;
import com.services.billingservice.repository.BillingEmailProcessingRepository;
import com.services.billingservice.service.BillingEmailProcessingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor

public class BillingEmailProcessingServiceImpl implements BillingEmailProcessingService {

    private final BillingEmailProcessingRepository billingEmailProcessingRepository;

    @Override
    public BillingEmailProcessingDTO getByPeriod(String in) {
        BillingEmailProcessing billingEmailPocessing = billingEmailProcessingRepository.findByPeriod(in)
                .orElseThrow(() -> new DataNotFoundException("data not found"));
        return mapToDTO(billingEmailPocessing);
    }

    @Override
    public List<BillingEmailProcessingDTO> getAll() {
        List<BillingEmailProcessing> billingReportList = billingEmailProcessingRepository.findAll();

        return mapToDTOList(billingReportList);
    }

    private BillingEmailProcessingDTO mapToDTO(BillingEmailProcessing billingEmailPocessing) {
        return BillingEmailProcessingDTO.builder()
                .customerCode(billingEmailPocessing.getCustomerCode())
                .customerName(billingEmailPocessing.getCustomerName())
                .customerEmail(billingEmailPocessing.getCustomerEmail())
                .period(billingEmailPocessing.getPeriod())
                .emailStatus(billingEmailPocessing.getEmailStatus())
                .sentAt(billingEmailPocessing.getSentAt())
                .desc(billingEmailPocessing.getDesc())
                .build();
    }

    private List<BillingEmailProcessingDTO> mapToDTOList(List<BillingEmailProcessing> billingEmailPocessingList) {
        return billingEmailPocessingList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }


}
