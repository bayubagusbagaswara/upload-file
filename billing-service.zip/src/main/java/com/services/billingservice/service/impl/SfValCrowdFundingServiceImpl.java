package com.services.billingservice.service.impl;

import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.exception.ExcelProcessingException;
import com.services.billingservice.exception.ReadExcelException;
import com.services.billingservice.exception.UnexpectedException;
import com.services.billingservice.model.SfValCrowdFunding;
import com.services.billingservice.repository.SfValCrowdFundingRepository;
import com.services.billingservice.service.SfValCrowdFundingService;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class SfValCrowdFundingServiceImpl implements SfValCrowdFundingService {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final SfValCrowdFundingRepository sfValCrowdFundingRepository;

    @Override
    public String readAndInsertToDB(String filePath) {
        log.info("File Path: {}", filePath);

        if (StringUtils.isBlank(filePath)) {
            throw new IllegalArgumentException("File path cannot be null or empty");
        }

        List<SfValCrowdFunding> sfValCrowdFundingList = new ArrayList<>();

        try (Workbook workbook = WorkbookFactory.create(new FileInputStream(filePath))) {
            processSheets(workbook, sfValCrowdFundingList);
            sfValCrowdFundingRepository.saveAll(sfValCrowdFundingList);
            return "Excel data processed and saved successfully";
        } catch (IOException e) {
            log.error("Error reading the Excel file: " + e.getMessage(), e);
            throw new ReadExcelException("Failed to process Excel file. Error reading the Excel file: " + e.getMessage());
        } catch (Exception e) {
            log.error("An unexpected error occurred: " + e.getMessage(), e);
            throw new UnexpectedException("Failed to process Excel file. An unexpected error occurred: " + e.getMessage());
        }
    }

    @Override
    public List<SfValCrowdFunding> getAll() {
        return sfValCrowdFundingRepository.findAll();
    }

    @Override
    public List<SfValCrowdFunding> getAllByClientCode(String clientCode) {
        return sfValCrowdFundingRepository.findAllByClientCode(clientCode);
    }

    @Override
    public List<SfValCrowdFunding> getAllByClientCodeAndMonthAndYear(String clientCode, String monthName, Integer year) {
        return sfValCrowdFundingRepository.findAllByClientCodeAndMonthAndYear(clientCode, monthName, year);
    }

    @Override
    public String deleteAll() {
        try {
            sfValCrowdFundingRepository.deleteAll();
            return "Successfully deleted all SfVal Crowd Funding";
        } catch (Exception e) {
            log.error("Error when delete all SfVal : " + e.getMessage(), e);
            throw new ConnectionDatabaseException("Error when delete all SfVal Crowd Funding : " + e.getMessage());
        }
    }

    private static void processSheets(Workbook workbook, List<SfValCrowdFunding> sfValCrowdFundingList) {
        Iterator<Sheet> sheetIterator = workbook.sheetIterator();

        while (sheetIterator.hasNext()) {
            Sheet sheet = sheetIterator.next();
            processRows(sheet, sfValCrowdFundingList);
        }
    }

    private static void processRows(Sheet sheet, List<SfValCrowdFunding> sfValCrowdFundingList) {
        Iterator<Row> rowIterator = sheet.rowIterator();

        while (rowIterator.hasNext()) {
            try {
                Row row = rowIterator.next();
                SfValCrowdFunding sfValCrowdFunding = createEntityFromRow(row);
                sfValCrowdFundingList.add(sfValCrowdFunding);
            } catch (Exception e) {
                log.error("[SfVal Crowd Funding] Error processing a row: {}", e.getMessage());
                throw new ExcelProcessingException("[SfVal Crowd Funding] Failed to process Excel file: " + e.getMessage(), e);
            }
        }
    }

    private static SfValCrowdFunding createEntityFromRow(Row row) {
        SfValCrowdFunding sfValCrowdFunding = new SfValCrowdFunding();

        // Number
        Cell cell0 = row.getCell(0);
        sfValCrowdFunding.setNumber(Integer.parseInt(cell0.toString()));

        // Settlement Date (Format tanggal dari file adalah 31/01/2024)
        Cell cell1 = row.getCell(1);

        LocalDate date = ConvertDateUtil.parseDateOrDefault(cell1.toString(), dateTimeFormatter);
        Integer year = date != null ? date.getYear() : null;
        String monthName = date != null ? date.getMonth().getDisplayName(TextStyle.FULL, ConvertDateUtil.getLocaleEN()) : "";

        // setSettlementDate
        sfValCrowdFunding.setSettlementDate(date);
        log.info("Settlement Date : {}");

        // setMonth
        log.info("Month Name : {}");
        sfValCrowdFunding.setMonth(monthName);

        // setYear
        log.info("Year : {}");
        sfValCrowdFunding.setYear(year);

        // Client Code
        Cell cell2 = row.getCell(2);
        log.info("Client Code : {}");
        sfValCrowdFunding.setClientCode(cell2.toString());

        // Security Code
        Cell cell3 = row.getCell(3);
        log.info("Security Code : {}");
        sfValCrowdFunding.setSecurityCode(cell3.toString());

        // Holding (Face Value)
        Cell cell4 = row.getCell(4);
        log.info("Face Value : {}");
        sfValCrowdFunding.setFaceValue(ConvertBigDecimalUtil.parseBigDecimalOrDefault(cell4.toString()));

        // Market Price
        Cell cell5 = row.getCell(5);
        log.info("Market Price : {}");
        sfValCrowdFunding.setMarketPrice(cell5.toString());

        // Market Value
        Cell cell6 = row.getCell(6);
        log.info("Market Value : {}");
        sfValCrowdFunding.setMarketValue(ConvertBigDecimalUtil.parseBigDecimalOrDefault(cell6.toString()));

        // Investor
        Cell cell8 = row.getCell(8);
        log.info("Investor : {}");
        sfValCrowdFunding.setInvestor(cell8.toString());

        return sfValCrowdFunding;
    }
}
