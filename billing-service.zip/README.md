# Billing Service


- Bagaimana penanda customer untuk menentukan bahwa customer ini adalah Fund, Core, atau Retail
- Jika termasuk customer Core, maka perlu penanda juga untuk type berapa

# Read File Excel

- membaca file excel KSEI Fee
- Ambil hanya beberapa kolom / cell


```json

[
  {
    "id": "1",
    "product": "FR001",
    "date": "2023-11-29"
  },
  {
    "id": "2",
    "product": "FR002",
    "date": "2023-11-29"
   },
   {
    "id": "3",
    "product": "FR001",
    "date": "2023-11-30"
   },
   {
    "id": "4",
    "product": "FR002",
    "date": "2023-11-30"
   }
]

```

## Generate Billing Core
- Trigger dari depan hanya mengirim type "Core" dan period "Nov 2023"
- Jadi di belakang, harusnya akan men-generate semua customer tipe core (type 1 - 11)

# Format File Billing

- Customer Code"_"Jenis (Fund/Retail/Core)"_"periode (mmyyyy)
- Customer Code adalah AID

# Account
- Format = GL 812017.0000 CC 0706
- 812017 from field Account
- 0706 from field Cost Center