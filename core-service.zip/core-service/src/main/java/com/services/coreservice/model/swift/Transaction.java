package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SendingSwiftEnum;
import com.services.coreservice.enums.SettlementStatusEnum;
import com.services.coreservice.enums.TransactionType;
import com.services.coreservice.model.base.Approvable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_transactions")
public class Transaction extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "contract_number", nullable = false)
    private String contractNumber;

    @Column(name = "trade_id")
    private String tradeId;

    @Column(name = "customer")
    private String customer;

    @Column(name = "trade_date")
    private LocalDate tradeDate;

    @Column(name = "settlement_date")
    private LocalDate settlementDate;

    @Column(name = "mature_date")
    private LocalDate matureDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type")
    private TransactionType transactionType;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "isin_code")
    private String isinCode;

    @Column(name = "currency")
    private String currency;

    @Column(name = "notional")
    private BigDecimal notional;

    @Column(name = "price")
    private BigDecimal price;

    @Column(name = "proceeds")
    private BigDecimal proceeds;

    @Column(name = "clean_price")
    private BigDecimal cleanPrice;

    @Column(name = "trader")
    private String trader;

    @Column(name = "book")
    private String book;

    @Column(name = "euroclear_code")
    private String euroclearCode;

    @Column(name = "bic_code_bdi")
    private String bicCodeBdi;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_outgoing", referencedColumnName = "id")
    private Outgoing idOutgoing;

    @Column(name = "status_ack_nack")
    private String statusAckNack; //ACK or NACK

    @Enumerated(EnumType.STRING)
    @Column(name = "sending_swift")
    private SendingSwiftEnum sendingSwift;

    //Fill after incoming come
    @Enumerated(EnumType.STRING)
    @Column(name = "settlement_status")
    private SettlementStatusEnum settleStatus;

    //Fill after incoming come
    @Column(name = "settled_amount")
    private BigDecimal settledAmount;

    //Fill after incoming come
    @Column(name = "unsettle_reason")
    private String unsettleReason;
}
