package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SwiftType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_scheduler_report")
public class SchedulerReport {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "generator_id")
    private String generatorId;

    @Column(name = "generate_date")
    private LocalDateTime generateDate;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_path")
    private String filePath;

    @Lob
    @Column(name = "file_content")
    private String fileContent;

    @Enumerated(EnumType.STRING)
    @Column(name = "swift_type")
    private SwiftType swiftType;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_incoming", referencedColumnName = "id")
    private Incoming idIncoming;

    @Column(name = "description")
    private String description;

    @Column(name = "is_generated")
    private Boolean generated;
}
