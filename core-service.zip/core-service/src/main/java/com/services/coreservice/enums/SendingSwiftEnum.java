package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SendingSwiftEnum {
    PENDING("Pending"),
    SENT("Sent");
    private String status;
}
