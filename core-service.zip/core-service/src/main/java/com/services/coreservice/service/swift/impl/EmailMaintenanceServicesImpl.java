package com.services.coreservice.service.swift.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.coreservice.dto.swift.ErrorMessageDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceApproveRequest;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceResponse;
import com.services.coreservice.dto.swift.emailMaintenance.UpdateEmailMaintenanceRequest;
import com.services.coreservice.exception.DataNotFoundException;
import com.services.coreservice.mapper.swift.EmailMaintenanceMapper;
import com.services.coreservice.model.swift.EmailMaintenance;
import com.services.coreservice.repository.swift.EmailMaintenanceRepository;
import com.services.coreservice.service.swift.DataChangeServices;
import com.services.coreservice.service.swift.EmailMaintenanceServices;
import com.services.coreservice.utils.BeanUtil;
import com.services.coreservice.utils.ConvertDateUtil;
import com.services.coreservice.utils.JsonUtil;
import com.services.coreservice.utils.ValidateValidatorUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class EmailMaintenanceServicesImpl implements EmailMaintenanceServices {
    @Autowired
    private EmailMaintenanceRepository emailMaintenanceRepository;
    @Autowired
    private DataChangeServices dataChangeServices;
    @Autowired
    private EmailMaintenanceMapper emailMaintenanceMapper;
    @Autowired
    private ValidateValidatorUtil<EmailMaintenanceDTO> validateValidatorUtil;
    @Autowired
    private ConvertDateUtil convertDateUtil;

    private ObjectMapper objectMapper = new ObjectMapper();
    private static final String UNKNOWN = "unknown";
    private static final String ID_NOT_FOUND = "EmailMaintenance not found with id: ";
    private static final String CODE_NOT_FOUND = "EmailMaintenance not found with code: ";

    @Override
    public EmailMaintenanceResponse updateSingleData(UpdateEmailMaintenanceRequest request, DataChangeDTO dataChangeDTO) {
        log.info("Update single data emailMaintenance with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EmailMaintenanceDTO clonedDTO = null;

        try {
            /* maps request data to dto */
            EmailMaintenanceDTO dto = emailMaintenanceMapper.mapUpdateRequestToDto(request);
            log.info("[Update Single] EmailMaintenance dto: {}", dto);

            /* clone dto */
            clonedDTO = new EmailMaintenanceDTO();
            BeanUtil.copyAllProperties(dto, clonedDTO);
            log.info("[Update Single] Result mapping request to dto: {}", dto);

            /* get emailMaintenance by id */
            EmailMaintenance existingData = emailMaintenanceRepository.findById(dto.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + dto.getId()));

            /* validation for each dto field */
            Errors errors = validateValidatorUtil.validateUsingValidator(clonedDTO, "EmailMaintenanceDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets inputId to a DataChange object */
            dataChangeDTO.setInputerId(request.getInputerId());
            dataChangeDTO.setInputDate(convertDateUtil.getDate());

            /* check the number of content of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                EmailMaintenanceDTO dtoForJsonDataBefore = emailMaintenanceMapper.mapToDto(existingData);
                log.info("DTO for Json Data Before: {}", dtoForJsonDataBefore);
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dtoForJsonDataBefore)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeDTO.setEntityId(existingData.getId().toString());
                dataChangeServices.createChangeActionEDIT(dataChangeDTO, EmailMaintenance.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EmailMaintenanceResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public EmailMaintenanceResponse updateSingleApprove(EmailMaintenanceApproveRequest approveRequest, String clientIP) {
        log.info("Approve when update emailMaintenance with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EmailMaintenanceDTO dataAfterDto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the EmailMaintenance dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());
            EmailMaintenanceDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), EmailMaintenanceDTO.class);
            log.info("[Update Approve] Map data from JsonDataAfter to dto: {}", dto);

            /* get emailMaintenance by id */
            EmailMaintenance existingData = emailMaintenanceRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* map data from dto to entity, to overwrite new data */
            emailMaintenanceMapper.mapObjectsDtoToEntity(dto, existingData);
            log.info("[Update Approve] Map object dto to entity: {}", existingData);

            /* map from entity to dto */
            dataAfterDto = emailMaintenanceMapper.mapToDto(existingData);
            log.info("[Update Approve] Map from entity to dto: {}", dataAfterDto);

            /* check validation each column dto */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto,"EmailMaintenanceDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets approveId, approveIPAddress, and entityId to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setEntityId(existingData.getId().toString());

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dataAfterDto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                EmailMaintenance updatedData = emailMaintenanceMapper.updateEntity(existingData, dataChangeDTO);
                EmailMaintenance updatedDataSaved = emailMaintenanceRepository.save(updatedData);
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(emailMaintenanceMapper.mapToDto(updatedDataSaved))));
                dataChangeDTO.setDescription("Successfully approve data change and update emailMaintenance entity with id: " + updatedDataSaved.getId());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dataAfterDto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EmailMaintenanceResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public List<EmailMaintenanceDTO> getAll() {
        List<EmailMaintenance> all = emailMaintenanceRepository.findAll();
        return emailMaintenanceMapper.mapToDTOList(all);
    }

    @Override
    public EmailMaintenanceDTO findById(Long id) {
        EmailMaintenance data = emailMaintenanceRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return emailMaintenanceMapper.mapToDto(data);
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeServices.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change id not found");
            throw new DataNotFoundException("Data Change not found with id: " + dataChangeId);
        }
    }

    private void handleGeneralError(EmailMaintenanceDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(dto != null ? String.valueOf(dto.getId()) : UNKNOWN, validationErrors));
    }

    private static ErrorMessageDTO getErrorMessageDTO(EmailMaintenanceDTO dto, List<String> validationErrors) {
        String string = dto.getId() == null ? UNKNOWN : dto.getId().toString();
        return new ErrorMessageDTO(string, validationErrors);
    }
}
