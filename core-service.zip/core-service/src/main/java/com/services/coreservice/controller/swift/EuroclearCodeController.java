package com.services.coreservice.controller.swift;

import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.euroclear.*;
import com.services.coreservice.service.swift.EuroclearCodeServices;
import com.services.coreservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/euroclearCode")
@RequiredArgsConstructor
public class EuroclearCodeController {
    @Autowired
    private EuroclearCodeServices euroclearCodeServices;


    private static final String URL_EUROCLEAR = "/api/swift/euroclearCode";
    private static final String MENU_EUROCLEAR = "Euroclear";

    @PostMapping("/create")
    public ResponseEntity<ResponseDTO<EuroclearResponse>> create(@RequestBody CreateEuroclearRequest request, HttpServletRequest servletRequest)  {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(URL_EUROCLEAR + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_EUROCLEAR)
                .build();
        EuroclearResponse createResponse = euroclearCodeServices.createSingleData(request, dataChangeDTO);
        ResponseDTO<EuroclearResponse> response = ResponseDTO.<EuroclearResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<EuroclearResponse>> createSingleApprove(@RequestBody EuroclearApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        EuroclearResponse listApprove = euroclearCodeServices.createSingleApprove(request, clientIp);
        ResponseDTO<EuroclearResponse> response = ResponseDTO.<EuroclearResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<EuroclearResponse>> updateSingleData(@RequestBody UpdateEuroclearRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_EUROCLEAR + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_EUROCLEAR)
                .build();
        EuroclearResponse updateResponse = euroclearCodeServices.updateSingleData(request, dataChangeDTO);
        ResponseDTO<EuroclearResponse> response = ResponseDTO.<EuroclearResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<EuroclearResponse>> updateSingleApprove(@RequestBody EuroclearApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        EuroclearResponse updateListResponse = euroclearCodeServices.updateSingleApprove(request, clientIp);
        ResponseDTO<EuroclearResponse> response = ResponseDTO.<EuroclearResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<EuroclearResponse>> deleteSingleData(@RequestBody DeleteEuroclearRequest request) {
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(URL_EUROCLEAR + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_EUROCLEAR)
                .build();
        EuroclearResponse deleteResponse = euroclearCodeServices.deleteSingleData(request, dataChangeDTO);
        ResponseDTO<EuroclearResponse> response = ResponseDTO.<EuroclearResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<EuroclearResponse>> deleteSingleApprove(@RequestBody EuroclearApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        EuroclearResponse deleteResponse = euroclearCodeServices.deleteSingleApprove(request, clientIp);
        ResponseDTO<EuroclearResponse> response = ResponseDTO.<EuroclearResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<EuroclearDTO>>> getAll() {
        List<EuroclearDTO> dtoList = euroclearCodeServices.getAll();
        ResponseDTO<List<EuroclearDTO>> response = ResponseDTO.<List<EuroclearDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDTO<List<EuroclearDTO>>> getByCode(@RequestParam("code") String code) {
        List<EuroclearDTO> data = euroclearCodeServices.findByCode(code);
        ResponseDTO<List<EuroclearDTO>> response = ResponseDTO.<List<EuroclearDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<EuroclearDTO>> getById(@RequestParam("id") Long id) {
        EuroclearDTO data = euroclearCodeServices.findById(id);
        ResponseDTO<EuroclearDTO> response = ResponseDTO.<EuroclearDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }
}
