package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SwiftType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_mt_template")
public class MessageTypeTemplate{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "swift_type", nullable = false)
    private SwiftType swiftType;

    @Column(name = "function_type", nullable = false)
    private String functionType;

    @Column(name = "block_1", nullable = false)
    private String block1;

    @Column(name = "block_2", nullable = false)
    private String block2;

    @Column(name = "block_3")
    private String block3;

    @Column(name = "block_4", columnDefinition = "nvarchar(max)", nullable = false)
    private String block4;

    @Column(name = "block_5")
    private String block5;
}
