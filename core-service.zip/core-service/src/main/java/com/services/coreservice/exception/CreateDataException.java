package com.services.coreservice.exception;

public class CreateDataException extends RuntimeException {

    public CreateDataException() {
        super();
    }

    public CreateDataException(String message) {
        super(message);
    }

    public CreateDataException(String message, Throwable cause) {
        super(message, cause);
    }

}
