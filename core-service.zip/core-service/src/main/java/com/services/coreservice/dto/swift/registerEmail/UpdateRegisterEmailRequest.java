package com.services.coreservice.dto.swift.registerEmail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateRegisterEmailRequest {
    private String inputerId;
    private String inputerIPAddress;
    private Long id;
    private String emailAddress;
    private String reportType;
    private String action;
}
