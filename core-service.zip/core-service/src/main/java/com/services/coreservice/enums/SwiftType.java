package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SwiftType {
	MT540 ("540"),
	MT541 ("541"),
	MT542 ("542"),
	MT543 ("543"),
	MT545 ("545"),
	MT547 ("547"),
	MT548 ("548"),
	MT544 ("544"),
	MT546 ("546"),
	MT564 ("564"),
	MT566 ("566"),
	MT567 ("567"),
	MT568 ("568"),
	MT999 ("999");

	private String value;
}
