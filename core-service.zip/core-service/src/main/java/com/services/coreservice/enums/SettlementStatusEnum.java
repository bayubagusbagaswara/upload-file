package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SettlementStatusEnum {
    SETTLE("Settle"),
    UNSETTLE("Unsettle");

    private String status;
}
