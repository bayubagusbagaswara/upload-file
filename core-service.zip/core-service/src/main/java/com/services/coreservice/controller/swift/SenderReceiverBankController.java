package com.services.coreservice.controller.swift;

import com.services.coreservice.annotation.interfaces.Converting;
import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.senderReceiverBank.*;
import com.services.coreservice.enums.SenderReceiverTypeEnum;
import com.services.coreservice.service.swift.SenderReceiverBankServices;
import com.services.coreservice.utils.ClientIPUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/senderReceiverBank")
public class SenderReceiverBankController {
    @Autowired
    private SenderReceiverBankServices senderReceiverBankServices;

    private static final String URL_BANK_CORESPONDENT = "/api/swift/senderReceiverBank";
    private static final String MENU_BANK_CORESPONDENT = "SenderReceiverBank";

    @PostMapping("/create")
    public ResponseEntity<ResponseDTO<SenderReceiverBankResponse>> create(@Converting @RequestBody CreateSenderReceiverBankRequest request, HttpServletRequest servletRequest)  {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(URL_BANK_CORESPONDENT + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_BANK_CORESPONDENT)
                .build();
        SenderReceiverBankResponse createResponse = senderReceiverBankServices.createSingleData(request, dataChangeDTO);
        ResponseDTO<SenderReceiverBankResponse> response = ResponseDTO.<SenderReceiverBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<SenderReceiverBankResponse>> createSingleApprove(@RequestBody SenderReceiverBankApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        SenderReceiverBankResponse listApprove = senderReceiverBankServices.createSingleApprove(request, clientIp);
        ResponseDTO<SenderReceiverBankResponse> response = ResponseDTO.<SenderReceiverBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<SenderReceiverBankResponse>> updateSingleData(@RequestBody UpdateSenderReceiverBankRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_BANK_CORESPONDENT + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_BANK_CORESPONDENT)
                .build();
        SenderReceiverBankResponse updateResponse = senderReceiverBankServices.updateSingleData(request, dataChangeDTO);
        ResponseDTO<SenderReceiverBankResponse> response = ResponseDTO.<SenderReceiverBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<SenderReceiverBankResponse>> updateSingleApprove(@RequestBody SenderReceiverBankApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        SenderReceiverBankResponse updateListResponse = senderReceiverBankServices.updateSingleApprove(request, clientIp);
        ResponseDTO<SenderReceiverBankResponse> response = ResponseDTO.<SenderReceiverBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<SenderReceiverBankResponse>> deleteSingleData(@RequestBody DeleteSenderReceiverBankRequest request) {
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(URL_BANK_CORESPONDENT + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_BANK_CORESPONDENT)
                .build();
        SenderReceiverBankResponse deleteResponse = senderReceiverBankServices.deleteSingleData(request, dataChangeDTO);
        ResponseDTO<SenderReceiverBankResponse> response = ResponseDTO.<SenderReceiverBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<SenderReceiverBankResponse>> deleteSingleApprove(@RequestBody SenderReceiverBankApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        SenderReceiverBankResponse deleteResponse = senderReceiverBankServices.deleteSingleApprove(request, clientIp);
        ResponseDTO<SenderReceiverBankResponse> response = ResponseDTO.<SenderReceiverBankResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SenderReceiverBankDTO>>> getAll() {
        List<SenderReceiverBankDTO> dtoList = senderReceiverBankServices.getAll();
        ResponseDTO<List<SenderReceiverBankDTO>> response = ResponseDTO.<List<SenderReceiverBankDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all/{type}")
    public ResponseEntity<ResponseDTO<List<SenderReceiverBankDTO>>> getAllSender(@PathVariable(value = "type") String type) {
        List<SenderReceiverBankDTO> dtoList = senderReceiverBankServices.getAllSenderOrReceiver(SenderReceiverTypeEnum.valueOf(type.toUpperCase()).getType());
        ResponseDTO<List<SenderReceiverBankDTO>> response = ResponseDTO.<List<SenderReceiverBankDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDTO<List<SenderReceiverBankDTO>>> getByCode(@RequestParam("code") String code) {
        List<SenderReceiverBankDTO> data = senderReceiverBankServices.findByCode(code);
        ResponseDTO<List<SenderReceiverBankDTO>> response = ResponseDTO.<List<SenderReceiverBankDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<SenderReceiverBankDTO>> getById(@RequestParam("id") Long id) {
        SenderReceiverBankDTO data = senderReceiverBankServices.findById(id);
        ResponseDTO<SenderReceiverBankDTO> response = ResponseDTO.<SenderReceiverBankDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }
}
