package com.services.coreservice.service.swift.impl;

import com.services.coreservice.repository.swift.SchedulerReportRepository;
import com.services.coreservice.service.swift.ReportGeneratedServices;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ReportGeneratedServicesImpl implements ReportGeneratedServices {
    @Autowired
    private SchedulerReportRepository schedulerReportRepository;
}
