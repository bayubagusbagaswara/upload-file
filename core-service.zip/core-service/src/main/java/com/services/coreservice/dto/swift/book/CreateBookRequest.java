package com.services.coreservice.dto.swift.book;

import com.services.coreservice.annotation.interfaces.UpperCase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateBookRequest {
    private String inputerId;
    private String inputerIPAddress;
    @UpperCase
    private String code;
    private String name;
}
