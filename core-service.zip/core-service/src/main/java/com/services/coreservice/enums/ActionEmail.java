package com.services.coreservice.enums;

public enum ActionEmail {
	TO, CC, BCC
}
