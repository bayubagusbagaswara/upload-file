package com.services.coreservice.service.swift.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.coreservice.dto.swift.ErrorMessageDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.senderReceiverBank.*;
import com.services.coreservice.exception.DataNotFoundException;
import com.services.coreservice.mapper.swift.SenderReceiverBankMapper;
import com.services.coreservice.model.swift.DataChange;
import com.services.coreservice.model.swift.SenderReceiverBank;
import com.services.coreservice.repository.swift.SenderReceiverBankRepository;
import com.services.coreservice.service.swift.DataChangeServices;
import com.services.coreservice.service.swift.SenderReceiverBankServices;
import com.services.coreservice.utils.BeanUtil;
import com.services.coreservice.utils.ConvertDateUtil;
import com.services.coreservice.utils.JsonUtil;
import com.services.coreservice.utils.ValidateValidatorUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class SenderReceiverBankServicesImpl implements SenderReceiverBankServices {
    @Autowired
    private SenderReceiverBankRepository senderReceiverBankRepository;
    @Autowired
    private DataChangeServices dataChangeServices;
    @Autowired
    private SenderReceiverBankMapper senderReceiverBankMapper;
    @Autowired
    private ValidateValidatorUtil<SenderReceiverBankDTO> validateValidatorUtil;
    @Autowired
    private ConvertDateUtil convertDateUtil;

    private ObjectMapper objectMapper = new ObjectMapper();
    private static final String UNKNOWN = "unknown";
    private static final String ID_NOT_FOUND = "Sender or Receiver Bank not found with id: ";
    private static final String CODE_NOT_FOUND = "Sender or Receiver Bank not found with code: ";

    @Override
    public SenderReceiverBankResponse createSingleData(CreateSenderReceiverBankRequest request, DataChangeDTO dataChangeDTO) {
        log.info("Create single data Sender or Receiver Bank with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SenderReceiverBankDTO dto = null;

        try {
            /* maps request data to dto */
            dto = senderReceiverBankMapper.mapCreateRequestToDto(request);

            /* validation for each dto field */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto, "SenderReceiverBankDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validation code and sub code already exists */
            validationCodeAlreadyExists(dto.getCode(), dto.getType(), validationErrors);

            /* sets input id to a DataChange object */
            dataChangeDTO.setInputerId(request.getInputerId());
            dataChangeDTO.setInputDate(convertDateUtil.getDate());

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeServices.createChangeActionADD(dataChangeDTO, DataChange.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SenderReceiverBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SenderReceiverBankResponse createSingleApprove(SenderReceiverBankApproveRequest approveRequest, String clientIP) {
        log.info("Approve when create Sender or Receiver Bank with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SenderReceiverBankDTO dto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the Currency dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), SenderReceiverBankDTO.class);

            /* perform data validation if necessary, for example checking whether the code already exists in the database */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto, "SenderReceiverBankDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validation code already exists */
            validationCodeAlreadyExists(dto.getCode(), dto.getType(), validationErrors);

            /* sets approveId and approveIPAddress to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            } else {
                SenderReceiverBank data = senderReceiverBankMapper.createEntity(dto, dataChangeDTO);
                senderReceiverBankRepository.save(data);
                dataChangeDTO.setDescription("Successfully approve data change and save data Sender or Receiver Bank with id: " + data.getId());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(senderReceiverBankMapper.mapToDto(data))));
                dataChangeDTO.setEntityId(data.getId().toString());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SenderReceiverBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SenderReceiverBankResponse updateSingleData(UpdateSenderReceiverBankRequest request, DataChangeDTO dataChangeDTO) {
        log.info("Update single data Sender or Receiver Bank with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SenderReceiverBankDTO clonedDTO = null;

        try {
            /* maps request data to dto */
            SenderReceiverBankDTO dto = senderReceiverBankMapper.mapUpdateRequestToDto(request);
            log.info("[Update Single] Sender or Receiver Bank dto: {}", dto);

            /* clone dto */
            clonedDTO = new SenderReceiverBankDTO();
            BeanUtil.copyAllProperties(dto, clonedDTO);
            log.info("[Update Single] Result mapping request to dto: {}", dto);

            /* get currency by id */
            SenderReceiverBank existingData = senderReceiverBankRepository.findById(dto.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + dto.getId()));

            /* validation for each dto field */
            Errors errors = validateValidatorUtil.validateUsingValidator(clonedDTO, "SenderReceiverBankDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validation code is exists */
            validationCodeIsExists(clonedDTO.getCode(), clonedDTO.getType(), validationErrors);

            /* sets inputId to a DataChange object */
            dataChangeDTO.setInputerId(request.getInputerId());
            dataChangeDTO.setInputDate(convertDateUtil.getDate());

            /* check the number of content of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                SenderReceiverBankDTO dtoForJsonDataBefore = senderReceiverBankMapper.mapToDto(existingData);
                log.info("DTO for Json Data Before: {}", dtoForJsonDataBefore);
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dtoForJsonDataBefore)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeDTO.setEntityId(existingData.getId().toString());
                dataChangeServices.createChangeActionEDIT(dataChangeDTO, SenderReceiverBank.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SenderReceiverBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SenderReceiverBankResponse updateSingleApprove(SenderReceiverBankApproveRequest approveRequest, String clientIP) {
        log.info("Approve when update Sender or Receiver Bank with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SenderReceiverBankDTO dataAfterDto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the Currency dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());
            SenderReceiverBankDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), SenderReceiverBankDTO.class);
            log.info("[Update Approve] Map data from JsonDataAfter to dto: {}", dto);

            /* get currency by id */
            SenderReceiverBank existingData = senderReceiverBankRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* map data from dto to entity, to overwrite new data */
            senderReceiverBankMapper.mapObjectsDtoToEntity(dto, existingData);
            log.info("[Update Approve] Map object dto to entity: {}", existingData);

            /* map from entity to dto */
            dataAfterDto = senderReceiverBankMapper.mapToDto(existingData);
            log.info("[Update Approve] Map from entity to dto: {}", dataAfterDto);

            /* check validation each column dto */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto,"SenderReceiverBankDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validation code is exists */
            validationCodeIsExists(dto.getCode(), dto.getType(), validationErrors);

            /* sets approveId, approveIPAddress, and entityId to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setEntityId(existingData.getId().toString());

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dataAfterDto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                SenderReceiverBank updatedData = senderReceiverBankMapper.updateEntity(existingData, dataChangeDTO);
                SenderReceiverBank updatedDataSaved = senderReceiverBankRepository.save(updatedData);
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(senderReceiverBankMapper.mapToDto(updatedDataSaved))));
                dataChangeDTO.setDescription("Successfully approve data change and update Sender or Receiver Bank entity with id: " + updatedDataSaved.getId());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dataAfterDto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SenderReceiverBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SenderReceiverBankResponse deleteSingleData(DeleteSenderReceiverBankRequest deleteRequest, DataChangeDTO dataChangeDTO) {
        log.info("Delete single Sender or Receiver Bank with request: {}", deleteRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SenderReceiverBankDTO dto = null;

        try {
            /* get currency by id */
            Long id = deleteRequest.getId();
            SenderReceiverBank existingData = senderReceiverBankRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));

            /* maps entity to dto */
            dto = senderReceiverBankMapper.mapToDto(existingData);

            /* set data change */
            dataChangeDTO.setInputerId(deleteRequest.getInputerId());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(senderReceiverBankMapper.mapToDto(existingData))));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(existingData.getId().toString());
            dataChangeServices.createChangeActionDELETE(dataChangeDTO, SenderReceiverBank.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SenderReceiverBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SenderReceiverBankResponse deleteSingleApprove(SenderReceiverBankApproveRequest approveRequest, String clientIP) {
        log.info("Approve when delete Sender or Receiver Bank with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SenderReceiverBankDTO dto = null;

        try {
            /*  validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());

            /* get investment management by id */
            SenderReceiverBank existingData = senderReceiverBankRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* maps from entity to dto */
            dto = senderReceiverBankMapper.mapToDto(existingData);

            /* set data change for approve id and approve ip address */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(senderReceiverBankMapper.mapToDto(existingData))));
            dataChangeDTO.setDescription("Successfully approve data change and delete Sender or Receiver Bank with id: " + existingData.getId());
            dataChangeServices.approvalStatusIsApproved(dataChangeDTO);

            /* delete data entity in the database */
            senderReceiverBankRepository.delete(existingData);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SenderReceiverBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private void validationCodeAlreadyExists(String code, String type, List<String> validationErrors) {
        if (senderReceiverBankRepository.existsByCodeAndType(code, type)) {
            validationErrors.add("Sender or Receiver Bank already taken with code: " + code);
        }
    }

    private void validationCodeIsExists(String code, String type, List<String> validationErrors) {
        if (!senderReceiverBankRepository.existsByCodeAndType(code, type)) {
            validationErrors.add("Sender or Receiver Bank not exists with code: " + code);
        }
    }

    @Override
    public List<SenderReceiverBankDTO> getAll() {
        List<SenderReceiverBank> all = senderReceiverBankRepository.findAll();
        return senderReceiverBankMapper.mapToDTOList(all);
    }

    @Override
    public List<SenderReceiverBankDTO> getAllSenderOrReceiver(final String type) {
        List<SenderReceiverBank> all = senderReceiverBankRepository.findByTypeOrderByCodeAsc(type);
        return senderReceiverBankMapper.mapToDTOList(all);
    }

    @Override
    public List<SenderReceiverBankDTO> findByCode(String code) {
        List<SenderReceiverBank> data = senderReceiverBankRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + code));
        List<SenderReceiverBankDTO> result = new ArrayList<>();
        data.stream()
                .forEach(f -> result.add(senderReceiverBankMapper.mapToDto(f)));
        return result;
    }

    @Override
    public SenderReceiverBankDTO findById(Long id) {
        SenderReceiverBank data = senderReceiverBankRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return senderReceiverBankMapper.mapToDto(data);
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeServices.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change id not found");
            throw new DataNotFoundException("Data Change not found with id: " + dataChangeId);
        }
    }

    private void handleGeneralError(SenderReceiverBankDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(dto != null ? String.valueOf(dto.getId()) : UNKNOWN, validationErrors));
    }

    private static ErrorMessageDTO getErrorMessageDTO(SenderReceiverBankDTO dto, List<String> validationErrors) {
        String string = dto.getId() == null ? UNKNOWN : dto.getId().toString();
        return new ErrorMessageDTO(string, validationErrors);
    }
}
