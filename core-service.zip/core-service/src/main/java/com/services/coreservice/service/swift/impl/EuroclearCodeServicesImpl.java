package com.services.coreservice.service.swift.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.coreservice.dto.swift.ErrorMessageDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.euroclear.*;
import com.services.coreservice.exception.DataNotFoundException;
import com.services.coreservice.mapper.swift.EuroclearMapper;
import com.services.coreservice.model.swift.DataChange;
import com.services.coreservice.model.swift.EuroclearCode;
import com.services.coreservice.repository.swift.EuroclearCodeRepository;
import com.services.coreservice.service.swift.DataChangeServices;
import com.services.coreservice.service.swift.EuroclearCodeServices;
import com.services.coreservice.utils.BeanUtil;
import com.services.coreservice.utils.ConvertDateUtil;
import com.services.coreservice.utils.JsonUtil;
import com.services.coreservice.utils.ValidateValidatorUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class EuroclearCodeServicesImpl implements EuroclearCodeServices {
    @Autowired
    private EuroclearCodeRepository euroclearCodeRepository;
    @Autowired
    private DataChangeServices dataChangeServices;
    @Autowired
    private EuroclearMapper euroclearMapper;
    @Autowired
    private ValidateValidatorUtil<EuroclearDTO> validateValidatorUtil;
    @Autowired
    private ConvertDateUtil convertDateUtil;

    private ObjectMapper objectMapper = new ObjectMapper();
    private static final String UNKNOWN = "unknown";
    private static final String ID_NOT_FOUND = "Euroclear not found with id: ";
    private static final String CODE_NOT_FOUND = "Euroclear not found with code: ";

    @Override
    public List<EuroclearCode> getByCode(String code) {
        List<EuroclearCode> euroclearCodeList = euroclearCodeRepository.searchByCodeLike(code);
        return euroclearCodeList;
    }

    @Override
    public EuroclearCode getById(Long id) {
        EuroclearCode euroclearCode = euroclearCodeRepository.findById(id).orElseThrow(()-> new DataNotFoundException("Data not found!"));
        return euroclearCode;
    }

    @Override
    public EuroclearResponse createSingleData(CreateEuroclearRequest request, DataChangeDTO dataChangeDTO) {
        log.info("Create single data EUROCLEAR with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EuroclearDTO dto = null;

        try {
            /* maps request data to dto */
            dto = euroclearMapper.mapCreateRequestToDto(request);

            /* validation for each dto field */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto, "EuroclearDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /*checking data exist or not*/
            validationCodeExists(dto.getCode(), validationErrors);

            /* sets input id to a DataChange object */
            dataChangeDTO.setInputerId(request.getInputerId());
            dataChangeDTO.setInputDate(convertDateUtil.getDate());

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeServices.createChangeActionADD(dataChangeDTO, DataChange.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EuroclearResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public EuroclearResponse createSingleApprove(EuroclearApproveRequest approveRequest, String clientIP) {
        log.info("Approve when create EUROCLEAR with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EuroclearDTO dto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the AssetTransferCustomer dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), EuroclearDTO.class);

            /* perform data validation if necessary, for example checking whether the code already exists in the database */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto, "EuroclearDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets approveId and approveIPAddress to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            } else {
                EuroclearCode data = euroclearMapper.createEntity(dto, dataChangeDTO);
                euroclearCodeRepository.save(data);
                dataChangeDTO.setDescription("Successfully approve data change and save data EUROCLEAR with id: " + data.getId());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(euroclearMapper.mapToDto(data))));
                dataChangeDTO.setEntityId(data.getId().toString());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EuroclearResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public EuroclearResponse updateSingleData(UpdateEuroclearRequest request, DataChangeDTO dataChangeDTO) {
        log.info("Update single data EUROCLEAR with request: {}", request);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EuroclearDTO clonedDTO = null;

        try {
            /* maps request data to dto */
            EuroclearDTO dto = euroclearMapper.mapUpdateRequestToDto(request);
            log.info("[Update Single] EUROCLEAR dto: {}", dto);

            /* clone dto */
            clonedDTO = new EuroclearDTO();
            BeanUtil.copyAllProperties(dto, clonedDTO);
            log.info("[Update Single] Result mapping EUROCLEAR request to dto: {}", dto);

            /* get EUROCLEAR by id */
            EuroclearCode existingData = euroclearCodeRepository.findById(dto.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + dto.getId()));

            /* validation for each dto field */
            Errors errors = validateValidatorUtil.validateUsingValidator(clonedDTO, "EuroclearDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets inputId to a DataChange object */
            dataChangeDTO.setInputerId(request.getInputerId());
            dataChangeDTO.setInputDate(convertDateUtil.getDate());

            /* check the number of content of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                EuroclearDTO dtoForJsonDataBefore = euroclearMapper.mapToDto(existingData);
                log.info("DTO for Json Data Before: {}", dtoForJsonDataBefore);
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dtoForJsonDataBefore)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeDTO.setEntityId(existingData.getId().toString());
                dataChangeServices.createChangeActionEDIT(dataChangeDTO, EuroclearCode.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EuroclearResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public EuroclearResponse updateSingleApprove(EuroclearApproveRequest approveRequest, String clientIP) {
        log.info("Approve when update EUROCLEAR with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EuroclearDTO dataAfterDto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the AssetTransferCustomer dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());
            EuroclearDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), EuroclearDTO.class);
            log.info("[Update Approve] Map data from JsonDataAfter to dto: {}", dto);

            /* get euroclear by id */
            EuroclearCode existingData = euroclearCodeRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* map data from dto to entity, to overwrite new data */
            euroclearMapper.mapObjectsDtoToEntity(dto, existingData);
            log.info("[Update Approve] Map object dto to entity: {}", existingData);

            /* map from entity to dto */
            dataAfterDto = euroclearMapper.mapToDto(existingData);
            log.info("[Update Approve] Map from entity to dto: {}", dataAfterDto);

            /* check validation each column dto */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto,"EuroclearDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets approveId, approveIPAddress, and entityId to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setEntityId(existingData.getId().toString());

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dataAfterDto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                EuroclearCode updatedData = euroclearMapper.updateEntity(existingData, dataChangeDTO);
                EuroclearCode updatedDataSaved = euroclearCodeRepository.save(updatedData);
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(euroclearMapper.mapToDto(updatedDataSaved))));
                dataChangeDTO.setDescription("Successfully approve data change and update EUROCLEAR entity with id: " + updatedDataSaved.getId());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dataAfterDto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EuroclearResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public EuroclearResponse deleteSingleData(DeleteEuroclearRequest deleteRequest, DataChangeDTO dataChangeDTO) {
        log.info("Delete single euroclear with request: {}", deleteRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EuroclearDTO dto = null;

        try {
            /* get euroclear by id */
            Long id = deleteRequest.getId();
            EuroclearCode existingData = euroclearCodeRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));

            /* maps entity to dto */
            dto = euroclearMapper.mapToDto(existingData);

            /* set data change */
            dataChangeDTO.setInputerId(deleteRequest.getInputerId());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(euroclearMapper.mapToDto(existingData))));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(existingData.getId().toString());
            dataChangeServices.createChangeActionDELETE(dataChangeDTO, EuroclearCode.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EuroclearResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public EuroclearResponse deleteSingleApprove(EuroclearApproveRequest approveRequest, String clientIP) {
        log.info("Approve when delete euroclear with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        EuroclearDTO dto = null;

        try {
            /*  validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());

            /* get investment management by id */
            EuroclearCode existingData = euroclearCodeRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* maps from entity to dto */
            dto = euroclearMapper.mapToDto(existingData);

            /* set data change for approve id and approve ip address */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(euroclearMapper.mapToDto(existingData))));
            dataChangeDTO.setDescription("Successfully approve data change and delete euroclear with id: " + existingData.getId());
            dataChangeServices.approvalStatusIsApproved(dataChangeDTO);

            /* delete data entity in the database */
            euroclearCodeRepository.delete(existingData);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new EuroclearResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }
    
    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeServices.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change id not found");
            throw new DataNotFoundException("Data Change not found with id: " + dataChangeId);
        }
    }

    private void handleGeneralError(EuroclearDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(dto != null ? String.valueOf(dto.getId()) : UNKNOWN, validationErrors));
    }

    private static ErrorMessageDTO getErrorMessageDTO(EuroclearDTO dto, List<String> validationErrors) {
        String string = dto.getId() == null ? UNKNOWN : dto.getId().toString();
        return new ErrorMessageDTO(string, validationErrors);
    }

    private void validationCodeExists(String code, List<String> validationErrors) {
        if (euroclearCodeRepository.existsByCode(code)) {
            validationErrors.add("Euroclear already taken with code: " + code);
        }
    }

    @Override
    public List<EuroclearDTO> getAll() {
        List<EuroclearCode> all = euroclearCodeRepository.findAll();
        return euroclearMapper.mapToDTOList(all);
    }

    @Override
    public List<EuroclearDTO> findByCode(String code) {
        List<EuroclearCode> all = euroclearCodeRepository.findByCode(code);
        return euroclearMapper.mapToDTOList(all);
    }

    @Override
    public EuroclearDTO findById(Long id) {
        EuroclearCode data = euroclearCodeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return euroclearMapper.mapToDto(data);
    }
}
