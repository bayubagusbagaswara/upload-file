package com.services.coreservice.enums;

public enum  ChangeAction {
        Add, Edit, Delete
}
