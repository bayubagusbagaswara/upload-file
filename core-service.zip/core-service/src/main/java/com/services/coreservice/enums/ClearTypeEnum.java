package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ClearTypeEnum {
    EUROCLEAR("", "Euroclear"),
    CLEARSTREAM("CS", "Clearstream");

    private String startWith;
    private String name;
}
