package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.datachange.RejectDataChangeRequest;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.model.swift.DataChange;

import java.util.List;

public interface DataChangeServices {
    DataChangeDTO getById(Long id);

    List<DataChange> getAll();

    List<String> findAllMenu();

    String deleteAll();

    <T> void createChangeActionADD(DataChangeDTO dataChangeDTO, Class<T> clazz);

    void approvalStatusIsRejected(DataChangeDTO dataChangeDTO, List<String> errorMessageList);

    void approvalStatusIsApproved(DataChangeDTO dataChangeDTO);

    <T> void createChangeActionEDIT(DataChangeDTO dataChangeDTO, Class<T> clazz);

    <T> void createChangeActionListEDIT(List<DataChangeDTO> dataChangeDTO, Class<T> clazz);

    <T> void createChangeActionDELETE(DataChangeDTO dataChangeDTO, Class<T> clazz);

    <T> void createChangeActionListDELETE(List<DataChangeDTO> dataChangeDTOList, Class<T> clazz);

    Boolean existByIdList(List<Long> idList, Integer idListSize);

    Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus status);

    boolean areAllIdsExistInDatabase(List<Long> idList);

    boolean existById(Long id);

    void update(DataChangeDTO dataChangeDTO);

    List<DataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus);

    void reject(RejectDataChangeRequest request, String clientIp);

    List<DataChange> getAllByApprovalStatus(String approvalStatus);

    String deleteById(Long id);
}
