package com.services.coreservice.config;

import com.services.coreservice.enums.TransactionType;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.AbstractConverter;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.modelmapper.spi.MappingContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Configuration
public class ApplicationConfig {

    @Bean
    public ModelMapper modelMapper() {
        ModelMapper modelMapper = new ModelMapper();

        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
        modelMapper.getConfiguration().isSkipNullEnabled();

        modelMapper.addConverter(stringToBigDecimalConverter());
        modelMapper.addConverter(bigDecimalToStringConverter());
        modelMapper.addConverter(toLocalDate());
        modelMapper.addConverter(toEnumTransactionType());

        return modelMapper;
    }

    @Bean
    public Converter<String, BigDecimal> stringToBigDecimalConverter() {
        return new AbstractConverter<String, BigDecimal>() {
            protected BigDecimal convert(String source) {
                return !StringUtils.isEmpty(source)? new BigDecimal(source) : BigDecimal.ZERO;
            }
        };
    }

    @Bean
    public Converter<BigDecimal, String> bigDecimalToStringConverter() {
        return new AbstractConverter<BigDecimal, String>() {
            protected String convert(BigDecimal value) {
                if (BigDecimal.ZERO.compareTo(value) == 0) {
                    return "0";
                } else {
//                    DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
//                    symbols.setGroupingSeparator(',');
//                    symbols.setDecimalSeparator('.');
//
//                    DecimalFormat decimalFormat = new DecimalFormat("#,##0.00", symbols);
//
//                    return decimalFormat.format(value);
                    return value.toPlainString();
                }
            }
        };
    }

    @Bean
    public Converter<String, LocalDate> toLocalDate() {
        return new Converter<String, LocalDate>() {
            @Override
            public LocalDate convert(MappingContext<String, LocalDate> context) {
                return LocalDate.parse(context.getSource(), DateTimeFormatter.BASIC_ISO_DATE);
            }
        };
    }

    @Bean
    public Converter<String, TransactionType> toEnumTransactionType() {
        return new Converter<String, TransactionType>() {
            @Override
            public TransactionType convert(MappingContext<String, TransactionType> context) {
                return TransactionType.fromCode(context.getSource());
            }
        };
    }

    @Bean
    public Converter<Boolean, String> booleanToStringConverter() {
        return new AbstractConverter<Boolean, String>() {
            @Override
            protected String convert(Boolean source) {
                return source != null ? source.toString() : "false";
            }
        };
    }

}
