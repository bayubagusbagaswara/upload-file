package com.services.coreservice.exception;

public class ReadExcelException extends RuntimeException {

    public ReadExcelException() {
    }

    public ReadExcelException(String message) {
        super(message);
    }
}
