package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.currency.*;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;

import java.util.List;

public interface CurrencyServices {
    CurrencyResponse createSingleData(final CreateCurrencyRequest request, final DataChangeDTO dataChangeDTO);

    CurrencyResponse createSingleApprove(CurrencyApproveRequest approveRequest, String clientIP);

    CurrencyResponse updateSingleData(UpdateCurrencyRequest request, DataChangeDTO dataChangeDTO);

    CurrencyResponse updateSingleApprove(CurrencyApproveRequest approveRequest, String clientIP);

    CurrencyResponse deleteSingleData(DeleteCurrencyRequest deleteRequest, DataChangeDTO dataChangeDTO);

    CurrencyResponse deleteSingleApprove(CurrencyApproveRequest approveRequest, String clientIP);

    List<CurrencyDTO> getAll();

    CurrencyDTO findByCode(String code);

    CurrencyDTO findById(Long id);
}
