package com.services.coreservice.dto.swift.transaction;

import com.services.coreservice.annotation.interfaces.ListConverting;
import com.services.coreservice.annotation.interfaces.UpperCase;
import com.services.coreservice.dto.swift.approval.InputIdentifierRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateTransactionListRequest extends InputIdentifierRequest {
    @NotBlank(message = "Sender cannot be empty")
    @UpperCase
    private String sender;
    @NotBlank(message = "Receiver cannot be empty")
    @UpperCase
    private String receiver;
    @ListConverting
    private List<CreateUploadTransactionListRequest> createUploadDataListRequests;
}
