package com.services.coreservice.controller.swift;

import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceApproveRequest;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceResponse;
import com.services.coreservice.dto.swift.emailMaintenance.UpdateEmailMaintenanceRequest;
import com.services.coreservice.service.swift.EmailMaintenanceServices;
import com.services.coreservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/emailMaintenance")
@RequiredArgsConstructor
public class EmailMaintenanceController {
    @Autowired
    private EmailMaintenanceServices emailMaintenanceServices;

    private static final String URL_EMAIL_MAINTENANCE = "/api/swift/emailMaintenance";
    private static final String MENU_EMAIL_MAINTENANCE = "Email Maintenance";

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<EmailMaintenanceResponse>> updateSingleData(@RequestBody UpdateEmailMaintenanceRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_EMAIL_MAINTENANCE + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_EMAIL_MAINTENANCE)
                .build();
        EmailMaintenanceResponse updateResponse = emailMaintenanceServices.updateSingleData(request, dataChangeDTO);
        ResponseDTO<EmailMaintenanceResponse> response = ResponseDTO.<EmailMaintenanceResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<EmailMaintenanceResponse>> updateSingleApprove(@RequestBody EmailMaintenanceApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        EmailMaintenanceResponse updateListResponse = emailMaintenanceServices.updateSingleApprove(request, clientIp);
        ResponseDTO<EmailMaintenanceResponse> response = ResponseDTO.<EmailMaintenanceResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<EmailMaintenanceDTO>>> getAll() {
        List<EmailMaintenanceDTO> dtoList = emailMaintenanceServices.getAll();
        ResponseDTO<List<EmailMaintenanceDTO>> response = ResponseDTO.<List<EmailMaintenanceDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<EmailMaintenanceDTO>> getById(@RequestParam("id") Long id) {
        EmailMaintenanceDTO data = emailMaintenanceServices.findById(id);
        ResponseDTO<EmailMaintenanceDTO> response = ResponseDTO.<EmailMaintenanceDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }
}
