package com.services.coreservice.dto.swift.transaction;

import com.services.coreservice.enums.TransactionType;
import com.services.coreservice.model.swift.Currency;
import com.services.coreservice.model.swift.EuroclearCode;
import com.services.coreservice.model.swift.Outgoing;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateTransactionRequest {
    private String inputerId;
    private String inputerIPAddress;
    private Long id;
    private String contractNumber;
    private String tradeId;
    private String customer;
    private String tradeDate;
    private String settlementDate;
    private String matureDate;
    private TransactionType transactionType;
    private String securityCode;
    private String isinCode;
    private Currency currency;
    private String notional;
    private String price;
    private String proceeds;
    private String cleanPrice;
    private String trader;
    private String book;
    private EuroclearCode euroclearCode;
    private String bicCodeBdi;
    private Outgoing idOutgoing;
    private String statusAckNack;
    private String sendingSwift;
}
