package com.services.coreservice.utils.Swift;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jcraft.jsch.IO;
import com.services.coreservice.enums.SettlementStatusEnum;
import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.swift.Incoming;
import com.services.coreservice.model.swift.SchedulerReport;
import com.services.coreservice.model.swift.Transaction;
import com.services.coreservice.repository.swift.IncomingRepository;
import com.services.coreservice.repository.swift.SchedulerReportRepository;
import com.services.coreservice.repository.swift.SenderReceiverBankRepository;
import com.services.coreservice.repository.swift.TransactionRepository;
import com.services.coreservice.service.swift.TransactionServices;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class SwiftAckNackReader {
    @Value("${base.path.acknack.swift}")
    private String ackNackPath;

    @Value("${base.path.acknack.swift.backup}")
    private String ackNackBackUpPath;

    @Autowired
    private SenderReceiverBankRepository senderReceiverBankRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private IncomingRepository incomingRepository;

    @Autowired
    private TransactionServices transactionServices;


    private String delimiter = "\\$";

    @Transactional(rollbackFor = Exception.class)
    public void ackNackFileReader(String filePath) {
        try {
            List<String> listOfStrings = new ArrayList<String>();

            // load content of file based on specific delimiter
            Scanner sc = new Scanner(new FileReader(filePath)).useDelimiter(delimiter);
            String str;

            // checking end of file
            while (sc.hasNext()) {
                str = sc.next();
                listOfStrings.add(str);
            }

            // convert any arraylist to array
            String[] array = listOfStrings.toArray(new String[0]);

            // print each string in array
            if (filePath.contains("CustodyAckNack")){
                System.out.println("--------------- ACK-NACK File ---------------");
                for (String eachString : array) {
                    if (eachString.contains("{1:F21")) {
                        String receiverFileIncoming = SwiftTaggingExtract.headerBlock1F21(eachString);
                        if (senderReceiverBankRepository.existsByCode(receiverFileIncoming)) {
                            processFileAckNack(eachString, receiverFileIncoming, filePath);
                        } else continue;
                    }
                }
                sc.close();
                Path sourcePath = Paths.get(filePath);
                Path destinationPath = Paths.get(ackNackBackUpPath + sourcePath.getFileName());
                Files.move(sourcePath, destinationPath);
            } else if (filePath.contains("CustodyInc")){
                throw new IOException("Reading wrong folder! Reading from FOLDER INCOMING should be read from FOLDER ACK_NACK.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processFileAckNack (String mtData, String receiver, String filePath){
        Incoming incoming = new Incoming();
        Transaction transaction = new Transaction();

        String ackNack = "";
        LocalDateTime dateTime = null;
        String reference = "";
        SwiftType mt = null;

        String lines[] = mtData.split("\n");
        for (String line : lines){
            //Date file Incoming
            if (line.contains("{177:")) {dateTime = SwiftTaggingExtract.headerBlock1177(line);}

            //Ack-Nack Status
            if (line.contains("{451:")) {ackNack = SwiftTaggingExtract.headerBlock1451(line);}

            //MT Type
            if (line.contains("{2:")) {
                mt = SwiftTaggingExtract.headerBlock12MT(line);
                if (mt == null){
                    log.error("Error when reading incoming MT {} where MT {} is not registered in ENUM!", filePath, mt.getValue());
                    continue;
                }
            }

            //Reference
            if (line.contains("20C")) {
                reference = SwiftTaggingExtract.tag20(line);
                transaction = transactionServices.getTransactionRecord(reference.trim());
                if (transaction == null){
                    break;
                }
            }
        }

        if(transaction != null) {
            //Fill Transaction Data
            transaction.setStatusAckNack(ackNack);

            //Fill Incoming Database
            incoming.setSwiftFormat(mtData);
            incoming.setFileName(FilenameUtils.getName(filePath));
            incoming.setFilePath(ackNackBackUpPath);
            incoming.setIncomingTime(dateTime);
            incoming.setSwiftType(mt);
            incoming.setIncomingTypeData(ackNack); //ACK or NACK or INC
            incoming.setReferenceTransaction(reference);
            incoming.setReceiverBank(receiver);
            incoming.setSenderBank("SWIFT");

            transactionRepository.save(transaction);
            incomingRepository.save(incoming);
        }
    }
}
