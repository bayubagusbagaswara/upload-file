package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceApproveRequest;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceResponse;
import com.services.coreservice.dto.swift.emailMaintenance.UpdateEmailMaintenanceRequest;

import java.util.List;

public interface EmailMaintenanceServices {
    EmailMaintenanceResponse updateSingleData(UpdateEmailMaintenanceRequest request, DataChangeDTO dataChangeDTO);

    EmailMaintenanceResponse updateSingleApprove(EmailMaintenanceApproveRequest approveRequest, String clientIP);

    List<EmailMaintenanceDTO> getAll();

    EmailMaintenanceDTO findById(Long id);
}
