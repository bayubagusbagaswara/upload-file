package com.services.coreservice.dto.swift.currency;

import com.services.coreservice.dto.swift.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyDTO extends ApprovalDTO {
    private Long id;

    @Pattern(regexp = "^[a-zA-Z]*$", message = "Code must contain only alphabet characters")
    @NotBlank(message = "Currency Code cannot be empty")
    @Size(min = 3, max = 3, message = "The code must have a minimum character length of 3")
    private String code;

    @NotBlank(message = "Currency Name cannot be empty")
    private String name;
}
