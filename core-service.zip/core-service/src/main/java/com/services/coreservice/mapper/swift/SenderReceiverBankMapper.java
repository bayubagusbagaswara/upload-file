package com.services.coreservice.mapper.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.senderReceiverBank.SenderReceiverBankDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.mapper.BaseMapper;
import com.services.coreservice.model.swift.SenderReceiverBank;
import com.services.coreservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class SenderReceiverBankMapper extends BaseMapper<SenderReceiverBank, SenderReceiverBankDTO> {

    private final ConvertDateUtil convertDateUtil;

    public SenderReceiverBankMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<SenderReceiverBank, SenderReceiverBankDTO> getPropertyMap() {
        return new PropertyMap<SenderReceiverBank, SenderReceiverBankDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<SenderReceiverBank> getEntityClass() {
        return SenderReceiverBank.class;
    }

    @Override
    protected Class<SenderReceiverBankDTO> getDtoClass() {
        return SenderReceiverBankDTO.class;
    }

    protected void setCommonProperties(SenderReceiverBank entity, DataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputDate(convertDateUtil.getDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
