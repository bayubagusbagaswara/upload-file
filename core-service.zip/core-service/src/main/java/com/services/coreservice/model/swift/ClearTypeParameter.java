package com.services.coreservice.model.swift;

import com.services.coreservice.enums.TransactionType;
import com.services.coreservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "swift_clear_type_parameter")
public class ClearTypeParameter extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "clear_type", nullable = false)
    private String clearType;

    @Enumerated(EnumType.STRING)
    @Column(name = "transaction_type", nullable = false)
    private TransactionType transactionType;

    @Column(name = "identifier_code", nullable = false, length = 11)
    private String identifierCode;

    @Column(name = "data_source_scheme", nullable = false, length = 8)
    private String dataSourceScheme;
}
