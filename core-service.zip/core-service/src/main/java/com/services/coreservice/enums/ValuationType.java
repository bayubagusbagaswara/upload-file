package id.co.danamon.apps.csa.recon.enums;

public enum ValuationType {
	HIPORT, BIS4, CBEST, EUROCLEAR, TRANSACTION,URUNDANA;
}
