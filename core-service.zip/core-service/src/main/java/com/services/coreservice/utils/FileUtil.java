package com.services.coreservice.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
public class FileUtil {
    protected static final String PATH_SEPARATOR = "\\";
    protected static final String REPLACE_SEPARATOR = "\\\\";

    public static String createFile (String folderPath, final String fileName) throws IOException {
        folderPath = folderPath.replaceAll("[\\\\/]+", REPLACE_SEPARATOR)
                .replaceAll("[\\\\/]+$", "");
        final String fullPath = folderPath + PATH_SEPARATOR + fileName;
        File folder = new File(folderPath);
        File file = new File(folder, fileName);

        // Create the folder if it doesn't exist
        createFolder(folderPath);

        // Create the file
        if (!file.exists()) {
            file.createNewFile();
            log.info("File {} created successfully!", fullPath);
        } else {
            log.info("File {} already exists!", fullPath);
        }
        return fullPath;
    }

    public static void createFolder (String folderPath) {
        File folder = new File(folderPath);
        // Create the folder if it doesn't exist
        if (!folder.exists()) {
            folder.mkdirs(); // Creates all necessary parent directories as well
        }
    }

    public static String getStrFullPath (String folderPath, final String fileName) {
        folderPath = folderPath.replaceAll("[\\\\/]+", REPLACE_SEPARATOR)
                .replaceAll("[\\\\/]+$", "");
        return folderPath + PATH_SEPARATOR + fileName;
    }

    public static Path getFullPathFolderAndFile (String folderPath, final String fileName) throws IOException {
        return Paths.get(folderPath + PATH_SEPARATOR + fileName);
    }
}
