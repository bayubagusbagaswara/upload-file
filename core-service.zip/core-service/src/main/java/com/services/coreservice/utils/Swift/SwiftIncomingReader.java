package com.services.coreservice.utils.Swift;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.services.coreservice.enums.SettlementStatusEnum;
import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.swift.*;
import com.services.coreservice.repository.swift.*;
import com.services.coreservice.service.swift.TransactionServices;
import com.services.coreservice.utils.StringPadder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
@Slf4j
public class SwiftIncomingReader {

    @Value("${base.path.incoming.swift}")
    private String incomingPath;

    @Value("${base.path.incoming.swift.backup}")
    private String incomingBackUpPath;

    @Value("${base.path.report.swift}")
    private String newReportPath;

    @Autowired
    private TransactionServices transactionServices;

    @Autowired
    private SenderReceiverBankRepository senderReceiverBankRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private IncomingRepository incomingRepository;

    @Autowired
    private SchedulerReportRepository schedulerReportRepository;

    private String delimiter = "\\$";

    @Transactional(rollbackFor = Exception.class)
    public void mtFileReader(String filePath) {
        try {
            List<String> listOfStrings = new ArrayList<String>();

            // load content of file based on specific delimiter
            Scanner sc = new Scanner(new FileReader(filePath)).useDelimiter(delimiter);
            String str;

            // checking end of file
            while (sc.hasNext()) {
                str = sc.next();
                listOfStrings.add(str);
            }

            // convert any arraylist to array
            String[] array = listOfStrings.toArray(new String[0]);

            // print each string in array
            if (filePath.contains("CustodyAckNack")){
                System.out.println("--------------- ACK-NACK File ---------------");
                throw new IOException("Reading wrong folder! Reading from FOLDER ACK_NACK should be read from FOLDER INCOMING.");
            } else if (filePath.contains("CustodyInc")){
                System.out.println("--------------- INCOMING File ---------------");
                for (String eachString : array) {
                    if (eachString.contains("{1:F21")) {
                        String receiverFileIncoming = SwiftTaggingExtract.headerBlock1F21(eachString);
                        if (senderReceiverBankRepository.existsByCode(receiverFileIncoming)) {
                            processFileInc(eachString, receiverFileIncoming, filePath);
                        } else continue;
                    }
                }
                sc.close();
                Path sourcePath = Paths.get(filePath);
                Path destinationPath = Paths.get(incomingBackUpPath + sourcePath.getFileName());
                Files.move(sourcePath, destinationPath);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void processFileInc(String mtData, String receiver, String filePath){
        Incoming incoming = new Incoming();
        Transaction transaction = new Transaction();
        SchedulerReport schedulerReport = new SchedulerReport();

        String ackNack = "";
        LocalDateTime dateTime = null;
        String reference = "";
        SwiftType mt = null;
        String sender = "";
        ObjectNode tag24B = null;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
        String formattedDateTime = LocalDateTime.now().format(formatter);
        String identifier = formattedDateTime;

        String block4SubString = StringUtils.substringAfterLast(mtData, "{4:");
        String block4 = SwiftTaggingExtract.getValueInSpecificSequence(block4SubString, "", "-}");
        String block5 = "";

        String lines[] = mtData.split("\n");

        try{
            for (String line : lines){
                //Date file Incoming
                if (line.contains("{177:")) {dateTime = SwiftTaggingExtract.headerBlock1177(line);}

                //Ack-Nack Status
                if (line.contains("{451:")) {ackNack = SwiftTaggingExtract.headerBlock1451(line);}

                //MT Type and Sender MT
                if (line.contains("{2:")) {
                    sender = SwiftTaggingExtract.headerBlock12Sender(line);
                    mt = SwiftTaggingExtract.headerBlock12MT(line);
                    if (mt == null){
                        log.error("Error when reading incoming MT {} where MT {} is not registered in ENUM!", filePath, mt.getValue());
                        continue;
                    }
                }

                if(line.contains("20") && line.contains("SEME")){
                    String originalString = line.trim();
                    Pattern pattern = Pattern.compile("SEME//([A-Z0-9]+)");
                    Matcher matcher = pattern.matcher(originalString);

                    if (matcher.find()) {
                        identifier = matcher.group(1); // Get the value captured by the first group
                    }
                }

                if (mt.getValue().equalsIgnoreCase("545") ||
                        mt.getValue().equalsIgnoreCase("547") ||
                        mt.getValue().equalsIgnoreCase("548")) {

                    //Reference
                    if (line.contains("20C") && line.contains("RELA")) {
                        reference = SwiftTaggingExtract.tag20(line);
                        transaction = transactionServices.getTransactionRecord(reference.trim());
                        if (transaction == null){
                            continue;
                        }
                    }

                    //TAG 24B - Reason
                    if (line.contains("24B")){
                        tag24B = SwiftTaggingExtract.tag24B(line);
                    }
                }

                //Block 5
                if (line.contains("{5:")){
                    block5 = SwiftTaggingExtract.getValueFromPattern("CHK:([A-Z0-9]+)", line.trim());
                }
            }

            if (ackNack.equalsIgnoreCase("ack")){
                //Fill Incoming Database
                incoming.setSwiftFormat(mtData);
                incoming.setFileName(FilenameUtils.getName(filePath));
                incoming.setFilePath(incomingBackUpPath);
                incoming.setIncomingTime(dateTime);
                incoming.setSwiftType(mt);
                incoming.setIncomingTypeData("INC"); //INC
                incoming.setReferenceTransaction(reference);
                incoming.setSenderBank(sender);
                incoming.setReceiverBank(receiver);

                //Create and Save txt Scheduler Report
                String newReport = createReportSwift(mt.getValue(), sender, receiver, block4, block5);
                String newReportName = mt+"_"+identifier+"_"+formattedDateTime+".txt";
                BufferedWriter writer = new BufferedWriter(new FileWriter(newReportPath+newReportName));
                writer.write(newReport);
                writer.close();

                //Store Scheduler Report
                schedulerReport.setIdIncoming(incoming);
                schedulerReport.setFileName(newReportName);
                schedulerReport.setFilePath(newReportPath);
                schedulerReport.setGenerateDate(LocalDateTime.now());
                schedulerReport.setFileContent(newReport);
                schedulerReport.setDescription("-");
                schedulerReport.setGeneratorId("SYSTEM");
                schedulerReport.setSwiftType(mt);
                schedulerReport.setGenerated(true);

                //Settlement Status and Processing
                if (mt.getValue().equalsIgnoreCase("548") && transaction != null) {
                    String unsettleReason = tag24B.get("statusCode").toString().replace("\"","");
                    transaction.setUnsettleReason(unsettleReason);
                    transactionRepository.save(transaction);

                //Receive Against Payment Confirmation
                } else if ((mt.getValue().equalsIgnoreCase("545") && transaction != null)||
                        (mt.getValue().equalsIgnoreCase("547") && transaction != null)) {

                    //Tag 19A : Settle Amount
                    String settleAmountStr = SwiftTaggingExtract.getValueInSpecificSequence(mtData, ":16R:AMT", ":16S:AMT");
                    String settleAmount = SwiftTaggingExtract.getValueFromPattern("USD\\d+(,\\d+)?", settleAmountStr.trim());
                    BigDecimal settleAmountNumber = new BigDecimal(
                            StringUtils.substringAfterLast(settleAmount.replace(",", "."), "USD"));

                    BigDecimal newSettledAmount = BigDecimal.ZERO;
                    if(transaction.getSettleStatus().equals(SettlementStatusEnum.UNSETTLE)){
                        newSettledAmount = transaction.getSettledAmount() == null ? settleAmountNumber : transaction.getSettledAmount().add(settleAmountNumber);
                        transaction.setSettledAmount(newSettledAmount);
                    } else {
                        throw new Exception("Transaction with Reference: " + transaction.getContractNumber() + " has been settled! Please check MT data!");
                    }

                    if (newSettledAmount.equals(transaction.getProceeds())){
                        transaction.setSettleStatus(SettlementStatusEnum.SETTLE);
                        transaction.setUnsettleReason("SETT");
                    }

                    transactionRepository.save(transaction);
                } else {
                    System.out.println("Other MT: " + mt.getValue());
                }

                schedulerReportRepository.save(schedulerReport);
                incomingRepository.save(incoming);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private String createReportSwift(String mt, String sender, String receiver, String block4, String block5){
        //Create New Report for Email Scheduler
        StringBuilder newReport = new StringBuilder();
        newReport.append(StringPadder.leftPad("SWIFT MESSAGE", " ", 30));
        newReport.append("\r\n\n");
        newReport.append(StringPadder.rightPad("Message Header", " ", 25));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Format:", " ", 30));
        newReport.append(StringPadder.rightPad("Swift", " ", 25));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Identifier:", " ", 30));
        newReport.append(StringPadder.rightPad("FIN." + mt, " ", 25));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Sender:", " ", 30));
        newReport.append(StringPadder.rightPad(sender, " ", 25));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Receiver:", " ", 30));
        newReport.append(StringPadder.rightPad(receiver, " ", 25));
        newReport.append("\r\n\n");
        newReport.append(StringPadder.rightPad("Message Text", " ", 100));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Block 4", " ", 100));
        newReport.append("\r\n");
        newReport.append(block4);
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Block 5", " ", 100));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("{"+ block5 +"}", "", 100));
        newReport.append("\r\n");
        newReport.append(StringPadder.rightPad("Other", "", 100));
        newReport.append("\r\n\n");
        newReport.append(StringPadder.rightPad("=========================================================", "", 100));
        return newReport.toString();
    }
}
