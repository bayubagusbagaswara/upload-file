package com.services.coreservice.repository.rb;

import com.services.coreservice.model.rb.Security;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SecurityRepository extends JpaRepository<Security, String> {
    boolean existsByCode(String code);

    boolean existsByIsinCode(String code);

    boolean existsByCodeAndIsinCode(String code, String isinCode);

    @Query("SELECT u FROM Security u WHERE u.approvalStatus = 'Approved' and u.isinCode = :isinCode")
    Security searchByIsinCode(@Param("isinCode") String isinCode);
}
