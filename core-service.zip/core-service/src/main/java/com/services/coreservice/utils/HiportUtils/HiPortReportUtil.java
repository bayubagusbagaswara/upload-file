package com.services.coreservice.utils.HiportUtils;

import com.services.coreservice.enums.TransactionType;
import com.services.coreservice.model.swift.Transaction;
import com.services.coreservice.utils.StringPadder;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

public class HiPortReportUtil {

	private static final DateFormat HDF = new SimpleDateFormat("yyyyMMdd HH:mm");
	private static final DateFormat SDF = new SimpleDateFormat("yyMMdd");
	private static final DateTimeFormatter SDTF = DateTimeFormatter.ofPattern("yyMMdd HH:mm");
	private static final DateTimeFormatter SDTFS = DateTimeFormatter.ofPattern("yyMMdd");

	public static String writeInterfaceHiport(List<Transaction> transactions, LocalDate currentDate) {
		StringBuilder sb = new StringBuilder();
		writeHeader(sb, currentDate.atTime(00, 00));
		writeBody(sb, transactions);
		return sb.toString();
	}

	private static void writeHeader(StringBuilder sb, LocalDateTime currentDate) {
		sb.append(StringPadder.rightPad("IDXITR", " ", 6));
		sb.append(StringPadder.rightPad("I-H", " ", 4));
		sb.append(SDTF.format(currentDate));
		sb.append("\r\n");
	}

	private static void writeBody(StringBuilder sb,
			List<Transaction> transactions) {
		for (Transaction transaction : transactions) {
			writeEntry(sb, transaction);
		}
	}

	private static void writeEntry(StringBuilder sb, Transaction transaction) {

		String hiportTxnType = (transaction.getTransactionType() == TransactionType.PURCHASE) ? "01"
				: "02";

		String isinCode = transaction.getIsinCode();

		double procced = 0d;
		double markePriceValue = 0d;

		if (transaction.getTransactionType() == TransactionType.PURCHASE) {
			procced = transaction.getNotional().doubleValue()
					* transaction.getPrice().doubleValue() * 0.01;
			markePriceValue = 0;
		} else {
			procced = 0;
			markePriceValue = transaction.getNotional().doubleValue()
					* transaction.getPrice().doubleValue() * 0.01;
		}

		sb.append(StringPadder.rightPad(transaction.getBook(), " ", 6));
		sb.append(StringPadder.rightPad(isinCode, " ", 8));
		sb.append(transaction.getSettlementDate().format(SDTFS));
		sb.append(hiportTxnType);
		sb.append("NUSDUSD"); // -> Ganti USD
		sb.append(StringPadder.rightPad("1", " ", 20));
		sb.append(StringPadder.rightPad("1", " ", 18));
		sb.append(StringPadder.rightPad("1", " ", 16));
		sb.append("EURCLE");
		sb.append(SDTFS.format(transaction.getSettlementDate()));
		sb.append(StringPadder.rightPad("", " ", 14));
		sb.append(StringPadder.rightPad("", " ", 59));
		writeAmount(sb, transaction.getNotional().doubleValue() , 13, 4, true);
		writeAmount(sb, transaction.getPrice().doubleValue(), 8, 6, true);
		writeAmount(sb, procced, 13, 2, true);
		writeAmount(sb, markePriceValue, 13, 2, true);
		sb.append(StringPadder.rightPad("", " ", 85));
		writeAmount(sb, markePriceValue, 13, 2, true);
		sb.append(StringPadder.rightPad("", " ", 34));
		writeAmount(sb, markePriceValue, 13, 2, true);
		sb.append(StringPadder.rightPad("", " ", 17));

		if (transaction.getTransactionType() == TransactionType.PURCHASE) {
			sb.append(StringPadder.rightPad("TRXFEE", " ", 6));
//			sb.append(StringPadder.rightPad(
//					"" + Math.round(transaction.getFeeAmount()), " ", 13));
			sb.append(StringPadder.rightPad(
					"" + Math.round(0), " ", 13));
			sb.append("E");
			sb.append("USD");// -> Ganti USD
			sb.append(StringPadder.rightPad("", " ", 23));

		} else {
			sb.append(StringPadder.rightPad("TAX", " ", 6));
//			sb.append(StringPadder.rightPad(
//					"" + Math.round(transaction.getTaxAmount()), " ", 13));
			sb.append(StringPadder.rightPad(
					"" + Math.round(0), " ", 13));
			sb.append("E");
			sb.append("USD"); // -> Ganti USD
			sb.append("TRXFEE");
//			sb.append(StringPadder.rightPad(
//					"" + Math.round(transaction.getFeeAmount()), " ", 13));
			sb.append(StringPadder.rightPad(
					"" + Math.round(0), " ", 13));
			sb.append("E");
			sb.append("USD"); // -> Ganti USD
		}

		sb.append(StringPadder.rightPad("", " ", 3 * 23));
		sb.append(StringPadder.rightPad("", " ", 2));
		sb.append(StringPadder.rightPad("", " ", 7 * 255));
		sb.append(StringPadder.rightPad("", " ", 172));
		sb.append(StringPadder.rightPad(transaction.getCustomer(), " ", 55));
		sb.append(StringPadder.rightPad(".", " ", 55));
		sb.append(StringPadder.rightPad(".", " ", 55));
		sb.append("\r\n");
	}

	private static void writeAmount(StringBuilder sb, double requestAmount,
			int beforeDecimal, int afterDecimal, boolean sign) {
		String format = String.format("%0" + (beforeDecimal + afterDecimal + 1)
				+ "." + afterDecimal + "f", Math.abs(requestAmount));
		sb.append(format);
		if (sign) {
			sb.append(requestAmount >= 0 ? ' ' : '-');
		}
	}

}
