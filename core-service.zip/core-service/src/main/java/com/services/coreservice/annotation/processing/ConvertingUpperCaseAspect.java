package com.services.coreservice.annotation.processing;

import com.services.coreservice.annotation.interfaces.ListConverting;
import com.services.coreservice.annotation.interfaces.UpperCase;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Aspect
@Component
public class ConvertingUpperCaseAspect {

    @Pointcut("execution(* *(.., @org.springframework.web.bind.annotation.RequestBody (*), ..))")
    public void requestBody() {}

    @Pointcut("execution(* *(.., @com.services.coreservice.annotation.interfaces.Converting (*), ..))")
    public void annotationParameter() {}

    @Pointcut("requestBody() && annotationParameter()")
    public void upperCasePointcut() {}

    @Before("upperCasePointcut()")
    public void processUpperCaseAnnotation(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        for (Object arg : args) {
            if (arg != null) {
                Field[] fields = arg.getClass().getDeclaredFields();
                for (Field field : fields) {
                    if (field.isAnnotationPresent(ListConverting.class)) {
                        field.setAccessible(true);
                        try {
                            List value = (ArrayList) field.get(arg);
                            value.stream().forEach(fe -> {
                                Arrays.stream(fe.getClass().getDeclaredFields())
                                        .forEach(f -> upperCaseValue(f, fe));
                            });
                        } catch (IllegalAccessException e) {
                            e.printStackTrace();
                        }
                    } else {
                        upperCaseValue(field, arg);
                    }
                }
            }
        }
    }

    private void upperCaseValue (Field field, Object arg) {
        if (field.isAnnotationPresent(UpperCase.class)) {
            UpperCase upperCase = field.getAnnotation(UpperCase.class);
            String typeValue = upperCase.value();
            field.setAccessible(true);
            try {
                Object value = field.get(arg);
                if (value instanceof String) {
                    String upperCaseValue;
                    if (typeValue.equalsIgnoreCase("all")) {
                        upperCaseValue = ((String) value).toUpperCase();
                    } else {
                        upperCaseValue = StringUtils.capitalize(((String) value).toLowerCase());
                    }
                    field.set(arg, upperCaseValue);
                }
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        }
    }
}
