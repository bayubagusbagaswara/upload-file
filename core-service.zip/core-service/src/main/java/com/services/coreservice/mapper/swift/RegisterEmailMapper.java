package com.services.coreservice.mapper.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.registerEmail.RegisterEmailDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.mapper.BaseMapper;
import com.services.coreservice.model.swift.RegisterEmail;
import com.services.coreservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class RegisterEmailMapper extends BaseMapper<RegisterEmail, RegisterEmailDTO> {

    private final ConvertDateUtil convertDateUtil;

    public RegisterEmailMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<RegisterEmail, RegisterEmailDTO> getPropertyMap() {
        return new PropertyMap<RegisterEmail, RegisterEmailDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<RegisterEmail> getEntityClass() {
        return RegisterEmail.class;
    }

    @Override
    protected Class<RegisterEmailDTO> getDtoClass() {
        return RegisterEmailDTO.class;
    }

    @Override
    protected void setCommonProperties(RegisterEmail entity, DataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
//        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(convertDateUtil.getDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
//        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}

