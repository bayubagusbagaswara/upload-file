package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.senderReceiverBank.*;

import java.util.List;

public interface SenderReceiverBankServices {
    SenderReceiverBankResponse createSingleData(CreateSenderReceiverBankRequest request, DataChangeDTO dataChangeDTO);

    SenderReceiverBankResponse createSingleApprove(SenderReceiverBankApproveRequest approveRequest, String clientIP);

    SenderReceiverBankResponse updateSingleData(UpdateSenderReceiverBankRequest request, DataChangeDTO dataChangeDTO);

    SenderReceiverBankResponse updateSingleApprove(SenderReceiverBankApproveRequest approveRequest, String clientIP);

    SenderReceiverBankResponse deleteSingleData(DeleteSenderReceiverBankRequest deleteRequest, DataChangeDTO dataChangeDTO);

    SenderReceiverBankResponse deleteSingleApprove(SenderReceiverBankApproveRequest approveRequest, String clientIP);

    List<SenderReceiverBankDTO> getAll();

    List<SenderReceiverBankDTO> getAllSenderOrReceiver(final String type);

    List<SenderReceiverBankDTO> findByCode(String code);

    SenderReceiverBankDTO findById(Long id);
}
