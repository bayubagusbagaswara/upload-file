package com.services.coreservice.dto.swift.euroclear;

import com.services.coreservice.dto.swift.approval.ApprovalDTO;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EuroclearDTO extends ApprovalDTO {
    private Long id;
    private String code;
    private String bank;
}
