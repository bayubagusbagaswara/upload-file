package com.services.coreservice.repository.swift;

import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.model.swift.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    @Query(value="SELECT * FROM swift_transactions WHERE approval_status = 'Approved' AND settlement_date = :settleDate", nativeQuery = true)
    List<Transaction> listTransactionBySettleDate(@Param("settleDate") LocalDate settleDate);

    boolean existsByContractNumberAndApprovalStatusIn(String contractNumber, List<ApprovalStatus> approvalStatuses);

    @Query(value = "SELECT t FROM Transaction t JOIN FETCH t.idOutgoing WHERE t.approvalStatus = :approvalStatus ORDER BY t.contractNumber ASC")
    List<Transaction> findByApprovalStatusOrderByContractNumberAsc(ApprovalStatus approvalStatus);

    @Query("SELECT u FROM Transaction u WHERE u.approvalStatus = 'Approved' and u.contractNumber = :contractNumber")
    Transaction searchByContactNumber(@Param("contractNumber") String contractNumber);

    @Query("SELECT t FROM Transaction t JOIN FETCH t.idOutgoing WHERE t.id = :id")
    Transaction findFecthById(@Param("id") Long id);

    @Query(value = "SELECT CASE WHEN COUNT(*) = :listSize THEN true ELSE false END " +
            "FROM Transaction WHERE id IN :idList and approvalStatus = :status")
    Boolean existsByIdListAndStatus(@Param("idList") List<Long> idList,
                                    @Param("listSize") Long listSize,
                                    @Param("status") ApprovalStatus status);
}
