package com.services.coreservice.dto.swift.transaction;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.coreservice.annotation.interfaces.UpperCase;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class CreateUploadTransactionListRequest {
    @JsonProperty(value = "CONTRACT ID")
    @Pattern(regexp = "^(?:[a-zA-Z0-9/–?:().,'+\\r\\n ]{1,16}$[\\r\\n]?)$", message = "CONTRACT ID must follow the rules of MT with the rules '16x'")
    @NotBlank(message = "CONTRACT ID cannot be empty")
    private String contractNumber;

    @JsonProperty(value = "TRADEID")
    @Pattern(regexp = "^\\d*$", message = "TRADEID must contain only numeric digits")
    @NotBlank(message = "TRADEID cannot be empty")
    private String tradeId;

    @JsonProperty(value = "CUSTOMER")
    @NotBlank(message = "CUSTOMER cannot be empty")
    private String customer;

    @JsonProperty(value = "TRADEDATE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyyMMdd")
    @Pattern(regexp = "^([0-9]{8})\\z", message = "TRADEDATE must follow the rules of MT with the rules '8!n'")
    @NotBlank(message = "TRADEDATE cannot be empty")
    private String tradeDate;

    @JsonProperty(value = "SETTLEDATE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyyMMdd")
    @Pattern(regexp = "^([0-9]{8})\\z", message = "SETTLEDATE must follow the rules of MT with the rules '8!n'")
    @NotBlank(message = "SETTLEDATE cannot be empty")
    private String settlementDate;

    @JsonProperty(value = "MATDATE")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyyMMdd")
    @Pattern(regexp = "^([0-9]{8})\\z", message = "MATDATE must follow the rules of MT with the rules '8!n'")
    private String matureDate;

    @JsonProperty(value = "P/S")
    @Pattern(regexp = "^[PSps]$", message = "P/S can only be filled with P or S and with a length of 1 character")
    @NotBlank(message = "P/S cannot be empty")
    @UpperCase
    private String transactionType;

    @JsonProperty(value = "SEC")
    @Pattern(regexp = "^(?:[a-zA-Z0-9/–?:().,'+\\r\\n ]{1,35}$[\\r\\n]?){1,4}$", message = "SEC must follow the rules of MT with the rules '4*35x'")
    @NotBlank(message = "SEC cannot be empty")
    @UpperCase
    private String securityCode;

    @JsonProperty(value = "ISIN CODES")
    @Pattern(regexp = "^[A-Z0-9]{12}$", message = "ISIN CODES must follow the rules of MT with the rules '12!c'")
    @NotBlank(message = "ISIN CODES cannot be empty")
    @UpperCase
    private String isinCode;

    @JsonProperty(value = "CCY")
    @Pattern(regexp = "^[A-Za-z]{3}$", message = "CCY can only be filled with alphabet and with a length of 3 character")
    @NotBlank(message = "CCY cannot be empty")
    @UpperCase
    private String currency;

    @JsonProperty(value = "NOTIONAL")
    @Pattern(regexp = "^[0-9,.]{1,15}$", message = "NOTIONAL can only be filled with decimal number, not a negative number and max length of 15 digits")
    private String notional;

    @JsonProperty(value = "PRICE")
    @Pattern(regexp = "^[0-9,.-]{1,15}$", message = "PRICE can only be filled with decimal number and max length of 15 digits")
    @NotBlank(message = "PRICE cannot be empty")
    private String price;

    @JsonProperty(value = "PROCEEDS")
    @Pattern(regexp = "^[0-9,.]{1,15}$", message = "PROCEEDS can only be filled with decimal number, not a negative number and max length of 15 digits")
    private String proceeds;

    @JsonProperty(value = "CleanPrice")
    @Pattern(regexp = "^[0-9,.]{1,15}$", message = "CleanPrice can only be filled with decimal number, not a negative number and max length of 15 digits")
    @NotBlank(message = "CleanPrice cannot be empty")
    private String cleanPrice;

    @JsonProperty(value = "TRADER")
    @UpperCase
    private String trader;

    @JsonProperty(value = "BOOK")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "BOOK must contain only alphanumeric characters")
    @NotBlank(message = "BOOK cannot be empty")
    @UpperCase
    private String book;

    @JsonProperty(value = "EURCLE CODE")
    @Pattern(regexp = "^(?:[a-zA-Z0-9/–?:().,'+\\r\\n ]{1,34}$[\\r\\n]?)$", message = "ISIN CODES must follow the rules of MT with the rules '34x'")
    @NotBlank(message = "EURCLE CODE cannot be empty")
    private String euroclearCode;

    @JsonProperty(value = "BIC BDI CODE")
    @Pattern(regexp = "^(?:[a-zA-Z0-9/–?:().,'+\\r\\n ]{1,35}$[\\r\\n]?)$", message = "ISIN CODES must follow the rules of MT with the rules '35x'")
    @NotBlank(message = "BIC BDI CODE cannot be empty")
    private String bicCodeBdi;
}
