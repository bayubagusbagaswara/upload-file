package com.services.coreservice.repository.swift;

import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.model.swift.DataChange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DataChangeRepository extends JpaRepository<DataChange, Long> {
    List<DataChange> findByApprovalStatus(ApprovalStatus ApprovalStatus);

    List<DataChange> findByEntityClassName(String entityClassName);

    @Query(value = "SELECT * FROM swift_data_changes WHERE approval_status = 'Pending'", nativeQuery = true)
    List<DataChange> searchAllByApprovalStatusPending();

    @Query(value = "SELECT * FROM swift_data_changes WHERE id = :idData AND approval_status = 'Pending'", nativeQuery = true)
    DataChange searchDataForApproveOrReject(@Param("idData") Long id);

    @Query(value = "SELECT DISTINCT menu FROM swift_data_changes WHERE ISNULL(menu, '') != '' ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenu();

    @Query(value = "SELECT DISTINCT menu FROM swift_data_changes WHERE ISNULL(menu, '') != '' AND approval_status = :approvalStatus ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenuByApprovalStatus(String approvalStatus);

    @Query(value = "SELECT CASE WHEN COUNT(*) = :listSize THEN 1 ELSE 0 END " +
            "FROM bill_data_change WHERE id IN :idList", nativeQuery = true)
    Boolean existsByIdList(@Param("idList") List<Long> idList, @Param("listSize") Integer listSize);

    @Query(value = "SELECT CASE WHEN COUNT(*) = :listSize THEN true ELSE false END " +
            "FROM DataChange WHERE id IN :idList and approvalStatus = :status")
    Boolean existsByIdListAndStatus(@Param("idList") List<Long> idList,
                                    @Param("listSize") Long listSize,
                                    @Param("status") ApprovalStatus status);

    long countByIdIn(List<Long> idList);

    List<DataChange> findByIdIn(List<Long> idList);

    List<DataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus);

    List<DataChange> findAllByApprovalStatus(String approvalStatusEnum);
}
