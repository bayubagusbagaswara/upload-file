package com.services.coreservice.dto.swift.emailMaintenance;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateEmailMaintenanceRequest {
    private String inputerId;
    private String inputerIPAddress;
    private Long id;
    private String swiftType;
    private String subjectEmail;
    private String bodyEmail;
    private String typeEmail;
}
