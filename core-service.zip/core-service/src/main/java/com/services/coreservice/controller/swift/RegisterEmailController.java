package com.services.coreservice.controller.swift;

import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.currency.CurrencyDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.registerEmail.*;
import com.services.coreservice.service.swift.RegisterEmailServices;
import com.services.coreservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/registerEmail")
@RequiredArgsConstructor
public class RegisterEmailController {

    private final RegisterEmailServices registerEmailServices;

    private static final String URL_REGISTER_EMAIL = "/api/swift/registerEmail";
    private static final String MENU_REG_EMAIL = "RegisterEmail";

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<RegisterEmailDTO>>> getAll() {
        List<RegisterEmailDTO> dtoList = registerEmailServices.getAll();
        ResponseDTO<List<RegisterEmailDTO>> response = ResponseDTO.<List<RegisterEmailDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping("/{code}")
    public ResponseEntity<ResponseDTO> getByCode(@PathVariable String code)  {
        ResponseDTO<List<RegisterEmailDTO>> response = ResponseDTO.<List<RegisterEmailDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(registerEmailServices.findByEmailAddressLike(code))
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<ResponseDTO> getById(@RequestParam Long id)  {
        ResponseDTO<RegisterEmailDTO> response = ResponseDTO.<RegisterEmailDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(registerEmailServices.findById(id))
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping("/create")
    public ResponseEntity<ResponseDTO<RegisterEmailResponse>> createSingleData(@RequestBody List<CreateRegisterEmailRequest> requests, HttpServletRequest servletRequest)  {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(URL_REGISTER_EMAIL + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_REG_EMAIL)
                .build();
        RegisterEmailResponse createResponse = registerEmailServices.createSingleData(requests, dataChangeDTO);
        ResponseDTO<RegisterEmailResponse> response = ResponseDTO.<RegisterEmailResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<RegisterEmailResponse>> createSingleApprove(@RequestBody RegisterEmailApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        RegisterEmailResponse listApprove = registerEmailServices.createSingleApprove(request, clientIp);
        ResponseDTO<RegisterEmailResponse> response = ResponseDTO.<RegisterEmailResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<RegisterEmailResponse>> updateSingleData(@RequestBody List<UpdateRegisterEmailRequest> requests, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_REGISTER_EMAIL + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_REG_EMAIL)
                .build();
        RegisterEmailResponse updateResponse = registerEmailServices.updateSingleData(requests, dataChangeDTO);
        ResponseDTO<RegisterEmailResponse> response = ResponseDTO.<RegisterEmailResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<RegisterEmailResponse>> updateSingleApprove(@RequestBody RegisterEmailApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        RegisterEmailResponse updateListResponse = registerEmailServices.updateSingleApprove(request, clientIp);
        ResponseDTO<RegisterEmailResponse> response = ResponseDTO.<RegisterEmailResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<RegisterEmailResponse>> deleteSingleData(@RequestBody List<DeleteRegisterEmailRequest> requests) {
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(URL_REGISTER_EMAIL + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_REG_EMAIL)
                .build();
        RegisterEmailResponse deleteResponse = registerEmailServices.deleteSingleData(requests, dataChangeDTO);
        ResponseDTO<RegisterEmailResponse> response = ResponseDTO.<RegisterEmailResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<RegisterEmailResponse>> deleteSingleApprove(@RequestBody RegisterEmailApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        RegisterEmailResponse deleteResponse = registerEmailServices.deleteSingleApprove(request, clientIp);
        ResponseDTO<RegisterEmailResponse> response = ResponseDTO.<RegisterEmailResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }
}
