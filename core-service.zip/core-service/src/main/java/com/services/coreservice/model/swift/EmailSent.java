package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SwiftType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_email_sent")
public class EmailSent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sender_id")
    private String senderId;

    @Column(name = "sent_date")
    private LocalDate sentDate;

    @Column(name = "attachment_path")
    private String attachmentPath;

    @Enumerated(EnumType.STRING)
    @Column(name = "swift_type")
    private SwiftType swiftType;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_scheduler_report", referencedColumnName = "id")
    private SchedulerReport schedulerReport;

    @Column(name = "is_sent")
    private Boolean sent;

    @Column(name = "description")
    private String description;

    @Column(name = "report_type")
    private String reportType;

    @Column(name = "settle_date_start")
    private String settleDateStart;

    @Column(name = "settle_date_end")
    private String settleDateEnd;

}
