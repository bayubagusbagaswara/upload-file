package com.services.coreservice.service.swift.impl;

import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.model.swift.Transaction;
import com.services.coreservice.repository.swift.TransactionRepository;
import com.services.coreservice.service.swift.ReportInterfaceHiportServices;
import com.services.coreservice.utils.HiportUtils.HiPortReportUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
@Slf4j
public class ReportInterfaceHiportImpl implements ReportInterfaceHiportServices {
    @Autowired
    TransactionRepository transactionRepository;

    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
            "dd/MM/yyyy");
    private static final DateTimeFormatter LDF = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    @Override
    public ResponseEntity<ResponseDTO<byte[]>> dowloadFileInterface(String date) {
        // Format String date to date
        LocalDate currentDate = getCurrentDateFromRequest(date);

        // Define the file name and path
        String fileName = "HiportInterface_"+ date.replace("/","") +".txt";
        File file = new File(fileName);
        byte[] byteArray;

        // Create the file and write some content to it
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))){
            List<Transaction> transactionList = transactionRepository.listTransactionBySettleDate(currentDate);
            String txtContent = HiPortReportUtil.writeInterfaceHiport(transactionList, currentDate);
            writer.write(txtContent);
        } catch (IOException e) {
            log.error("Failed download file with error : {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseDTO.<byte[]>builder()
                            .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                            .message(HttpStatus.NOT_FOUND.getReasonPhrase())
                            .payload(null)
                            .build());
        }

//        Convert to byte
        try {
            byteArray = FileUtils.readFileToByteArray(file);
        } catch (IOException e) {
            log.error("Failed download file with error : {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseDTO.<byte[]>builder()
                            .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                            .message(HttpStatus.NOT_FOUND.getReasonPhrase())
                            .payload(null)
                            .build());
        } finally {
            file.delete();
        }

        // Prepare the response
        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
        headers.setContentType(MediaType.APPLICATION_JSON);

        ResponseDTO<byte[]> response = ResponseDTO.<byte[]>builder()
                .code(HttpStatus.OK.value())
                .message(fileName)
                .payload(byteArray)
                .build();
        return ResponseEntity.ok().body(response);
    }

    public static LocalDate getCurrentDateFromRequest(String dateString) {
        LocalDate currentDate = LocalDate.now();
        if (dateString != null && !dateString.isEmpty()) {
            try {
                currentDate = LocalDate.parse(dateString, LDF);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return currentDate;
    }

}
