package com.services.coreservice.service.swift;

public interface EmailSentServices {
}
