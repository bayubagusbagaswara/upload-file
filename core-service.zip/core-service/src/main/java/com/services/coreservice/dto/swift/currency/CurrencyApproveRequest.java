package com.services.coreservice.dto.swift.currency;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyApproveRequest {
    private String approverId;
    private String approverIPAddress;
    private String dataChangeId;
    private CurrencyDTO data;
}
