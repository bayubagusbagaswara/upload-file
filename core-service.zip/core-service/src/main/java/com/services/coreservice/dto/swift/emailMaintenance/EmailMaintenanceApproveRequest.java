package com.services.coreservice.dto.swift.emailMaintenance;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmailMaintenanceApproveRequest {
    private String approverId;
    private String approverIPAddress;
    private String dataChangeId;
    private EmailMaintenanceDTO data;
}
