package com.services.coreservice.dto.swift.registerEmail;

import com.services.coreservice.dto.swift.ErrorMessageDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterEmailResponse {
    private Integer totalDataSuccess;
    private Integer totalDataFailed;
    private List<ErrorMessageDTO> errorMessageDTOList;
}
