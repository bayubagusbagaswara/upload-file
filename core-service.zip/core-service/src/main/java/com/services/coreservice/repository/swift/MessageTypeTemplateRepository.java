package com.services.coreservice.repository.swift;

import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.swift.MessageTypeTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MessageTypeTemplateRepository extends JpaRepository<MessageTypeTemplate, Long> {
    MessageTypeTemplate findBySwiftType (SwiftType swiftType);
}
