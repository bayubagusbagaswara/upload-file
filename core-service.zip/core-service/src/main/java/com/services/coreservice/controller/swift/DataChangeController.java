package com.services.coreservice.controller.swift;

import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.datachange.RejectDataChangeRequest;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.model.swift.DataChange;
import com.services.coreservice.service.swift.DataChangeServices;
import com.services.coreservice.utils.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/dataChange")
@RequiredArgsConstructor
public class DataChangeController {
    @Autowired
    private final DataChangeServices DataChangeServices;

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<DataChange>>> getAll() {
        List<DataChange> DataChangeList = DataChangeServices.getAll();
        ResponseDTO<List<DataChange>> response = ResponseDTO.<List<DataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(DataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/approval-status")
    public ResponseEntity<ResponseDTO<List<DataChange>>> getAllByApprovalStatus(@RequestParam("approvalStatus") String approvalStatus) {
        List<DataChange> dataChangeList = DataChangeServices.getAllByApprovalStatus(approvalStatus);
        ResponseDTO<List<DataChange>> response = ResponseDTO.<List<DataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/deleteById/{id}")
    public ResponseEntity<ResponseDTO<String>> deleteById(@PathVariable("id") Long id) {
        String status = DataChangeServices.deleteById(id);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all/menu")
    public ResponseEntity<ResponseDTO<List<String>>> getAllMenu() {
        List<String> menuList = DataChangeServices.findAllMenu();
        ResponseDTO<List<String>> response = ResponseDTO.<List<String>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(menuList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/getByMenuAndStatus")
    public ResponseEntity<ResponseDTO<List<DataChange>>> getByMenuAndStatus(@RequestParam("menu") String menu,
                                                                                   @RequestParam("status") String status) {
        ApprovalStatus approvalStatus = ApprovalStatus.valueOf(status);
        List<DataChange> DataChangeList = DataChangeServices.findByMenuAndApprovalStatus(menu, approvalStatus);
        ResponseDTO<List<DataChange>> response = ResponseDTO.<List<DataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(DataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/checkIdDataChanges")
    public ResponseEntity<ResponseDTO<String>> checkIdDataChanges(@RequestBody List<Long> ids) {
        Boolean isExits = DataChangeServices.existByIdListAndStatus(ids, Long.valueOf(ids.size()), ApprovalStatus.Pending);

        if (!isExits)
            return ResponseEntity.status(HttpStatus.OK.value())
                    .body(ResponseDTO.<String>builder()
                            .code(HttpStatus.NOT_ACCEPTABLE.value())
                            .message(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase())
                            .payload("The ID data list does not match the data in the database.")
                            .build());

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping("/reject")
    public ResponseEntity<ResponseDTO<String>> doReject(@RequestBody RejectDataChangeRequest request, HttpServletRequest servletRequest){
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeServices.reject(request, clientIp);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }
}
