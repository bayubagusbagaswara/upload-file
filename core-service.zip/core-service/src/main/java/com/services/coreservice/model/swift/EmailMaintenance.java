package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.enums.TypeEmail;
import com.services.coreservice.model.base.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "swift_email_maintenance")
public class EmailMaintenance extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "swift_type")
    private SwiftType swiftType;

    @Column(name = "subject_email")
    private String subjectEmail;

    @Column(name = "body_email", columnDefinition = "nvarchar(max)")
    private String bodyEmail;

    @Enumerated(EnumType.STRING)
    @Column(name = "type_email" )
    private TypeEmail typeEmail;
}
