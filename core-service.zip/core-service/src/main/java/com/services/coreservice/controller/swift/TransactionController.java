package com.services.coreservice.controller.swift;

import com.services.coreservice.annotation.interfaces.Converting;
import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.approval.UpdateApprovalStatusRequest;
import com.services.coreservice.dto.swift.transaction.CreateTransactionListRequest;
import com.services.coreservice.dto.swift.transaction.TransactionResponse;
import com.services.coreservice.dto.swift.transaction.TransactionResponseDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.service.swift.TransactionServices;
import com.services.coreservice.utils.ClientIPUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/transaction")
public class TransactionController {
    @Autowired
    private TransactionServices transactionServices;

    @PostMapping(path = "/create-list")
    public ResponseEntity<ResponseDTO<TransactionResponse>> createList(@Converting @RequestBody CreateTransactionListRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        TransactionResponse createListResponse = transactionServices.createMultipleData(request, clientIp);
        ResponseDTO<TransactionResponse> response = ResponseDTO.<TransactionResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/byStatus")
    public ResponseEntity<ResponseDTO<List<TransactionResponseDTO>>> getByApprovalStatusOrderByContractNumberAsc(@RequestParam(value = "status") String status) {
        List<TransactionResponseDTO> dtoList = transactionServices.getByApprovalStatusOrderByContractNumberAsc(ApprovalStatus.valueOf(StringUtils.capitalize(status.toLowerCase())));
        ResponseDTO<List<TransactionResponseDTO>> response = ResponseDTO.<List<TransactionResponseDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/approval-status")
    public ResponseEntity<ResponseDTO<String>> updateApprovalStatus(@Converting @RequestBody UpdateApprovalStatusRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        String status = transactionServices.updateApprovalStatus(request, clientIp);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/checkIdTransactions")
    public ResponseEntity<ResponseDTO<String>> checkIdTransactions(@RequestBody List<Long> ids) {
        Boolean isExits = transactionServices.existByIdListAndStatus(ids, Long.valueOf(ids.size()), ApprovalStatus.Pending);

        if (!isExits)
            return ResponseEntity.status(HttpStatus.OK.value())
                    .body(ResponseDTO.<String>builder()
                            .code(HttpStatus.NOT_ACCEPTABLE.value())
                            .message(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase())
                            .payload("The ID data list does not match the data in the database.")
                            .build());

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }

}
