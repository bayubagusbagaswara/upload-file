package com.services.coreservice.scheduler.swift;

import com.services.coreservice.scheduler.swift.task.SwiftAckNackTrigger;
import com.services.coreservice.scheduler.swift.task.SwiftIncomingTrigger;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@EnableAsync
@RequiredArgsConstructor
public class SwiftSchedulerService {
    private final SwiftAckNackTrigger swiftAckNackTrigger;
    private final SwiftIncomingTrigger swiftIncomingTrigger;

//    @Async("asyncTaskExecutor") //Custom async thread pool bean name for running scheduler with fixedRate or fixedDelay
//    @Scheduled(fixedRateString = "${fixedRate.in.milliseconds}")
//    @Scheduled(cron = "${cron.expression}")
    @Scheduled(fixedDelayString = "${fixedDelay.in.milliseconds}", initialDelayString = "${initialDelay.in.milliseconds}")
    public void ackNackScheduler() throws InterruptedException {
        try {
            swiftAckNackTrigger.SwiftAckNackScheduler();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

//    @Async("asyncTaskExecutor") //Custom async thread pool bean name for running scheduler with fixedRate or fixedDelay
//    @Scheduled(fixedRateString = "${fixedRate.in.milliseconds}")
//    @Scheduled(cron = "${cron.expression}")
    @Scheduled(fixedDelayString = "${fixedDelay.in.milliseconds}", initialDelayString = "${initialDelay.in.milliseconds}")
    public void incomingScheduler() throws InterruptedException {
        try {
            swiftIncomingTrigger.SwiftIncomingScheduler();
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
