package com.services.coreservice.enums;

public enum ApprovalStatus {

	Pending("Pending"),
	Approved("Approved"),
	Rejected("Rejected");

	private final String status;

	ApprovalStatus(String status) {
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

}
