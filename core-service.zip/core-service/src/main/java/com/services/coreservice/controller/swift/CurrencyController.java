package com.services.coreservice.controller.swift;

import com.services.coreservice.annotation.interfaces.Converting;
import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.currency.*;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.service.swift.CurrencyServices;
import com.services.coreservice.utils.ClientIPUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/currency")
public class CurrencyController {
    @Autowired
    private CurrencyServices currencyServices;

    private static final String URL_CURRENCY = "/api/swift/currency";
    private static final String MENU_CURRENCY = "Currency";

    @PostMapping("/create")
    public ResponseEntity<ResponseDTO<CurrencyResponse>> create(@Converting @RequestBody CreateCurrencyRequest request, HttpServletRequest servletRequest)  {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(URL_CURRENCY + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CURRENCY)
                .build();
        CurrencyResponse createResponse = currencyServices.createSingleData(request, dataChangeDTO);
        ResponseDTO<CurrencyResponse> response = ResponseDTO.<CurrencyResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<CurrencyResponse>> createSingleApprove(@RequestBody CurrencyApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        CurrencyResponse listApprove = currencyServices.createSingleApprove(request, clientIp);
        ResponseDTO<CurrencyResponse> response = ResponseDTO.<CurrencyResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<CurrencyResponse>> updateSingleData(@RequestBody UpdateCurrencyRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_CURRENCY + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CURRENCY)
                .build();
        CurrencyResponse updateResponse = currencyServices.updateSingleData(request, dataChangeDTO);
        ResponseDTO<CurrencyResponse> response = ResponseDTO.<CurrencyResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<CurrencyResponse>> updateSingleApprove(@RequestBody CurrencyApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        CurrencyResponse updateListResponse = currencyServices.updateSingleApprove(request, clientIp);
        ResponseDTO<CurrencyResponse> response = ResponseDTO.<CurrencyResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<CurrencyResponse>> deleteSingleData(@RequestBody DeleteCurrencyRequest request) {
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(URL_CURRENCY + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CURRENCY)
                .build();
        CurrencyResponse deleteResponse = currencyServices.deleteSingleData(request, dataChangeDTO);
        ResponseDTO<CurrencyResponse> response = ResponseDTO.<CurrencyResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<CurrencyResponse>> deleteSingleApprove(@RequestBody CurrencyApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        CurrencyResponse deleteResponse = currencyServices.deleteSingleApprove(request, clientIp);
        ResponseDTO<CurrencyResponse> response = ResponseDTO.<CurrencyResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<CurrencyDTO>>> getAll() {
        List<CurrencyDTO> dtoList = currencyServices.getAll();
        ResponseDTO<List<CurrencyDTO>> response = ResponseDTO.<List<CurrencyDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDTO<CurrencyDTO>> getByCode(@RequestParam("code") String code) {
        CurrencyDTO data = currencyServices.findByCode(code);
        ResponseDTO<CurrencyDTO> response = ResponseDTO.<CurrencyDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<CurrencyDTO>> getById(@RequestParam("id") Long id) {
        CurrencyDTO data = currencyServices.findById(id);
        ResponseDTO<CurrencyDTO> response = ResponseDTO.<CurrencyDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }
}
