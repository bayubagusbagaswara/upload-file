package com.services.coreservice.repository.swift;

import com.services.coreservice.enums.TransactionType;
import com.services.coreservice.model.swift.ClearTypeParameter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClearTypeParameterRepository extends JpaRepository<ClearTypeParameter, Long> {
    ClearTypeParameter findByClearTypeAndTransactionType(String clearType, TransactionType transactionType);
}
