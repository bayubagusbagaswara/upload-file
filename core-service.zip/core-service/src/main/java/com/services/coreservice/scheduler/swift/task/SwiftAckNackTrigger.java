package com.services.coreservice.scheduler.swift.task;

import com.services.coreservice.utils.Swift.SwiftAckNackReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;

@Service
@Slf4j
public class SwiftAckNackTrigger {

    @Autowired
    private SwiftAckNackReader swiftAckNackReader;

    @Value("${base.path.acknack.swift}")
    private String ackNackPath;

    public void SwiftAckNackScheduler() throws InterruptedException{
        // Specify the directory to watch
        Path folderToWatch = Paths.get(ackNackPath);

        // Create a WatchService
        try (WatchService watchService = FileSystems.getDefault().newWatchService()) {
            // Register the directory with the WatchService for CREATE events
            folderToWatch.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
            log.info("Watching ACK-NACK Folder: " + folderToWatch);

            // Infinite loop to wait for events
            while (true) {
                WatchKey key;
                try {
                    // Wait for a key to be available
                    key = watchService.take();
                } catch (InterruptedException e) {
                    System.err.println("Interrupted Exception (ACK-NACK): " + e.getMessage());
                    return;
                }

                // Process the events for this key
                for (WatchEvent<?> event : key.pollEvents()) {
                    WatchEvent.Kind<?> kind = event.kind();

                    // Get the file name
                    WatchEvent<Path> ev = (WatchEvent<Path>) event;
                    Path fileName = ev.context();

                    log.info("ACK-NACK - pathFile: " + ackNackPath+fileName);

                    // You can also perform actions with the new file here
                    swiftAckNackReader.ackNackFileReader(ackNackPath+fileName);
                }

                // Reset the key to receive further events
                boolean valid = key.reset();
                if (!valid) {
                    break; // Exit the loop if the key is no longer valid
                }
            }
        } catch (IOException e) {
            System.err.println("IOException: " + e.getMessage());
        }
    }
}
