package com.services.coreservice.dto.swift.euroclear;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateEuroclearRequest {
    private String inputerId;
    private String inputerIPAddress;
    private Long id;
    private String code;
    private String bank;
}
