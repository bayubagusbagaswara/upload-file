package com.services.coreservice.dto.swift.registerEmail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateRegisterEmailRequest {
    private String inputerId;
    private String inputerIPAddress;
    @Pattern(regexp = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$", message = "Email must follow email address format!")
    @NotBlank(message = "Email Address cannot be empty!")
    private String emailAddress;
    @NotBlank(message = "Report Type cannot be empty!")
    private String reportType;
    @NotBlank(message = "Action cannot be empty!")
    private String action;
}
