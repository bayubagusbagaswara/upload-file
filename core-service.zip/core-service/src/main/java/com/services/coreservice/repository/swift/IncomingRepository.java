package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.Incoming;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncomingRepository extends JpaRepository<Incoming, Long> {
    boolean existsByReferenceTransaction(String reference);
}
