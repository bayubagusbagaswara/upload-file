package com.services.coreservice.dto.swift.emailMaintenance;

import com.services.coreservice.dto.swift.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmailMaintenanceDTO extends ApprovalDTO {
    private Long id;

    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Swift Type must contain only alphanumeric characters")
    @NotBlank(message = "Swift Type cannot be empty")
    private String swiftType;

    @NotBlank(message = "Subject Email cannot be empty")
    private String subjectEmail;

    @NotBlank(message = "Body Email cannot be empty")
    private String bodyEmail;

    @Pattern(regexp = "^[a-zA-Z]*$", message = "Swift Type must contain only alphabet characters")
    @NotBlank(message = "Type Email cannot be empty")
    private String typeEmail;
}
