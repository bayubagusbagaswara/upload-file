package com.services.coreservice.dto.swift.transaction;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.coreservice.annotation.interfaces.UpperCase;
import com.services.coreservice.dto.swift.approval.ApprovalDTO;
import com.services.coreservice.model.swift.Outgoing;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionResponseDTO extends ApprovalDTO {
    private Long id;
    private String contractNumber;
    private String tradeId;
    private String customer;
    private String tradeDate;
    private String settlementDate;
    private String matureDate;
    private String transactionType;
    private String securityCode;
    private String isinCode;
    private String currency;
    private String notional;
    private String price;
    private String proceeds;
    private String cleanPrice;
    private String trader;
    private String book;
    private String euroclearCode;
    private String bicCodeBdi;
    private Outgoing idOutgoing;
}
