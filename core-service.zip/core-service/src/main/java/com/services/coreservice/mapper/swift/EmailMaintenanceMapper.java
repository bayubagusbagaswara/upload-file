package com.services.coreservice.mapper.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.emailMaintenance.EmailMaintenanceDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.mapper.BaseMapper;
import com.services.coreservice.model.swift.EmailMaintenance;
import com.services.coreservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class EmailMaintenanceMapper extends BaseMapper<EmailMaintenance, EmailMaintenanceDTO> {
    private final ConvertDateUtil convertDateUtil;

    public EmailMaintenanceMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<EmailMaintenance, EmailMaintenanceDTO> getPropertyMap() {
        return new PropertyMap<EmailMaintenance, EmailMaintenanceDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<EmailMaintenance> getEntityClass() {
        return EmailMaintenance.class;
    }

    @Override
    protected Class<EmailMaintenanceDTO> getDtoClass() {
        return EmailMaintenanceDTO.class;
    }

    @Override
    protected void setCommonProperties(EmailMaintenance entity, DataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
//        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(convertDateUtil.getDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
//        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
