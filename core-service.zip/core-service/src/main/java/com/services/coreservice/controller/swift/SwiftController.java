package com.services.coreservice.controller.swift;

import com.services.coreservice.dto.swift.ResponseDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import static com.services.coreservice.utils.ClientIPUtil.getClientIp;

@RestController
@RequestMapping(path = "/api/swift")
@RequiredArgsConstructor
public class SwiftController {

    @GetMapping(path = "/helloWorld")
    public ResponseEntity<ResponseDTO<String>> getHelloWorld() {
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Hello World")
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/helloWorld")
    public ResponseEntity<ResponseDTO<String>> postHelloWorld(@RequestBody String helloWorld, HttpServletRequest request) {
        String remoteAddr = getClientIp(request);
        String remoteHost = request.getRemoteHost();
        String remoteUser = request.getRemoteUser();
        String contentType = request.getHeader("content-type");
        String userAgent = request.getHeader("user-agent");
        Integer remotePort = request.getRemotePort();
        String localAddr = request.getLocalAddr();
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(helloWorld + ",remoteAddr:" + remoteAddr + ",remoteHost:" + remoteHost
                        + ",remoteUser:" + remoteUser + ",contentType:" + contentType
                        + ",userAgent:" + userAgent + ",remotePort:" + remotePort + ",localAddr:" + localAddr)
                .build();
        return ResponseEntity.ok(response);
    }
}
