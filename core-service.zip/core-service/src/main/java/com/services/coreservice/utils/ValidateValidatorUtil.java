package com.services.coreservice.utils;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@RequiredArgsConstructor
@Slf4j
@Component
public class ValidateValidatorUtil<D> {
    private final Validator validator;
    public Errors validateUsingValidator(final D dto, final String objectName) {
        Errors errors = new BeanPropertyBindingResult(dto, objectName);
        validator.validate(dto, errors);
        return errors;
    }
}
