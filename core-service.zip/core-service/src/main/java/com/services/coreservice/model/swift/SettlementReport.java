package com.services.coreservice.model.swift;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_settlement_report")
public class SettlementReport {
    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

//    @OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "id_inc_info", referencedColumnName = "id")
//    private Incoming idIncInfo; //MT548

//    @OneToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "id_inc_conf", referencedColumnName = "id")
//    private Incoming idIncConfirmation; //MT545 & MT547

//    @Column(name = "generate_date")
    private LocalDateTime generateDate;

//    @Column(name = "isin_code")
    private String isinCode;

//    @Column(name = "note")
    private String note;

//    @Column(name = "transaction_type")
    private String transactionType;

//    @Column(name = "face_value")
    private BigDecimal faceValue;

    //Proceed in settlement report is Clean Price from Trx
//    @Column(name = "proceed_value")
    private BigDecimal proceedValue;

//    @Column(name = "trade_date")
    private LocalDate tradeDate;

//    @Column(name = "settle_date")
    private LocalDate settleDate;

//    @Column(name = "settle_amount")
    private BigDecimal settleAmount;

//    @Column(name = "unsettle_amount")
    private BigDecimal unsettleAmount;

//    @Column(name = "contact_number")
    private String contactNumber;

//    @Column(name = "unsettle_reason")
    private String unsettleReason;
}
