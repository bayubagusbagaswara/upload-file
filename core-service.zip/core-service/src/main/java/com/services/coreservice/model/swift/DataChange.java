package com.services.coreservice.model.swift;

import com.services.coreservice.enums.ChangeAction;
import com.services.coreservice.model.base.ApprovableDataChange;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "swift_data_changes")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DataChange extends ApprovableDataChange {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private ChangeAction action;

    @Column(name = "entity_class_name")
    private String entityClassName;

    @Column(name = "entity_id" )
    private String entityId;

    @Column(name = "table_name" )
    private String tableName;

    @Lob
    @Column(name = "data_before", columnDefinition = "nvarchar(max)")
    private String jsonDataBefore;

    @Lob
    @Column(name = "data_after", columnDefinition = "nvarchar(max)")
    private String jsonDataAfter;

    @Column(name = "description")
    private String description;

    @Column(name = "method")
    private String methodHttp;

    @Column(name = "endpoint")
    private String endpoint;

    @Column(name = "is_request_body")
    private Boolean isRequestBody;

    @Column(name = "is_request_param")
    private Boolean isRequestParam;

    @Column(name = "is_path_variable")
    private Boolean isPathVariable;

    @Column(name = "menu")
    private String menu;

}
