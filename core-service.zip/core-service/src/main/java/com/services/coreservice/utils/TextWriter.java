package com.services.coreservice.utils;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import static com.services.coreservice.utils.FileUtil.createFolder;

@Slf4j
@UtilityClass
public class TextWriter {
    public static String printText (String format, String text) {
        return String.format(format, text);
    }

    public static void generateTextFileFromSingleData (String folderPath, String fileName, String text, String format) {
        createFolder(folderPath);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FileUtil.getStrFullPath(folderPath, fileName)))) {
            writer.write(printText(format, text));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
