package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SwiftType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_incoming")
public class Incoming {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Lob
    @Column(name = "swift_format")
    private String swiftFormat;

    @Column(name = "sender_bank")
    private String senderBank;

    @Column(name = "receiver_bank")
    private String receiverBank;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_path")
    private String filePath;

    @Enumerated(EnumType.STRING)
    @Column(name = "swift_type")
    private SwiftType swiftType;

    @Column(name = "incoming_time")
    private LocalDateTime incomingTime;

    @Column(name = "incoming_type_data")
    private String incomingTypeData; //ACK or NACK or INC

    //Cuma ada untuk ACK, NACK dan MT548, MT547 dan MT545
    @Column(name = "reference_transaction")
    private String referenceTransaction;
}
