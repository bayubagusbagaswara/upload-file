package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum TransactionType {
    PURCHASE("P", "Purchase", "FI-PUR"),
    SALE("S", "Sale", "FI-SAL");

    private String code;
    private String name;
    private String reportSettleCode;

    public static TransactionType fromCode(String code) {
        for (TransactionType type : values()) {
            if (type.code.equals(code)) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }

}
