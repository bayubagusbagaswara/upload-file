package com.services.coreservice.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.swift.Transaction;
import com.services.coreservice.repository.swift.SenderReceiverBankRepository;
import com.services.coreservice.repository.swift.TransactionRepository;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateTimeConverter {
    public static LocalDate convertDate(String dateString){
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyMMdd");
        LocalDate date = LocalDate.parse(dateString, dateFormatter);
        return date;
    }

    public static LocalTime convertTime(String timeString){
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmm");
        LocalTime time = LocalTime.parse(timeString, timeFormatter);
        return time;
    }
}
