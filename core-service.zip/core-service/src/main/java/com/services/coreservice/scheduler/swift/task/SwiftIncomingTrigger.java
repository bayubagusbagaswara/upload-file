package com.services.coreservice.scheduler.swift.task;

import com.services.coreservice.utils.Swift.SwiftIncomingReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.*;

@Service
@Slf4j
public class SwiftIncomingTrigger {

    @Autowired
    private SwiftIncomingReader incomingReader;

    @Value("${base.path.incoming.swift}")
    private String pathInc;

    public void SwiftIncomingScheduler () throws InterruptedException{
        // Specify the directory to watch
        Path folderToWatch = Paths.get(pathInc);

        // Create a WatchService
        try (WatchService watchService = FileSystems.getDefault().newWatchService()) {
            // Register the directory with the WatchService for CREATE events
            folderToWatch.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
            log.info("Watching INCOMING Folder: " + folderToWatch);

            // Infinite loop to wait for events
            while (true) {
                WatchKey key;
                try {
                    key = watchService.take();
                } catch (InterruptedException e) {
                    System.err.println("Interrupted Exception (Incoming): " + e.getMessage());
                    return;
                }

                // Process the events for this key
                for (WatchEvent<?> event : key.pollEvents()) {
                    WatchEvent.Kind<?> kind = event.kind();

                    // Get the file name
                    WatchEvent<Path> ev = (WatchEvent<Path>) event;
                    Path fileName = ev.context();
                    log.info("INCOMING - pathFile: " + pathInc+fileName);

                    // You can also perform actions with the new file here
                    incomingReader.mtFileReader(pathInc+fileName);
                }

                // Reset the key to receive further events
                boolean valid = key.reset();
                if (!valid) {
                    break; // Exit the loop if the key is no longer valid
                }
            }
        } catch (IOException e) {
            System.err.println("IOException: " + e.getMessage());
        }
    }
}
