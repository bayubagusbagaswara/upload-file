package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.currency.CurrencyApproveRequest;
import com.services.coreservice.dto.swift.currency.CurrencyResponse;
import com.services.coreservice.dto.swift.currency.DeleteCurrencyRequest;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.euroclear.*;
import com.services.coreservice.model.swift.EuroclearCode;

import java.util.List;

public interface EuroclearCodeServices {
    List<EuroclearCode> getByCode(String code);

    EuroclearCode getById(Long id);

    EuroclearResponse createSingleData(CreateEuroclearRequest request, DataChangeDTO dataChangeDTO);

    EuroclearResponse createSingleApprove(EuroclearApproveRequest approveRequest, String clientIP);

    EuroclearResponse updateSingleData(UpdateEuroclearRequest request, DataChangeDTO dataChangeDTO);

    EuroclearResponse updateSingleApprove(EuroclearApproveRequest approveRequest, String clientIP);

    EuroclearResponse deleteSingleData(DeleteEuroclearRequest deleteRequest, DataChangeDTO dataChangeDTO);

    EuroclearResponse deleteSingleApprove(EuroclearApproveRequest approveRequest, String clientIP);

    List<EuroclearDTO> getAll();

    List<EuroclearDTO> findByCode(String code);

    EuroclearDTO findById(Long id);

}
