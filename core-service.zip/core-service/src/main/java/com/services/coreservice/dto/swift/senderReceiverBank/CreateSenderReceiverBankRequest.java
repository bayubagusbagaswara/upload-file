package com.services.coreservice.dto.swift.senderReceiverBank;

import com.services.coreservice.annotation.interfaces.UpperCase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateSenderReceiverBankRequest {
    private String inputerId;
    private String inputerIPAddress;
    @UpperCase
    private String code;
    private String name;
    private String type;
}
