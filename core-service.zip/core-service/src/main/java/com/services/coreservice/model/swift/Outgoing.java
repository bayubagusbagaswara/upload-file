package com.services.coreservice.model.swift;

import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.base.Approvable;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "swift_outgoing")
public class Outgoing extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "sender_bank")
    private String senderBank;

    @Column(name = "receiver_bank")
    private String receiverBank;

    @Column(name = "swift_format", columnDefinition = "nvarchar(max)")
    private String swiftFormat;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_path")
    private String filePath;

    @Enumerated(EnumType.STRING)
    @Column(name = "swift_type")
    private SwiftType swiftType;
}
