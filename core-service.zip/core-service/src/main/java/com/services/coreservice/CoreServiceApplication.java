package com.services.coreservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
public class CoreServiceApplication extends SpringBootServletInitializer {
    public static void main(String[] args) throws InterruptedException {
        SpringApplication.run(CoreServiceApplication.class, args);
    }
}
