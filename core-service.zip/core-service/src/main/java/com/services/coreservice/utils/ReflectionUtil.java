package com.services.coreservice.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

public class ReflectionUtil {

    public static List<Field> getAllFields(Object object) {
        List<Field> fields = new ArrayList<>();
        Class<?> clazz = object.getClass();
        while (clazz != null) {
            fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
            clazz = clazz.getSuperclass();
        }
        return fields;
    }

    public static Map<String, Object> getAllFieldValues(Object obj) throws IllegalAccessException {
        Map<String, Object> fieldValues = new HashMap<>();
        if (obj != null) {
            Class<?> clazz = obj.getClass();
            for (Field field : clazz.getDeclaredFields()) {
                field.setAccessible(true); // Make private fields accessible
                fieldValues.put(field.getName(), field.get(obj));
            }
        }
        return fieldValues;
    }

    // Method to get the value of a field using its name
    public static Object get(Object obj, String fieldName) {
        try {
            // Get the getter method for the field
            Method getter = obj.getClass().getMethod("get" + capitalize(fieldName));
            // Invoke the getter method and return the value
            return getter.invoke(obj);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to set the value of a field using its name
    public static void set(Object obj, String fieldName, Object value) {
        try {
            // Get the field to determine its type
            Field field = obj.getClass().getDeclaredField(fieldName);
            // Get the setter method for the field
            Method setter = obj.getClass().getMethod("set" + capitalize(fieldName), field.getType());
            // Invoke the setter method with the provided value
            setter.invoke(obj, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Helper method to capitalize the first letter of a string
    private static String capitalize(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
    public static Object getFieldValueByName(Object obj, String fieldName) {
        Object value = null;
        try {
            Field field = obj.getClass().getDeclaredField(fieldName);
            field.setAccessible(true); // Make private fields accessible
            value = field.get(obj);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return value;
    }

}
