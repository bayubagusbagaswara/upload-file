package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.SettlementReport;
import com.services.coreservice.model.swift.Transaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface SettlementReportRepository extends JpaRepository<SettlementReport, Long> {
    @Query(value="SELECT * FROM swift_transactions WHERE approval_status = 'Approved' AND settlement_date = :settleDate", nativeQuery = true)
    List<Transaction> listTransactionBySettleDate(@Param("settleDate") Date settleDate);

    @Query("SELECT u FROM SettlementReport u WHERE u.contactNumber = :reference")
    List<SettlementReport> listOfSettlementReportByReference(@Param("reference") String reference);
}
