package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum ReportType {
	Scheduler_MT540 ("Scheduler_540"),
	Scheduler_MT541 ("Scheduler_541"),
	Scheduler_MT542 ("Scheduler_542"),
	Scheduler_MT543 ("Scheduler_543"),
	Scheduler_MT545 ("Scheduler_545"),
	Scheduler_MT547 ("Scheduler_547"),
	Scheduler_MT548 ("Scheduler_548"),
	Scheduler_MT544 ("Scheduler_544"),
	Scheduler_MT546 ("Scheduler_546"),
	Scheduler_MT564 ("Scheduler_564"),
	Scheduler_MT566 ("Scheduler_566"),
	Scheduler_MT567 ("Scheduler_567"),
	Scheduler_MT568 ("Scheduler_568"),
	Scheduler_MT999 ("Scheduler_999"),
	Report_Settlement ("Report_Settlement");

	private String value;
}
