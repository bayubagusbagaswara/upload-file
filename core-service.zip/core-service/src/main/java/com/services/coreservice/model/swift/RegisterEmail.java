package com.services.coreservice.model.swift;

import com.services.coreservice.enums.ActionEmail;
import com.services.coreservice.enums.ReportType;
import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.base.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "swift_register_email")
public class RegisterEmail extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "email_address")
    private String emailAddress;

    @Enumerated(EnumType.STRING)
    @Column(name = "report_type" )
    private ReportType reportType;

    @Enumerated(EnumType.STRING)
    @Column(name = "action" )
    private ActionEmail action;
}
