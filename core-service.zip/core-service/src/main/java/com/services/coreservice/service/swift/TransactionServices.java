package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.approval.UpdateApprovalStatusRequest;
import com.services.coreservice.dto.swift.transaction.CreateTransactionListRequest;
import com.services.coreservice.dto.swift.transaction.TransactionResponse;
import com.services.coreservice.dto.swift.transaction.TransactionResponseDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.model.swift.Transaction;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface TransactionServices {
    TransactionResponse createMultipleData(CreateTransactionListRequest listRequest, String clientIp);

    Transaction getTransactionRecord(String reference);

    List<TransactionResponseDTO> getByApprovalStatusOrderByContractNumberAsc(ApprovalStatus approvalStatus);

    String updateApprovalStatus(UpdateApprovalStatusRequest request, String clientIp);

    Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus status);

}
