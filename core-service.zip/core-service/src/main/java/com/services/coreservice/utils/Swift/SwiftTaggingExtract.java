package com.services.coreservice.utils.Swift;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.services.coreservice.enums.SettlementStatusEnum;
import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.swift.Incoming;
import com.services.coreservice.model.swift.SchedulerReport;
import com.services.coreservice.model.swift.Transaction;
import com.services.coreservice.repository.swift.IncomingRepository;
import com.services.coreservice.repository.swift.SchedulerReportRepository;
import com.services.coreservice.repository.swift.SenderReceiverBankRepository;
import com.services.coreservice.repository.swift.TransactionRepository;
import com.services.coreservice.utils.DateTimeConverter;
import com.services.coreservice.utils.StringPadder;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SwiftTaggingExtract {

    private static ObjectMapper mapper = new ObjectMapper();

    public static String headerBlock1F21(String mtData){
        String receiverCode = StringUtils.substringAfterLast(mtData, "{1:F21");
        String bankCode = receiverCode.substring(0, 8);
        String branchCode = receiverCode.substring(9, 12);
        String receiverBank = bankCode + branchCode;
//        String receiverFileIncoming = SwiftTaggingExtract.receiverMtForCustody(receiverBank);
//        System.out.println("receiverFileIncoming: " + receiverFileIncoming);
        return receiverBank;
    }

    public static LocalDateTime headerBlock1177(String line){
        String dateTimeIncoming = StringUtils.substringAfterLast(line, "{177:");
        String date = dateTimeIncoming.substring(0, 6);
        String time = dateTimeIncoming.substring(6, 10);
        LocalDate incomingDate = DateTimeConverter.convertDate(date);
        LocalTime incomingTime = DateTimeConverter.convertTime(time);
        LocalDateTime dateTime = LocalDateTime.of(incomingDate, incomingTime);
        return dateTime;
    }

    public static String headerBlock1451(String line){
        String ackNackLine = StringUtils.substringAfterLast(line, "{451:");
        String ackNackNr = ackNackLine.substring(0, 1);
        String ackNack;
        if (ackNackNr.equalsIgnoreCase("0")){
            ackNack = "ACK";
        } else ackNack = "NACK";
        return ackNack;
    }

    public static SwiftType headerBlock12MT(String line){
        String ackNackLine = StringUtils.substringAfterLast(line, "{2:");
        String incOut = ackNackLine.substring(0, 1); //I = Input ke SWIFT (Outgoing) - O = Output dari SWIFT (Incoming)
        String swiftTypeStr = ackNackLine.substring(1, 4);
        SwiftType mt = getSwiftType(swiftTypeStr);
        System.out.println("SwiftType: MT " + mt.getValue());
        return mt;
    }

    public static String headerBlock12Sender(String line){
        String senderCode = StringUtils.substringAfterLast(line, "{2:");
        String bankCode = senderCode.substring(14, 22);
        String branchCode = senderCode.substring(23, 26);
        String sender = bankCode + branchCode;
        return sender;
    }

    public static String tag20(String line){
        String referenceLine = StringUtils.substringAfterLast(line, "//");
        return referenceLine;
    }

    public ObjectNode tag25D(String line){
        String statusSettle = StringUtils.substringAfterLast(line, ":");
        String qualifier = statusSettle.substring(0, 4);
        String statusCode = statusSettle.substring(6, 10);

        ObjectNode tag25D = mapper.createObjectNode();
        tag25D.put("qualifier", qualifier);
        tag25D.put("statusCode", statusCode);
        System.out.println("Tag 25D: " + tag25D);
        return tag25D;
    }

    public static ObjectNode tag24B(String line){
        String statusSettle = StringUtils.substringAfterLast(line, ":");
        String qualifier = statusSettle.substring(0, 4);
        String statusCode = statusSettle.substring(6, 10);

        ObjectNode tag24B = mapper.createObjectNode();
        tag24B.put("qualifier", qualifier);
        tag24B.put("statusCode", statusCode);
        System.out.println("Tag 24B: " + tag24B);
        return tag24B;
    }

    public ObjectNode tag19A(String line){
        String tagAmount = StringUtils.substringAfterLast(line, ":");
        String qualifier = tagAmount.substring(0, 4);
        String currency = tagAmount.substring(6, 9);
        String amount = getValueFromPattern("\\d+(,\\d+)?", tagAmount.trim());

        ObjectNode tag19A = mapper.createObjectNode();
        tag19A.put("qualifier", qualifier);
        tag19A.put("currency", currency);
        tag19A.put("amount", amount);
        System.out.println("Tag 19A: " + tag19A);
        return tag19A;
    }

    public static String getValueFromPattern (String regex, String line){
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(line);
        String value = "";
        if (matcher.find()) {
            value =  matcher.group();
        }
        return value;
    }

    public static String getValueInSpecificSequence(String mainString, String value1, String value2){
        String result = "";
        int index1 = mainString.indexOf(value1);
        if (index1 != -1) {
            index1 += value1.length();
            int index2 = mainString.indexOf(value2, index1);
            if (index2 != -1) {
                result = mainString.substring(index1, index2).trim();
            }
        }
        return result;
    }

    public static SwiftType getSwiftType (String swiftTypeStr){
        SwiftType swiftType = null;
        switch (swiftTypeStr) {
            case ("540"):
                swiftType = SwiftType.MT540;
                break;
            case ("541"):
                swiftType = SwiftType.MT541;
                break;
            case ("542"):
                swiftType = SwiftType.MT542;
                break;
            case ("543"):
                swiftType = SwiftType.MT543;
                break;
            case ("545"):
                swiftType = SwiftType.MT545;
                break;
            case ("547"):
                swiftType = SwiftType.MT547;
                break;
            case ("548"):
                swiftType = SwiftType.MT548;
                break;
            case ("544"):
                swiftType = SwiftType.MT544;
                break;
            case ("546"):
                swiftType = SwiftType.MT546;
                break;
            case ("564"):
                swiftType = SwiftType.MT564;
                break;
            case ("566"):
                swiftType = SwiftType.MT566;
                break;
            case ("567"):
                swiftType = SwiftType.MT567;
                break;
            case ("568"):
                swiftType = SwiftType.MT568;
                break;
            case ("999"):
                swiftType = SwiftType.MT999;
                break;
        }
        return swiftType;
    }
}
