package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Optional<Book> findByCode (final String code);

    boolean existsByCode(String code);
}
