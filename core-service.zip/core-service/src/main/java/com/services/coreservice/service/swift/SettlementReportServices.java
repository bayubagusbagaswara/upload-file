package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.ResponseDTO;
import org.springframework.http.ResponseEntity;

public interface SettlementReportServices {

    ResponseEntity<ResponseDTO<byte[]>> dowloadFileInterface(String date);
}
