package com.services.coreservice.service.swift.impl;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.datachange.RejectDataChangeRequest;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.enums.ChangeAction;
import com.services.coreservice.exception.DataNotFoundException;
import com.services.coreservice.exception.InvalidInputException;
import com.services.coreservice.model.swift.DataChange;
import com.services.coreservice.repository.swift.DataChangeRepository;
import com.services.coreservice.service.swift.DataChangeServices;
import com.services.coreservice.utils.ConvertDateUtil;
import com.services.coreservice.utils.StringUtil;
import com.services.coreservice.utils.TableNameResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class DataChangeServicesImpl implements DataChangeServices {
    @Autowired
    private DataChangeRepository dataChangeRepository;
    @Autowired
    ConvertDateUtil convertDateUtil;
    
    private static final String ERROR_MSG_NOT_FOUND_ID = "Data Change not found with id: ";

    @Override
    public DataChangeDTO getById(Long id) {
        DataChange dataChange = dataChangeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + id));
        return mapToDTO(dataChange);
    }

    @Override
    public List<DataChange> getAll() {
        return dataChangeRepository.findAll();
    }

    @Override
    public String deleteAll() {
        dataChangeRepository.deleteAll();
        return "Successfully delete all data change from table";
    }

    @Override
    public <T> void createChangeActionADD(DataChangeDTO dataChangeDTO, Class<T> clazz) {
        DataChange dataChange = DataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(dataChangeDTO.getInputerId())
                .inputDate(new Date())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Add)
                .entityId("")
                .entityClassName(clazz.getName())
                .tableName(TableNameResolver.getTableName(clazz))
                .jsonDataBefore("")
                .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
        dataChangeRepository.save(dataChange);
    }

    @Override
    public List<String> findAllMenu() {
        return dataChangeRepository.findAllMenu();
    }

    @Override
    public void approvalStatusIsRejected(DataChangeDTO dataChangeDTO, List<String> errorMessageList) {
        DataChange dataChange = dataChangeRepository.findById(dataChangeDTO.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + dataChangeDTO.getId()));

        dataChange.setApprovalStatus(ApprovalStatus.Rejected);
        dataChange.setApproverId(dataChangeDTO.getApproverId());
        dataChange.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        dataChange.setApproveDate(dataChangeDTO.getApproveDate() == null ? new Date() : dataChangeDTO.getApproveDate());
        dataChange.setJsonDataAfter(dataChangeDTO.getJsonDataAfter() == null ? "" : dataChangeDTO.getJsonDataAfter());
        dataChange.setJsonDataBefore(dataChangeDTO.getJsonDataBefore() == null ? "" : dataChangeDTO.getJsonDataBefore());
        dataChange.setEntityId(dataChangeDTO.getEntityId() == null ? "" : dataChangeDTO.getEntityId());
        dataChange.setDescription(StringUtil.joinStrings(errorMessageList));

        dataChangeRepository.save(dataChange);
    }

    @Override
    public void approvalStatusIsApproved(DataChangeDTO dataChangeDTO) {
        DataChange dataChange = dataChangeRepository.findById(dataChangeDTO.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + dataChangeDTO.getId()));

        dataChange.setApprovalStatus(ApprovalStatus.Approved);
        dataChange.setApproverId(dataChangeDTO.getApproverId());
        dataChange.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        dataChange.setApproveDate(dataChangeDTO.getApproveDate() == null ? new Date() : dataChangeDTO.getApproveDate());
        dataChange.setJsonDataAfter(dataChangeDTO.getJsonDataAfter() == null ? "" : dataChangeDTO.getJsonDataAfter());
        dataChange.setJsonDataBefore(dataChangeDTO.getJsonDataBefore() == null ? "" : dataChangeDTO.getJsonDataBefore());
        dataChange.setEntityId(dataChangeDTO.getEntityId());
        dataChange.setDescription(dataChangeDTO.getDescription());

        DataChange save = dataChangeRepository.save(dataChange);
        log.info("Save data change edit: {}", save);
    }

    @Override
    public <T> void createChangeActionEDIT(DataChangeDTO dataChangeDTO, Class<T> clazz) {
        DataChange dataChange = DataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(dataChangeDTO.getInputerId())
                .inputDate(new Date())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Edit)
                .entityId(dataChangeDTO.getEntityId())
                .entityClassName(clazz.getName())
                .tableName(TableNameResolver.getTableName(clazz))
                .jsonDataBefore(dataChangeDTO.getJsonDataBefore())
                .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
        DataChange save = dataChangeRepository.save(dataChange);
    }

    @Override
    public <T> void createChangeActionListEDIT(List<DataChangeDTO> dataChangeDTOList, Class<T> clazz) {
        List<DataChange> dataChangeList = new ArrayList<>();
        for (DataChangeDTO dataChangeDTO : dataChangeDTOList){
            DataChange dataChange = DataChange.builder()
                    .approvalStatus(ApprovalStatus.Pending)
                    .inputerId(dataChangeDTO.getInputerId())
                    .inputDate(new Date())
                    .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                    .approverId("")
                    .approveDate(null)
                    .approverIPAddress("")
                    .action(ChangeAction.Edit)
                    .entityId(dataChangeDTO.getEntityId())
                    .entityClassName(clazz.getName())
                    .tableName(TableNameResolver.getTableName(clazz))
                    .jsonDataBefore(dataChangeDTO.getJsonDataBefore())
                    .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                    .description("")
                    .methodHttp(dataChangeDTO.getMethodHttp())
                    .endpoint(dataChangeDTO.getEndpoint())
                    .isRequestBody(dataChangeDTO.isRequestBody())
                    .isRequestParam(dataChangeDTO.isRequestParam())
                    .isPathVariable(dataChangeDTO.isPathVariable())
                    .menu(dataChangeDTO.getMenu())
                    .build();
            dataChangeList.add(dataChange);
        }
        dataChangeRepository.saveAll(dataChangeList);
    }

    @Override
    public <T> void createChangeActionDELETE(DataChangeDTO dataChangeDTO, Class<T> clazz) {
        DataChange dataChange = DataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(dataChangeDTO.getInputerId())
                .inputDate(new Date())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Delete)
                .entityId(dataChangeDTO.getEntityId())
                .entityClassName(clazz.getName())
                .tableName(TableNameResolver.getTableName(clazz))
                .jsonDataBefore(dataChangeDTO.getJsonDataBefore())
                .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
        dataChangeRepository.save(dataChange);
    }

    @Override
    public <T> void createChangeActionListDELETE(List<DataChangeDTO> dataChangeDTOList, Class<T> clazz) {
        List<DataChange> dataChangeList = new ArrayList<>();
        for (DataChangeDTO dataChangeDTO : dataChangeDTOList){
            DataChange dataChange = DataChange.builder()
                    .approvalStatus(ApprovalStatus.Pending)
                    .inputerId(dataChangeDTO.getInputerId())
                    .inputDate(new Date())
                    .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                    .approverId("")
                    .approveDate(null)
                    .approverIPAddress("")
                    .action(ChangeAction.Delete)
                    .entityId(dataChangeDTO.getEntityId())
                    .entityClassName(clazz.getName())
                    .tableName(TableNameResolver.getTableName(clazz))
                    .jsonDataBefore(dataChangeDTO.getJsonDataBefore())
                    .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                    .description("")
                    .methodHttp(dataChangeDTO.getMethodHttp())
                    .endpoint(dataChangeDTO.getEndpoint())
                    .isRequestBody(dataChangeDTO.isRequestBody())
                    .isRequestParam(dataChangeDTO.isRequestParam())
                    .isPathVariable(dataChangeDTO.isPathVariable())
                    .menu(dataChangeDTO.getMenu())
                    .build();
            dataChangeList.add(dataChange);
        }
        dataChangeRepository.saveAll(dataChangeList);
    }

    @Override
    public Boolean existByIdList(List<Long> idList, Integer idListSize) {
        Boolean existsByIdList = dataChangeRepository.existsByIdList(idList, idListSize);
        log.info("Status Exist by Id list: {}", existsByIdList);
        return existsByIdList;
    }

    @Override
    public Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus status) {
        Boolean existsByIdList = dataChangeRepository.existsByIdListAndStatus(idList, idListSize, status);
        log.info("Status Exist by Id list: {}", existsByIdList);
        return existsByIdList;
    }

    @Override
    public boolean areAllIdsExistInDatabase(List<Long> idList) {
        long countOfExistingIds = dataChangeRepository.countByIdIn(idList);
        List<DataChange> existingDataChanges = dataChangeRepository.findByIdIn(idList);
        Set<Long> existingIds = existingDataChanges.stream()
                .map(DataChange::getId)
                .collect(Collectors.toSet());
        Set<Long> idSet = new HashSet<>(idList);
        return existingIds.equals(idSet) && countOfExistingIds == idList.size();
    }

    @Override
    public boolean existById(Long id) {
        return dataChangeRepository.existsById(id);
    }

    @Override
    public void update(DataChangeDTO dataChangeDTO) {
        log.info("Data Change dto: {}", dataChangeDTO);
        DataChange dataChange = dataChangeRepository.findById(dataChangeDTO.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + dataChangeDTO.getId()));
        log.info("Data Change: {}", dataChangeDTO);

        dataChange.setApprovalStatus(dataChangeDTO.getApprovalStatus());
        dataChange.setInputerId(dataChangeDTO.getInputerId());
        dataChange.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        dataChange.setInputDate(dataChangeDTO.getInputDate());
        dataChange.setApproverId(dataChangeDTO.getApproverId());
        dataChange.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        dataChange.setApproveDate(dataChangeDTO.getApproveDate());
        dataChange.setDescription(dataChangeDTO.getDescription());
        if (!dataChangeDTO.getJsonDataAfter().isEmpty()) {
            dataChange.setJsonDataAfter(dataChangeDTO.getJsonDataAfter());
        }
        if (!dataChangeDTO.getJsonDataBefore().isEmpty()) {
            dataChange.setJsonDataBefore(dataChangeDTO.getJsonDataBefore());
        }

        dataChangeRepository.save(dataChange);
    }

    @Override
    public List<DataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus) {
        return dataChangeRepository.findByMenuAndApprovalStatus(menu, approvalStatus);
    }

    @Override
    public void reject(RejectDataChangeRequest request, String clientIp) {
        DataChange dataChange = dataChangeRepository.findById(request.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + request.getId()));
        dataChange.setApprovalStatus(ApprovalStatus.Rejected);
        dataChange.setApproveDate(convertDateUtil.getDate());
        dataChange.setApproverId(request.getApproverId());
        dataChange.setApproverIPAddress(clientIp);
        dataChangeRepository.save(dataChange);
    }

    @Override
    public List<DataChange> getAllByApprovalStatus(String approvalStatus) {
        // validate approvalStatus
        String approvalStatusEnum;
        if (ApprovalStatus.Pending.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = ApprovalStatus.Pending.name();
        } else if (ApprovalStatus.Approved.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = ApprovalStatus.Approved.name();
        } else if (ApprovalStatus.Rejected.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = ApprovalStatus.Rejected.name();
        } else {
            approvalStatusEnum = "";
        }

        if (approvalStatusEnum.isEmpty()) {
            throw new InvalidInputException("Approval Status enum not found: " + approvalStatus);
        }
        return dataChangeRepository.findAllByApprovalStatus(approvalStatusEnum);
    }

    @Override
    public String deleteById(Long id) {
        DataChange dataChange = dataChangeRepository.findById(id).orElseThrow(() -> new DataNotFoundException("Data Change not found with id: " + id));
        dataChangeRepository.delete(dataChange);
        return "Successfully delete Data Change with id: " + id;
    }

    private static DataChangeDTO mapToDTO(DataChange dataChange) {
        return DataChangeDTO.builder()
                .id(dataChange.getId())
                .approvalStatus(dataChange.getApprovalStatus())
                .inputerId(dataChange.getInputerId())
                .inputerIPAddress(dataChange.getInputerIPAddress())
                .inputDate(dataChange.getInputDate())
                .approverId(dataChange.getApproverId())
                .approverIPAddress(dataChange.getApproverIPAddress())
                .approveDate(dataChange.getApproveDate())
                .action(dataChange.getAction())
                .entityId(dataChange.getEntityId())
                .entityClassName(dataChange.getEntityClassName())
                .tableName(dataChange.getTableName())
                .jsonDataBefore(dataChange.getJsonDataBefore())
                .jsonDataAfter(dataChange.getJsonDataAfter())
                .description(dataChange.getDescription())
                .methodHttp(dataChange.getMethodHttp())
                .endpoint(dataChange.getEndpoint())
                .isRequestBody(dataChange.getIsRequestBody())
                .isRequestParam(dataChange.getIsRequestParam())
                .isPathVariable(dataChange.getIsPathVariable())
                .menu(dataChange.getMenu())
                .build();
    }

//    private static List<DataChangeDTO> mapToDTOList(List<DataChange> dataChangeList) {
//        return dataChangeList.stream()
//                .map(DataChangeServiceImpl::mapToDTO)
//                .collect(Collectors.toList());
//    }

}
