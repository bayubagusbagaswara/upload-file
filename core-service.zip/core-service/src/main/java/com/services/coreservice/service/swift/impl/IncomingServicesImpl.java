package com.services.coreservice.service.swift.impl;

import com.services.coreservice.repository.swift.IncomingRepository;
import com.services.coreservice.service.swift.IncomingServices;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class IncomingServicesImpl implements IncomingServices {
    @Autowired
    private IncomingRepository incomingRepository;
}
