package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.book.*;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;

import java.util.List;

public interface BookServices {
    BookResponse createSingleData(final CreateBookRequest request, final DataChangeDTO dataChangeDTO);

    BookResponse createSingleApprove(BookApproveRequest approveRequest, String clientIP);

    BookResponse updateSingleData(UpdateBookRequest request, DataChangeDTO dataChangeDTO);

    BookResponse updateSingleApprove(BookApproveRequest approveRequest, String clientIP);

    BookResponse deleteSingleData(DeleteBookRequest deleteRequest, DataChangeDTO dataChangeDTO);

    BookResponse deleteSingleApprove(BookApproveRequest approveRequest, String clientIP);

    List<BookDTO> getAll();

    BookDTO findByCode(String code);

    BookDTO findById(Long id);
}
