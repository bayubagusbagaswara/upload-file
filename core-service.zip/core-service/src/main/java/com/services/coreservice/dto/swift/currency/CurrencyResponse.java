package com.services.coreservice.dto.swift.currency;

import com.services.coreservice.dto.swift.ErrorMessageDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyResponse {
    private Integer totalDataSuccess;
    private Integer totalDataFailed;
    private List<ErrorMessageDTO> errorMessageDTOList;
}
