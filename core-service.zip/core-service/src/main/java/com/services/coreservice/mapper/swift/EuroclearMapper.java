package com.services.coreservice.mapper.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.euroclear.EuroclearDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.mapper.BaseMapper;
import com.services.coreservice.model.swift.EuroclearCode;
import com.services.coreservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class EuroclearMapper extends BaseMapper<EuroclearCode, EuroclearDTO> {

    private final ConvertDateUtil convertDateUtil;

    public EuroclearMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<EuroclearCode, EuroclearDTO> getPropertyMap() {
        return new PropertyMap<EuroclearCode, EuroclearDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<EuroclearCode> getEntityClass() {
        return EuroclearCode.class;
    }

    @Override
    protected Class<EuroclearDTO> getDtoClass() {
        return EuroclearDTO.class;
    }

    @Override
    protected void setCommonProperties(EuroclearCode entity, DataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
//        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(convertDateUtil.getDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
//        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
