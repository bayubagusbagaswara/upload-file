package com.services.coreservice.utils;

public class UserIdUtil {
   private static ThreadLocal<String> userIdLocal = new ThreadLocal<>();

    public static  void setUserId(String userid) {
        userIdLocal.set(userid);
    }
    public static String getUser() {
        return userIdLocal.get();
    }
    public static void clearUserId(){
        userIdLocal.remove();
    }
}
