package com.services.coreservice.service.swift.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.coreservice.dto.swift.ErrorMessageDTO;
import com.services.coreservice.dto.swift.approval.UpdateApprovalStatusRequest;
import com.services.coreservice.dto.swift.transaction.*;
import com.services.coreservice.enums.*;
import com.services.coreservice.exception.DataNotFoundException;
import com.services.coreservice.exception.UnexpectedException;
import com.services.coreservice.mapper.swift.TransactionMapper;
import com.services.coreservice.model.swift.ClearTypeParameter;
import com.services.coreservice.model.swift.Outgoing;
import com.services.coreservice.model.swift.Transaction;
import com.services.coreservice.repository.rb.SecurityRepository;
import com.services.coreservice.repository.swift.*;
import com.services.coreservice.service.swift.TransactionServices;
import com.services.coreservice.utils.ConvertDateUtil;
import com.services.coreservice.utils.ReflectionUtil;
import com.services.coreservice.utils.TextWriter;
import com.services.coreservice.utils.ValidateValidatorUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TransactionServicesImpl implements TransactionServices {
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private EuroclearCodeRepository euroclearCodeRepository;
    @Autowired
    private SecurityRepository securityRepository;
    @Autowired
    private BicCodeRepository bicCodeRepository;
    @Autowired
    private SenderReceiverBankRepository senderReceiverBankRepository;
    @Autowired
    private OutgoingRepository outgoingRepository;
    @Autowired
    private MessageTypeTemplateRepository messageTypeTemplateRepository;
    @Autowired
    private ClearTypeParameterRepository clearTypeParameterRepository;
    @Autowired
    private TransactionMapper transactionMapper;
    @Autowired
    private ValidateValidatorUtil<TransactionDTO> validateValidatorUtil;
    @Autowired
    private ConvertDateUtil convertDateUtil;

    private ObjectMapper objectMapper = new ObjectMapper();
    private ModelMapper modelMapper = new ModelMapper();
    private static final String UNKNOWN = "unknown";
    private static final String REGEX_1 = "\\{([^}]*)\\}";
    private static final String REGEX_2 = "\\<([^>]*)\\>";
    private static final String OPEN_1 = "{";
    private static final String CLOSE_1 = "}";
    private static final String OPEN_2 = "<";
    private static final String CLOSE_2 = ">";
    private static final String NEXT_ITERATE = "$";
    private static final String FORMAT_ANY_TYPE = "%s";
    @Value("${base.path.outgoing.swift}")
    private String pathFolderOutgoing;

    @Override
    public TransactionResponse createMultipleData(CreateTransactionListRequest listRequest, String clientIp) {
        log.info("Create Transaction multiple data with request: {}", listRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        List<Outgoing> outgoings = new ArrayList<>();
        List<Transaction> transactions = new ArrayList<>();

        /* validation Sender Receiver already exists */
        validationIsExistsSenderCode(listRequest.getSender(), validationErrors);
        validationIsExistsReceiverCode(listRequest.getReceiver(), validationErrors);
        if (!validationErrors.isEmpty()) {
            ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(null, validationErrors);
            errorMessageDTOList.add(errorMessageDTO);
            totalDataFailed = listRequest.getCreateUploadDataListRequests().size() > 0
                    ? listRequest.getCreateUploadDataListRequests().size() : 1;
            return new TransactionResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
        }

        /* repeat data one by one */
        for (CreateUploadTransactionListRequest request : listRequest.getCreateUploadDataListRequests()) {
            List<String> validationErrorsTemp = new ArrayList<>();
            TransactionDTO dto = null;
            String swiftType = null;
            try {
                /* Define Swift Type */
                if (request.getTransactionType().equalsIgnoreCase(TransactionType.PURCHASE.getCode())){
                    swiftType = SwiftType.MT541.toString();
                } else if (request.getTransactionType().equalsIgnoreCase(TransactionType.SALE.getCode())) {
                    swiftType = SwiftType.MT543.toString();
                }

                /* mapping data from request to dto */
                dto = transactionMapper.mapCreateListRequestToDTO(request);

                /* validating for each column dto */
                Errors errors = validateValidatorUtil.validateUsingValidator(dto, "TransactionDTO");
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrorsTemp.add(error.getDefaultMessage()));
                }

                /* validation contract number already exists */
                validationContractNumberAlreadyExists(dto.getContractNumber(), validationErrorsTemp);

                /* validation MATDATE greater than SETTLEDATE greater than TRADEDATE */
                validationCompareAllDateColumn(dto, validationErrorsTemp);

                /* validation security code and ISIN Number already exists */
//                validationIsExistsSecurityAndIsinCode(dtoSave.getSecurityCode(), dtoSave.getIsinCode(), validationErrorsTemp);

                /* validation ISIN Number already exists */
                validationIsExistsIsinCode(dto.getIsinCode(), validationErrorsTemp);

                /* validation currency is exists */
                validationIsExistsCurrency(dto.getCurrency(), validationErrorsTemp);

                /* validation BOOK code already exists */
                validationIsExistsBook(dto.getBook(), validationErrorsTemp);

                /* validation euroclear code and bank already exists */
                validationIsExistsEuroclearCodeAndBank(dto.getEuroclearCode(), dto.getCustomer(), validationErrorsTemp);

                /* validation bic code already exists */
                validationIsExistsBicCode(dto.getBicCodeBdi(), validationErrorsTemp);

                /* set data input id to dto */
                dto.setInputerId(listRequest.getInputerId());
                dto.setInputerIPAddress(clientIp);
                dto.setInputDate(convertDateUtil.getStringDate());

                /* create swift object to fill it into swift outgoing data from MT Template */
                String swiftFormat = swiftFormatProcess(swiftType, listRequest, dto);

                /* create swift data outgoing */
                Outgoing outgoing = new Outgoing();
                outgoing.setSenderBank(listRequest.getSender());
                outgoing.setReceiverBank(listRequest.getReceiver());
                outgoing.setSwiftFormat(swiftFormat);
                outgoing.setSwiftType(SwiftType.valueOf(swiftType));
                outgoing.setInputerId(listRequest.getInputerId());
                outgoing.setInputDate(new Date());
                outgoing.setApprovalStatus(ApprovalStatus.Pending);
                outgoings.add(outgoing);

                /* check validation errors for custom response */
                if (validationErrorsTemp.isEmpty()) {
                    Transaction transaction = new Transaction();
                    transactionMapper.mapObjectsDtoToEntity(dto, transaction);
                    transaction.setIdOutgoing(outgoing);
                    transaction.setInputerId(listRequest.getInputerId());
                    transaction.setInputDate(new Date());
                    transaction.setApprovalStatus(ApprovalStatus.Pending);
                    transaction.setSendingSwift(SendingSwiftEnum.PENDING);
                    transactions.add(transaction);
                    totalDataSuccess++;
                } else {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(dto.getContractNumber(), validationErrorsTemp);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(dto, e, validationErrorsTemp, errorMessageDTOList);
                totalDataFailed++;
            }
            validationErrors.addAll(validationErrorsTemp);
        }

        /* Saving The Data */
        try {
            saveData(validationErrors, transactions, outgoings);
        } catch (Exception e) {
            List<String> validationErrorsTemp = new ArrayList<>();
            validationErrorsTemp.add("Error when saving transaction data.");
            handleSavingError(new TransactionDTO(), e, validationErrorsTemp, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }

        return new TransactionResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public Transaction getTransactionRecord(String reference){
        Transaction transaction = transactionRepository.searchByContactNumber(reference);
        if(transaction == null){
            transaction = null;
        } else {
            System.out.println("transactionReference: " + reference);
        }
        return transaction;
    }
    private String swiftFormatProcess(String swiftType, CreateTransactionListRequest listRequest, TransactionDTO dto) {
        String swiftFormat = "";
        String block1 = blockSenderProcess(swiftType, listRequest.getSender());
        String block2 = blockReceiverProcess(swiftType, listRequest.getReceiver());
        String block3 = blockFromRequestProcess(swiftType, dto, "block3", TransactionType.fromCode(dto.getTransactionType()));
        String block4 = blockFromRequestProcess(swiftType, dto, "block4", TransactionType.fromCode(dto.getTransactionType()));
        String block5 = blockFromRequestProcess(swiftType, dto, "block5", TransactionType.fromCode(dto.getTransactionType()));

        if (!StringUtils.isEmpty(block1)) swiftFormat += OPEN_1 + block1 + CLOSE_1;
        if (!StringUtils.isEmpty(block2)) swiftFormat += OPEN_1 + block2 + CLOSE_1;
        if (!StringUtils.isEmpty(block3)) swiftFormat += OPEN_1 + block3 + CLOSE_1;
        if (!StringUtils.isEmpty(block4)) swiftFormat += OPEN_1 + block4 + CLOSE_1;
        if (!StringUtils.isEmpty(block5)) swiftFormat += OPEN_1 + block5 + CLOSE_1;

        return swiftFormat;
    }

    private String blockSenderProcess (String swiftType, String sender) {
        String block1 = Optional.ofNullable(messageTypeTemplateRepository.findBySwiftType(SwiftType.valueOf(swiftType)))
                .map(m -> m.getBlock1())
                .orElse("");
        if(StringUtils.isEmpty(block1)) return "";

        Map<String, String> replacement = new HashMap<>();
        replacement.put("sender", sender.substring(0, sender.length() - 3));
        replacement.put("sender_branch", sender.substring(sender.length() - 3));

        for(String field : replaceBlockVar(REGEX_2, block1)) {
            block1 = block1.replace(OPEN_2 + field + CLOSE_2, replacement.get(field));
        }
        return block1;
    }

    private String blockReceiverProcess (String swiftType, String receiver) {
        String block2 = Optional.ofNullable(messageTypeTemplateRepository.findBySwiftType(SwiftType.valueOf(swiftType)))
                .map(m -> m.getBlock2())
                .orElse("");
        if(StringUtils.isEmpty(block2)) return "";

        Map<String, String> replacement = new HashMap<>();
        replacement.put("receiver", receiver.substring(0, receiver.length() - 3));
        replacement.put("receiver_branch", receiver.substring(receiver.length() - 3));

        for(String field : replaceBlockVar(REGEX_2, block2)) {
            block2 = block2.replace(OPEN_2 + field + CLOSE_2, replacement.get(field));
        }
        return block2;
    }

    private String blockFromRequestProcess (String swiftType, TransactionDTO dto, String blockFieldName, TransactionType transactionType) {
        String blockFromRequest = Optional.ofNullable(messageTypeTemplateRepository.findBySwiftType(SwiftType.valueOf(swiftType)))
                .map(m -> ReflectionUtil.getFieldValueByName(m, blockFieldName))
                .map(m -> m.toString())
                .orElse("");
        if(StringUtils.isEmpty(blockFromRequest)) return "";

        for(String field : replaceBlockVar(REGEX_1, blockFromRequest)) {
            String replacement = Optional.ofNullable(ReflectionUtil.getFieldValueByName(dto, field))
                    .map(m -> m.toString())
                    .orElse("");
            blockFromRequest = blockFromRequest.replace(OPEN_1 + field + CLOSE_1, replacement);
        }

        /* create swift object to fill it into swift outgoing data from Clear Type Parameter */
        ClearTypeEnum clearType = (dto.getEuroclearCode().startsWith(ClearTypeEnum.CLEARSTREAM.getStartWith()))
                ?ClearTypeEnum.CLEARSTREAM:ClearTypeEnum.EUROCLEAR;
        ClearTypeParameter clearTypeParameters =
                clearTypeParameterRepository.findByClearTypeAndTransactionType(clearType.toString(), transactionType);
        for(String field : replaceBlockVar(REGEX_2, blockFromRequest)) {
            blockFromRequest = blockFromRequest.replace(OPEN_2 + field + CLOSE_2,
                    ReflectionUtil.getFieldValueByName(clearTypeParameters, field).toString());
        }

        return blockFromRequest;
    }

    private List<String> replaceBlockVar (String regex, String text) {
        List<String> result = new ArrayList<>();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(text);

        List<String> matches = new ArrayList<>();

        while (matcher.find()) {
            matches.add(matcher.group(1));
        }

        for (String match : matches) {
            result.add(match);
        }

        return result;
    }

    private void validationContractNumberAlreadyExists(String contractNumber, List<String> validationErrors) {
        List<ApprovalStatus> approvalStatuses = new ArrayList<>();
        approvalStatuses.add(ApprovalStatus.Pending);
        approvalStatuses.add(ApprovalStatus.Approved);
        if (transactionRepository.existsByContractNumberAndApprovalStatusIn(contractNumber, approvalStatuses)) {
            validationErrors.add("Contract Number or Contract Id already taken with code: " + contractNumber);
        }
    }

    private void validationCompareAllDateColumn(TransactionDTO dto, List<String> validationErrors) {
        LocalDate matureDate = LocalDate.parse(dto.getMatureDate(), DateTimeFormatter.BASIC_ISO_DATE);
        LocalDate settlementDate = LocalDate.parse(dto.getSettlementDate(), DateTimeFormatter.BASIC_ISO_DATE);
        LocalDate tradeDate = LocalDate.parse(dto.getTradeDate(), DateTimeFormatter.BASIC_ISO_DATE);
        if (matureDate.compareTo(settlementDate) < 0) {
            validationErrors.add("MATDATE must greater than SETTLEDATE");
        }

        if (settlementDate.compareTo(tradeDate) < 0) {
            validationErrors.add("SETTLEDATE must greater than TRADEDATE");
        }
    }

    private void validationIsExistsCurrency(String code, List<String> validationErrors) {
        if (!currencyRepository.existsByCode(code)) {
            validationErrors.add("Currency not exists with code: " + code);
        }
    }

    private void validationIsExistsBook(String code, List<String> validationErrors) {
        if (!bookRepository.existsByCode(code)) {
            validationErrors.add("BOOK not exists with code: " + code);
        }
    }

    private void validationIsExistsSecurityAndIsinCode(String code, String isinCode, List<String> validationErrors) {
        if (!securityRepository.existsByCodeAndIsinCode(code, isinCode)) {
            validationErrors.add("Security and ISIN Number not exists with code: " + code + " and ISIN Number : " + isinCode);
        }
    }

    private void validationIsExistsIsinCode(String code, List<String> validationErrors) {
        if (!securityRepository.existsByIsinCode(code)) {
            validationErrors.add("ISIN Number not exists with code: " + code);
        }
    }

    private void validationIsExistsEuroclearCodeAndBank(String code, String bank, List<String> validationErrors) {
        if (!euroclearCodeRepository.isExistsByCodeAndBank(code.toUpperCase(), bank.toUpperCase())) {
            validationErrors.add("Euroclear Code And Customer not exists with code: " + code + " and Customer : " + bank);
        }
    }

    private void validationIsExistsBicCode(String code, List<String> validationErrors) {
        if (!bicCodeRepository.existsByCode(code)) {
            validationErrors.add("Bic Code not exists with code: " + code);
        }
    }

    private void validationIsExistsSenderCode(String code, List<String> validationErrors) {
        if (!senderReceiverBankRepository.existsByCodeAndType(code, SenderReceiverTypeEnum.SENDER.getType())) {
            validationErrors.add("Sender Code not exists with code: " + code);
        }
    }
    private void validationIsExistsReceiverCode(String code, List<String> validationErrors) {
        if (!senderReceiverBankRepository.existsByCodeAndType(code, SenderReceiverTypeEnum.RECEIVER.getType())) {
            validationErrors.add("Receiver Code not exists with code: " + code);
        }
    }


    @Transactional
    private void saveData (List<String> validationErrors, List<Transaction> transactions, List<Outgoing> outgoings) throws Exception {
        if (validationErrors.isEmpty()) {
            for (Transaction transaction : transactions) {
                Outgoing outgoing = transaction.getIdOutgoing();
                if (outgoing != null && outgoing.getId() == null) {
                    // Save the outgoing entity first if it's not already saved
                    outgoingRepository.save(outgoing);
                }
            }
            // Save all transactions
            transactionRepository.saveAll(transactions);
        }
    }

    private void handleGeneralError(TransactionDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(dto != null ? String.valueOf(dto.getId()) : UNKNOWN, validationErrors));
    }

    private void handleSavingError(TransactionDTO dto, Exception e, List<String> validationErrorsTemp, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("Error when saving transaction data with error : {}", e.getMessage(), e);
        validationErrors.addAll(validationErrorsTemp);
        errorMessageList.add(new ErrorMessageDTO(dto != null ? String.valueOf(dto.getId()) : UNKNOWN, validationErrors));
    }

    @Override
    public List<TransactionResponseDTO> getByApprovalStatusOrderByContractNumberAsc(ApprovalStatus approvalStatus) {
        List<Transaction> all = transactionRepository.findByApprovalStatusOrderByContractNumberAsc(approvalStatus);
        return all.stream()
                .map(e -> modelMapper.map(e, TransactionResponseDTO.class))
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public String updateApprovalStatus(UpdateApprovalStatusRequest request, String clientIp) {
        try {
            Transaction transaction = Optional.ofNullable(transactionRepository.findFecthById(request.getId()))
                    .orElseThrow(() -> new DataNotFoundException("Transaction ID not found with id : " + request.getId()));

            final ApprovalStatus approvalStatus = ApprovalStatus.valueOf(request.getApprovalStatus());
            final String fileName = transaction.getIdOutgoing().getSwiftType().toString();

            Date approvalDate = new Date();
            transaction.setApprovalStatus(approvalStatus);
            transaction.setApproverId(clientIp);
            transaction.setApproveDate(approvalDate);

            transaction.getIdOutgoing().setApprovalStatus(approvalStatus);
            transaction.getIdOutgoing().setApproverId(clientIp);
            transaction.getIdOutgoing().setApproveDate(approvalDate);

            if (approvalStatus == ApprovalStatus.Approved)
                TextWriter.generateTextFileFromSingleData(pathFolderOutgoing, fileName,
                        transaction.getIdOutgoing().getSwiftFormat(), FORMAT_ANY_TYPE );

            transactionRepository.save(transaction);
            outgoingRepository.save(transaction.getIdOutgoing());

            return "Successfully update Transaction with id : " + request.getId() + " and approval status: " + approvalStatus;
        } catch (Exception e) {
            throw new UnexpectedException("Error when update approval status Transaction: " + e.getMessage());
        }
    }

    @Override
    public Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus status) {
        Boolean existsByIdList = transactionRepository.existsByIdListAndStatus(idList, idListSize, status);
        log.info("Status Exist by Id list: {}", existsByIdList);
        return existsByIdList;
    }
}
