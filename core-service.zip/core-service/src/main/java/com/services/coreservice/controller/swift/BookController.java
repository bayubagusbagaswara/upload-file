package com.services.coreservice.controller.swift;

import com.services.coreservice.annotation.interfaces.Converting;
import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.dto.swift.book.*;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.service.swift.BookServices;
import com.services.coreservice.utils.ClientIPUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/swift/book")
public class BookController {
    @Autowired
    private BookServices bookServices;

    private static final String URL_CURRENCY = "/api/swift/book";
    private static final String MENU_CURRENCY = "Book";

    @PostMapping("/create")
    public ResponseEntity<ResponseDTO<BookResponse>> create(@Converting @RequestBody CreateBookRequest request, HttpServletRequest servletRequest)  {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.POST.name())
                .endpoint(URL_CURRENCY + "/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CURRENCY)
                .build();
        BookResponse createResponse = bookServices.createSingleData(request, dataChangeDTO);
        ResponseDTO<BookResponse> response = ResponseDTO.<BookResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<BookResponse>> createSingleApprove(@RequestBody BookApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        BookResponse listApprove = bookServices.createSingleApprove(request, clientIp);
        ResponseDTO<BookResponse> response = ResponseDTO.<BookResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<BookResponse>> updateSingleData(@RequestBody UpdateBookRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .inputerIPAddress(clientIp)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_CURRENCY + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CURRENCY)
                .build();
        BookResponse updateResponse = bookServices.updateSingleData(request, dataChangeDTO);
        ResponseDTO<BookResponse> response = ResponseDTO.<BookResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<BookResponse>> updateSingleApprove(@RequestBody BookApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        BookResponse updateListResponse = bookServices.updateSingleApprove(request, clientIp);
        ResponseDTO<BookResponse> response = ResponseDTO.<BookResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<BookResponse>> deleteSingleData(@RequestBody DeleteBookRequest request) {
        DataChangeDTO dataChangeDTO = DataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(URL_CURRENCY + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_CURRENCY)
                .build();
        BookResponse deleteResponse = bookServices.deleteSingleData(request, dataChangeDTO);
        ResponseDTO<BookResponse> response = ResponseDTO.<BookResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<BookResponse>> deleteSingleApprove(@RequestBody BookApproveRequest request, HttpServletRequest servletRequest) {
        String clientIp = ClientIPUtil.getClientIp(servletRequest);
        BookResponse deleteResponse = bookServices.deleteSingleApprove(request, clientIp);
        ResponseDTO<BookResponse> response = ResponseDTO.<BookResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BookDTO>>> getAll() {
        List<BookDTO> dtoList = bookServices.getAll();
        ResponseDTO<List<BookDTO>> response = ResponseDTO.<List<BookDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dtoList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDTO<BookDTO>> getByCode(@RequestParam("code") String code) {
        BookDTO data = bookServices.findByCode(code);
        ResponseDTO<BookDTO> response = ResponseDTO.<BookDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/id")
    public ResponseEntity<ResponseDTO<BookDTO>> getById(@RequestParam("id") Long id) {
        BookDTO data = bookServices.findById(id);
        ResponseDTO<BookDTO> response = ResponseDTO.<BookDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(data)
                .build();
        return ResponseEntity.ok(response);
    }
}
