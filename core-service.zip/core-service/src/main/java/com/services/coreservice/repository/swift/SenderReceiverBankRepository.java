package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.SenderReceiverBank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SenderReceiverBankRepository extends JpaRepository<SenderReceiverBank, Long> {
    Optional<List<SenderReceiverBank>> findByCode(final String code);
    Optional<SenderReceiverBank> findByCodeAndType(final String code, final String type);
    boolean existsByCodeAndType(String code, String type);
    boolean existsByCode(String code);

    @Query("SELECT u FROM SenderReceiverBank u WHERE u.approvalStatus = 'Approved' and u.code = :code")
    List<SenderReceiverBank> searchByCode(@Param("code") String code);

    List<SenderReceiverBank> findByTypeOrderByCodeAsc(final String type);
}
