package com.services.coreservice.repository.swift;

import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.enums.ReportType;
import com.services.coreservice.enums.SwiftType;
import com.services.coreservice.model.swift.RegisterEmail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RegisterEmailRepository extends JpaRepository<RegisterEmail, Long> {
    Optional<List<RegisterEmail>> findByEmailAddressLike(String email);

    @Query(value="SELECT case when count(*) > 0 then true else false end FROM RegisterEmail WHERE approvalStatus = :approvalStatus AND emailAddress = :emailAddress AND reportType = :reportType")
    boolean checkDataByEmailAndSwiftType(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("emailAddress") String emailAddress,
            @Param("reportType") ReportType reportType);
}
