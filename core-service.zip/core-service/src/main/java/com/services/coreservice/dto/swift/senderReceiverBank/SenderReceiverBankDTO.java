package com.services.coreservice.dto.swift.senderReceiverBank;

import com.services.coreservice.dto.swift.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SenderReceiverBankDTO extends ApprovalDTO {
    private Long id;

    @Pattern(regexp = "^[A-Z]+$", message = "Code must filled with Capital Letters!")
    @NotBlank(message = "Code cannot be empty!")
    private String code;

    private String name;

    @NotBlank(message = "Type cannot be empty!")
    private String type;
}
