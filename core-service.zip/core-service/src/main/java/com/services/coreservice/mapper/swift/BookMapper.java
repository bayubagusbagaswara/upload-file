package com.services.coreservice.mapper.swift;

import com.services.coreservice.dto.swift.book.BookDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.mapper.BaseMapper;
import com.services.coreservice.model.swift.Book;
import com.services.coreservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class BookMapper extends BaseMapper<Book, BookDTO> {

    private final ConvertDateUtil convertDateUtil;

    public BookMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<Book, BookDTO> getPropertyMap() {
        return new PropertyMap<Book, BookDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<Book> getEntityClass() {
        return Book.class;
    }

    @Override
    protected Class<BookDTO> getDtoClass() {
        return BookDTO.class;
    }

    @Override
    protected void setCommonProperties(Book entity, DataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
//        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(convertDateUtil.getDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
//        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
