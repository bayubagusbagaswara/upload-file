package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.EmailSent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmailSentRepository extends JpaRepository<EmailSent, Long> {
}
