package com.services.coreservice.service.swift;

import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.registerEmail.*;

import java.util.List;

public interface RegisterEmailServices {
    RegisterEmailResponse createSingleData(List<CreateRegisterEmailRequest> requests, DataChangeDTO dataChangeDTO);

    RegisterEmailResponse createSingleApprove(RegisterEmailApproveRequest approveRequest, String clientIP);

    RegisterEmailResponse updateSingleData(List<UpdateRegisterEmailRequest> request, DataChangeDTO dataChangeDTO);

    RegisterEmailResponse updateSingleApprove(RegisterEmailApproveRequest approveRequest, String clientIP);

    RegisterEmailResponse deleteSingleData(List<DeleteRegisterEmailRequest> deleteRequest, DataChangeDTO dataChangeDTO);

    RegisterEmailResponse deleteSingleApprove(RegisterEmailApproveRequest approveRequest, String clientIP);

    List<RegisterEmailDTO> getAll();

    List<RegisterEmailDTO> findByEmailAddressLike(String email);

    RegisterEmailDTO findById(Long id);
}
