package com.services.coreservice.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableAsync
@Slf4j
public class SpringAsyncConfig {
    // Async for running scheduler with fixedRate or fixedDelay
//    @Bean(name = "asyncTaskExecutor")
//    public ThreadPoolTaskExecutor asyncTaskExecutor() {
//        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
//        executor.setCorePoolSize(5); // Set the initial number of threads in the pool
//        executor.setMaxPoolSize(10); // Set the maximum number of threads in the pool
//        executor.setQueueCapacity(25); // Set the queue capacity for holding pending tasks
//        executor.setThreadNamePrefix("AsyncTask-"); // Set a prefix for thread names
//
//        // Set the RejectedExecutionHandler to log an error message
//        executor.setRejectedExecutionHandler((Runnable r, ThreadPoolExecutor e) -> {
//            // Log the error message indicating the task has been rejected due to the full queue
//            log.error("Task Rejected: Thread pool is full. Increase the thread pool size.");
//        });
//
//        executor.initialize();
//        return executor;
//    }

    // Async for running scheduler with fixedRate or fixedDelay
    @Bean(name = "asyncTaskExecutor")
    public TaskScheduler taskScheduler() {
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(10);
        threadPoolTaskScheduler.setThreadNamePrefix("ThreadPoolTaskScheduler");
        return threadPoolTaskScheduler;
    }
}
