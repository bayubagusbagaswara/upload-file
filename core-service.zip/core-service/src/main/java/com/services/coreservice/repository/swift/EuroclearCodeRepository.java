package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.EuroclearCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EuroclearCodeRepository extends JpaRepository<EuroclearCode, Long> {

    boolean existsByCode( final String code);

    @Query("SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false end " +
            "FROM EuroclearCode u " +
            "WHERE UPPER(u.code) = :code " +
            "   AND UPPER(u.bank) = :bank")
    boolean isExistsByCodeAndBank(@Param("code") final String code,
                                  @Param("bank") final String bank);

    Optional<EuroclearCode> findById(Long id);

    @Query("SELECT u FROM EuroclearCode u WHERE u.approvalStatus = 'Approved' and u.code like %:code%")
    List<EuroclearCode> searchByCodeLike(@Param("code") String code);

    List<EuroclearCode> findByCode (final String code);
}
