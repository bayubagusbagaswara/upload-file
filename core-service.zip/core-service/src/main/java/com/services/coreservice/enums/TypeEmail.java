package com.services.coreservice.enums;

public enum TypeEmail {
	Report, Scheduler
}
