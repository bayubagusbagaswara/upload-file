package com.services.coreservice.dto.swift.book;

import com.services.coreservice.dto.swift.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookDTO extends ApprovalDTO {
    private Long id;

    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "Code must contain only alphanumeric characters")
    @NotBlank(message = "Book Code cannot be empty")
    private String code;

    @NotBlank(message = "Book Name cannot be empty")
    private String name;
}
