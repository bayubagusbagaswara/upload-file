package com.services.coreservice.dto.swift.registerEmail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegisterEmailApproveRequest {
    private String approverId;
    private String approverIPAddress;
    private String dataChangeId;
    private RegisterEmailDTO data;
}
