package id.co.danamon.apps.csa.rb.enums;

public enum SecurityStatus {
	Active, Closed
}
