package com.services.coreservice.model.rb;

import com.services.coreservice.enums.ApprovalStatus;
import id.co.danamon.apps.csa.rb.enums.SecurityStatus;
import id.co.danamon.apps.csa.recon.enums.ValuationType;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Data
@SuperBuilder
@NoArgsConstructor
@Table(name = "rb_security")
public class Security{

	private static final long serialVersionUID = 1L;

	public static final String CODE = "code";
	public static final String SECURITY_TYPE = "securityType";
	public static final String NAME = "name";
	public static final String CURRENCY = "currency";
	public static final String ISSUED_DATE = "issuedDate";
	public static final String STATUS = "status";

	private ApprovalStatus approvalStatus;

	private String inputerId;

	private Date inputDate;

	private String approverId;

	private Date approveDate;

	@Id
	private String code;

	private String securityType;

	private String name;

	private String currency;

	private String taxCurrency;

	private Date issuedDate;

	private SecurityStatus status;

	private double marketPrice;

	private double commision;

	private boolean tax;

    private double taxAmount;

    private String penerbit;

	private ValuationType settlementSystem;

	private String isinCode;

	public ApprovalStatus getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(ApprovalStatus approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getInputerId() {
		return inputerId;
	}

	public void setInputerId(String inputerId) {
		this.inputerId = inputerId;
	}

	public Date getInputDate() {
		return inputDate;
	}

	public void setInputDate(Date inputDate) {
		this.inputDate = inputDate;
	}

	public String getApproverId() {
		return approverId;
	}

	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}

	public Date getApproveDate() {
		return approveDate;
	}

	public void setApproveDate(Date approveDate) {
		this.approveDate = approveDate;
	}

	public String getSecurityType() {
		return securityType;
	}

	public void setSecurityType(String securityType) {
		this.securityType = securityType;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code != null ? code.toUpperCase() : code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name != null ? name.toUpperCase() : name;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency != null ? currency.toUpperCase() : currency;
	}

	public String getTaxCurrency() {
		return taxCurrency;
	}

	public void setTaxCurrency(String taxCurrency) {
		this.taxCurrency = taxCurrency != null ? taxCurrency.toUpperCase()
				: taxCurrency;
	}

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public SecurityStatus getStatus() {
		return status;
	}

	public void setStatus(SecurityStatus status) {
		this.status = status;
	}

	public boolean isActive() {
		return status == SecurityStatus.Active;
	}

	public double getMarketPrice() {
		return marketPrice;
	}

	public void setMarketPrice(double marketPrice) {
		this.marketPrice = marketPrice;
	}

	public double getCommision() {
		return commision;
	}

	public void setCommision(double commision) {
		this.commision = commision;
	}

	public String toString() {
		return name;
	}

    public boolean isTax() {
        return tax;
    }

    public void setTax(boolean tax) {
        this.tax = tax;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

	public ValuationType getSettlementSystem() {
		return settlementSystem;
	}

	public void setSettlementSystem(ValuationType settlementSystem) {
		this.settlementSystem = settlementSystem;
	}

	public String getPenerbit() {
		return penerbit = penerbit != null ? penerbit : "";
	}

	public void setPenerbit(String penerbit) {
		this.penerbit = penerbit;
	}


	public String getIsinCode() {
		return isinCode;
	}

	public void setIsinCode(String isinCode) {
		this.isinCode = isinCode;
	}

}
