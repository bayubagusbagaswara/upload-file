package com.services.coreservice.dto.swift.euroclear;

import com.services.coreservice.annotation.interfaces.UpperCase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateEuroclearRequest {
    private String inputerId;
    private String inputerIPAddress;
    private String code;
    @UpperCase
    private String bank;
}
