package com.services.coreservice.service.swift.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.coreservice.dto.swift.ErrorMessageDTO;
import com.services.coreservice.dto.swift.datachange.DataChangeDTO;
import com.services.coreservice.dto.swift.registerEmail.*;
import com.services.coreservice.enums.ActionEmail;
import com.services.coreservice.enums.ApprovalStatus;
import com.services.coreservice.enums.ReportType;
import com.services.coreservice.exception.DataNotFoundException;
import com.services.coreservice.mapper.swift.RegisterEmailMapper;
import com.services.coreservice.model.swift.DataChange;
import com.services.coreservice.model.swift.RegisterEmail;
import com.services.coreservice.repository.swift.RegisterEmailRepository;
import com.services.coreservice.service.swift.DataChangeServices;
import com.services.coreservice.service.swift.RegisterEmailServices;
import com.services.coreservice.utils.BeanUtil;
import com.services.coreservice.utils.ConvertDateUtil;
import com.services.coreservice.utils.JsonUtil;
import com.services.coreservice.utils.ValidateValidatorUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class RegisterEmailServicesImpl implements RegisterEmailServices {
    @Autowired
    private RegisterEmailRepository registerEmailRepository;
    @Autowired
    private DataChangeServices dataChangeServices;
    @Autowired
    private RegisterEmailMapper registerEmailMapper;
    @Autowired
    private ValidateValidatorUtil<RegisterEmailDTO> validateValidatorUtil;
    @Autowired
    private ConvertDateUtil convertDateUtil;

    private ObjectMapper objectMapper = new ObjectMapper();
    private static final String UNKNOWN = "unknown";
    private static final String ID_NOT_FOUND = "RegisterEmail not found with id: ";
    private static final String EMAIL_NOT_FOUND = "RegisterEmail not found with email: ";

    @Override
    public RegisterEmailResponse createSingleData(List<CreateRegisterEmailRequest> requests, DataChangeDTO dataChangeDTO) {
        log.info("Create single data registerEmail with request: {}", requests);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        RegisterEmailDTO dto = null;

        try {
            /* maps request data to dto */
            for (CreateRegisterEmailRequest request : requests){
                dto = registerEmailMapper.mapCreateRequestToDto(request);

                /* validation for each dto field */
                Errors errors = validateValidatorUtil.validateUsingValidator(dto, "RegisterEmailDTO");
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                /* validate data */
                validateDataExist(dto.getEmailAddress(), dto.getReportType(), validationErrors);

                /* sets input id to a DataChange object */
                dataChangeDTO.setInputerId(request.getInputerId());
                dataChangeDTO.setInputDate(convertDateUtil.getDate());

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                    dataChangeServices.createChangeActionADD(dataChangeDTO, DataChange.class);
                    totalDataSuccess++;
                }
            }
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new RegisterEmailResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public RegisterEmailResponse createSingleApprove(RegisterEmailApproveRequest approveRequest, String clientIP) {
        log.info("Approve when create registerEmail with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        RegisterEmailDTO dto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the RegisterEmail dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), RegisterEmailDTO.class);

            /* perform data validation if necessary, for example checking whether the code already exists in the database */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto, "RegisterEmailDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets approveId and approveIPAddress to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            } else {
                RegisterEmail data = registerEmailMapper.createEntity(dto, dataChangeDTO);
                registerEmailRepository.save(data);
                dataChangeDTO.setDescription("Successfully approve data change and save data registerEmail with id: " + data.getId());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(registerEmailMapper.mapToDto(data))));
                dataChangeDTO.setEntityId(data.getId().toString());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new RegisterEmailResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public RegisterEmailResponse updateSingleData(List<UpdateRegisterEmailRequest> requests, DataChangeDTO dataChangeDTO) {
        log.info("Update single data registerEmail with request: {}", requests);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        RegisterEmailDTO clonedDTO = null;
        List<DataChangeDTO> dataChangeDTOList = new ArrayList<>();

        try {
            for (UpdateRegisterEmailRequest request : requests){
                /* maps request data to dto */
                RegisterEmailDTO dto = registerEmailMapper.mapUpdateRequestToDto(request);
                log.info("[Update Single] RegisterEmail dto: {}", dto);

                /* clone dto */
                clonedDTO = new RegisterEmailDTO();
                BeanUtil.copyAllProperties(dto, clonedDTO);
                log.info("[Update Single] Result mapping request to dto: {}", dto);

                /* get registerEmail by id */
                RegisterEmail existingData = registerEmailRepository.findById(dto.getId())
                        .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + dto.getId()));

                /* validation for each dto field */
                Errors errors = validateValidatorUtil.validateUsingValidator(clonedDTO, "RegisterEmailDTO");
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                /* checking is data change or not */
                if (checkingDataForUpdate(dto, existingData)){
                    /* sets inputId to a DataChange object */
                    dataChangeDTO.setInputerId(request.getInputerId());
                    dataChangeDTO.setInputDate(convertDateUtil.getDate());

                    /* check the number of content of the ValidationErrors object, then map it to the response */
                    if (!validationErrors.isEmpty()) {
                        ErrorMessageDTO errorMessageDTO = getErrorMessageDTO(dto, validationErrors);
                        errorMessageDTOList.add(errorMessageDTO);
                        totalDataFailed++;
                    } else {
                        RegisterEmailDTO dtoForJsonDataBefore = registerEmailMapper.mapToDto(existingData);
                        log.info("DTO for Json Data Before: {}", dtoForJsonDataBefore);
                        dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dtoForJsonDataBefore)));
                        dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dto)));
                        dataChangeDTO.setEntityId(existingData.getId().toString());
                        dataChangeDTOList.add(dataChangeDTO);
//                        dataChangeServices.createChangeActionEDIT(dataChangeDTO, RegisterEmail.class);
                        totalDataSuccess++;
                    }
                }
            }

            if (totalDataFailed == 0 && !dataChangeDTOList.isEmpty()){
                dataChangeServices.createChangeActionListEDIT(dataChangeDTOList, RegisterEmail.class);
            }

        } catch (Exception e) {
            handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new RegisterEmailResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public RegisterEmailResponse updateSingleApprove(RegisterEmailApproveRequest approveRequest, String clientIP) {
        log.info("Approve when update registerEmail with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        RegisterEmailDTO dataAfterDto = null;

        try {
            /* validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange, then map the JsonDataAfter data to the RegisterEmail dto class */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());
            RegisterEmailDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), RegisterEmailDTO.class);
            log.info("[Update Approve] Map data from JsonDataAfter to dto: {}", dto);

            /* get registerEmail by id */
            RegisterEmail existingData = registerEmailRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* map data from dto to entity, to overwrite new data */
            registerEmailMapper.mapObjectsDtoToEntity(dto, existingData);
            log.info("[Update Approve] Map object dto to entity: {}", existingData);

            /* map from entity to dto */
            dataAfterDto = registerEmailMapper.mapToDto(existingData);
            log.info("[Update Approve] Map from entity to dto: {}", dataAfterDto);

            /* check validation each column dto */
            Errors errors = validateValidatorUtil.validateUsingValidator(dto,"RegisterEmailDTO");
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* sets approveId, approveIPAddress, and entityId to a DataChange object */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setEntityId(existingData.getId().toString());

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(dataAfterDto)));
                dataChangeServices.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                RegisterEmail updatedData = registerEmailMapper.updateEntity(existingData, dataChangeDTO);
                RegisterEmail updatedDataSaved = registerEmailRepository.save(updatedData);
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(registerEmailMapper.mapToDto(updatedDataSaved))));
                dataChangeDTO.setDescription("Successfully approve data change and update registerEmail entity with id: " + updatedDataSaved.getId());
                dataChangeServices.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(dataAfterDto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new RegisterEmailResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public RegisterEmailResponse deleteSingleData(List<DeleteRegisterEmailRequest> deleteRequests, DataChangeDTO dataChangeDTO) {
        log.info("Delete single registerEmail with request: {}", deleteRequests);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        RegisterEmailDTO dto = null;
        List<DataChangeDTO> dataChangeDTOList = new ArrayList<>();

        try {
            for (DeleteRegisterEmailRequest deleteRequest : deleteRequests){
                DataChangeDTO dtoSaving = new DataChangeDTO();
                BeanUtil.copyAllProperties(dataChangeDTO, dtoSaving);

                /* get registerEmail by id */
                Long id = deleteRequest.getId();
                RegisterEmail existingData = registerEmailRepository.findById(id)
                        .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));

                /* maps entity to dto */
                dto = registerEmailMapper.mapToDto(existingData);

                /* set data change */
                dtoSaving.setInputerId(deleteRequest.getInputerId());
                dtoSaving.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(registerEmailMapper.mapToDto(existingData))));
                dtoSaving.setJsonDataAfter("");
                dtoSaving.setEntityId(existingData.getId().toString());
                dataChangeDTOList.add(dtoSaving);
//                dataChangeServices.createChangeActionDELETE(dataChangeDTO, RegisterEmail.class);
                totalDataSuccess++;
            }

            if (totalDataFailed == 0 && !dataChangeDTOList.isEmpty()){
                dataChangeServices.createChangeActionListDELETE(dataChangeDTOList, RegisterEmail.class);
            }

        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new RegisterEmailResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public RegisterEmailResponse deleteSingleApprove(RegisterEmailApproveRequest approveRequest, String clientIP) {
        log.info("Approve when delete registerEmail with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        RegisterEmailDTO dto = null;

        try {
            /*  validate dataChangeId whether it exists or not */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data from DataChange */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            DataChangeDTO dataChangeDTO = dataChangeServices.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());

            /* get investment management by id */
            RegisterEmail existingData = registerEmailRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            /* maps from entity to dto */
            dto = registerEmailMapper.mapToDto(existingData);

            /* set data change for approve id and approve ip address */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(registerEmailMapper.mapToDto(existingData))));
            dataChangeDTO.setDescription("Successfully approve data change and delete registerEmail with id: " + existingData.getId());
            dataChangeServices.approvalStatusIsApproved(dataChangeDTO);

            /* delete data entity in the database */
            registerEmailRepository.delete(existingData);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(dto, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new RegisterEmailResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public List<RegisterEmailDTO> getAll() {
        List<RegisterEmail> all = registerEmailRepository.findAll();
        return registerEmailMapper.mapToDTOList(all);
    }

    @Override
    public List<RegisterEmailDTO> findByEmailAddressLike(String email) {
        List<RegisterEmail> data = registerEmailRepository.findByEmailAddressLike("%"+ email +"%")
                .orElseThrow(() -> new DataNotFoundException(EMAIL_NOT_FOUND + email));
        return registerEmailMapper.mapToDTOList(data);
    }

    @Override
    public RegisterEmailDTO findById(Long id) {
        RegisterEmail data = registerEmailRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return registerEmailMapper.mapToDto(data);
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeServices.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change id not found");
            throw new DataNotFoundException("Data Change not found with id: " + dataChangeId);
        }
    }

    private void handleGeneralError(RegisterEmailDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(dto != null ? String.valueOf(dto.getId()) : UNKNOWN, validationErrors));
    }

    private static ErrorMessageDTO getErrorMessageDTO(RegisterEmailDTO dto, List<String> validationErrors) {
        String string = dto.getId() == null ? UNKNOWN : dto.getId().toString();
        return new ErrorMessageDTO(string, validationErrors);
    }

    private void validateDataExist(String email, String mt, List<String> validationErrors) {
        if (registerEmailRepository.checkDataByEmailAndSwiftType(ApprovalStatus.Approved, email, ReportType.valueOf(mt))) {
            validationErrors.add("MT " + mt + " already registered for email: " + email);
        }
    }

    private boolean checkingDataForUpdate(RegisterEmailDTO updatedData, RegisterEmail existingData){
        boolean isChange;
        if (existingData.getEmailAddress().equalsIgnoreCase(updatedData.getEmailAddress())
            && existingData.getId() == updatedData.getId()
            && existingData.getAction() == ActionEmail.valueOf(updatedData.getAction())
            && existingData.getReportType() == ReportType.valueOf(updatedData.getReportType())){
            isChange = false;
        } else isChange = true;
        return isChange;
    }
}
