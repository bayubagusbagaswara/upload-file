package com.services.coreservice.repository.swift;

import com.services.coreservice.model.swift.BicCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BicCodeRepository extends JpaRepository<BicCode, Long> {
    Optional<BicCode> findByCode (final String code);

    boolean existsByCode(String code);
}
