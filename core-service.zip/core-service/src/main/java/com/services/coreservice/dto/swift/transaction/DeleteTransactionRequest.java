package com.services.coreservice.dto.swift.transaction;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteTransactionRequest {
    private String inputerId;
    private String inputerIPAddress;
    private Long id;
}
