package com.services.coreservice.dto.swift.approval;

import com.services.coreservice.annotation.interfaces.UpperCase;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateApprovalStatusRequest {
    private String approverId;
    private String approverIPAddress;
    private Long id;
    @UpperCase("first")
    private String approvalStatus;
}
