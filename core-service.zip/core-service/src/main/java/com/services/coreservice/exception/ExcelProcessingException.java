package com.services.coreservice.exception;

public class ExcelProcessingException extends RuntimeException {

    public ExcelProcessingException(String message, Throwable cause) {
        super(message, cause);
    }
}
