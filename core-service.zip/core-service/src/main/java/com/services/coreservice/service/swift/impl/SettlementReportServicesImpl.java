package com.services.coreservice.service.swift.impl;

import com.services.coreservice.dto.swift.ResponseDTO;
import com.services.coreservice.repository.swift.SettlementReportRepository;
import com.services.coreservice.service.swift.SettlementReportServices;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;

import static com.services.coreservice.service.swift.impl.ReportInterfaceHiportImpl.getCurrentDateFromRequest;

@Service
@Slf4j
public class SettlementReportServicesImpl implements SettlementReportServices {
    @Autowired
    private SettlementReportRepository settlementReportRepository;

    @Override
    public ResponseEntity<ResponseDTO<byte[]>> dowloadFileInterface(String date) {
        // Format String date to date
        LocalDate currentDate = getCurrentDateFromRequest(date);

        // Define the file name and path
        String fileName = "HiportInterface_"+ date.replace("/","") +".txt";
        File file = new File(fileName);
        byte[] byteArray;

        // Create the file and write some content to it
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))){
//            List<Transaction> transactionList = transactionRepository.listTransactionBySettleDate(currentDate);
//            String txtContent = HiPortReportUtil.writeInterfaceHiport(transactionList, currentDate);
            String txtContent = "TEST!";
            writer.write(txtContent);
        } catch (IOException e) {
            log.error("Failed download settlement report error : {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseDTO.<byte[]>builder()
                            .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                            .message(HttpStatus.NOT_FOUND.getReasonPhrase())
                            .payload(null)
                            .build());
        }

//        Convert to byte
        try {
            byteArray = FileUtils.readFileToByteArray(file);
        } catch (IOException e) {
            log.error("Failed download settlement report error : {}", e.getMessage());
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(ResponseDTO.<byte[]>builder()
                            .code(HttpStatus.INTERNAL_SERVER_ERROR.value())
                            .message(HttpStatus.NOT_FOUND.getReasonPhrase())
                            .payload(null)
                            .build());
        } finally {
            file.delete();
        }

        // Prepare the response
        HttpHeaders headers = new HttpHeaders();
        headers.setContentDisposition(ContentDisposition.attachment().filename(fileName).build());
        headers.setContentType(MediaType.APPLICATION_JSON);

        ResponseDTO<byte[]> response = ResponseDTO.<byte[]>builder()
                .code(HttpStatus.OK.value())
                .message(fileName)
                .payload(byteArray)
                .build();
        return ResponseEntity.ok().body(response);
    }
}
