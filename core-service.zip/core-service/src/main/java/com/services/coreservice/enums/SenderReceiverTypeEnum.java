package com.services.coreservice.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SenderReceiverTypeEnum {
    SENDER("Sender"),
    RECEIVER("Receiver");
    private String type;
}
