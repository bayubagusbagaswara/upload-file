package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingDataChange;
import com.services.billingservice.model.base.Approvable;

import java.util.List;

public interface BillingDataChangeService {

    BillingDataChangeDTO getById(Long id);

    List<BillingDataChange> getAll();

    List<String> findAllMenu();

    BillingDataChangeDTO getById(String id);
    String deleteAll();

    <T> void createChangeActionADD(BillingDataChangeDTO dataChangeDTO, Class<T> clazz);

    void approvalStatusIsRejected(BillingDataChangeDTO dataChangeDTO, List<String> errorMessageList);

    void approvalStatusIsApproved(BillingDataChangeDTO dataChangeDTO);

    <T> void createChangeActionEDIT(BillingDataChangeDTO dataChangeDTO, Class<T> clazz);

    <T> void createChangeActionDELETE(BillingDataChangeDTO dataChangeDTO, Class<T> clazz);

    Boolean existByIdList(List<Long> idList, Integer idListSize);

    Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus status);

    boolean areAllIdsExistInDatabase(List<Long> idList);

    boolean existById(Long id);

    void update(BillingDataChangeDTO dataChangeDTO);

    List<BillingDataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus);

    void reject(Long id);

    List<BillingDataChange> getAllByApprovalStatus(String approvalStatus);

    String deleteById(Long id);
}
