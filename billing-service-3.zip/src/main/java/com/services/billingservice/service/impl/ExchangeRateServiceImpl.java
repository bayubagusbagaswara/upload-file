package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.exchangerate.*;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.mapper.ExchangeRateMapper;
import com.services.billingservice.model.ExchangeRate;
import com.services.billingservice.repository.ExchangeRateRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.ExchangeRateService;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExchangeRateServiceImpl implements ExchangeRateService {

    private static final String ID_NOT_FOUND = "Exchange Rate not found with id: ";
    private static final String UNKNOWN = "unknown";
    private static final DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final ExchangeRateRepository exchangeRateRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final ExchangeRateMapper exchangeRateMapper;

    // PASTIKAN MAPPING DARI STRING KE TIPE DATE itu SESUAI
    //         LocalDate date = ConvertDateUtil.parseDateOrDefault(request.getDate(), formatter);

    @Override
    public ExchangeRateDTO getById(Long id) {
        ExchangeRate exchangeRate = exchangeRateRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return exchangeRateMapper.mapToDto(exchangeRate);
    }

    @Override
    public List<ExchangeRateDTO> getAll() {
        List<ExchangeRate> all = exchangeRateRepository.findAll();
        return exchangeRateMapper.mapToDTOList(all);
    }

    @Override
    public ExchangeRateDTO getByCurrency(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findByCurrency(currency)
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate not found with currency: " + currency));
        return exchangeRateMapper.mapToDto(exchangeRate);
    }

    @Override
    public ExchangeRateResponse createSingleData(CreateExchangeRateRequest createRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data exchange rate with request: {}", createRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        ExchangeRateDTO exchangeRateDTO = exchangeRateMapper.mapFromCreateRequestToDto(createRequest);

        try {
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateExchangeRateUsingValidator(exchangeRateDTO);

            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(exchangeRateDTO.getId().toString(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setInputerId(createRequest.getInputerId());
                dataChangeDTO.setInputerIPAddress(createRequest.getInputerIPAddress());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRateDTO)));

                dataChangeService.createChangeActionADD(dataChangeDTO, ExchangeRate.class);
                totalDataSuccess++;
            }

        } catch (Exception e) {
            handleGeneralError(exchangeRateDTO, e, errorMessageDTOList);
            totalDataFailed++;
        }
        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public ExchangeRateResponse createSingleApprove(ExchangeRateApproveRequest approveRequest) {
        log.info("Approve when create single data exchange rate with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        ExchangeRateDTO exchangeRateDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);

            Errors errors = validateExchangeRateUsingValidator(exchangeRateDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRateDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            } else {
                ExchangeRate exchangeRate = exchangeRateMapper.createEntity(exchangeRateDTO, dataChangeDTO);
                ExchangeRate exchangeRateSaved = exchangeRateRepository.save(exchangeRate);

                dataChangeDTO.setDescription("Successfully approve data change and save data exchange rate");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRateSaved)));
                dataChangeDTO.setEntityId(exchangeRateSaved.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(exchangeRateDTO, e, errorMessageDTOList);
            totalDataFailed++;
        }
        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public ExchangeRateResponse updateSingleData(UpdateExchangeRateRequest updateRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data exchange rate with request: {}", updateRequest);
        dataChangeDTO.setInputerId(updateRequest.getInputId());
        dataChangeDTO.setInputerIPAddress(updateRequest.getInputIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        ExchangeRateDTO exchangeRateDTO = exchangeRateMapper.mapFromUpdateRequestToDto(updateRequest);
        try {
            ExchangeRate exchangeRate = exchangeRateRepository.findById(exchangeRateDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + exchangeRateDTO.getId()));

            AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
            AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

            processUpdateExchangeRate(exchangeRate, exchangeRateDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

            totalDataSuccess = successCounter.get();
            totalDataFailed = failedCounter.get();
        } catch (Exception e) {
            handleGeneralError(exchangeRateDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private void processUpdateExchangeRate(ExchangeRate exchangeRate,
                                          ExchangeRateDTO exchangeRateDTO,
                                          BillingDataChangeDTO dataChangeDTO,
                                          List<ErrorMessageDTO> errorMessageList,
                                          AtomicInteger successCounter,
                                          AtomicInteger failedCounter) {
        try {
            List<String> validationErrors = new ArrayList<>();

            Errors errors = validateExchangeRateUsingValidator(exchangeRateDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(exchangeRateDTO.getId().toString(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                failedCounter.getAndIncrement();
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRate)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRateDTO)));
                dataChangeDTO.setEntityId(exchangeRate.getId().toString());

                dataChangeService.createChangeActionEDIT(dataChangeDTO, ExchangeRate.class);
                successCounter.incrementAndGet(); // Increment totalDataSuccess
            }
        } catch (Exception e) {
            handleGeneralError(exchangeRateDTO, e, errorMessageList);
            failedCounter.incrementAndGet(); // Increment totalDataFailed
        }
    }

    @Override
    public ExchangeRateResponse updateApprove(ExchangeRateApproveRequest approveRequest) {
        log.info("Approve when update exchange rate with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        ExchangeRateDTO exchangeRateDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            Errors errors = validateExchangeRateUsingValidator(exchangeRateDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            ExchangeRate exchangeRate = exchangeRateRepository.findById(exchangeRateDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + exchangeRateDTO.getId()));

            // Copy data from DTO to Entity
            exchangeRateMapper.mapObjects(exchangeRateDTO, exchangeRate);
            log.info("Fee schedule after copy properties: {}", exchangeRate);

            // Retrieve and set billing data change
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setEntityId(exchangeRate.getId().toString());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRateDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                ExchangeRate exchangeRateUpdated = exchangeRateMapper.updateEntity(exchangeRate, dataChangeDTO);
                ExchangeRate exchangeRateSaved = exchangeRateRepository.save(exchangeRateUpdated);

                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRateSaved)));
                dataChangeDTO.setDescription("Successfully approve data change and update data entity");
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(exchangeRateDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public String deleteAll() {
        exchangeRateRepository.deleteAll();
        return "Successfully delete all Exchange Rate";
    }

    private Errors validateExchangeRateUsingValidator(ExchangeRateDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "exchangeRateDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change not found with id: {}", dataChangeId);
            throw new DataNotFoundException("Data Change id not found with id: " + dataChangeId);
        }
    }

    private void handleGeneralError(ExchangeRateDTO exchangeRateDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(exchangeRateDTO != null ? String.valueOf(exchangeRateDTO.getId()) : UNKNOWN, validationErrors));
    }

}
