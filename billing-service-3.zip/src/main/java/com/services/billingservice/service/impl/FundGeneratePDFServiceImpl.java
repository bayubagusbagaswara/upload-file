package com.services.billingservice.service.impl;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingFundMapper;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.FundGeneratePDFService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.constant.FundConstant.*;
import static com.services.billingservice.constant.FundConstant.KSEI_TRANSACTION_AMOUNT_DUE;
import static com.services.billingservice.constant.FundConstant.TOTAL_AMOUNT_DUE;
import static com.services.billingservice.enums.BillingTemplate.FUND_TEMPLATE;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundGeneratePDFServiceImpl implements FundGeneratePDFService {

    @Value("${base.path.billing.fund}")
    private String basePathBillingFund;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private static final String ACCOUNT_BANK_BDI = "PT Bank Danamon Indonesia";

    private final BillingFundRepository billingFundRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingFundMapper billingFundMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;


    @Override
    public String generatePDF(String category, String monthYear) {
        log.info("Start generate PDF Billing Fund with month year '{}'", monthYear);
        try {
            /**
             * TODO: Bagaimana monthYear nya? Apakah dari belakang getMonthMinus1()
             * TODO: kapan proses generate PDF ini dilakukan? atau request dari depan apa saja?
             */
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(monthYear);
            String month = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatus(
                    category, month, year, approvalStatus
            );

            generateAndSavePdfStatements(billingFundList);

            log.info("Finished generate PDF file for Billing Fund");
            return "Successfully created a PDF file for Billing Fund";
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Fund : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Fund : " + e.getMessage());
        }
    }

    private void generateAndSavePdfStatements(List<BillingFund> billingFundList) {
        log.info("Start generate and save pdf statements Billing Fund");
        Instant dateNow = Instant.now();
        List<BillingFundDTO> billingFundDTOList = billingFundMapper.mapToDTOList(billingFundList);

        for (BillingFundDTO fundDTO : billingFundDTOList) {
            log.info("Start generate PDF Billing Fund type '{}' and customer code '{}'", fundDTO.getBillingType(), fundDTO.getCustomerCode());

            BillingReportGenerator billingReportGenerator = new BillingReportGenerator();
            String investmentManagementName = fundDTO.getInvestmentManagementName();
            String investmentManagementEmail = fundDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = fundDTO.getInvestmentManagementUniqueKey();
            String customerCode = fundDTO.getCustomerCode();
            String customerName = fundDTO.getCustomerName();
            String billingCategory = fundDTO.getBillingCategory();
            String billingType = fundDTO.getBillingType();
            String billingPeriod = fundDTO.getBillingPeriod();
            String currency = fundDTO.getCurrency();

            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String htmlContent;
            byte[] pdfBytes;
            String fileName;
            String filePath;
            String folderPath;
            String outputPath;

            monthYearMap = convertDateUtil.extractMonthYearInformation(fundDTO.getBillingPeriod());

            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            yearMonthFormat =  year + monthYearMap.get("monthValue");

            fileName = generateFileName(customerCode, yearMonthFormat);

            folderPath = basePathBillingFund + yearMonthFormat + "/" +  investmentManagementName;

            filePath = folderPath + "/" + fileName;

            try {
                htmlContent = renderThymeleafTemplate(fundDTO);
                pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);

                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                Path outputPathObj = folderPathObj.resolve(fileName);
                outputPath = outputPathObj.toString();

                pdfGenerator.savePdfToFile(pdfBytes, outputPath);

                billingReportGeneratorService.checkingExistingBillingReportGenerator(
                        customerCode, billingCategory, billingType, currency, billingPeriod
                );

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setInvestmentManagementUniqueKey(investmentManagementUniqueKey);
                billingReportGenerator.setCustomerCode(customerCode);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
                billingReportGenerator.setDesc("Success generate and save PDF statements");

                billingReportGeneratorService.saveSingleData(billingReportGenerator);
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF : " + e.getMessage(), e);
                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setInvestmentManagementUniqueKey(investmentManagementUniqueKey);
                billingReportGenerator.setCustomerCode(customerCode);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(folderPath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
                billingReportGenerator.setDesc(e.getMessage());

                billingReportGeneratorService.saveSingleData(billingReportGenerator);
            }
        }
    }

    private String renderThymeleafTemplate(BillingFundDTO fundDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, fundDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, fundDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, fundDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, fundDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, fundDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, fundDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, fundDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, fundDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, fundDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, fundDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, fundDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, fundDTO.getInvestmentManagementAddress4());
        context.setVariable(ACCOUNT_NAME, fundDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, fundDTO.getAccount());
        context.setVariable(ACCOUNT_BANK, ACCOUNT_BANK_BDI);
        context.setVariable(CUSTOMER_FEE, fundDTO.getCustomerFee());
        context.setVariable(ACCRUAL_CUSTODIAL_FEE, fundDTO.getAccrualCustodialFee());
        context.setVariable(BI_SSSS_TRANSACTION_VALUE_FREQUENCY, fundDTO.getBis4TransactionValueFrequency());
        context.setVariable(BI_SSSS_TRANSACTION_FEE, fundDTO.getBis4TransactionFee());
        context.setVariable(BI_SSSS_TRANSACTION_AMOUNT_DUE, fundDTO.getBis4TransactionAmountDue());
        context.setVariable(SUB_TOTAL, fundDTO.getSubTotal());
        context.setVariable(VAT_FEE, fundDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, fundDTO.getVatAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, fundDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, fundDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, fundDTO.getKseiTransactionAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, fundDTO.getTotalAmountDue());

        // tambahkan Image URL
        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        return templateEngine.process(FUND_TEMPLATE.getValue(), context);
    }

    private String generateFileName(String aid, String yearMonth) {
        return aid + "_" + yearMonth + ".pdf";
    }


}
