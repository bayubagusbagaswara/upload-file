package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.*;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.mapper.FeeParameterMapper;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.repository.BillingFeeParamRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingFeeParameterService;
import com.services.billingservice.utils.JsonUtil;
import com.services.billingservice.utils.NumericValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFeeParameterServiceImpl implements BillingFeeParameterService {

    private static final String ID_NOT_FOUND = "Fee Parameter not found with id: ";
    private static final String CODE_NOT_FOUND = "Fee Parameter not found with code: ";
    private static final String UNKNOWN = "unknown";

    private final BillingFeeParamRepository feeParameterRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final FeeParameterMapper feeParameterMapper;
    private final NumericValidator numericValidator;

    @Override
    public boolean isCodeAlreadyExists(String code) {
        return feeParameterRepository.existsByFeeCode(code);
    }

    @Override
    public boolean isNameAlreadyExists(String name) {
        return feeParameterRepository.existsByFeeName(name);
    }

    @Override
    public FeeParameterResponse createSingleData(CreateFeeParameterRequest createFeeParameterRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data fee parameter with request: {}", createFeeParameterRequest);
        FeeParameterDTO feeParameterDTO = feeParameterMapper.mapFromCreateRequestToDto(createFeeParameterRequest);
        dataChangeDTO.setInputerId(createFeeParameterRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createFeeParameterRequest.getInputerIPAddress());
        return processFeeParameterCreation(feeParameterDTO, dataChangeDTO);
    }

    @Override
    public FeeParameterResponse createMultipleData(FeeParameterListRequest createFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create multiple fee parameter with request: {}", createFeeParameterListRequest);
        dataChangeDTO.setInputerId(createFeeParameterListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createFeeParameterListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (FeeParameterDataListRequest feeParameterDataListRequest : createFeeParameterListRequest.getFeeParameterDataListRequests()) {
            FeeParameterDTO feeParameterDTO = feeParameterMapper.mapFromDataListToDTO(feeParameterDataListRequest);
            FeeParameterResponse response = processFeeParameterCreation(feeParameterDTO, dataChangeDTO);
            totalDataSuccess += response.getTotalDataSuccess();
            totalDataFailed += response.getTotalDataFailed();
            errorMessageList.addAll(response.getErrorMessageDTOList());
        }

        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private FeeParameterResponse processFeeParameterCreation(FeeParameterDTO feeParameterDTO, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            List<String> validationErrors = new ArrayList<>();

            // validate columns
            Errors errors = validateFeeParameterUsingValidator(feeParameterDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(objectError -> validationErrors.add(objectError.getDefaultMessage()));
            }

            // validate code already exists
            validationCodeAlreadyExists(feeParameterDTO.getFeeCode(), validationErrors);

            // validate name already exists
            validationNameAlreadyExists(feeParameterDTO.getFeeName(), validationErrors);

            dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
            dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
            dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));

            if (validationErrors.isEmpty()) {
                dataChangeService.createChangeActionADD(dataChangeDTO, BillingFeeParam.class);
                totalDataSuccess++;
            } else {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getFeeCode(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                totalDataFailed++;
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, errorMessageList);
            totalDataFailed++;
        }

        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeParameterResponse createSingleApprove(FeeParameterApproveRequest approveRequest) {
        log.info("Approve single fee parameter with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        FeeParameterDTO feeParameterDTO = approveRequest.getData();

        try {
            List<String> validationErrors = new ArrayList<>();

            // validate columns
            Errors errors = validateFeeParameterUsingValidator(feeParameterDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(objectError -> validationErrors.add(objectError.getDefaultMessage()));
            }

            // validate code already exists
            validationCodeAlreadyExists(feeParameterDTO.getFeeCode(), validationErrors);

            // validate name already exists
            validationNameAlreadyExists(feeParameterDTO.getFeeName(), validationErrors);

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(Long.valueOf(approveRequest.getDataChangeId()));
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingFeeParam feeParameter = feeParameterMapper.createEntity(feeParameterDTO, dataChangeDTO);
                feeParameterRepository.save(feeParameter);

                dataChangeDTO.setDescription("Successfully approve data change and save data fee parameter");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameter)));
                dataChangeDTO.setEntityId(feeParameter.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeParameterResponse updateSingleData(UpdateFeeParameterRequest updateRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data fee parameter with request: {}", updateRequest);
        dataChangeDTO.setInputerId(updateRequest.getInputId());
        dataChangeDTO.setInputerIPAddress(updateRequest.getInputIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        FeeParameterDTO feeParameterDTO = feeParameterMapper.mapFromUpdateRequestToDto(updateRequest);
        try {
            BillingFeeParam feeParameter = feeParameterRepository.findById(feeParameterDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeParameterDTO.getId()));

            AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
            AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

            processUpdateFeeParameter(feeParameter, feeParameterDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

            totalDataSuccess = successCounter.get();
            totalDataFailed = failedCounter.get();
        } catch (DataNotFoundException e) {
            handleDataNotFoundException(feeParameterDTO, e, errorMessageList);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeParameterResponse updateMultipleData(FeeParameterListRequest updateListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple data fee parameter with request: {}", updateListRequest);
        dataChangeDTO.setInputerId(updateListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (FeeParameterDataListRequest feeParameterDataListRequest : updateListRequest.getFeeParameterDataListRequests()) {
            FeeParameterDTO feeParameterDTO = feeParameterMapper.mapFromDataListToDTO(feeParameterDataListRequest);
            try {
                BillingFeeParam feeParameter = feeParameterRepository.findByCode(feeParameterDTO.getFeeCode())
                        .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + feeParameterDTO.getFeeCode()));

                AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
                AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

                processUpdateFeeParameter(feeParameter, feeParameterDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

                totalDataSuccess = successCounter.get();
                totalDataFailed = failedCounter.get();
            } catch (DataNotFoundException e) {
                handleDataNotFoundException(feeParameterDTO, e, errorMessageList);
                totalDataFailed++;
            } catch (Exception e) {
                handleGeneralError(feeParameterDTO, e, errorMessageList);
                totalDataFailed++;
            }
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private void processUpdateFeeParameter(BillingFeeParam feeParameter,
                                           FeeParameterDTO feeParameterDTO,
                                           BillingDataChangeDTO dataChangeDTO,
                                           List<ErrorMessageDTO> errorMessageList,
                                           AtomicInteger successCounter,
                                           AtomicInteger failedCounter) {
        try {
            List<String> validationErrors = new ArrayList<>();
            // TODO: data CustomerDTO tidak semua diisi, maka kita perlu cek satu per satu datanya apakah null atau tidak

            // CATATAN: Code and Name tidak boleh diupdate
            // kemungkinan di upload list akan dikirimkan code dan name, kita get data berdasarkan feeParameterCode
            // Cara agar feeName tidak keupdate adalah mengisi datanya null atau string kosong
            if (feeParameterDTO.getFeeName() != null && !feeParameterDTO.getFeeName().isEmpty()) {
                feeParameterDTO.setFeeName(""); // atau bisa diganti feeParameter.getFeeName();
            }

            // TODO: check validation Fee Value
            if (feeParameterDTO.getFeeValue() != null && !feeParameterDTO.getFeeValue().isEmpty()) {
                validationFeeValue(feeParameterDTO.getFeeValue(), validationErrors);
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getFeeCode(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                failedCounter.incrementAndGet();
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameter)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeDTO.setEntityId(feeParameter.getId().toString());

                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingFeeParam.class);
                successCounter.incrementAndGet(); // Increment totalDataSuccess
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, errorMessageList);
            failedCounter.incrementAndGet(); // Increment totalDataFailed
        }
    }

    private void validationFeeValue(String feeValue, List<String> validationErrors) {
        if (!numericValidator.isValidBigDecimal(feeValue)) {
            validationErrors.add("Fee Value must contain decimal digit");
        }
    }

    @Override
    public FeeParameterResponse updateSingleApprove(FeeParameterApproveRequest approveRequest) {
        log.info("Approve when update fee parameter with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        FeeParameterDTO feeParameterDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            BillingFeeParam feeParameter = feeParameterRepository.findByCode(feeParameterDTO.getFeeCode())
                    .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + feeParameterDTO.getFeeCode()));

            // copy data DTO to Entity
            feeParameterMapper.mapObjects(feeParameterDTO, feeParameter);
            log.info("Fee Parameter after copy properties: {}", feeParameter);

            // Retrieve and set billing data change
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setEntityId(feeParameter.getId().toString());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingFeeParam feeParameterUpdated = feeParameterMapper.updateEntity(feeParameter, dataChangeDTO);
                BillingFeeParam feeParameterSaved = feeParameterRepository.save(feeParameterUpdated);

                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterSaved)));
                dataChangeDTO.setDescription("Successfully approve data change and update data entity");
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public List<FeeParameterDTO> getAll() {
        List<BillingFeeParam> all = feeParameterRepository.findAll();
        return feeParameterMapper.mapToDTOList(all);
    }

    @Override
    public FeeParameterDTO getByCode(String code) {
        BillingFeeParam billingFeeParam  = feeParameterRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + code));
        return feeParameterMapper.mapToDto(billingFeeParam);
    }

    @Override
    public FeeParameterDTO findById(Long id) {
        BillingFeeParam billingFeeParam  = feeParameterRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return feeParameterMapper.mapToDto(billingFeeParam);
    }

    @Override
    public String deleteAll() {
        feeParameterRepository.deleteAll();
        return "Successfully delete all Fee Parameter";
    }

    @Override
    public BigDecimal getValueByName(String name) {
        BillingFeeParam billingFeeParam = feeParameterRepository.findByFeeName(name)
                .orElseThrow(() -> new DataNotFoundException("Fee Parameter not found with name: " + name));
        return billingFeeParam.getFeeValue();
    }

    @Override
    public Map<String, BigDecimal> getValueByNameList(List<String> nameList) {
        List<BillingFeeParam> feeParameterList = feeParameterRepository.findBillingFeeParamByFeeNameList(nameList);
        Map<String, BigDecimal> collect = feeParameterList.stream()
                .collect(Collectors.toMap(
                        BillingFeeParam::getFeeName,
                        BillingFeeParam::getFeeValue
                ));
        for (String name : nameList) {
            if (!collect.containsKey(name)) {
                throw new DataNotFoundException("Fee Parameter not found with name: " + name);
            }
        }
        return collect;
    }

    private void validationCodeAlreadyExists(String code, List<String> errorMessages) {
        if (isCodeAlreadyExists(code)) {
            errorMessages.add("Fee Parameter is already taken with code: " + code);
        }
    }

    private void validationNameAlreadyExists(String name, List<String> validationErrors) {
        if (isNameAlreadyExists(name)) {
            validationErrors.add("Fee Parameter is already taken with name: " + name);
        }
    }

    private Errors validateFeeParameterUsingValidator(FeeParameterDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "feeParameterDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void handleDataNotFoundException(FeeParameterDTO feeParameterDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageList) {
        log.error("Fee Parameter not found with id: {}", feeParameterDTO != null ? feeParameterDTO.getFeeCode() : UNKNOWN, e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeParameterDTO != null ? feeParameterDTO.getFeeCode() : UNKNOWN, validationErrors));
    }

    private void handleGeneralError(FeeParameterDTO feeParameterDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeParameterDTO != null ? feeParameterDTO.getFeeCode() : UNKNOWN, validationErrors));
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change not found with id: {}", dataChangeId);
            throw new DataNotFoundException("Data Change id not found: " + dataChangeId);
        }
    }

}
