package com.services.billingservice.service.impl;

import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.GefuTransactionStatus;
import com.services.billingservice.enums.GefuTransactionType;
import com.services.billingservice.model.*;
import com.services.billingservice.repository.*;
import com.services.billingservice.service.BillingGefuGeneratorService;
import com.services.billingservice.utils.GefuUtil;
import com.services.billingservice.utils.RC4Util;
import com.services.billingservice.utils.SFTPClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.services.billingservice.enums.BillingCategory.*;
import static com.services.billingservice.enums.BillingTemplate.*;
import static com.services.billingservice.enums.BillingType.*;


@Slf4j
@Service
@RequiredArgsConstructor
public class BillingGefuGeneratorServiceImpl implements BillingGefuGeneratorService {

    private final BillingCoreRepository billingCoreRepository;
    private final BillingFundRepository billingFundRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingGefuHistoryRepository billingGefuHistoryRepository;
    private final BillingGefuDetailRepository billingGefuDetailRepository;
    private final BillingGlCreditRepository billingGlCreditRepository;
    private final BillingCustomerRepository billingCustomerRepository;
    private final ExchangeRateRepository rateRepository;
    private final BillingConnectionParameterRepository connectionParameterRepository;

    private static DateFormat DF1 = new SimpleDateFormat("yyyyMMdd");
    private static DateFormat DF2 = new SimpleDateFormat("ddMMyy");
    private static DateFormat DF3 = new SimpleDateFormat("dd MMMM yyyy");
    private static DecimalFormat decimalFmt = new DecimalFormat("0");

    private static String fileFolder = "D:\\DST\\CSA\\FILES";

    @Override
    public void checkExistGefuFileName(String fileName) {

    }

    @Override
    public void deleteExistGefuFile(String fileName) {

    }

    @Override
    public String createGefu(String category, String month, int year, String customerCode, String userId) {
        String successCode = "00";
        final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
                "yyyyMMdd");

        long idBilling = 0;
        String template = null;
        String type = null;
        String currency = "";

        if (CORE.name().contains(category)) {
            BillingCore billingCores = billingCoreRepository.
                    findByCustomerCodeAndMonthAndYearAndApprovalStatus(
                            month, year, customerCode, ApprovalStatus.Approved.getStatus());
            if (billingCores != null) {
                idBilling = billingCores.getId();
                type = billingCores.getBillingType();
                template = billingCores.getBillingTemplate();
                currency = billingCores.getCurrency();
            }
        } else if (FUND.name().contains(category)) {
            BillingFund billingFund = billingFundRepository.
                    findByCustomerCodeAndMonthAndYearAndApprovalStatus(
                            customerCode, month, year, ApprovalStatus.Approved.getStatus());
            if (billingFund != null) {
                idBilling = billingFund.getId();
                type = billingFund.getBillingType();
                template = billingFund.getBillingTemplate();
                currency = billingFund.getCurrency();

            }
        } else if (RETAIL.name().contains(category)) {
            BillingRetail billingRetail = billingRetailRepository.
                    findByCustomerCodeAndMonthAndYearAndApprovalStatus(
                            customerCode, month, year, ApprovalStatus.Approved.getStatus());
            if (billingRetail != null) {
                idBilling = billingRetail.getId();
                type = billingRetail.getBillingType();
                template = billingRetail.getBillingTemplate();
                currency = billingRetail.getCurrency();
            }
        }


        if (template != null) {

            String gefufileName = "CSA_GEFU_BILLING_" + month +
                    String.valueOf(year) + "_" + customerCode + "_"
                    + DATE_FORMAT.format(new Date()) + ".hit";

            BillingGefuProcessHistory history = billingGefuHistoryRepository.
                    findByFileName(gefufileName);


            if (history == null) {

                history = new BillingGefuProcessHistory();
                history.setApprovalStatus(ApprovalStatus.Pending);
                history.setProcessDate(new Date());
                history.setInputerId(userId);
                history.setInputDate(new Date());
                history.setFileName(gefufileName);
                history.setCategory(category);
                history.setType(type);
                history.setTemplate(template);
                history.setIdBilling(idBilling);
                history.setCurrency(currency);
                history.setCustomerCode(customerCode);
                history.setBillingPeriode(month + " " + year);

                billingGefuHistoryRepository.save(history);


                gefuCoreGenerator(history, template);


            }


        }

        return successCode;
    }

    @Override
    public boolean approveAndSendGefu(long gefuProcessHistory, String approverId) {
        BillingGefuProcessHistory gefuHistory =
                billingGefuHistoryRepository.findById(gefuProcessHistory);

        List<ConnectionParameter> param = connectionParameterRepository.findAll();
        ConnectionParameter parameter = param.get(2);

        String host = parameter.getNcbsSftpHost();
        String userID = parameter.getNcbsSftpUser();
        String privateKeyPath = parameter.getNcbsSftpPrivateKeyPath();
        String sftpDestFolder = parameter.getNcbsSftpRemoteFolderIn();

        File outputFolder = new File(fileFolder, parameter.getNcbsSftpLocalFolderOutgoing());


        BillingRetail billingRetail = null;
        BillingFund billingFund = null;
        BillingCore billingCores = null;

        if (CORE.name().contains(gefuHistory.getCategory())) {
            billingCores = billingCoreRepository.
                    findById(gefuHistory.getIdBilling()).orElse(null);
        } else if (FUND.name().contains(gefuHistory.getCategory())) {
            billingFund = billingFundRepository.
                    findById(gefuHistory.getIdBilling()).orElse(null);
        } else if (RETAIL.name().contains(gefuHistory.getCategory())) {
            billingRetail = billingRetailRepository.
                    findById(gefuHistory.getIdBilling()).orElse(null);
        }

        boolean sendSuccess = false;

        try {

            String content = "";
            String billTemplate = gefuHistory.getTemplate();

            if (TYPE_1.name().contains(gefuHistory.getType())) {

                if (FUND_TEMPLATE.name().contains(billTemplate)) {
                    content = gefuFundFileGenerator(gefuHistory, billingFund);
                } else if (RETAIL_TEMPLATE_1_IDR.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else if (RETAIL_TEMPLATE_1_USD.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                }

            } else if (TYPE_2.name().contains(gefuHistory.getType())) {

                if (RETAIL_TEMPLATE_2_IDR.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else if (RETAIL_TEMPLATE_2_USD.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                }

            } else if (TYPE_3.name().contains(gefuHistory.getType())) {

                if (RETAIL_TEMPLATE_3_IDR.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else if (RETAIL_TEMPLATE_3_USD.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                }

            } else if (TYPE_4.name().contains(gefuHistory.getType())) {

                if (RETAIL_TEMPLATE_4_IDR.name().contains(billTemplate)) {
                    content = gefuRetailFileGenerator(gefuHistory, billingRetail);
                } else if (CORE_TEMPLATE_5.name().contains(billTemplate)) {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                } else {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                }

            } else if (TYPE_5.name().contains(gefuHistory.getType())) {

                if (CORE_TEMPLATE_1.name().contains(billTemplate)) {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                } else {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                }

            } else if (TYPE_6.name().contains(gefuHistory.getType())) {
                if (CORE_TEMPLATE_1.name().contains(billTemplate)) {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                } else {
                    content = gefuCoreFileGenerator(gefuHistory, billingCores);
                }
            } else if (TYPE_7.name().contains(gefuHistory.getType())) {
                content = gefuCoreFileGenerator(gefuHistory, billingCores);
            } else if (TYPE_8.name().contains(gefuHistory.getType())) {
                content = gefuCoreFileGenerator(gefuHistory, billingCores);
            } else if (TYPE_9.name().contains(gefuHistory.getType())) {
                content = gefuCoreFileGenerator(gefuHistory, billingCores);
            } else if (TYPE_10.name().contains(gefuHistory.getType())) {
                content = gefuCoreFileGenerator(gefuHistory, billingCores);
            } else if (TYPE_11.name().contains(gefuHistory.getType())) {
                content = gefuCoreFileGenerator(gefuHistory, billingCores);
            }


            byte[] encryptedContent = new RC4Util(parameter.getGefuResponsePassword().getBytes())
                    .encrypt(content.getBytes());

            File file = new File(outputFolder,
                    gefuHistory.getFileName());
            FileOutputStream out = new FileOutputStream(file);
            IOUtils.write(encryptedContent, out);
            out.flush();
            out.close();
            out = null;
            System.gc();

            sendSuccess = GefuUtil.sendFileGefu(file, host, userID
                    , privateKeyPath, sftpDestFolder);

            if (sendSuccess) {
                gefuHistory.setSent(true);
                gefuHistory.setSentDate(new Date());
                gefuHistory.setApprovalStatus(ApprovalStatus.Approved);
                gefuHistory.setApproverId(approverId);
                gefuHistory.setApproveDate(new Date());

                billingGefuHistoryRepository.save(gefuHistory);

                file.setWritable(true);
            }

        } catch (Exception e) {
            gefuHistory.setSent(false);
            gefuHistory.setSentDate(new Date());
            gefuHistory.setApprovalStatus(ApprovalStatus.Rejected);
            gefuHistory.setApproverId(approverId);
            gefuHistory.setApproveDate(new Date());

            billingGefuHistoryRepository.save(gefuHistory);

            e.printStackTrace();
        }


        return sendSuccess;
    }

    @Override
    public void rejectGefu(long gefuProcessHistory, String approverId) {
        BillingGefuProcessHistory gefuHistory =
                billingGefuHistoryRepository.findById(gefuProcessHistory);

        if (gefuHistory != null) {
            String fileName = gefuHistory.getFileName().replace(".hit", "_reject.hit");
            gefuHistory.setApprovalStatus(ApprovalStatus.Rejected);
            gefuHistory.setApproverId(approverId);
            gefuHistory.setApproveDate(new Date());
            gefuHistory.setFileName(fileName);

            billingGefuHistoryRepository.save(gefuHistory);
            billingGefuDetailRepository.rejectGefuDetail(gefuProcessHistory, approverId);
        }
    }

    @Override
    public boolean readGefuResponse() {

        List<ConnectionParameter> param = connectionParameterRepository.findAll();
        ConnectionParameter parameter = param.get(2);

        String host = parameter.getNcbsSftpHost();
        String userID = parameter.getNcbsSftpUser();
        String privateKeyPath = parameter.getNcbsSftpPrivateKeyPath();
        String sftpDestFolder = parameter.getNcbsSftpRemoteFolderIn();
        String filenamePattern = parameter.getGefuFileNamePattern() + "";
        String sftpLocalFolderIn = parameter.getGefuSftpLocalFolderIncoming();

        System.out.println("sftp local folder in : " + sftpLocalFolderIn);
        System.out.println(" Filename Pattern : " + filenamePattern);

        SFTPClient sftpClient = null;
        try {
            System.out.println("Read Gefu Responses");

//            sftpClient = new SFTPClient(host, userID, privateKeyPath);
//            sftpClient.changeLocalDirectory(sftpLocalFolderIn);
//            sftpClient.changeDirectory(sftpDestFolder);
//            List<String> fileNames = sftpClient.getFileNames(sftpDestFolder);

            List<String> fileNames = billingGefuHistoryRepository.findNotRejectedFileName();


            System.out.println("sftp dest folder out : " + sftpDestFolder);

            for (String fileName : fileNames) {
//                if (fileName.startsWith(filenamePattern)) {
                System.out.println("Downloading file " + fileName + "...");
                System.out.println(sftpLocalFolderIn);
                System.out.println(fileName);

                File file = new File(sftpLocalFolderIn, fileName);
                System.out.println(file.exists());
                if (file.exists()) {

                    System.out.println("kemari");
                    getGefuDetail(parameter, sftpClient, fileName, file);

                } else {

                    boolean downloadSuccess = sftpClient.getFile(fileName, file.getAbsolutePath());

                    if (downloadSuccess && file.exists()) {

                        boolean deleteSuccess = sftpClient.delete(fileName);
                        if (deleteSuccess) {
                            System.out.println("Successfully delete remote file " + fileName);
                        } else {
                            System.out.println("Failed deleting remote file " + fileName + "!");
                        }

                        getGefuDetail(parameter, sftpClient, fileName, file);

                    } else {
                        System.out.println("Failed downloading file " + fileName + " from NCBS!");
                    }
                }


//                }
            }

        } catch (Exception e) {
            System.err.println("terjadi exception " + e.getMessage());
        } finally {
            if (sftpClient != null) {
                sftpClient.close();
            }
        }

        return false;

    }

    private void getGefuDetail(ConnectionParameter parameter, SFTPClient sftpClient, String fileName, File file) throws IOException {
        System.out.println("Successfully downloaded file " + fileName + " from NCBS");

        boolean parseSuccess = false;
        boolean processed = false;

        byte[] gefuFilePassword = parameter.getGefuResponsePassword().getBytes();

        byte[] textFile = IOUtils.toByteArray(new FileInputStream(file));

        byte[] decryptedText = new RC4Util(gefuFilePassword).decrypt(textFile);
        System.out.println(new String(decryptedText));

        String clearText = new String(decryptedText);
        String[] split = clearText.split("\n");

        String[] response;

        for (int i = 1; i < split.length - 1; i++) {
            response = split[i].split(":");

            BillingGefuProcessHistory history = billingGefuHistoryRepository
                    .findByFileName(fileName);

            BillingGefuProcessDetail gefuprocessDetail = null;

            if (history != null) {
                gefuprocessDetail = billingGefuDetailRepository.
                        findByGefuProcessHistoryAndReference(history.getId(), response[16]);
            }

            if (gefuprocessDetail != null) {
                if (response[19].equalsIgnoreCase("5")) {
                    gefuprocessDetail.setStatus(GefuTransactionStatus.Success);

                    parseSuccess = true;
                    processed = true;

                } else if (response[19].equalsIgnoreCase("6")) {
                    gefuprocessDetail.setStatus(GefuTransactionStatus.Failure);
                    gefuprocessDetail.setDescription(response[20]);

                    parseSuccess = true;
                    processed = true;
                }

                billingGefuDetailRepository.save(gefuprocessDetail);

            }

        }

        if (processed) {
            if (parseSuccess) {
                System.out.println("Successfully parsed content of file " + fileName);

            }
        } else {
            System.out.println("File " + fileName + " is not yet processed. Skipping..");
        }
    }

    @Override
    public String gefuCoreFileGenerator(BillingGefuProcessHistory gefuHistory, BillingCore billing) {

        ExchangeRate rate = rateRepository.findByCurrency(gefuHistory.getCurrency()).orElse(null);
        double rateValue = (rate != null) ? rate.getValue().doubleValue() : 1;
        System.out.println(rateValue);


        String settleDateStr1 = DF1.format(new Date());
        ;// ;DF1.format(gefuHistory.getProcessDate());
        String settleDateStr2 = DF2.format(gefuHistory.getProcessDate());

        int totalCredit = 0;
        int totalDebit = 0;

        double amountTotalCredit = 0;
        double amountTotalDebit = 0;

        String glNo = "";
        String costCenter = "";
        String trxType = "";
        double amount = 0;

        String txnCode = "";
        String glName = "";
        String trxCodeType = "";
        String typeTxn = "";
        String lobCode = "";

        List<BillingGefuProcessDetail> listGefuDetail = billingGefuDetailRepository.findAllByGefuProcessHistory(gefuHistory.getId());

        StringBuilder sb = new StringBuilder();
        sb.append("1:" + settleDateStr1).append("\r\n");

        for (BillingGefuProcessDetail gefuProcessDetail : listGefuDetail) {

            glNo = gefuProcessDetail.getGLNo().trim();
            costCenter = (gefuProcessDetail.getCostCenter() != null &&
                    !gefuProcessDetail.getCostCenter().trim().isEmpty()) ?
                    gefuProcessDetail.getCostCenter().trim() : "9207";
            amount = gefuProcessDetail.getTotalAmount();

            String result = String.format("%.2f", amount);
            double resultDouble = Double.valueOf(result);

            trxType = gefuProcessDetail.getGefuTransactionType().toString();

            if (trxType.contains("Debit")) {
                trxCodeType = "D";
            } else if (trxType.contains("Credit")) {
                trxCodeType = "C";
            }

            glName = gefuProcessDetail.getGLName();

            if (gefuProcessDetail.isGl()) {
                if (trxCodeType.contains("C")) {
                    txnCode = "1460";
                } else {
                    txnCode = "1060";
                }
            } else {
                if (trxCodeType.contains("C")) {
                    txnCode = "1408";
                } else {
                    txnCode = "1008";
                }
            }

            if (gefuProcessDetail.isGl()) {
                typeTxn = "3";
            } else {
                typeTxn = "1";
            }

            if (glNo.contains("111001")) {
                lobCode = "71";
            } else if (glNo.contains("246025")) {
                lobCode = "71";
            } else {
                lobCode = "0";
            }

            double amountResultXRate = (Math.round(resultDouble * rateValue * 100));
            double amountResult = (Math.round(resultDouble * 100));


            sb.append(
                    "2:" + typeTxn + ":" + glNo + ":" + costCenter + ":"
                            + lobCode + ":GFO923400:0:" + txnCode + ":0:"
                            + settleDateStr1 + ":" + trxCodeType + ":"
                            + settleDateStr1 + ":" + gefuHistory.getCurrency() + ":"
                            + String.format("%.0f", amountResultXRate)
                            + ":" + String.format("%.0f", amountResult) + ":"
                            + decimalFmt.format(rateValue) + ":"
                            + gefuProcessDetail.getReference() + ":1:"
                            + trxCodeType + " " + glNo + " on "
                            + settleDateStr2 + " amt "
                            + String.format("%.0f", amountResult)).append("\r\n");

            if (gefuProcessDetail.getGefuTransactionType().equals(
                    GefuTransactionType.Credit)) {
                totalCredit++;
                amountTotalCredit += Math.round((resultDouble * 100));
            } else {
                totalDebit++;
                amountTotalDebit += Math.round((resultDouble * 100));
            }
        }

        sb.append(
                "3:" + totalDebit + ":"
                        + String.format("%.0f", amountTotalDebit) + ":"
                        + totalCredit + ":"
                        + String.format("%.0f", amountTotalCredit)).

                append("\r");

        System.out.println(sb.toString());
        return sb.toString();
    }

    @Override
    public String gefuRetailFileGenerator(BillingGefuProcessHistory gefuHistory, BillingRetail billing) {

        ExchangeRate rate = rateRepository.findByCurrency(gefuHistory.getCurrency()).orElse(null);
        double rateValue = (rate != null) ? rate.getValue().doubleValue() : 1;
        System.out.println(rateValue);


        String settleDateStr1 = DF1.format(new Date());
        ;// ;DF1.format(gefuHistory.getProcessDate());
        String settleDateStr2 = DF2.format(gefuHistory.getProcessDate());

        int totalCredit = 0;
        int totalDebit = 0;

        double amountTotalCredit = 0;
        double amountTotalDebit = 0;

        String glNo = "";
        String costCenter = "";
        String trxType = "";
        double amount = 0;

        String txnCode = "";
        String glName = "";
        String trxCodeType = "";
        String typeTxn = "";
        String lobCode = "";

        List<BillingGefuProcessDetail> listGefuDetail = billingGefuDetailRepository.findAllByGefuProcessHistory(gefuHistory.getId());

        StringBuilder sb = new StringBuilder();
        sb.append("1:" + settleDateStr1).append("\r\n");

        for (BillingGefuProcessDetail gefuProcessDetail : listGefuDetail) {

            glNo = gefuProcessDetail.getGLNo().trim();
            costCenter = (gefuProcessDetail.getCostCenter() != null &&
                    !gefuProcessDetail.getCostCenter().trim().isEmpty()) ?
                    gefuProcessDetail.getCostCenter().trim() : "9207";
            amount = gefuProcessDetail.getTotalAmount();

            String result = String.format("%.2f", amount);
            double resultDouble = Double.valueOf(result);

            trxType = gefuProcessDetail.getGefuTransactionType().toString();

            if (trxType.contains("Debit")) {
                trxCodeType = "D";
            } else if (trxType.contains("Credit")) {
                trxCodeType = "C";
            }

            glName = gefuProcessDetail.getGLName();

            if (gefuProcessDetail.isGl()) {
                if (trxCodeType.contains("C")) {
                    txnCode = "1460";
                } else {
                    txnCode = "1060";
                }
            } else {
                if (trxCodeType.contains("C")) {
                    txnCode = "1408";
                } else {
                    txnCode = "1008";
                }
            }

            if (gefuProcessDetail.isGl()) {
                typeTxn = "3";
            } else {
                typeTxn = "1";
            }

            if (glNo.contains("111001")) {
                lobCode = "71";
            } else if (glNo.contains("246025")) {
                lobCode = "71";
            } else {
                lobCode = "0";
            }

            double amountResultXRate = (Math.round(resultDouble * rateValue * 100));
            double amountResult = (Math.round(resultDouble * 100));


            sb.append(
                    "2:" + typeTxn + ":" + glNo + ":" + costCenter + ":"
                            + lobCode + ":GFO923400:0:" + txnCode + ":0:"
                            + settleDateStr1 + ":" + trxCodeType + ":"
                            + settleDateStr1 + ":" + gefuHistory.getCurrency() + ":"
                            + String.format("%.0f", amountResultXRate)
                            + ":" + String.format("%.0f", amountResult) + ":"
                            + decimalFmt.format(rateValue) + ":"
                            + gefuProcessDetail.getReference() + ":1:"
                            + trxCodeType + " " + glNo + " on "
                            + settleDateStr2 + " amt "
                            + String.format("%.0f", amountResult)).append("\r\n");

            if (gefuProcessDetail.getGefuTransactionType().equals(
                    GefuTransactionType.Credit)) {
                totalCredit++;
                amountTotalCredit += Math.round((resultDouble * 100));
            } else {
                totalDebit++;
                amountTotalDebit += Math.round((resultDouble * 100));
            }
        }

        sb.append(
                "3:" + totalDebit + ":"
                        + String.format("%.0f", amountTotalDebit) + ":"
                        + totalCredit + ":"
                        + String.format("%.0f", amountTotalCredit)).

                append("\r");

        System.out.println(sb.toString());
        return sb.toString();
    }


    @Override
    public String gefuFundFileGenerator(BillingGefuProcessHistory gefuHistory, BillingFund billing) {

        ExchangeRate rate = rateRepository.findByCurrency(gefuHistory.getCurrency()).orElse(null);
        double rateValue = (rate != null) ? rate.getValue().doubleValue() : 1;
        System.out.println(rateValue);


        String settleDateStr1 = DF1.format(new Date());
        ;// ;DF1.format(gefuHistory.getProcessDate());
        String settleDateStr2 = DF2.format(gefuHistory.getProcessDate());

        int totalCredit = 0;
        int totalDebit = 0;

        double amountTotalCredit = 0;
        double amountTotalDebit = 0;

        String glNo = "";
        String costCenter = "";
        String trxType = "";
        double amount = 0;

        String txnCode = "";
        String glName = "";
        String trxCodeType = "";
        String typeTxn = "";
        String lobCode = "";

        List<BillingGefuProcessDetail> listGefuDetail = billingGefuDetailRepository.findAllByGefuProcessHistory(gefuHistory.getId());

        StringBuilder sb = new StringBuilder();
        sb.append("1:" + settleDateStr1).append("\r\n");

        for (BillingGefuProcessDetail gefuProcessDetail : listGefuDetail) {

            glNo = gefuProcessDetail.getGLNo().trim();
            costCenter = (gefuProcessDetail.getCostCenter() != null &&
                    !gefuProcessDetail.getCostCenter().trim().isEmpty()) ?
                    gefuProcessDetail.getCostCenter().trim() : "9207";
            amount = gefuProcessDetail.getTotalAmount();

            String result = String.format("%.2f", amount);
            double resultDouble = Double.valueOf(result);

            trxType = gefuProcessDetail.getGefuTransactionType().toString();

            if (trxType.contains("Debit")) {
                trxCodeType = "D";
            } else if (trxType.contains("Credit")) {
                trxCodeType = "C";
            }

            glName = gefuProcessDetail.getGLName();

            if (gefuProcessDetail.isGl()) {
                if (trxCodeType.contains("C")) {
                    txnCode = "1460";
                } else {
                    txnCode = "1060";
                }
            } else {
                if (trxCodeType.contains("C")) {
                    txnCode = "1408";
                } else {
                    txnCode = "1008";
                }
            }

            if (gefuProcessDetail.isGl()) {
                typeTxn = "3";
            } else {
                typeTxn = "1";
            }

            if (glNo.contains("111001")) {
                lobCode = "71";
            } else if (glNo.contains("246025")) {
                lobCode = "71";
            } else {
                lobCode = "0";
            }

            double amountResultXRate = (Math.round(resultDouble * rateValue * 100));
            double amountResult = (Math.round(resultDouble * 100));


            sb.append(
                    "2:" + typeTxn + ":" + glNo + ":" + costCenter + ":"
                            + lobCode + ":GFO923400:0:" + txnCode + ":0:"
                            + settleDateStr1 + ":" + trxCodeType + ":"
                            + settleDateStr1 + ":" + gefuHistory.getCurrency() + ":"
                            + String.format("%.0f", amountResultXRate)
                            + ":" + String.format("%.0f", amountResult) + ":"
                            + decimalFmt.format(rateValue) + ":"
                            + gefuProcessDetail.getReference() + ":1:"
                            + trxCodeType + " " + glNo + " on "
                            + settleDateStr2 + " amt "
                            + String.format("%.0f", amountResult)).append("\r\n");

            if (gefuProcessDetail.getGefuTransactionType().equals(
                    GefuTransactionType.Credit)) {
                totalCredit++;
                amountTotalCredit += Math.round((resultDouble * 100));
            } else {
                totalDebit++;
                amountTotalDebit += Math.round((resultDouble * 100));
            }
        }

        sb.append(
                "3:" + totalDebit + ":"
                        + String.format("%.0f", amountTotalDebit) + ":"
                        + totalCredit + ":"
                        + String.format("%.0f", amountTotalCredit)).

                append("\r");

        System.out.println(sb.toString());
        return sb.toString();
    }

    @Override
    public void gefuCoreGenerator(BillingGefuProcessHistory gefuHistory, String billTemplate) {
        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        billingGefuHistoryRepository.save(gfProcessHistory);

        if (TYPE_1.name().contains(gfProcessHistory.getType())) {


            if (FUND_TEMPLATE.name().contains(billTemplate)) {
                //TODO create gefuFundGeneratorCASA(gefuHistory);
                gefuFundGeneratorCASA(gefuHistory);
            } else if (RETAIL_TEMPLATE_1_IDR.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorDirectIDR(gefuHistory);
                gefuRetailGeneratorDirect(gefuHistory);
            } else if (RETAIL_TEMPLATE_1_USD.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorDirectUSD(gefuHistory);
                gefuRetailGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_2.name().contains(gfProcessHistory.getType())) {

            if (RETAIL_TEMPLATE_2_IDR.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorCASAIDR(gefuHistory);
                gefuRetailGeneratorCASA(gefuHistory);
            } else if (RETAIL_TEMPLATE_2_USD.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorCASAUSD(gefuHistory);
                gefuRetailGeneratorCASA(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_3.name().contains(gfProcessHistory.getType())) {

            if (RETAIL_TEMPLATE_3_IDR.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorCASAIDR(gefuHistory);
                gefuRetailGeneratorCASA(gefuHistory);
            } else if (RETAIL_TEMPLATE_3_USD.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorCASAUSD(gefuHistory);
                gefuRetailGeneratorCASA(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_4.name().contains(gfProcessHistory.getType())) {

            if (RETAIL_TEMPLATE_4_IDR.name().contains(billTemplate)) {
                //TODO create gefuRetaileneratorCASAIDR(gefuHistory);
                gefuRetailGeneratorCASA(gefuHistory);
            } else if (CORE_TEMPLATE_5.name().contains(billTemplate)) {
                gefuCoreGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_5.name().contains(gfProcessHistory.getType())) {

            if (CORE_TEMPLATE_1.name().contains(billTemplate)) {
                gefuCoreGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_6.name().contains(gfProcessHistory.getType())) {
            if (CORE_TEMPLATE_1.name().contains(billTemplate)) {
                gefuCoreGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }
        } else if (TYPE_7.name().contains(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        } else if (TYPE_8.name().contains(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        } else if (TYPE_9.name().contains(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        } else if (TYPE_10.name().contains(gfProcessHistory.getType())) {
            gefuCoreGeneratorDirect(gefuHistory);
        } else if (TYPE_11.name().contains(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        }
    }

    @Override
    public void gefuCoreGeneratorDirect(BillingGefuProcessHistory gefuHistory) {
        BillingCore billing =
                billingCoreRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();


        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuHistoryRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);


        // GL Nasabah
        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(billingCustomer.getDebitTransfer());
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(billingCustomer.isGl());
        billingGefuDetailRepository.save(glDebit);

        BillingGlCredit glCredit =
                billingGlCreditRepository.findByGlBillingTemplate(gefuHistory.getTemplate());

        // GL HAK Operasional Credit
        BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
        glCreditDetail
                .setGefuProcessHistory(gefuHistory);
        glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
        glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
        glCreditDetail.setCostCenter("9207");
        glCreditDetail.setFileName(gefuHistory
                .getFileName());
        glCreditDetail
                .setGefuTransactionType(GefuTransactionType.Credit);
        glCreditDetail.setTotalAmount(settleAmount);
        glCreditDetail.setInputerId(gefuHistory.getInputerId());
        glCreditDetail.setInputDate(new java.util.Date());
        glCreditDetail.setReference("C " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(true);
        billingGefuDetailRepository.save(glCreditDetail);
    }

    @Override
    public boolean sendGefu(BillingGefuProcessHistory gefuHistory) {
        return false;
    }

    @Override
    public void gefuCoreGeneratorCASA(BillingGefuProcessHistory gefuHistory) {

        BillingCore billing =
                billingCoreRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuHistoryRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL / Account Nasabah
        String costCenter = billingCustomer.getDebitTransfer() != null ?
                billingCustomer.getDebitTransfer() : "9207";

        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(costCenter);
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D 0" + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(billingCustomer.isGl());
        billingGefuDetailRepository.save(glDebit);

        // GL Dana Custodian Credit

        List<BillingGlCredit> glCreditList =
                billingGlCreditRepository.findAllByGlBillingTemplate(gefuHistory.getTemplate());

        for (BillingGlCredit glCredit : glCreditList) {

            double amount = 0;
            if (glCredit.getGlCreditName().trim().contains("GL Dana Custodian")) {
                amount = billing.getTotalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Transaction Handling")) {
                amount = billing.getTransactionHandlingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Safekeeping Fee")) {
                amount = billing.getSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("VAT")) {
                amount = billing.getVatAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Safekeeping Fee + KSEI Fee")) {
                amount = billing.getSafekeepingAmountDue().doubleValue() +
                        billing.getKseiSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("KSEI Fee (Transaction)")) {
                amount = billing.getKseiTransactionAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("BI-SSSS( Transaction )+ KSEI Fee ( Transaction )")) {
                amount = billing.getBis4TransactionAmountDue().doubleValue() +
                        billing.getKseiTransactionAmountDue().doubleValue();
            }


            BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
            glCreditDetail
                    .setGefuProcessHistory(gefuHistory);
            glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
            glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
            glCreditDetail.setCostCenter("9207");
            glCreditDetail.setFileName(gefuHistory
                    .getFileName());

            String initialType = "C ";
            if (glCredit.getJurnalType().contains(GefuTransactionType.Credit.name())) {
                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Credit);
            } else {
                initialType = "D ";

                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Debit);
            }


            glCreditDetail.setTotalAmount(amount);
            glCreditDetail.setInputerId(gefuHistory.getInputerId());
            glCreditDetail.setInputDate(new java.util.Date());
            glCreditDetail.setReference(initialType + glCredit.getJurnalSequence() + billing.getBillingNumber() + " " + billing.getCustomerCode());
            glDebit.setGl(true);
            billingGefuDetailRepository.save(glCreditDetail);

        }

    }

    @Override
    public void gefuRetailGeneratorDirect(BillingGefuProcessHistory gefuHistory) {
        BillingRetail billing =
                billingRetailRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuHistoryRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL Nasabah
        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(billingCustomer.getDebitTransfer());
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(billingCustomer.isGl());
        billingGefuDetailRepository.save(glDebit);

        BillingGlCredit glCredit =
                billingGlCreditRepository.findByGlBillingTemplate(gefuHistory.getTemplate());

        // GL HAK Operasional Credit
        BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
        glCreditDetail
                .setGefuProcessHistory(gefuHistory);
        glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
        glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
        glCreditDetail.setCostCenter("9207");
        glCreditDetail.setFileName(gefuHistory
                .getFileName());
        glCreditDetail
                .setGefuTransactionType(GefuTransactionType.Credit);
        glCreditDetail.setTotalAmount(settleAmount);
        glCreditDetail.setInputerId(gefuHistory.getInputerId());
        glCreditDetail.setInputDate(new java.util.Date());
        glCreditDetail.setReference("C " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(true);
        billingGefuDetailRepository.save(glCreditDetail);
    }


    @Override
    public void gefuRetailGeneratorCASA(BillingGefuProcessHistory gefuHistory) {

        BillingRetail billing =
                billingRetailRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuHistoryRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL / Account Nasabah
        String costCenter = billingCustomer.getDebitTransfer() != null ?
                billingCustomer.getDebitTransfer() : "9207";

        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(costCenter);
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D 0" + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(billingCustomer.isGl());
        billingGefuDetailRepository.save(glDebit);

        // GL Dana Custodian Credit

        List<BillingGlCredit> glCreditList =
                billingGlCreditRepository.findAllByGlBillingTemplate(gefuHistory.getTemplate());

        for (BillingGlCredit glCredit : glCreditList) {

            double amount = 0;
            if (glCredit.getGlCreditName().trim().contains("GL Dana Custodian")) {
                amount = billing.getTotalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Biaya Penyimpanan")) {
                amount = billing.getSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Biaya Penyelesaian Transaksi + Biaya Pihak ketiga")) {
                amount = billing.getTransactionSettlementAmountDue().doubleValue()
                        + billing.getThirdPartyAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("VAT")) {
                amount = billing.getVatAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Transaction Handling + Transaction Handling Internal")) {
                amount = billing.getTransactionHandlingAmountDue().doubleValue() +
                        billing.getTransactionHandlingInternalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Safekeeping Fee")) {
                amount = billing.getSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Biaya Transfer")) {
                amount = billing.getTransferAmountDue().doubleValue();
            }


            BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
            glCreditDetail
                    .setGefuProcessHistory(gefuHistory);
            glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
            glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
            glCreditDetail.setCostCenter("9207");
            glCreditDetail.setFileName(gefuHistory
                    .getFileName());

            String initialType = "C ";
            if (glCredit.getJurnalType().contains(GefuTransactionType.Credit.name())) {
                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Credit);
            } else {
                initialType = "D ";

                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Debit);
            }


            glCreditDetail.setTotalAmount(amount);
            glCreditDetail.setInputerId(gefuHistory.getInputerId());
            glCreditDetail.setInputDate(new java.util.Date());
            glCreditDetail.setReference(initialType + glCredit.getJurnalSequence() + billing.getBillingNumber() + " " + billing.getCustomerCode());
            glDebit.setGl(true);
            billingGefuDetailRepository.save(glCreditDetail);

        }

    }

    @Override
    public void gefuFundGeneratorCASA(BillingGefuProcessHistory gefuHistory) {

        BillingFund billing =
                billingFundRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuHistoryRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);


        // GL / Account Nasabah
        String costCenter = billingCustomer.getDebitTransfer() != null ?
                billingCustomer.getDebitTransfer() : "9207";

        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(costCenter);
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D 0" + billing.getBillingNumber() + " " + billing.getCustomerCode());
        glDebit.setGl(billingCustomer.isGl());
        billingGefuDetailRepository.save(glDebit);

        // GL Dana Custodian Credit

        List<BillingGlCredit> glCreditList =
                billingGlCreditRepository.findAllByGlBillingTemplate(gefuHistory.getTemplate());

        for (BillingGlCredit glCredit : glCreditList) {

            double amount = 0;
            if (glCredit.getGlCreditName().trim().contains("GL Dana Custodian")) {
                amount = billing.getTotalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Accrual Biaya Kustodian")) {
                amount = billing.getAccrualCustodialFee().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("VAT")) {
                amount = billing.getVatAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().contains("Biaya S4+Biaya KSEI")) {
                amount = billing.getBis4TransactionAmountDue().doubleValue() +
                        billing.getKseiTransactionAmountDue().doubleValue();
            }

            BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
            glCreditDetail
                    .setGefuProcessHistory(gefuHistory);
            glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
            glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
            glCreditDetail.setCostCenter("9207");
            glCreditDetail.setFileName(gefuHistory
                    .getFileName());

            String initialType = "C ";
            if (glCredit.getJurnalType().contains(GefuTransactionType.Credit.name())) {
                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Credit);
            } else {
                initialType = "D ";

                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Debit);
            }


            glCreditDetail.setTotalAmount(amount);
            glCreditDetail.setInputerId(gefuHistory.getInputerId());
            glCreditDetail.setInputDate(new java.util.Date());
            glCreditDetail.setReference(initialType + glCredit.getJurnalSequence() + billing.getBillingNumber() + " " + billing.getCustomerCode());
            glCreditDetail.setGl(true);
            billingGefuDetailRepository.save(glCreditDetail);
        }

    }

    @Override
    public List<BillingGefuProcessHistory> gefuHistoryList(String category, String month, int year, String customerCode) {


        List<BillingGefuProcessHistory> histories = null;
        String billingPeriode = month + " " + year;

        System.out.println(category);
        System.out.println(billingPeriode);
        if (!customerCode.isEmpty() && customerCode != null) {
            histories = billingGefuHistoryRepository.findAllByCategoryAndBillingPeriodeAndCustomerCode(category, month + "" + year, customerCode);
        } else {
            histories = billingGefuHistoryRepository.findAllByCategoryAndBillingPeriode(category, billingPeriode);
        }

        return histories;
    }

    @Override
    public List<BillingGefuProcessDetail> gefuDetailList(long historyId) {

        List<BillingGefuProcessDetail> detail =
                billingGefuDetailRepository.findAllByGefuProcessHistory(historyId);

        return detail;
    }

}
