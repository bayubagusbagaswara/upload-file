package com.services.billingservice.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.BillingTemplateDTO;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.exception.InvalidInputException;
import com.services.billingservice.mapper.CustomerMapper;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.repository.BillingCustomerRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.EnumValidator;
import com.services.billingservice.utils.JsonUtil;
import com.services.billingservice.utils.NumericValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingCustomerServiceImpl implements BillingCustomerService {

    private static final String ID_NOT_FOUND = "Billing Customer not found with id: ";
    private static final String UNKNOWN = "unknown";

    private final BillingCustomerRepository customerRepository;
    private final BillingMIService investmentManagementService;
    private final BillingDataChangeService dataChangeService;
    private final BillingSellingAgentDataService sellingAgentService;
    private final BillingTemplateService billingTemplateService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final CustomerMapper customerMapper;
    private final NumericValidator numericValidator;

    @Override
    public boolean isCodeAlreadyExists(String code, String subCode) {
        return customerRepository.existsCustomerByCustomerCodeAndSubCode(code, subCode);
    }

    @Override
    public List<CustomerDTO> getAll() {
        List<BillingCustomer> all = customerRepository.findAll();
        return customerMapper.mapToDTOList(all);
    }

    @Override
    public CustomerDTO getByCode(String customerCode) {
        BillingCustomer billingCustomer = customerRepository.findByCode(customerCode)
                .orElseThrow(() -> new DataNotFoundException("Billing Customer not found with code: " + customerCode));
        return customerMapper.mapToDto(billingCustomer);
    }

    @Override
    public List<BillingCustomer> getAllByBillingCategoryAndBillingType(String billingCategory, String billingType) {
        log.info("Get customers by billing category: {}, and billing type: {}", billingCategory, billingCategory);
        return customerRepository.findAllByBillingCategoryAndBillingType(billingCategory, billingType);
    }

    @Override
    public String deleteAll() {
        customerRepository.deleteAll();
        return "Successfully delete all billing customer;";
    }

    @Override
    public CustomerResponse createSingleData(CreateCustomerRequest createRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data billing customer with request: {}", createRequest);
        CustomerDTO customerDTO = customerMapper.mapFromCreateRequestToDto(createRequest);
        dataChangeDTO.setInputerId(createRequest.getInputerId());
        return processCustomerCreationAndInsertToDataChange(customerDTO, dataChangeDTO);
    }

    @Override
    public CustomerResponse createMultipleData(CreateCustomerListRequest createListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create billing customer multiple data with request: {}", createListRequest);
        dataChangeDTO.setInputerId(createListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (CreateCustomerDataListRequest createCustomerDataListRequest : createListRequest.getCustomerDataListRequests()) {
            CustomerDTO customerDTO = customerMapper.mapFromDataListToDTO(createCustomerDataListRequest);
            CustomerResponse response = processCustomerCreationAndInsertToDataChange(customerDTO, dataChangeDTO);
            totalDataSuccess += response.getTotalDataSuccess();
            totalDataFailed += response.getTotalDataFailed();
            errorMessageDTOList.addAll(response.getErrorMessageDTOList());
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private CustomerResponse processCustomerCreationAndInsertToDataChange(CustomerDTO customerDTO, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        try {
            List<String> validationErrors = new ArrayList<>();

            // validation column dto
            Errors errors = validateCustomerUsingValidator(customerDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            // validation customer code and sub code already exists
            validationCustomerCodeAlreadyExists(customerDTO.getCustomerCode(), customerDTO.getSubCode(), validationErrors);

            // validation selling agent
            if (!StringUtils.isEmpty(customerDTO.getSellingAgent())) {
                validationSellingAgentCodeAlreadyExists(customerDTO.getSellingAgent(), validationErrors);
            }

            // validasi nilai GL
            if (!isValidIsGLValue(customerDTO.getGl())) {
                throw new InvalidInputException("Invalid value for isGL. Value must be 'TRUE' or 'FALSE'");
            }
            // validation GL
            validateGLForCostCenterDebit(Boolean.valueOf(customerDTO.getGl()), customerDTO.getDebitTransfer(), validationErrors);

            // validation enum Billing Category
            validateEnumBillingCategory(customerDTO.getBillingCategory(), validationErrors);

            // validation enum Billing Type
            validateEnumBillingType(customerDTO.getBillingType(), validationErrors);

            // validation enum Currency
            validateEnumCurrency(customerDTO.getCurrency(), validationErrors);

            // validation Billing Template
            validationBillingTemplate(customerDTO.getBillingCategory(), customerDTO.getBillingType(), customerDTO.getCurrency(), customerDTO.getSubCode(), customerDTO.getBillingTemplate(), validationErrors);

            // validation mi code
            InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customerDTO.getMiCode());
            customerDTO.setMiCode(investmentManagementDTO.getCode());
            customerDTO.setMiName(investmentManagementDTO.getName());

            if (validationErrors.isEmpty()) {
//                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
//                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                // dataChangeDTO sudah di set inputerId dan inputerIPAddress
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));

                dataChangeService.createChangeActionADD(dataChangeDTO, BillingCustomer.class);
                totalDataSuccess++;
            } else {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            }
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse createSingleApprove(CustomerApproveRequest createCustomerApproveRequest) {
        log.info("Approve multiple for create billing customer with request: {}", createCustomerApproveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        validateDataChangeId(createCustomerApproveRequest.getDataChangeId());
        try {
            Long dataChangeId = Long.valueOf(createCustomerApproveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            CustomerDTO customerDTO = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), CustomerDTO.class);

            // validation customer code and sub code
            validationCustomerCodeAlreadyExists(customerDTO.getCustomerCode(), customerDTO.getSubCode(), validationErrors);

            // validation selling agent
            if (!StringUtils.isEmpty(customerDTO.getSellingAgent())) {
                validationSellingAgentCodeAlreadyExists(customerDTO.getSellingAgent(), validationErrors);
            }

            // validation GL
            validateGLForCostCenterDebit(Boolean.valueOf(customerDTO.getGl()), customerDTO.getDebitTransfer(), validationErrors);

            // kalau mau bisa tambahkan juga validasi disini
            // validation Billing Template
            // Category: FUND to CORE

            validationBillingTemplate(customerDTO.getBillingCategory(), customerDTO.getBillingType(), customerDTO.getCurrency(), customerDTO.getSubCode(), customerDTO.getBillingTemplate(), validationErrors);

            // validation mi code
            InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customerDTO.getMiCode());
            customerDTO.setMiCode(investmentManagementDTO.getCode());
            customerDTO.setMiName(investmentManagementDTO.getName());

            // set data change
            dataChangeDTO.setApproverId(createCustomerApproveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(createCustomerApproveRequest.getApproverIPAddress());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingCustomer customer = customerMapper.createEntity(customerDTO, dataChangeDTO);
                customerRepository.save(customer);

                dataChangeDTO.setDescription("Successfully approve data change and save data billing customer");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customer)));
                dataChangeDTO.setEntityId(customer.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(null, e, errorMessageDTOList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public CustomerResponse updateSingleData(UpdateCustomerRequest request, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update billing customer by id with request: {}", request);
        dataChangeDTO.setInputerId(request.getInputId());
        dataChangeDTO.setInputerIPAddress(request.getInputIPAddress());
        CustomerDTO customerDTO = customerMapper.mapFromUpdateRequestToDto(request);
        // kalau update satuan, kita mappping dari dto ke entity, lalu validasi nilainya
        return processUpdateForCustomerListAndInsertToDataChange(Collections.singletonList(customerDTO), dataChangeDTO);
    }

    @Override
    public CustomerResponse updateMultipleData(UpdateCustomerListRequest updateCreateCustomerListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple billing customer with request: {}", updateCreateCustomerListRequest);
        dataChangeDTO.setInputerId(updateCreateCustomerListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateCreateCustomerListRequest.getInputerIPAddress());

        List<CustomerDTO> customerDTOList = new ArrayList<>();
        for (UpdateCustomerDataListRequest customerDataListRequest : updateCreateCustomerListRequest.getCustomerDataListRequests()) {
            customerDTOList.add(customerMapper.mapFromCreateRequestToDto(customerDataListRequest));
        }

        // kalau update list, kita cek satu per satu dulu request dari depan apakah null atau tidak
        return processUpdateForCustomerListAndInsertToDataChange(customerDTOList, dataChangeDTO);
    }

    private CustomerResponse processUpdateForCustomerListAndInsertToDataChange(List<CustomerDTO> customerDTOList, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (CustomerDTO customerDTO : customerDTOList) {
            try {
                List<String> validationErrors = new ArrayList<>();

                BillingCustomer originalCustomer = customerRepository.findByCustomerCodeAndOptionalSubCode(customerDTO.getCustomerCode(), customerDTO.getSubCode())
                        .orElseThrow(() -> new DataNotFoundException("Customer not found with customer code: " + customerDTO.getCustomerCode() + ", and sub code: " + customerDTO.getSubCode()));

                if (customerDTO.getGl() != null && !customerDTO.getGl().isEmpty()) {
                    if (!isValidIsGLValue(customerDTO.getGl())) {
                        throw new InvalidInputException("Invalid value for isGL. Value must be 'TRUE' or 'FALSE'");
                    }
                    validateGLForCostCenterDebit(Boolean.valueOf(customerDTO.getGl()), customerDTO.getDebitTransfer(), validationErrors);
                }

                if (customerDTO.getDebitTransfer() != null && !customerDTO.getDebitTransfer().isEmpty()) {
                    validateGLForCostCenterDebit(originalCustomer.isGl(), customerDTO.getDebitTransfer(), validationErrors);
                }

                if (customerDTO.getMiCode() != null && !customerDTO.getMiCode().isEmpty()) {
                    // validation mi code
                    InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customerDTO.getMiCode());
                    log.info("Investment Management for update customer: {}", investmentManagementDTO.getCode());
                    customerDTO.setMiCode(investmentManagementDTO.getCode());
                    customerDTO.setMiName(investmentManagementDTO.getName());
                }

                if (!StringUtils.isEmpty(customerDTO.getSellingAgent())) {
                    validationSellingAgentCodeAlreadyExists(customerDTO.getSellingAgent(), validationErrors);
                }

                if (customerDTO.getBillingCategory() != null && !customerDTO.getBillingCategory().isEmpty()) {
                    validateEnumBillingCategory(customerDTO.getBillingCategory(), validationErrors);
                }

                if (customerDTO.getBillingType() != null && !customerDTO.getBillingType().isEmpty()) {
                    validateEnumBillingType(customerDTO.getBillingType(), validationErrors);
                }

                if (customerDTO.getCurrency() != null && !customerDTO.getCurrency().isEmpty()) {
                    validateEnumCurrency(customerDTO.getCurrency(), validationErrors);
                }

                // Set billingCategory, billingType, currency, billingSubCode ket customer dto
                if (customerDTO.getBillingCategory() == null || customerDTO.getBillingCategory().isEmpty()) {
                    customerDTO.setBillingCategory(originalCustomer.getBillingCategory());
                }

                if (customerDTO.getBillingType() == null || customerDTO.getBillingType().isEmpty()) {
                    customerDTO.setBillingType(originalCustomer.getBillingType());
                }

                if (customerDTO.getCurrency() == null || customerDTO.getCurrency().isEmpty()) {
                    customerDTO.setCurrency(originalCustomer.getCurrency());
                }

                if (customerDTO.getSubCode() == null || customerDTO.getSubCode().isEmpty()) {
                    customerDTO.setSubCode(originalCustomer.getSubCode());
                }

                if (customerDTO.getBillingTemplate() == null || customerDTO.getBillingTemplate().isEmpty()) {
                    customerDTO.setBillingTemplate(originalCustomer.getBillingTemplate());
                }

                // Jika billing template mau diupdate harus di validation dulu
                if (customerDTO.getBillingTemplate() != null && !customerDTO.getBillingTemplate().isEmpty()) {
                    validationBillingTemplate(customerDTO.getBillingCategory(),
                            customerDTO.getBillingType(), customerDTO.getCurrency(), customerDTO.getSubCode(),
                            customerDTO.getBillingTemplate(), validationErrors);
                }

                if (customerDTO.getAccount() != null && !customerDTO.getAccount().isEmpty()) {
                    validationAccount(customerDTO.getAccount(), validationErrors);
                }

                if (customerDTO.getDebitTransfer() != null && !customerDTO.getDebitTransfer().isEmpty()) {
                    validationDebitTransfer(customerDTO.getDebitTransfer(), validationErrors);
                }

                if (customerDTO.getCostCenter() != null && !customerDTO.getCostCenter().isEmpty()) {
                    validationCostCenter(customerDTO.getCostCenter(), validationErrors);
                }

                if (customerDTO.getGlAccountHasil() != null && !customerDTO.getGlAccountHasil().isEmpty()) {
                    validationGLAccountHasil(customerDTO.getGlAccountHasil(), validationErrors);
                }

                // update nilai customer safekeeping fee
                if (customerDTO.getCustomerSafekeepingFee() != null && !customerDTO.getCustomerSafekeepingFee().isEmpty()) {
                    validationCustomerSafekeepingFee(customerDTO.getCustomerSafekeepingFee(), validationErrors);
                }

                if (customerDTO.getCustomerMinimumFee() != null && !customerDTO.getCustomerMinimumFee().isEmpty()) {
                    validationCustomerMinimumFee(customerDTO.getCustomerMinimumFee(), validationErrors);
                }

                if (customerDTO.getCustomerTransactionHandling() != null && !customerDTO.getCustomerTransactionHandling().isEmpty()) {
                    validationTransactionHandling(customerDTO.getCustomerTransactionHandling(), validationErrors);
                }

                if (customerDTO.getKseiSafeCode() != null && !customerDTO.getKseiSafeCode().isEmpty()) {
                    validationKSEISafeCode(customerDTO.getKseiSafeCode(), validationErrors);
                }

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(customerDTO.getCustomerCode(), validationErrors);
                    errorMessageList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    updateCustomerAndDataChange(originalCustomer, customerDTO, dataChangeDTO);
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(customerDTO, e, errorMessageList);
                totalDataFailed++;
            }
        }

        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private void validationAccount(String account, List<String> validationErrors) {
        if (!numericValidator.isValidNumeric(account)) {
            validationErrors.add("Account must contain only numeric digit");
        }
    }

    private void validationDebitTransfer(String debitTransfer, List<String> validationErrors) {
        if (!numericValidator.isValidNumeric(debitTransfer)) {
            validationErrors.add("Cost Center Debit must contain only numeric digit");
        }
    }

    private void validationCostCenter(String costCenter, List<String> validationErrors) {
        if (!numericValidator.isValidNumeric(costCenter)) {
            validationErrors.add("Cost Center must contain only numeric digit");
        }
    }

    private void validationGLAccountHasil(String glAccountHasil, List<String> validationErrors) {
        if (!numericValidator.isValidNumeric(glAccountHasil)) {
            validationErrors.add("GL Account Hasil must contain only numeric digit");
        }
    }

    private void validationCustomerSafekeepingFee(String safekeepingFee, List<String> validationErrors) {
        if (!numericValidator.isValidBigDecimal(safekeepingFee)) {
            validationErrors.add("Customer Safekeeping Fee must contain decimal digit");
        }
    }

    private void validationCustomerMinimumFee(String customerMinimumFee, List<String> validationErrors) {
        if (!numericValidator.isValidBigDecimal(customerMinimumFee)) {
            validationErrors.add("Customer Minimum Fee must contain decimal digit");
        }
    }

    private void validationTransactionHandling(String transactionHandling, List<String> validationErrors) {
        if (!numericValidator.isValidBigDecimal(transactionHandling)) {
            validationErrors.add("Customer Transaction Handling must contain decimal digit");
        }
    }

    private void validationKSEISafeCode(String kseiSafeCode, List<String> validationErrors) {
        if (!numericValidator.isValidAlphaNumeric(kseiSafeCode)) {
            validationErrors.add("KSEI Safe Code must contain only alphanumeric characters");
        }
    }

    private void updateCustomerAndDataChange(BillingCustomer customer, CustomerDTO customerDTO, BillingDataChangeDTO dataChangeDTO) throws JsonProcessingException {
        dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
        dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customer)));
        dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));

        dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingCustomer.class);
    }

    @Override
    public CustomerResponse updateSingleApprove(CustomerApproveRequest updateCustomerApproveRequest) {
        log.info("Approve single update billing customer with request: {}", updateCustomerApproveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(updateCustomerApproveRequest.getDataChangeId());
        try {
            List<String> validationErrors = new ArrayList<>();
            Long dataChangeId = Long.valueOf(updateCustomerApproveRequest.getDataChangeId());
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);

            CustomerDTO customerDTO = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), CustomerDTO.class);
            log.info("Result read JSON Data After: {}", customerDTO); // jika customerName adalah string kosong, maka akan masuk update (memperbarui data entity)

            BillingCustomer customer = customerRepository.findByCustomerCodeAndSubCode(customerDTO.getCustomerCode(), customerDTO.getSubCode())
                    .orElseThrow(() -> new DataNotFoundException("Customer not found with customer code: " + customerDTO.getCustomerCode() + ", and sub code: " + customerDTO.getSubCode()));

            customerMapper.mapObjects(customerDTO, customer);
            log.info("Customer after mapper from dto to entity: {}", customer);

            // validation mi
            InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());
            customer.setMiCode(investmentManagementDTO.getCode());
            customer.setMiName(investmentManagementDTO.getCode());

            // set billing data change
            dataChangeDTO.setApproverId(updateCustomerApproveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(updateCustomerApproveRequest.getApproverIPAddress());
            dataChangeDTO.setEntityId(customer.getId().toString());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            } else {
                BillingCustomer customerUpdated = customerMapper.updateEntity(customer, dataChangeDTO);
                BillingCustomer customerSaved = customerRepository.save(customerUpdated);

                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customerSaved)));
                dataChangeDTO.setDescription("Successfully approved and update data entity");
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(null, e, errorMessageList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public CustomerResponse deleteSingleData(DeleteCustomerRequest deleteCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete single data billing customer with request: {}", deleteCustomerRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        CustomerDTO customerDTO = CustomerDTO.builder()
                .id(deleteCustomerRequest.getId())
                .build();
        try {
            BillingCustomer customer = customerRepository.findById(customerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + customerDTO.getId()));

            dataChangeDTO.setInputerId(deleteCustomerRequest.getInputId());
            dataChangeDTO.setInputerIPAddress(deleteCustomerRequest.getInputIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customer)));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(customer.getId().toString());

            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingCustomer.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public CustomerResponse deleteSingleApprove(CustomerApproveRequest deleteCustomerApproveRequest) {
        log.info("Approve delete multiple billing customer with request: {}", deleteCustomerApproveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(deleteCustomerApproveRequest.getDataChangeId());
        CustomerDTO customerDTO = deleteCustomerApproveRequest.getData();
        BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(deleteCustomerApproveRequest.getDataChangeId());

        try {
            BillingCustomer customer = customerRepository.findById(customerDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + customerDTO.getId()));

            dataChangeDTO.setApproverId(deleteCustomerApproveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(deleteCustomerApproveRequest.getApproverIPAddress());
            dataChangeDTO.setApproveDate(new Date());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(customer)));
            dataChangeDTO.setDescription("Successfully approve data change and delete data entity");

            dataChangeService.approvalStatusIsApproved(dataChangeDTO);
            customerRepository.delete(customer);
            totalDataSuccess++;
        } catch (DataNotFoundException e) {
            handleDataNotFoundException(customerDTO, e, errorMessageList);
            sendToApprovalRejected(deleteCustomerApproveRequest, customerDTO, dataChangeDTO);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(customerDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new CustomerResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public CustomerDTO getById(String id) {
        BillingCustomer billingCustomer = customerRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return customerMapper.mapToDto(billingCustomer);
    }

    private void sendToApprovalRejected(CustomerApproveRequest deleteCustomerApproveRequest, CustomerDTO customerDTO, BillingDataChangeDTO dataChangeDTO) {
        dataChangeDTO.setApproverId(deleteCustomerApproveRequest.getApproverId());
        dataChangeDTO.setApproverIPAddress(deleteCustomerApproveRequest.getApproverIPAddress());
        dataChangeDTO.setApproveDate(new Date());
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(ID_NOT_FOUND + customerDTO.getId());

        dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change ids not found");
            throw new DataNotFoundException("Data Change ids not found");
        }
    }

    private Errors validateCustomerUsingValidator(CustomerDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "customerDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validationCustomerCodeAlreadyExists(String customerCode, String subCode, List<String> validationErrors) {
        if (isCodeAlreadyExists(customerCode, subCode)) {
            validationErrors.add("Billing Customer already taken with code: " + customerCode + ", and sub code: " + subCode);
        }
    }

    private void validationBillingTemplate(String category, String type, String currency, String subCode, String templateName, List<String> validationErrors) {
        if (!billingTemplateService.isExistsByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(category, type, currency, subCode, templateName)) {
            validationErrors.add("Billing Template not found with category: " + category + ", type: " + type + ", currency: " + currency + ", sub code: " + subCode + ", and template name: " + templateName);
        }
    }

//    private BillingTemplateDTO getByCategoryAndTypeAndCurrencyAndSubCode(String category, String type, String currency, String subCode) {
//        return billingTemplateService.getByCategoryAndTypeAndCurrencyAndSubCode(
//                category, type, currency, subCode
//        );
//    }

    private void validationSellingAgentCodeAlreadyExists(String sellingAgentCode, List<String> validationErrors) {
        if (!sellingAgentService.isCodeAlreadyExists(sellingAgentCode)) {
            validationErrors.add("Selling Agent not found with code: " + sellingAgentCode);
        }
    }

    private void handleGeneralError(CustomerDTO customerDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(customerDTO != null ? customerDTO.getCustomerCode() : UNKNOWN, validationErrors));
    }

    private void handleDataNotFoundException(CustomerDTO customerDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageList) {
        log.error("Billing Customer not found with id: {}", customerDTO != null ? customerDTO.getCustomerCode(): UNKNOWN, e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(customerDTO != null ? customerDTO.getCustomerCode() : UNKNOWN, validationErrors));
    }

//    private void validateBillingEnums(String billingCategory, String billingType, String billingTemplate, String currency, List<String> validationErrors) {
//        if (EnumValidator.validateEnumBillingCategory(billingCategory)) {
//            validationErrors.add("Billing Category enum not found with value: " + billingCategory);
//        }
//        if (EnumValidator.validateEnumBillingType(billingType)) {
//            validationErrors.add("Billing Type enum not found with value: " + billingType);
//        }
//        if (EnumValidator.validateEnumBillingTemplate(billingTemplate)) {
//            validationErrors.add("Billing Template enum not found with value: " + billingTemplate);
//        }
//        if (EnumValidator.validateEnumCurrency(currency)) {
//            validationErrors.add("Currency enum not found with value: " + currency);
//        }
//    }

    private void validateEnumBillingCategory(String billingCategory, List<String> validationErrors) {
        if (EnumValidator.validateEnumBillingCategory(billingCategory)) {
            validationErrors.add("Billing Category enum not found with value: " + billingCategory);
        }
    }

    private void validateEnumBillingType(String billingType, List<String> validationErrors) {
        if (EnumValidator.validateEnumBillingType(billingType)) {
            validationErrors.add("Billing Type enum not found with value: " + billingType);
        }
    }

    private void validateEnumBillingTemplate(String billingTemplate, List<String> validationErrors) {
        if (EnumValidator.validateEnumBillingTemplate(billingTemplate)) {
            validationErrors.add("Billing Template enum not found with value: " + billingTemplate);
        }
    }

    private void validateEnumCurrency(String currency, List<String> validationErrors) {
        if (EnumValidator.validateEnumCurrency(currency)) {
            validationErrors.add("Currency enum not found with value: " + currency);
        }
    }

    private void validateGLForCostCenterDebit(boolean isGl, String debitTransfer, List<String> validationErrors) {
        // Improved readability with comments
        if (isGl) {
            // Check if costCenterDebit is null or blank (empty string)
            if (debitTransfer == null || debitTransfer.isEmpty()) {
                validationErrors.add("Cost Center Debit is required when GL is true");
            }
        } else {
            // Check if costCenterDebit is not null or blank (for readability)
            if (!StringUtils.isEmpty(debitTransfer)) {
                validationErrors.add("Cost Center Debit must be blank when GL is false");
            }
        }
    }

    private boolean isValidIsGLValue(String isGL) {
        return "TRUE".equalsIgnoreCase(isGL) || "FALSE".equalsIgnoreCase(isGL);
    }

}
