package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.*;

import java.util.List;

public interface BillingSellingAgentDataService {

    boolean isCodeAlreadyExists(String sellingAgentCode);

    SellingAgentResponse createSingleData(CreateSellingAgentRequest createSellingAgentRequest, BillingDataChangeDTO dataChangeDTO);

    // create approve approve
    SellingAgentResponse createSingleApprove(SellingAgentApproveRequest sellingAgentApproveRequest);

    // update single data
    SellingAgentResponse updateSingleData(UpdateSellingAgentRequest updateSellingAgentRequest, BillingDataChangeDTO dataChangeDTO);

    // update multiple data
    SellingAgentResponse updateMultipleData(SellingAgentListRequest listRequest, BillingDataChangeDTO dataChangeDTO);

    // update single approve
    SellingAgentResponse updateSingleApprove(SellingAgentApproveRequest sellingAgentApproveRequest);

    SellingAgentResponse deleteSingleData(DeleteSellingAgentRequest deleteRequest, BillingDataChangeDTO dataChangeDTO);

    SellingAgentResponse deleteSingleApprove(SellingAgentApproveRequest approveRequest);

    SellingAgentDTO getByCode(String code);

    List<SellingAgentDTO> getAll();

    String deleteById(Long id);

    String deleteAll();

}
