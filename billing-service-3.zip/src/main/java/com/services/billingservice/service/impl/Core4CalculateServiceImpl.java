package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_3;
import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_5;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core4CalculateServiceImpl implements Core4CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParameterService;
    private final SkTranService skTransactionService;
    private final SfValRgDailyService sfValRgDailyService;
    private final KseiSafeService kseiSafekeepingFeeService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final CoreGeneralService coreGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            int year = Integer.parseInt(monthMinus1.get("year"));

            Instant dateNow = Instant.now();
            int totalDataSuccess = 0;

            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            // Get data Fee Parameter
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(KSEI.getValue());
            feeParamList.add(VAT.getValue());

            Map<String, BigDecimal> feeParamMap = feeParameterService.getValueByNameList(feeParamList);
            BigDecimal kseiTransactionFee = feeParamMap.get(KSEI.getValue());
            BigDecimal vatFee = feeParamMap.get(VAT.getValue());

            for (BillingCustomer billingCustomer : billingCustomerList) {
                String aid = billingCustomer.getCustomerCode();
                String customerName = billingCustomer.getCustomerName();
                String kseiSafeCode = billingCustomer.getKseiSafeCode();
                BigDecimal customerMinimumFee = billingCustomer.getCustomerMinimumFee();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                BigDecimal transactionHandlingFee = billingCustomer.getCustomerTransactionHandling();
                String billingType = billingCustomer.getBillingType();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingTemplate = billingCustomer.getBillingTemplate();
                String miCode = billingCustomer.getMiCode();

                // check and delete billing data existing
                coreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(aid, monthName, year);

                List<SfValRgDaily> sfValRgDailyList = sfValRgDailyService.getAllByAidAndMonthAndYear(aid, monthName, year);

                BigDecimal kseiSafeFeeAmount = kseiSafekeepingFeeService.calculateAmountFeeByKseiSafeCodeAndMonthAndYear(kseiSafeCode, monthName, year);

                BillingCore billingCore = new BillingCore();

                if (CORE_TEMPLATE_5.getValue().equalsIgnoreCase(billingTemplate)) {
                    billingCore = calculateEB(aid, customerName, billingTemplate, kseiSafeFeeAmount, kseiTransactionFee, skTransactionList);
                } else if(CORE_TEMPLATE_3.getValue().equalsIgnoreCase(billingTemplate)) {
                    billingCore = calculateITAMA(aid, customerName, billingTemplate, customerSafekeepingFee, vatFee, sfValRgDailyList, transactionHandlingFee);
                } else {
                    log.info("AID '{}' and Template '{}' is not valid for Billing Type 4", aid, billingTemplate);
                }

                billingCore.setCreatedAt(dateNow);
                billingCore.setUpdatedAt(dateNow);
                billingCore.setApprovalStatus(ApprovalStatus.Pending);
                billingCore.setBillingStatus(BillingStatus.Generated);
                billingCore.setMonth(monthName);
                billingCore.setYear(year);
                billingCore.setBillingPeriod(monthName + " " + year);
                billingCore.setBillingStatementDate(ConvertDateUtil.convertInstantToString(dateNow));
                billingCore.setBillingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow));
                billingCore.setBillingCategory(billingCustomer.getBillingCategory());
                billingCore.setBillingType(billingCustomer.getBillingType());
                billingCore.setBillingTemplate(billingCustomer.getBillingTemplate());
                billingCore.setInvestmentManagementName(billingMIDTO.getName());
                billingCore.setInvestmentManagementAddress1(billingMIDTO.getAddress1());
                billingCore.setInvestmentManagementAddress2(billingMIDTO.getAddress2());
                billingCore.setInvestmentManagementAddress3(billingMIDTO.getAddress3());
                billingCore.setInvestmentManagementAddress4(billingMIDTO.getAddress4());
                billingCore.setInvestmentManagementEmail(billingMIDTO.getEmail());
                billingCore.setInvestmentManagementUniqueKey(billingMIDTO.getUniqueKey());

                billingCore.setCustomerMinimumFee(customerMinimumFee);

                billingCore.setGefuCreated(false);
                billingCore.setPaid(false);
                billingCore.setAccount(billingCustomer.getAccount());
                billingCore.setAccountName(billingCustomer.getAccountName());
                billingCore.setCurrency(billingCustomer.getCurrency());

                String number = billingNumberService.generateSingleNumber(monthName, year);
                billingCore.setBillingNumber(number);
                billingCoreRepository.save(billingCore);
                billingNumberService.saveSingleNumber(number);
                totalDataSuccess++;
            }

            log.info("Finished calculate Billing Core type 4 with month year: '{}'", request.getMonthYear());
            return "Successfully calculated Billing Core type 4 with a total: " + totalDataSuccess;
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 4: {}", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 4: ", e);
        }
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgDaily> sfValRgDailyList) {
        List<SfValRgDaily> latestEntries = sfValRgDailyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgDailyList.stream()
                        .map(SfValRgDaily::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgDaily latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}'", latestEntry.getDate(), latestEntry.getSecurityName());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgDaily::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 4 ITAMA] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, List<SfValRgDaily> sfValRgDailyList) {
        BigDecimal safekeepingAmountDue = sfValRgDailyList.stream()
                .map(SfValRgDaily::getEstimationSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 4 ITAMA] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateVatAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotalAmountDue.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 4 ITAMA] VAT amount due Aid '{}' is '{}'", aid, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueITAMA(String aid, BigDecimal safekeepingAmountDue, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDueITAMA = safekeepingAmountDue.add(vatAmountDue);
        log.info("[Core Type 4] Total amount due ITAMA Aid '{}' is '{}'", aid, vatAmountDue);
        return totalAmountDueITAMA;
    }

    private static BillingCore calculateITAMA(String aid, String customerName, String billingTemplate, BigDecimal customerSafekeepingFee, BigDecimal vatFee, List<SfValRgDaily> sfValRgDailyList, BigDecimal transactionHandlingFee) {
        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgDailyList);
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(aid, sfValRgDailyList);
        BigDecimal vatAmountDue = calculateVatAmountDue(aid, safekeepingAmountDue, vatFee);
        BigDecimal totalAmountDueITAMA = calculateTotalAmountDueITAMA(aid, safekeepingAmountDue, vatAmountDue);

        Integer transactionHandlingFrequency = 0;
        BigDecimal transactionHandlingAmountDue = BigDecimal.ZERO;
        BigDecimal subTotal = transactionHandlingAmountDue.add(safekeepingAmountDue);

        return BillingCore.builder()
                .customerCode(aid)
                .customerName(customerName)
                .billingTemplate(billingTemplate)
                .transactionHandlingValueFrequency(transactionHandlingFrequency)
                .transactionHandlingFee(transactionHandlingFee)
                .transactionHandlingAmountDue(transactionHandlingAmountDue)
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(customerSafekeepingFee)
                .safekeepingAmountDue(safekeepingAmountDue)
                .subTotal(subTotal)
                .vatFee(vatFee)
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDueITAMA)
                .build();
    }

    private static int calculateTransactionHandlingValueFrequency(String aid, List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 4 EB] Total transaction handling Aid '{}' is '{}'", aid, totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateKSEITransactionAmountDue(String aid, BigDecimal kseiTransactionFee, Integer transactionValueFrequency) {
        BigDecimal kseiTransactionAmountDue = kseiTransactionFee.multiply(new BigDecimal(transactionValueFrequency))
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 4 EB] KSEI transaction amount due Aid '{}' is '{}'", aid, kseiTransactionAmountDue);
        return kseiTransactionAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueEB(String aid, BigDecimal kseiSafekeepingAmountDue, BigDecimal kseiTransactionAmountDue) {
        BigDecimal totalAmountDueEB = kseiSafekeepingAmountDue.add(kseiTransactionAmountDue);
        log.info("[Core Type 4 EB] Total amount due Aid '{}' is '{}'", aid, totalAmountDueEB);
        return totalAmountDueEB;
    }

    private static BillingCore calculateEB(String aid, String customerName, String billingTemplate, BigDecimal kseiSafeFeeAmount, BigDecimal kseiTransactionFee, List<SkTransaction> skTransactionList) {
        int kseiTransactionValueFrequency = calculateTransactionHandlingValueFrequency(aid, skTransactionList);
        BigDecimal kseiTransactionAmountDue = calculateKSEITransactionAmountDue(aid, kseiTransactionFee, kseiTransactionValueFrequency);
        BigDecimal totalAmountDueEB = calculateTotalAmountDueEB(aid, kseiSafeFeeAmount, kseiTransactionAmountDue);

        return BillingCore.builder()
                .customerCode(aid)
                .customerName(customerName)
                .billingTemplate(billingTemplate)
                .kseiSafekeepingAmountDue(kseiSafeFeeAmount)
                .kseiTransactionValueFrequency(kseiTransactionValueFrequency)
                .kseiTransactionFee(kseiTransactionFee)
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .totalAmountDue(totalAmountDueEB)
                .build();
    }

}
