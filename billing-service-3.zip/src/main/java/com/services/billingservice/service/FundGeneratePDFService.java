package com.services.billingservice.service;

public interface FundGeneratePDFService {

    String generatePDF(String category, String monthYear);

}
