package com.services.billingservice.repository;

import com.services.billingservice.model.BillingTemplate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingTemplateRepository extends JpaRepository<BillingTemplate, Long> {

    @Query(value = "SELECT * FROM bill_template WHERE id = :id", nativeQuery = true)
    Optional<BillingTemplate> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM bill_template", nativeQuery = true)
    List<BillingTemplate> findAll();

    @Query(value = "SELECT DISTINCT sub_code FROM bill_template where sub_code IS NOT NULL", nativeQuery = true)
    List<String> findAllSubCode();

    @Query(value = "SELECT * FROM bill_template where bill_template_type = :type", nativeQuery = true)
    List<BillingTemplate> findAllByType(@Param("type") String type);

    @Query(value = "SELECT * FROM bill_template where bill_template_category = :category " +
            "and bill_template_type = :type " +
            "and ISNULL(sub_code, '') = ISNULL(:subCode, '') " +
            "and currency = :currency", nativeQuery = true)
    List<BillingTemplate> findAllByCategoryAndTypeAndSubCode(@Param("category") String category, @Param("type") String type, @Param("subCode") String subCode, @Param("currency") String currency);

    @Query(value = "SELECT * FROM bill_template " +
            "where bill_template_category = :category " +
            "and bill_template_type = :type " +
            "and currency = :currency " +
            "and bill_template_name = :templateName " +
            "and ISNULL(sub_code, '') = ISNULL(:subCode, '')", nativeQuery = true)
    Optional<BillingTemplate> findByCategoryAndTypAndCurrencyAndSubCodeAndTemplateName(@Param("category") String category,
                                                                                       @Param("type") String type,
                                                                                       @Param("currency") String currency,
                                                                                       @Param("templateName") String templateName,
                                                                                       @Param("subCode") String subCode);
//    @Query(value = "select case when count(*)> 0 then true else false end FROM BillingTemplate " +
//            "WHERE category = :billingCategory " +
//            "AND type = :billingType " +
//            "AND lower(COALESCE(subCode,'')) = lower(COALESCE(:subCode, ''))")
//    boolean existsByCategoryAndTypeAndSubCode(
//            @Param("billingCategory") String category,
//            @Param("billingType") String type,
//            @Param("subCode") String subCode
//    );

    @Query(value = "select case when count(c) > 0 then true else false end from BillingTemplate c " +
            "WHERE lower(c.category) = lower(:category) " +
            "AND lower(c.type) = lower(:type) " +
            "AND lower(c.currency) = lower(:currency) " +
            "AND lower(c.templateName) = lower(:templateName) " +
            "AND lower(COALESCE(c.subCode,'')) = lower(COALESCE(:subCode, ''))")
    boolean existsByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(
            @Param("category") String category,
            @Param("type") String type,
            @Param("currency") String currency,
            @Param("subCode") String subCode,
            @Param("templateName") String templateName
    );

}
