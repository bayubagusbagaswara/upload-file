package com.services.billingservice.repository;

import com.services.billingservice.model.BillingCustomer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingCustomerRepository extends JpaRepository<BillingCustomer, Long> {

    @Query(value = "SELECT * FROM billing_customer where customer_code = :code", nativeQuery = true)
    Optional<BillingCustomer> findByCode(@Param("code")String code);

    @Query(value = "SELECT * FROM billing_customer", nativeQuery = true)
    List<BillingCustomer> findAll();

    @Query(value = "SELECT * FROM billing_customer " +
            "WHERE billing_category = :billingCategory " +
            "AND billing_type = :billingType", nativeQuery = true)
    List<BillingCustomer> findAllByBillingCategoryAndBillingType(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType
    );

    @Query(value = "SELECT * FROM billing_customer " +
            "WHERE ksei_safe_code = :kseiSafeCode", nativeQuery = true)
    Optional<BillingCustomer> findByKseiSafeCode(
            @Param("kseiSafeCode") String kseiSafeCode
    );

    @Query(value = "SELECT * FROM billing_customer " +
            "WHERE billing_category = :billingCategory " +
            "AND billing_type = :billingType " +
            "AND currency = :currency", nativeQuery = true)
    List<BillingCustomer> findAllByBillingCategoryAndBillingTypeAndCurrency(
            @Param("billingCategory") String billingCategory,
            @Param("billingType") String billingType,
            @Param("currency") String currency
    );

    @Query(value = "SELECT CASE WHEN EXISTS (" +
            "SELECT 1 FROM billing_customer WHERE customer_code = :customerCode " +
            "and ISNULL(sub_code, '') = ISNULL(:subCode, '')) THEN 1 ELSE 0 END", nativeQuery = true)
    Boolean existsByCustomerCodeAndSubCode(@Param("customerCode") String customerCode,
                                           @Param("subCode") String subCode);

    @Query(value = "select case when count(c)> 0 then true else false end from BillingCustomer c where lower(c.customerCode) = lower(:customerCode) AND lower(COALESCE(c.subCode,'')) = lower(COALESCE(:subCode, ''))")
    boolean existsCustomerByCustomerCodeAndSubCode(@Param("customerCode") String customerCode, @Param("subCode") String subCode);

    @Query(value = "SELECT * FROM billing_customer WHERE customer_code = :customerCode AND ISNULL(sub_code, '') = ISNULL(:subCode, '')", nativeQuery = true)
    Optional<BillingCustomer> findByCustomerCodeAndSubCode(@Param("customerCode") String customerCode, @Param("subCode") String subCode);

    @Query(value = "SELECT * FROM billing_customer WHERE customer_code = :customerCode AND ISNULL(sub_code, '') = ISNULL(:subCode, '')", nativeQuery = true)
    Optional<BillingCustomer> findByCustomerCodeAndOptionalSubCode(@Param("customerCode") String customerCode, @Param("subCode") String subCode);

}
