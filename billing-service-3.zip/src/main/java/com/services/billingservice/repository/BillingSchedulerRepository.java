package com.services.billingservice.repository;

import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingScheduler;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillingSchedulerRepository extends JpaRepository<BillingScheduler, Long> {

    @Query(value = "SELECT * FROM billing_scheduler " +
            "WHERE enable = :enable", nativeQuery = true)
    List<BillingScheduler> findAllByEnable(
            @Param("enable") boolean enable
    );

}
