package com.services.billingservice.enums;

public enum Currency {

    IDR("IDR"),
    USD("USD");

    private final String value;

    Currency(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
