package com.services.billingservice.dto.feeparameter;

import com.services.billingservice.dto.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeParameterDTO extends ApprovalDTO {

    private Long id;

    @NotBlank(message = "Code cannot be empty")
    private String feeCode;

    @NotBlank(message = "Name cannot be empty")
    private String feeName;

    private String feeDescription;

    @NotBlank(message = "Value cannot be empty")
    private String feeValue;
}
