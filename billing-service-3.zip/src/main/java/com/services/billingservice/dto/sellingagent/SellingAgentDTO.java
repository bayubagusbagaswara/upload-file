package com.services.billingservice.dto.sellingagent;

import com.services.billingservice.dto.approval.ApprovalDTO;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SellingAgentDTO extends ApprovalDTO {

    private Long id;

    private String code;

    private String name;

}
