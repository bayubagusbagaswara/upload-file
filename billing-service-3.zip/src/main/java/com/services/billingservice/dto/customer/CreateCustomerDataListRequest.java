package com.services.billingservice.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CreateCustomerDataListRequest {

    @JsonProperty(value = "Customer Code")
    @Pattern(regexp = "^[a-zA-Z0-9]{6}$", message = "Code must contain exactly 6 alphanumeric characters")
    @NotBlank(message = "Customer Code cannot be empty")
    private String customerCode;

    @JsonProperty(value = "Sub Code")
    private String subCode;

    @JsonProperty(value = "Customer Name")
    private String customerName;

    @JsonProperty(value = "Billing Category")
    private String billingCategory;

    @JsonProperty(value = "Billing Type")
    private String billingType;

    @JsonProperty(value = "Billing Template")
    private String billingTemplate;

    @JsonProperty(value = "Currency")
    private String currency;

    @JsonProperty(value = "Code MI")
    private String miCode;

    private String miName;

    @JsonProperty(value = "Account")
    @Pattern(regexp = "^\\d*$", message = "Account must contain only numeric digits")
    private String account;

    @JsonProperty(value = "Account Name")
    private String accountName;

    @JsonProperty(value = "Cost Center Debit")
    @Pattern(regexp = "^\\d*$", message = "Cost Center Debit must contain only numeric digits")
    private String debitTransfer;

    @JsonProperty(value = "Cost Center")
    @Pattern(regexp = "^\\d*$", message = "Cost Center must contain only numeric digits")
    private String costCenter;

    @JsonProperty(value = "GL Account Hasil")
    @Pattern(regexp = "^\\d*$", message = "GL Account Hasil must contain only numeric digits")
    private String glAccountHasil;

    @JsonProperty(value = "Minimum Fee")
    @Pattern(regexp = "^\\d+(?:\\.\\d+)?$", message = "Customer Minimum Fee must be in decimal format")
    private String customerMinimumFee;

    @Pattern(regexp = "^\\d+(?:\\.\\d+)?$", message = "Customer Safekeeping Fee must be in decimal format")
    @JsonProperty(value = "Customer Safekeeping Fee")
    private String customerSafekeepingFee;

    @JsonProperty(value = "Transaction Handling")
    @Pattern(regexp = "^\\d+(?:\\.\\d+)?$", message = "Transaction Handling must be in decimal format")
    private String customerTransactionHandling;

    @JsonProperty(value = "NPWP")
    private String npwpNumber;

    @JsonProperty(value = "Nama NPWP")
    private String npwpName;

    @JsonProperty(value = "Alamat NPWP")
    private String npwpAddress;

    @JsonProperty(value = "KSEI Safe Code")
    @Pattern(regexp = "^[a-zA-Z0-9]*$", message = "KSEI Safe Code must contain only alphanumeric characters")
    private String kseiSafeCode;

    @JsonProperty(value = "Selling Agent")
    private String sellingAgent;

    @JsonProperty(value = "Is GL")
    @NotBlank(message = "Is GL cannot be empty")
    private String gl;

}
