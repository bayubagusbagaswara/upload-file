package com.services.billingservice.dto.feeschedule;

import com.services.billingservice.dto.approval.ApprovalDTO;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeScheduleDTO extends ApprovalDTO {

    private Long id;

    private String feeMinimum;

    private String feeMaximum;

    private String feeAmount;
}
