package com.services.billingservice.dto.feeparameter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateFeeParameterRequest {

    private String inputId;
    private String inputIPAddress;

    private Long id;

    private String feeCode;

    private String feeName;

    private String feeDescription;

    private String feeValue;

}
