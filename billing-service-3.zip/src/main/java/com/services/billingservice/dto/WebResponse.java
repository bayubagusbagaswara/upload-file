package com.services.billingservice.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

@Data
@Builder
//@JsonPropertyOrder({
//        "success",
//        "message",
//        "data"
//})
@AllArgsConstructor
@NoArgsConstructor
public class WebResponse<T> {

    private HttpStatus status;

    @JsonProperty("error_code")
    private Integer errorCode;

    @JsonProperty("message")
    private String message;

    @JsonProperty("timestamp")
    private LocalDateTime timeStamp;

    @JsonProperty("data")
    private T data;

}
