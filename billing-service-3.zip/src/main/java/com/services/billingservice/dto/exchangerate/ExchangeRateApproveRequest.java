package com.services.billingservice.dto.exchangerate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExchangeRateApproveRequest {

    private String approverId;
    private String approverIPAddress;

    private String dataChangeId;

    private ExchangeRateDTO data;
}
