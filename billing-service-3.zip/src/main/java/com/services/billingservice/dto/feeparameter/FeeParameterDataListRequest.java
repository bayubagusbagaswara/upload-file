package com.services.billingservice.dto.feeparameter;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeeParameterDataListRequest {

    private Long id;

    @JsonProperty(value = "Fee Code")
    private String feeCode;

    @JsonProperty(value = "Fee Name")
    private String feeName;

    @JsonProperty(value = "Fee Description")
    private String feeDescription;

    @JsonProperty(value = "Fee Value")
    private String feeValue;

}
