package com.services.billingservice.utils;

import lombok.experimental.UtilityClass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@UtilityClass
public class ZipPDFFiles {

    public static void zipPdfFiles(String sourceFolderPath, String outputZipPath) throws IOException {
        List<File> pdfFiles = listPdfFiles(sourceFolderPath);
        if (pdfFiles.isEmpty()) {
            throw new IOException("No PDF files found in the specified folder: " + sourceFolderPath);
        }

        try (FileOutputStream fos = new FileOutputStream(outputZipPath);
             ZipOutputStream zos = new ZipOutputStream(fos)) {
            for (File pdfFile : pdfFiles) {
                addToZip(pdfFile, zos);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        }
    }

    private static List<File> listPdfFiles(String folderPath) {
        List<File> pdfFiles = new ArrayList<>();
        File folder = new File(folderPath);

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isFile() && file.getName().toLowerCase().endsWith(".pdf")) {
                        pdfFiles.add(file);
                    }
                }
            }
        }
        return pdfFiles;
    }

    private static void addToZip(File file, ZipOutputStream zos) throws IOException {
        String zipEntryName = file.getName();
        ZipEntry zipEntry = new ZipEntry(zipEntryName);
        zos.putNextEntry(zipEntry);

        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zos.write(bytes, 0, length);
            }
        } finally {
            zos.closeEntry();
        }
    }

}
