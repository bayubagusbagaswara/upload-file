package com.services.billingservice.utils;


import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

    public static final String IDR = "IDR";
    public static final int DEFAULT_TXN_HANDLING_FEE = 50000;

    public static final String CURRENT_DATE_PARAM = "currentDate";
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
            "dd/MM/yyyy");
    public static final NumberFormat AMOUNT_FORMAT = new DecimalFormat(
            "#,##0.00");

    public static Date getCurrentDateFromRequest(HttpServletRequest request) {
        Date currentDate = new Date();
        String currentDateStr = (String) request
                .getAttribute(CURRENT_DATE_PARAM);
        if (currentDateStr != null && !currentDateStr.isEmpty()) {
            try {
                currentDate = DATE_FORMAT.parse(currentDateStr);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return currentDate;
    }


    public static void checkNulls(Object... params) {
        for (Object param : params) {
            if (param == null) {
                throw new IllegalArgumentException("Invalid parameter: null");
            }
        }
    }

    public static Date getDate(String dateStr) {
        Date date = null;
        try {
            date = DATE_FORMAT.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public static Double getAmount(String numberStr) {
        Number amount = null;
        try {
            amount = AMOUNT_FORMAT.parse(numberStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (amount != null) ? amount.doubleValue() : null;
    }

    public static boolean isInternal(String bankName) {
        return bankName.toUpperCase().contains("DANAMON");
    }

    public static byte[] hexStringToByteArray(String s) {
        return new BigInteger(s, 16).toByteArray();
    }

    public static String decimalStringToStringFormat(String num, int minDigit,
                                                     int maxDigit, boolean parseInteger, boolean setGrouping,
                                                     RoundingMode setRounding) {
        try {
            NumberFormat nf = NumberFormat.getInstance();
            nf.setMinimumFractionDigits(minDigit);
            nf.setMaximumFractionDigits(maxDigit);
            nf.setParseIntegerOnly(parseInteger);
            nf.setGroupingUsed(setGrouping);
            nf.setRoundingMode(setRounding);

            double numFloat = Double.parseDouble(num);
            return nf.format(numFloat);

        } catch (Exception err) {
            err.printStackTrace();
            String errorNum = "0.00";
            return errorNum;
        }
    }
	

}
