package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.*;
import com.services.billingservice.service.BillingMIService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/mi")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
@Slf4j
public class BillingMIController {

    private static final String MENU_INVESTMENT_MANAGEMENT = "Investment Management";

    private final BillingMIService billingMIService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> create(@RequestBody CreateInvestmentManagementRequest request) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/mi/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_INVESTMENT_MANAGEMENT)
                .build();
        InvestmentManagementResponse singleData = billingMIService.createSingleData(request, dataChangeDTO);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create-list")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> createList(@RequestBody CreateInvestmentManagementListRequest requestList) {
        log.info("List Request: {}", requestList);
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/mi/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_INVESTMENT_MANAGEMENT)
                .build();
        InvestmentManagementResponse listData = billingMIService.createMultipleData(requestList, dataChangeDTO);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(listData)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> createSingleApprove(@RequestBody InvestmentManagementApproveRequest approveRequest) {
        InvestmentManagementResponse listApprove = billingMIService.createSingleApprove(approveRequest);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> updateById(@RequestBody UpdateInvestmentManagementRequest request) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/mi/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_INVESTMENT_MANAGEMENT)
                .build();
        InvestmentManagementResponse updateInvestmentManagementListResponse = billingMIService.updateSingleData(request, dataChangeDTO);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateInvestmentManagementListResponse)
                .build();

        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update-list")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> updateList(@RequestBody UpdateInvestmentManagementListRequest request) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/mi/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_INVESTMENT_MANAGEMENT)
                .build();
        InvestmentManagementResponse updateInvestmentManagementListResponse = billingMIService.updateMultipleData(request, dataChangeDTO);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateInvestmentManagementListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> updateListApprove(@RequestBody InvestmentManagementApproveRequest approveRequest) {
        InvestmentManagementResponse updateInvestmentManagementListResponse = billingMIService.updateSingleApprove(approveRequest);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateInvestmentManagementListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/getByCode")
    public ResponseEntity<ResponseDTO<InvestmentManagementDTO>> getByCode(@RequestParam(name = "code") String code) {
        InvestmentManagementDTO investmentManagementDTO = billingMIService.getByCode(code);
        ResponseDTO<InvestmentManagementDTO> response = ResponseDTO.<InvestmentManagementDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(investmentManagementDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/getById")
    public ResponseEntity<ResponseDTO<InvestmentManagementDTO>> getById(@RequestParam(name = "id") String id) {
        InvestmentManagementDTO investmentManagementDTO = billingMIService.getById(id);
        ResponseDTO<InvestmentManagementDTO> response = ResponseDTO.<InvestmentManagementDTO>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(investmentManagementDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<InvestmentManagementDTO>>> getAll() {
        List<InvestmentManagementDTO> investmentManagementDTOList = billingMIService.getAll();
        ResponseDTO<List<InvestmentManagementDTO>> response = ResponseDTO.<List<InvestmentManagementDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(investmentManagementDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> deleteById(@RequestBody DeleteInvestmentManagementRequest request) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint("/api/mi/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_INVESTMENT_MANAGEMENT)
                .build();
        InvestmentManagementResponse deleteInvestmentManagementListResponse = billingMIService.deleteSingleData(request, dataChangeDTO);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteInvestmentManagementListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<InvestmentManagementResponse>> deleteApprove(@RequestBody InvestmentManagementApproveRequest request) {
        InvestmentManagementResponse deleteInvestmentManagementListResponse = billingMIService.deleteSingleApprove(request);
        ResponseDTO<InvestmentManagementResponse> response = ResponseDTO.<InvestmentManagementResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteInvestmentManagementListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/all")
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = billingMIService.deleteAll();
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

}
