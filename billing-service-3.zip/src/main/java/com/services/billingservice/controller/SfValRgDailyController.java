package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.service.SfValRgDailyService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RestController
@RequestMapping(path = "/api/sfval/rg-daily")
@RequiredArgsConstructor
public class SfValRgDailyController {

    @Value("${file.path.sf-val-rg-daily}")
    public String filePath;

    private final SfValRgDailyService rgDailyService;
    private final ConvertDateUtil convertDateUtil;

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert(@RequestParam("monthYear") String monthYear) {
        log.info("File Path : {}", filePath);
        // tambahkan filePath untuk periode nya
        // ketika Read, dari depan akan mengirimkan Period: November 2023
        // lalu kita convert menjadi 202311, lalu tambahkan ke path

//        String totalPeriod = period + "/nameFile";
//        String result = filePath + "/" + totalPeriod;

        String status = rgDailyService.readFileAndInsertToDB(filePath, monthYear);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAll() {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAll();

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByPeriod(@RequestParam("month") String month,
                                                                          @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByMonthAndYear(month, year);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAid(@RequestParam("aid") String aid) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAid(aid);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndPeriod(@RequestParam("aid") String aid,
                                                                                @RequestParam("month") String month,
                                                                                @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(aid, month, year);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/retail/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllRetailByAidAndTypeAndCurrencyAndPeriod(@RequestParam("aid") String aid,
                                                                                      @RequestParam("typeRetail") String typeRetail,
                                                                                      @RequestParam("currency") String currency,
                                                                                      @RequestParam("month") String month,
                                                                                      @RequestParam("year") Integer year) {
        String monthYearFormat = month + " " + year;
        LocalDate date = convertDateUtil.getFirstDateOfMonthYear(monthYearFormat);

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllRetailByAidAndTypeAndCurrencyAndPeriod(aid, typeRetail, currency, date);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/security-name")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndSecurityName(
            @RequestParam("aid") String aid,
            @RequestParam("securityName") String securityName) {

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAidAndSecurityName(aid, securityName);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/security-name/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndSecurityName(
            @RequestParam("aid") String aid,
            @RequestParam("securityName") String securityName,
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {
        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findByAidAndSecurityNameAndMonthAndYear(aid, securityName, month, year);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/aid/date")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getAllByAidAndDate(
            @RequestParam("aid") String aid,
            @RequestParam("date") String date) {

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllByAidAndDate(aid, date);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = rgDailyService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/recap/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getRecapByPeriod(@RequestParam("month") String month,
                                                                          @RequestParam("year") Integer year) {
        String monthYearFormat = month + " " + year;
        LocalDate latestDate = convertDateUtil.getLatestDateOfMonthYear(monthYearFormat);

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findRecapByMonthAndYear(month, year, latestDate);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/recap/aid/period")
    public ResponseEntity<ResponseDTO<List<SfValRgDaily>>> getRecapByAidAndPeriod(@RequestParam("aid") String aid,
                                                                            @RequestParam("month") String month,
                                                                            @RequestParam("year") Integer year) {
        String monthYearFormat = month + " " + year;
        LocalDate latestDate = convertDateUtil.getLatestDateOfMonthYear(monthYearFormat);

        List<SfValRgDaily> sfValRgDailyList = rgDailyService.findRecapByAidAndMonthAndYear(aid, month, year, latestDate);

        ResponseDTO<List<SfValRgDaily>> response = ResponseDTO.<List<SfValRgDaily>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValRgDailyList)
                .build();

        return ResponseEntity.ok().body(response);
    }
}
