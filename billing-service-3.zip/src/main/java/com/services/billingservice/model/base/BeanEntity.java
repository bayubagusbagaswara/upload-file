package com.services.billingservice.model.base;

import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import net.bytebuddy.implementation.bind.annotation.Super;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;

@MappedSuperclass
@SuperBuilder
@NoArgsConstructor
public class BeanEntity implements Serializable {

    private static final long serialVersionUID = -2594221424640904002L;
}
