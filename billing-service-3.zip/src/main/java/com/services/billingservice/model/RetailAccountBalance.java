package com.services.billingservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "rekap_account_balance")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailAccountBalance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "as_of")
    private String asOf;

    @Column(name = "aid")
    private String aid;

    @Column(name = "selling_agent")
    private String sellingAgent;

    @Column(name = "security_group")
    private String securityGroup;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "currency")
    private String currency;

    @Column(name = "name")
    private String name;

    @Column(name = "balance")
    private BigDecimal balance;

    @Column(name = "cif_number")
    private String cifNumber;

    @Column(name = "fee")
    private BigDecimal fee;
}
