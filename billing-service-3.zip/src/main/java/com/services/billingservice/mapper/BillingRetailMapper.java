package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class BillingRetailMapper {

    public BillingRetailDTO mapToDTO(BillingRetail billingRetail) {
        return BillingRetailDTO.builder()
                .createdAt(billingRetail.getCreatedAt())
                .updatedAt(billingRetail.getUpdatedAt())
                .approvalStatus(billingRetail.getApprovalStatus().getStatus())
                .billingStatus(billingRetail.getBillingStatus().getStatus())
                .customerCode(billingRetail.getCustomerCode())
                .customerName(billingRetail.getCustomerName())
                .month(billingRetail.getMonth())
                .year(String.valueOf(billingRetail.getYear()))
                .billingNumber(billingRetail.getBillingNumber())
                .billingPeriod(billingRetail.getBillingPeriod())
                .billingStatementDate(billingRetail.getBillingStatementDate())
                .billingPaymentDueDate(billingRetail.getBillingPaymentDueDate())
                .billingCategory(billingRetail.getBillingCategory())
                .billingType(billingRetail.getBillingType())
                .billingTemplate(billingRetail.getBillingTemplate())
                .investmentManagementName(billingRetail.getInvestmentManagementName())
                .investmentManagementAddress1(billingRetail.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingRetail.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingRetail.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingRetail.getInvestmentManagementAddress4())
                .investmentManagementEmail(billingRetail.getInvestmentManagementEmail())
                .accountName(billingRetail.getAccountName())
//                .accountNumber(billingRetail.getAccountNumber())
//                .accountBank(billingRetail.getAccountBank())
//                .swiftCode(billingRetail.getSwiftCode())
//                .corrBank(billingRetail.getCorrBank())
                .currency(billingRetail.getCurrency())

                .sellingAgent(billingRetail.getSellingAgent())
                .currency(billingRetail.getCurrency())
                .safekeepingFR(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingFR()))
                .safekeepingSR(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingSR()))
                .safekeepingST(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingST()))
                .safekeepingORI(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingORI()))
                .safekeepingSBR(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingSBR()))
                .safekeepingPBS(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingPBS()))
                .safekeepingCorporateBond(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingCorporateBond()))

                .subTotalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSubTotalAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTotalAmountDue()))

                .safekeepingValueFrequency(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingValueFrequency()))
                .safekeepingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingFee()))
                .safekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getSafekeepingAmountDue()))

                .transactionSettlementValueFrequency(String.valueOf(billingRetail.getTransactionSettlementValueFrequency()))
                .transactionSettlementFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionSettlementFee()))
                .transactionSettlementAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionSettlementAmountDue()))

                .adHocReportValueFrequency(String.valueOf(billingRetail.getAdHocReportValueFrequency()))
                .adHocReportFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getAdHocReportFee()))
                .adHocReportAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getAdHocReportAmountDue()))

                .thirdPartyValueFrequency(String.valueOf(billingRetail.getThirdPartyValueFrequency()))
                .thirdPartyFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getThirdPartyFee()))
                .thirdPartyAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getThirdPartyAmountDue()))

                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getVatAmountDue()))

                .transactionHandlingValueFrequency(String.valueOf(billingRetail.getTransactionHandlingValueFrequency()))
                .transactionHandlingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingFee()))
                .transactionHandlingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingAmountDue()))

                .transactionHandlingInternalValueFrequency(String.valueOf(billingRetail.getTransactionHandlingInternalValueFrequency()))
                .transactionHandlingInternalFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingInternalFee()))
                .transactionHandlingInternalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransactionHandlingInternalAmountDue()))

                .transferValueFrequency(String.valueOf(billingRetail.getTransferValueFrequency()))
                .transferFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransferFee()))
                .transferAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingRetail.getTransferAmountDue()))

                .build();
    }

    public List<BillingRetailDTO> mapToDTOList(List<BillingRetail> billingRetailList) {
        return billingRetailList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
