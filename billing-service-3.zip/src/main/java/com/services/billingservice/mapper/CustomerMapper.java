package com.services.billingservice.mapper;

import com.services.billingservice.dto.customer.CustomerDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class CustomerMapper extends BaseMapper<BillingCustomer, CustomerDTO> {

    private final ConvertDateUtil convertDateUtil;

    public CustomerMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingCustomer, CustomerDTO> getPropertyMap() {
        return new PropertyMap<BillingCustomer, CustomerDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<BillingCustomer> getEntityClass() {
        return BillingCustomer.class;
    }

    @Override
    protected Class<CustomerDTO> getDtoClass() {
        return CustomerDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingCustomer entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
