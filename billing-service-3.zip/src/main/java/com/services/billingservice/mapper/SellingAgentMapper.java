package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.SellingAgentDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingSellingAgentData;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

@Component
public class SellingAgentMapper extends BaseMapper<BillingSellingAgentData, SellingAgentDTO> {

    private final ConvertDateUtil convertDateUtil;

    public SellingAgentMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingSellingAgentData, SellingAgentDTO> getPropertyMap() {
        return new PropertyMap<BillingSellingAgentData, SellingAgentDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    protected Class<BillingSellingAgentData> getEntityClass() {
        return BillingSellingAgentData.class;
    }

    @Override
    protected Class<SellingAgentDTO> getDtoClass() {
        return SellingAgentDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingSellingAgentData entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
