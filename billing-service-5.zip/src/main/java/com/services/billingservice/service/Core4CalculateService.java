package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;

public interface Core4CalculateService {

    String calculate(CoreCalculateRequest request);

}
