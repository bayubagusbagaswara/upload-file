package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.BillingCoreDTO;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingType;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingCoreMapper;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.CoreGeneratePDFService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.time.Month;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.constant.CoreConstant.*;
import static com.services.billingservice.constant.CoreConstant.SAFEKEEPING_FEE_PERIOD;
import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_3;
import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_5;

@Slf4j
@Service
@RequiredArgsConstructor
public class CoreGeneratePDFServiceImpl implements CoreGeneratePDFService {

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private static final String BANK_ACCOUNT_BDI = "PT Bank Danamon Indonesia";

    private final BillingCoreRepository billingCoreRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingCoreMapper billingCoreMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;

    @Override
    public String generatePDF(CoreCalculateRequest request) {
        log.info("Start generate PDF Billing Core type: {}", request.getType());
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            generateAndSavePdfStatements(billingCoreList);

            log.info("Finished generate PDF Billing Core type {}", categoryUpperCase);
            return "Successfully created a PDF file for Billing Core type: " + typeUpperCase;
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Core type '" + typeUpperCase + "' : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Core type '" + typeUpperCase + "' : " + e.getMessage());
        }
    }

    private void generateAndSavePdfStatements(List<BillingCore> billingCoreList) {
        log.info("Start generate and save pdf statements Billing Core");
        Instant dateNow = Instant.now();
        List<BillingCoreDTO> billingCoreDTOList = billingCoreMapper.mapToDTOList(billingCoreList);

        for (BillingCoreDTO billingCoreDTO : billingCoreDTOList) {
            log.info("Start generate PDF Billing Core type '{}' and AID '{}'", billingCoreDTO.getBillingType(), billingCoreDTO.getCustomerCode());

            BillingReportGenerator billingReportGenerator = new BillingReportGenerator();
            String investmentManagementName = billingCoreDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingCoreDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = billingCoreDTO.getInvestmentManagementUniqueKey();
            String customerCode = billingCoreDTO.getCustomerCode();
            String customerName = billingCoreDTO.getCustomerName();
            String billingCategory = billingCoreDTO.getBillingCategory();
            String billingType = billingCoreDTO.getBillingType();
            String billingTemplate = billingCoreDTO.getBillingTemplate();
            String billingPeriod = billingCoreDTO.getBillingPeriod();
            String billingNumber = billingCoreDTO.getBillingNumber();

            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String fileName = null;
            String filePath;
            String folderPath;
            String htmlContent;
            byte[] pdfBytes;
            String outputPath;


            if (billingType.equalsIgnoreCase(BillingType.TYPE_7.getValue())) {
                String[] split = billingPeriod.split(" - ");

                monthYearMap = convertDateUtil.extractMonthYearInformation(split[1]);
                yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");
            } else {
                monthYearMap = convertDateUtil.extractMonthYearInformation(billingPeriod);
                yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");
            }

            if (billingType.equalsIgnoreCase(BillingType.TYPE_4.getValue())) {
                if (billingTemplate.equalsIgnoreCase(CORE_TEMPLATE_5.name())) {
                    fileName = generateFileNameEB(customerCode, billingCategory, billingType, yearMonthFormat, billingNumber);
                } else if (billingTemplate.equalsIgnoreCase(CORE_TEMPLATE_3.name())) {
                    fileName = generateFileNameITAMA(customerCode, billingCategory, billingType, yearMonthFormat, billingNumber);
                } else {
                    log.info("Ini adalah type 4 tapi bukan Template 5 maupun Template 3");
                }
            } else if (billingType.equalsIgnoreCase(BillingType.TYPE_7.getValue())) {
                fileName = generateFileNameMUFG(billingCategory, billingType, billingPeriod, billingNumber);
            } else {
                fileName = generateFileName(customerCode, billingCategory, billingType, yearMonthFormat, billingNumber);
            }

            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            folderPath = basePathBillingCore + yearMonthFormat + "/" + investmentManagementName;

            filePath = folderPath + "/" + fileName;

            try {
                htmlContent = renderThymeleafTemplate(billingCoreDTO);
                pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);

                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                Path outputPathObj = folderPathObj.resolve(fileName);
                outputPath = outputPathObj.toString();

                pdfGenerator.savePdfToFile(pdfBytes, outputPath);

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setInvestmentManagementUniqueKey(investmentManagementUniqueKey);
                billingReportGenerator.setCustomerCode(customerCode);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
                billingReportGenerator.setDesc("Success generate and save PDF statements");

                billingReportGeneratorService.saveSingleData(billingReportGenerator);
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: {}", e.getMessage(), e);
                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setInvestmentManagementUniqueKey(investmentManagementUniqueKey);
                billingReportGenerator.setCustomerCode(customerCode);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(folderPath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
                billingReportGenerator.setDesc(e.getMessage());

                billingReportGeneratorService.saveSingleData(billingReportGenerator);
            }
        }
    }

    private String renderThymeleafTemplate(BillingCoreDTO billingCoreDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, billingCoreDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, billingCoreDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, billingCoreDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, billingCoreDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, billingCoreDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, billingCoreDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, billingCoreDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, billingCoreDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, billingCoreDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, billingCoreDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, billingCoreDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, billingCoreDTO.getInvestmentManagementAddress4());
        context.setVariable(ACCOUNT_NAME, billingCoreDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, billingCoreDTO.getAccount());
        context.setVariable(ACCOUNT_BANK, BANK_ACCOUNT_BDI);

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, billingCoreDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, billingCoreDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, billingCoreDTO.getTransactionHandlingAmountDue());
        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, billingCoreDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, billingCoreDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getSafekeepingAmountDue());
        context.setVariable(SUB_TOTAL, billingCoreDTO.getSubTotal());
        context.setVariable(VAT_FEE, billingCoreDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, billingCoreDTO.getVatAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, billingCoreDTO.getTotalAmountDue());

        context.setVariable(JOURNAL_CREDIT_TO, billingCoreDTO.getJournalCreditTo());
        context.setVariable(KSEI_SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getKseiSafekeepingAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, billingCoreDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getKseiTransactionAmountDue());
        context.setVariable(BIS4_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getBis4TransactionValueFrequency());
        context.setVariable(BIS4_TRANSACTION_FEE, billingCoreDTO.getBis4TransactionFee());
        context.setVariable(BIS4_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getBis4TransactionAmountDue());

        context.setVariable(SAFEKEEPING_FEE_JOURNAL, billingCoreDTO.getSafekeepingFeeJournal());
        context.setVariable(TRANSACTION_HANDLING_JOURNAL, billingCoreDTO.getTransactionHandlingJournal());
        // context.setVariable(ACCOUNT_NUMBER_CBEST, billingCoreDTO.getAccNumberCBEST());

        context.setVariable(ADMINISTRATION_SET_UP_ITEM, billingCoreDTO.getAdministrationSetUpItem());
        context.setVariable(ADMINISTRATION_SET_UP_FEE, billingCoreDTO.getAdministrationSetUpFee());
        context.setVariable(ADMINISTRATION_SET_UP_AMOUNT_DUE, billingCoreDTO.getAdministrationSetUpAmountDue());
        context.setVariable(SIGNING_REPRESENTATION_ITEM, billingCoreDTO.getSigningRepresentationItem());
        context.setVariable(SIGNING_REPRESENTATION_FEE, billingCoreDTO.getSigningRepresentationFee());
        context.setVariable(SIGNING_REPRESENTATION_AMOUNT_DUE, billingCoreDTO.getSigningRepresentationAmountDue());
        context.setVariable(SECURITY_AGENT_ITEM, billingCoreDTO.getSecurityAgentItem());
        context.setVariable(SECURITY_AGENT_FEE, billingCoreDTO.getSecurityAgentFee());
        context.setVariable(SECURITY_AGENT_AMOUNT_DUE, billingCoreDTO.getSecurityAgentAmountDue());
        context.setVariable(TRANSACTION_HANDLING_ITEM, billingCoreDTO.getTransactionHandlingItem());
        context.setVariable(SAFEKEEPING_ITEM, billingCoreDTO.getSafekeepingItem());
        context.setVariable(OTHER_ITEM, billingCoreDTO.getOtherItem());
        context.setVariable(OTHER_FEE, billingCoreDTO.getOtherFee());
        context.setVariable(OTHER_AMOUNT_DUE, billingCoreDTO.getOtherAmountDue());

        context.setVariable(SAFEKEEPING_FEE_PERIOD, billingCoreDTO.getBillingPeriod());

        // tambahkan Image URL
        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        String billingTemplate = billingCoreDTO.getBillingTemplate();
        log.info("Billing Template '{}'", billingTemplate);
        return templateEngine.process(billingTemplate, context);
    }

    private String generateFileName(String aid, String billingCategory, String billingType, String yearMonthFormat, String billingNumber) {
        String replaceBillingNumber = billingNumber.replaceAll("/", "_")
                .replaceAll("-", "_");
        // return aid + "_" + billingCategory + "_" + billingType + "_" + yearMonthFormat + ".pdf";
        return replaceBillingNumber + ".pdf";
    }

    private String generateFileNameEB(String aid, String billingCategory, String billingType, String yearMonthFormat, String billingNumber) {
        String replaceBillingNumber = billingNumber.replaceAll("/", "_")
                .replaceAll("-", "_");
        // return aid + "_" + "EB" + "_" + billingCategory + "_" + billingType + "_" + yearMonthFormat + ".pdf";
        return "EB_" + replaceBillingNumber + ".pdf";
    }

    private String generateFileNameITAMA(String aid, String billingCategory, String billingType, String yearMonthFormat, String billingNumber) {
        String replaceBillingNUmber = billingNumber.replaceAll("/", "_")
                .replaceAll("-", "_");
        // return aid + "_" + "Itama" + "_" + billingCategory + "_" + billingType + "_" + yearMonthFormat + ".pdf";
        return "ITAMA_" + replaceBillingNUmber + ".pdf";
    }

    private String generateFileNameMUFG(String billingCategory, String billingType, String billingPeriod, String billingNumber) {
        // Billing Period = Aug 2023 - Oct 2023
        String[] split = billingPeriod.split(" - ");
        String[] s = split[0].split(" ");

        String monthString1 = s[0]; // OCTOBER
        String s2 = s[1]; // 2023

        Month month1 = MonthConverterUtil.getMonth(monthString1.toUpperCase());
        int monthValue1 = month1.getValue();

        String formattedMonth1 = (monthValue1 < 10) ? "0" + monthValue1 : String.valueOf(monthValue1);

        String[] s3 = split[1].split(" ");
        String monthString2 = s3[0]; // AUGUST

        String s5 = s3[1]; // 2023

        Month month2 = MonthConverterUtil.getMonth(monthString2.toUpperCase());

        int monthValue2 = month2.getValue();
        String formattedMonth2 = (monthValue2 < 10) ? "0" + monthValue2 : String.valueOf(monthValue2);

        String replaceBillingNumber = billingNumber.replaceAll("/", "_")
                .replaceAll("-", "_");
        // return "MUFG_" + billingCategory + "_" + billingType + "_" + formattedMonth1 + s2 + "-" + formattedMonth2 + s5 + ".pdf";
        return replaceBillingNumber + ".pdf";
    }

}
