package com.services.billingservice.service.impl;

import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingRetailMapper;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.RetailGeneratePDFService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.PdfGenerator;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.constant.RetailConstant.*;
import static com.services.billingservice.constant.RetailConstant.TRANSFER_AMOUNT_DUE;

@Slf4j
@Service
@RequiredArgsConstructor
public class RetailGeneratePDFServiceImpl implements RetailGeneratePDFService {

    @Value("${base.path.billing.retail}")
    private String basePathBillingRetail;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final BillingRetailRepository billingRetailRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingRetailMapper billingRetailMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;

    @Override
    public String generatePDF(RetailCalculateRequest request) {
        log.info("Start generate PDF Billing Retail type: {}", request.getType());
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingRetail> billingRetailList = billingRetailRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            generateAndSavePdfStatements(billingRetailList);

            log.info("Finished generate PDF Billing Retail type '{}'", categoryUpperCase);
            return "Successfully created a PDF file for Billing Core type: " + typeUpperCase;
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Retail type '" + typeUpperCase + "' : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Retail type '" + typeUpperCase + "' : " + e.getMessage());
        }
    }

    private void generateAndSavePdfStatements(List<BillingRetail> billingRetailList) {
        log.info("Start generate and save PDF statements Billing Retail size: {}", billingRetailList.size());
        Instant dateNow = Instant.now();

        List<BillingRetailDTO> billingRetailDTOList = billingRetailMapper.mapToDTOList(billingRetailList);
        log.info("Billing Retail DTO List: {}", billingRetailDTOList.size());

        for (BillingRetailDTO billingRetailDTO : billingRetailDTOList) {
            log.info("Start generate PDF Billing Retail type '{}' and currency '{}'", billingRetailDTO.getBillingType(), billingRetailDTO.getCurrency());

            BillingReportGenerator billingReportGenerator = new BillingReportGenerator();
            String investmentManagementName = billingRetailDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingRetailDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = billingRetailDTO.getInvestmentManagementUniqueKey();
            String sellingAgent = billingRetailDTO.getSellingAgent();
            String customerName = billingRetailDTO.getCustomerName();
            String billingCategory = billingRetailDTO.getBillingCategory();
            String billingType = billingRetailDTO.getBillingType();
            String billingPeriod = billingRetailDTO.getBillingPeriod();
            String currency = billingRetailDTO.getCurrency();
            String billingNumber = billingRetailDTO.getBillingNumber();

            log.info("Start generate PDF Billing Retail type '{}', selling agent '{}', and currency '{}'", billingType, sellingAgent, currency);

            Map<String, String> monthYearMap;
            String yearMonthFormat;
            String htmlContent;
            byte[] pdfBytes;
            String fileName;
            String filePath;
            String folderPath;
            String outputPath;

            monthYearMap = convertDateUtil.extractMonthYearInformation(billingPeriod);
            yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");

            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            fileName = generateFileName(sellingAgent, billingCategory, currency, yearMonthFormat, billingNumber);

            folderPath = basePathBillingRetail + yearMonthFormat + "/" + investmentManagementName;

            filePath = folderPath + "/" + fileName;
            ;

            try {
                htmlContent = renderThymeleafTemplate(billingRetailDTO);
                pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);

                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                Path outputPathObj = folderPathObj.resolve(fileName);
                outputPath = outputPathObj.toString();

                pdfGenerator.savePdfToFile(pdfBytes, outputPath);

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setInvestmentManagementUniqueKey(investmentManagementUniqueKey);
                billingReportGenerator.setCustomerCode(sellingAgent);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.SUCCESS.getStatus());
                billingReportGenerator.setDesc("Success generate and save PDF statements");

                billingReportGeneratorService.saveSingleData(billingReportGenerator);
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: {}", e.getMessage(), e);

                billingReportGenerator.setCreatedAt(dateNow);
                billingReportGenerator.setInvestmentManagementName(investmentManagementName);
                billingReportGenerator.setInvestmentManagementEmail(investmentManagementEmail);
                billingReportGenerator.setInvestmentManagementUniqueKey(investmentManagementUniqueKey);
                billingReportGenerator.setCustomerCode(sellingAgent);
                billingReportGenerator.setCustomerName(customerName);
                billingReportGenerator.setCategory(billingCategory);
                billingReportGenerator.setType(billingType);
                billingReportGenerator.setMonth(monthName);
                billingReportGenerator.setYear(year);
                billingReportGenerator.setCurrency(currency);
                billingReportGenerator.setPeriod(billingPeriod);
                billingReportGenerator.setFileName(fileName);
                billingReportGenerator.setFilePath(filePath);
                billingReportGenerator.setStatus(ReportGeneratorStatus.FAILED.getStatus());
                billingReportGenerator.setDesc(e.getMessage());

                billingReportGeneratorService.saveSingleData(billingReportGenerator);
            }
        }
    }

    private String renderThymeleafTemplate(BillingRetailDTO retailDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, retailDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, retailDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, retailDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, retailDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, retailDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, retailDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, retailDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, retailDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, retailDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, retailDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, retailDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, retailDTO.getInvestmentManagementAddress4());

        context.setVariable(SAFEKEEPING_FR, retailDTO.getSafekeepingFR());
        context.setVariable(SAFEKEEPING_SR, retailDTO.getSafekeepingSR());
        context.setVariable(SAFEKEEPING_ST, retailDTO.getSafekeepingST());
        context.setVariable(SAFEKEEPING_ORI, retailDTO.getSafekeepingORI());
        context.setVariable(SAFEKEEPING_SBR, retailDTO.getSafekeepingSBR());
        context.setVariable(SAFEKEEPING_PBS, retailDTO.getSafekeepingPBS());
        context.setVariable(SAFEKEEPING_CORPORATE_BOND, retailDTO.getSafekeepingCorporateBond());

        context.setVariable(TOTAL_AMOUNT_DUE, retailDTO.getTotalAmountDue());

        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, retailDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, retailDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, retailDTO.getSafekeepingAmountDue());

        context.setVariable(TRANSACTION_SETTLEMENT_VALUE_FREQUENCY, retailDTO.getTransactionSettlementValueFrequency());
        context.setVariable(TRANSACTION_SETTLEMENT_FEE, retailDTO.getTransactionSettlementFee());
        context.setVariable(TRANSACTION_SETTLEMENT_AMOUNT_DUE, retailDTO.getTransactionSettlementAmountDue());

        context.setVariable(AD_HOC_REPORT_VALUE_FREQUENCY, retailDTO.getAdHocReportValueFrequency());
        context.setVariable(AD_HOC_REPORT_FEE, retailDTO.getAdHocReportFee());
        context.setVariable(AD_HOC_REPORT_AMOUNT_DUE, retailDTO.getAdHocReportAmountDue());

        context.setVariable(THIRD_PARTY_VALUE_FREQUENCY, retailDTO.getThirdPartyValueFrequency());
        context.setVariable(THIRD_PARTY_FEE, retailDTO.getThirdPartyFee());
        context.setVariable(THIRD_PARTY_AMOUNT_DUE, retailDTO.getThirdPartyAmountDue());

        context.setVariable(VAT_FEE, retailDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, retailDTO.getVatAmountDue());

        context.setVariable(SUB_TOTAL, retailDTO.getSubTotalAmountDue());

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, retailDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, retailDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, retailDTO.getTransactionHandlingAmountDue());

        context.setVariable(TRANSACTION_HANDLING_INTERNAL_VALUE_FREQUENCY, retailDTO.getTransactionHandlingInternalValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_INTERNAL_FEE, retailDTO.getTransactionHandlingInternalFee());
        context.setVariable(TRANSACTION_HANDLING_INTERNAL_AMOUNT_DUE, retailDTO.getTransactionHandlingInternalAmountDue());

        context.setVariable(TRANSFER_VALUE_FREQUENCY, retailDTO.getTransferValueFrequency());
        context.setVariable(TRANSFER_FEE, retailDTO.getTransferFee());
        context.setVariable(TRANSFER_AMOUNT_DUE, retailDTO.getTransferAmountDue());

        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        String billingTemplate = retailDTO.getBillingTemplate();
        log.info("Billing Template: {}", billingTemplate);

        // Format Template = RETAIL_TYPE_1_IDR
//        String templateFormat = billingCategory + "_" + billingType + "_" + currency;

        return templateEngine.process(billingTemplate, context);
    }

    private String generateFileName(String sellingAgent, String billingCategory, String currency, String yearMonthFormat, String billingNumber) {
        // SELLING_AGENT + BILLING CATEGORY + CURRENCY + YEAR MONTH FORMAT
        String replaceBillingNumber = billingNumber.replaceAll("/", "_")
                .replaceAll("-", "_");
        // return sellingAgent + "_" + billingCategory + "_" + currency + "_" + yearMonthFormat + ".pdf";
        return replaceBillingNumber + ".pdf";
    }

}
