package com.services.billingservice.service.impl;

import com.services.billingservice.dto.kseisafe.CreateKseiSafeRequest;
import com.services.billingservice.enums.FeeParameter;
import com.services.billingservice.exception.*;
import com.services.billingservice.model.KseiSafekeepingFee;
import com.services.billingservice.repository.KseiSafekeepingFeeRepository;
import com.services.billingservice.service.BillingFeeParameterService;
import com.services.billingservice.service.KseiSafeService;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class KseiSafeServiceImpl implements KseiSafeService {

    private static final String BASE_FILE_NAME = "Ksei_Safe_";
    private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");

    private final KseiSafekeepingFeeRepository kseiSafekeepingFeeRepository;
    private final BillingFeeParameterService feeParameterService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public List<KseiSafekeepingFee> createList(List<CreateKseiSafeRequest> requestList) {
        List<KseiSafekeepingFee> kseiSafekeepingFeeList = new ArrayList<>();

        for (CreateKseiSafeRequest request : requestList) {

            // created date
            String createdDate = request.getCreatedDate(); // 2023/11/01
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            LocalDate localDate = LocalDate.parse(createdDate, dateTimeFormatter);
            String monthName = localDate.getMonth().getDisplayName(TextStyle.FULL, ConvertDateUtil.getLocaleEN());
            int year = localDate.getYear();

            // Fee Description
            String feeDescription = request.getFeeDescription().isEmpty() ? "" : request.getFeeDescription();

            // Ksei Safe Code
            String kseiSafeCode = request.getKseiSafeCode().isEmpty() ? "" : request.getKseiSafeCode();

            // Amount Fee
            BigDecimal amountFee = request.getAmountFee().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getAmountFee());

            KseiSafekeepingFee kseiSafekeepingFee = KseiSafekeepingFee.builder()
                    .createdDate(localDate)
                    .month(monthName)
                    .year(year)
                    .feeDescription(feeDescription)
                    .kseiSafeCode(kseiSafeCode)
                    .amountFee(amountFee)
                    .build();
            kseiSafekeepingFeeList.add(kseiSafekeepingFee);
        }
        return kseiSafekeepingFeeRepository.saveAll(kseiSafekeepingFeeList);
    }

    @Override
    public String readAndInsertToDB(String filePath, String monthYear) {
        log.info("File Path: {}, and Month Year: {}", filePath, monthYear);

        try {
            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            String monthValue = monthMinus1.get("monthValue");
            int year = Integer.parseInt(monthMinus1.get("year"));

            String fileName = BASE_FILE_NAME + year + monthValue + ".xlsx";
            String filePathNew = filePath + fileName;

            if (StringUtils.isBlank(filePathNew)) {
                throw new InvalidInputException("File path cannot be null or empty");
            }

            File file = new File(filePathNew);
            if (!file.exists()) {
                log.error("File not found: {}", filePathNew);
                throw new DataNotFoundException("KSEI Safe Fee file not found with path: " + filePathNew);
            }

            // Find and delete existing data for the specified month and year
            kseiSafekeepingFeeRepository.deleteByMonthAndYear(monthName, year);

            List<KseiSafekeepingFee> kseiSafekeepingFeeList = readDataFromFile(file);
            kseiSafekeepingFeeRepository.saveAll(kseiSafekeepingFeeList);
            return "Excel data processed and saved successfully";
        } catch (DataNotFoundException e) {
            log.error("Data not found: {}", e.getMessage());
            throw new DataNotFoundException(e.getMessage());
        } catch (Exception e) {
            log.error("An unexpected error occurred: {}", e.getMessage(), e);
            throw new GeneralException(e.getMessage());
        }
    }

    private List<KseiSafekeepingFee> readDataFromFile(File file) {
        List<KseiSafekeepingFee> kseiSafekeepingFeeList = new ArrayList<>();
        try (Workbook workbook = WorkbookFactory.create(new FileInputStream(file))) {
            processSheets(workbook, kseiSafekeepingFeeList);
        } catch (IOException e) {
            log.error("Error reading the Excel file: {}", e.getMessage());
            throw new ReadExcelException("Failed to process Excel file. Error reading the Excel file: " + e.getMessage());
        }
        return kseiSafekeepingFeeList;
    }

    @Override
    public List<KseiSafekeepingFee> getAll() {
        return kseiSafekeepingFeeRepository.findAll();
    }

    @Override
    public List<KseiSafekeepingFee> getAllByKseiSafeCode(String kseiSafeCode) {
        return kseiSafekeepingFeeRepository.findAllByKseiSafeCode(kseiSafeCode);
    }

    @Override
    public BigDecimal calculateAmountFeeByKseiSafeCodeAndMonthAndYear(String kseiSafeCode, String monthName, int year) {
        BigDecimal vatFee = feeParameterService.getValueByName(FeeParameter.VAT.getValue());
        log.info("[Ksei Safe Service] VAT Fee : {}", vatFee);

        KseiSafekeepingFee kseiSafekeepingFee = kseiSafekeepingFeeRepository.findByKseiSafeCodeAndMonthAndYear(kseiSafeCode, monthName, year)
                .orElseThrow(() -> new DataNotFoundException("KSEI Safe with ksei safe code '" + kseiSafeCode+ "' and Month Year '" + monthName + " " + year + "' not found."));

        BigDecimal amountFee = kseiSafekeepingFee.getAmountFee();
        log.info("Customer Code: {}, Amount Fee: {}", kseiSafekeepingFee.getKseiSafeCode(), amountFee);

        BigDecimal valueAfterVAT = amountFee.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("Value after VAT : {}", valueAfterVAT);

        BigDecimal totalAmount = amountFee.add(valueAfterVAT).setScale(0, RoundingMode.HALF_UP);
        log.info("Total Amount : {}", totalAmount);

        return totalAmount;
    }

    @Override
    public String deleteAll() {
        try {
            kseiSafekeepingFeeRepository.deleteAll();
            return "Successfully deleted all KSEI Safekeeping Fee";
        } catch (Exception e) {
            log.error("Error when delete all KSEI Safekeeping Fee : " + e.getMessage());
            throw new UnexpectedException("Error when delete all KSEI Safekeeping Fee : " + e.getMessage());
        }
    }

    @Override
    public List<KseiSafekeepingFee> getAllByMonthAndYear(String month, Integer year) {
        return kseiSafekeepingFeeRepository.findAllByMonthAndYear(month, year);
    }

    @Override
    public KseiSafekeepingFee getByKseiSafeCodeAndMonthAndYear(String kseiSafeCode, String month, Integer year) {
        return kseiSafekeepingFeeRepository.findByKseiSafeCodeAndMonthAndYear(kseiSafeCode, month, year)
                .orElseThrow(() -> new DataNotFoundException("Ksei Safe Fee with ksei safe code '" + kseiSafeCode + "' " +
                        "and month '" + month + "' " +
                        "and year '" + year + "'"));
    }

    @Override
    public BigDecimal getAmountFeeByKseiSafeCodeAndMonthAndYear(String kseiSafeCode, String month, Integer year) {
        KseiSafekeepingFee kseiSafekeepingFee = kseiSafekeepingFeeRepository.findByKseiSafeCodeAndMonthAndYear(kseiSafeCode, month, year)
                .orElseThrow(() -> new DataNotFoundException("Ksei Safe Fee with ksei safe code '" + kseiSafeCode + "' " +
                        "and month '" + month + "' " +
                        "and year '" + year + "'"));
        return kseiSafekeepingFee.getAmountFee();
    }

    private static void processSheets(Workbook workbook, List<KseiSafekeepingFee> kseiSafekeepingFeeList) {
        Iterator<Sheet> sheetIterator = workbook.sheetIterator();

        while (sheetIterator.hasNext()) {
            Sheet sheet = sheetIterator.next();
            processRows(sheet, kseiSafekeepingFeeList);
        }
    }

    private static void processRows(Sheet sheet, List<KseiSafekeepingFee> kseiSafekeepingFeeList) {
        Iterator<Row> rowIterator = sheet.rowIterator();

        // Skip the first row (header)
        if (rowIterator.hasNext()) {
            rowIterator.next(); // move to the next row
        }

        while (rowIterator.hasNext()) {
            try {
                Row row = rowIterator.next();
                KseiSafekeepingFee kseiSafekeepingFee = createEntityFromRow(row);
                kseiSafekeepingFeeList.add(kseiSafekeepingFee);
            } catch (Exception e) {
                log.error("Error processing a row: {}", e.getMessage(), e);
                // You may choose to continue processing other rows or break the loop
                throw new GeneralException("Failed to process Excel file: " + e.getMessage());
            }
        }
    }

    private static KseiSafekeepingFee createEntityFromRow(Row row) {
        KseiSafekeepingFee kseiSafekeepingFee = new KseiSafekeepingFee();
        Cell cell3 = row.getCell(2);
        kseiSafekeepingFee.setCreatedDate(ConvertDateUtil.parseDateOrDefault(cell3.toString(), dateFormatter));

        LocalDate date = ConvertDateUtil.parseDateOrDefault(cell3.toString(), dateFormatter);
        Integer year = date != null ? date.getYear() : null;
        String monthName = date != null ? date.getMonth().getDisplayName(TextStyle.FULL, ConvertDateUtil.getLocaleEN()) : "";

        kseiSafekeepingFee.setCreatedDate(date);

        kseiSafekeepingFee.setMonth(monthName);

        kseiSafekeepingFee.setYear(year);

        Cell cell14 = row.getCell(14);
        kseiSafekeepingFee.setFeeDescription(cell14.toString());

        String kseiSafeCode = checkContainsSafekeeping(cell14.toString());
        kseiSafekeepingFee.setKseiSafeCode(kseiSafeCode);

        Cell cell15 = row.getCell(15);
        BigDecimal amountFee = ConvertBigDecimalUtil.parseBigDecimalOrDefault(cell15.toString());
        kseiSafekeepingFee.setAmountFee(amountFee);

        return kseiSafekeepingFee;
    }

    private static String checkContainsSafekeeping(String inputString) {
        String result;
        if (containsKeyword(inputString)) {
            result = cleanedDescription(inputString);
        } else {
            result = "";
        }
        return result;
    }

    private static boolean containsKeyword(String input) {
        return input.contains("Safekeeping fee for account");
    }

    private static String cleanedDescription(String inputContainsSafekeeping) {
        return inputContainsSafekeeping.replace("Safekeeping fee for account", "").trim();
    }

}
