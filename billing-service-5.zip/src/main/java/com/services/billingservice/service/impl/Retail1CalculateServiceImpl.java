package com.services.billingservice.service.impl;

import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.Retail1QueryResultDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.enums.Currency;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.constant.SecurityGroupConstant.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail1CalculateServiceImpl implements Retail1CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingNumberService billingNumberService;
    private final RetailGeneralService retailGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();

            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            int year = Integer.parseInt(monthMinus1.get("year"));

            Map<String, String> monthNow = convertDateUtil.getMonthNow();
            String monthNameNow = monthNow.get("monthName");
            int yearNow = Integer.parseInt(monthNow.get("year"));

            Instant dateNow = Instant.now();
            int totalDataSuccess = 0;

            // Data is BDI with currency IDR and BDI with currency USD
            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomer billingCustomer : billingCustomerList) {
                String sellingAgent = billingCustomer.getSellingAgent();
                String customerCode = billingCustomer.getCustomerCode();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                String currency = billingCustomer.getCurrency();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingType = billingCustomer.getBillingType();
                String billingTemplate = billingCustomer.getBillingTemplate();
                String miCode = billingCustomer.getMiCode();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                // Check apakah billing sudah tergenerate
                retailGeneralService.checkingExistingBillingRetail(customerCode, currency, monthName, year);

                // Create a new BillingRetail object for each customer
                BillingRetail billingRetail = new BillingRetail();

                // Check currency is IDR or USD
                if (currency.equalsIgnoreCase(Currency.IDR.getValue())) {
                    // Calculate Billing IDR
                    List<Retail1QueryResultDTO> retailAccountBalances = retailAccountBalanceRepository.getSumTotalAmountFeeBySellingAgentAndCurrencyIDR(sellingAgent, currency);

                    BigDecimal totalAmountDue = BigDecimal.ZERO; // Initialize totalAmountDue

                    for (Retail1QueryResultDTO accountBalance : retailAccountBalances) {
                        BigDecimal totalAmountFee = accountBalance.getTotalAmountFee();
                        String securityGroup = accountBalance.getSecurityGroup();

                        // Set safekeeping fees based on security group
                        switch (securityGroup.toUpperCase()) {
                            case FR:
                                billingRetail.setSafekeepingFR(totalAmountFee);
                                break;
                            case SR:
                                billingRetail.setSafekeepingSR(totalAmountFee);
                                break;
                            case ST:
                                billingRetail.setSafekeepingST(totalAmountFee);
                                break;
                            case ORI:
                                billingRetail.setSafekeepingORI(totalAmountFee);
                                break;
                            case SBR:
                                billingRetail.setSafekeepingSBR(totalAmountFee);
                                break;
                            case PBS:
                                billingRetail.setSafekeepingPBS(totalAmountFee);
                                break;
                            case CORPORATE_BOND:
                                billingRetail.setSafekeepingCorporateBond(totalAmountFee);
                                break;
                            default:
                                break;
                        }

                        // Accumulate totalAmountFee to calculate totalAmountDue
                        totalAmountDue = totalAmountDue.add(totalAmountFee);
                    }

                    // Set the total amount due for IDR
                    billingRetail.setTotalAmountDue(totalAmountDue);
                } else {
                    // Calculate Billing USD
                    BigDecimal totalAmountDue = retailAccountBalanceRepository.getSumTotalAmountFeeBySellingAgentAndCurrencyUSD(sellingAgent, currency);

                    // Set the total amount due for USD
                    billingRetail.setTotalAmountDue(totalAmountDue);
                }

                // set default field
                billingRetail.setCreatedAt(dateNow);
                billingRetail.setUpdatedAt(dateNow);
                billingRetail.setApprovalStatus(ApprovalStatus.Pending);
                billingRetail.setBillingStatus(BillingStatus.Generated);
                billingRetail.setSellingAgent(sellingAgent);
                billingRetail.setMonth(monthName);
                billingRetail.setYear(year);
                billingRetail.setBillingPeriod(monthName + " " + year);
                billingRetail.setBillingStatementDate(ConvertDateUtil.convertInstantToString(dateNow));
                billingRetail.setBillingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow));
                billingRetail.setBillingCategory(billingCategory);
                billingRetail.setBillingType(billingType);
                billingRetail.setBillingTemplate(billingTemplate);
                billingRetail.setInvestmentManagementName(billingMIDTO.getName());
                billingRetail.setInvestmentManagementAddress1(billingMIDTO.getAddress1());
                billingRetail.setInvestmentManagementAddress2(billingMIDTO.getAddress2());
                billingRetail.setInvestmentManagementAddress3(billingMIDTO.getAddress3());
                billingRetail.setInvestmentManagementAddress4(billingMIDTO.getAddress4());
                billingRetail.setInvestmentManagementEmail(billingMIDTO.getEmail());

                // set data customer, customerCode, customerName
                billingRetail.setGefuCreated(false);
                billingRetail.setPaid(false);
                billingRetail.setCustomerCode(billingCustomer.getCustomerCode());
                billingRetail.setCustomerName(billingCustomer.getCustomerName());
                billingRetail.setCurrency(currency);

                // Set the customer safekeeping fee
                billingRetail.setSafekeepingFee(customerSafekeepingFee);

                // Set the billing category dan billing template
                billingRetail.setBillingCategory(billingCategory);
                billingRetail.setBillingTemplate(billingTemplate);

                String number = billingNumberService.generateSingleNumber(monthNameNow, yearNow);
                billingRetail.setBillingNumber(number);
                billingRetailRepository.save(billingRetail);
                billingNumberService.saveSingleNumber(number);
                totalDataSuccess++;
            }

            log.info("Finished calculate Billing Core type 1 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Retail type 1 with total: " + totalDataSuccess;
        } catch (Exception e) {
            log.error("Error when calculate Billing Retail type 1: ", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Retail type 1: " + e.getMessage());
        }
    }

}
