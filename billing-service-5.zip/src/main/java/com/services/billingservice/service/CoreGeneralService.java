package com.services.billingservice.service;

import com.services.billingservice.dto.core.*;
import com.services.billingservice.model.BillingCore;

import java.util.List;

public interface CoreGeneralService {

    void checkingExistingBillingCore(String monthName, Integer year, String aid, String billingCategory, String billingType);

    String deleteAll();

    List<BillingCoreDTO> getAll(String categoryUpperCase, String typeUpperCase, String monthName, Integer year);
    List<BillingCoreDTO> findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndAid(String categoryUpperCase, String typeUpperCase, String monthName, Integer year, String customerCode);

    List<BillingCore> findByMonthAndYear(String month, Integer year);

    List<BillingCoreListProcessDTO> getAllListProcess();

    List<BillingCoreListProcessDTO> getAllListPendingApprove();

    String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request);

    List<BillingCoreDTO> updateAll(List<UpdateBillingCoreRequest> requestList);

    String updateApprovalStatus(UpdateApprovalStatusBillingCoreRequest request);
}
