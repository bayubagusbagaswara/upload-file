package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core9CalculateServiceImpl implements Core9CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final SkTranService skTranService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final CoreGeneralService coreGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core type 9 with request '{}'", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            int year = Integer.parseInt(monthMinus1.get("year"));

            Map<String, String> monthNow = convertDateUtil.getMonthNow();
            String monthNameNow = monthNow.get("monthName");
            int yearNow = Integer.parseInt(monthNow.get("year"));

            // Initialization variable
            Integer transactionHandlingValueFrequency;
            BigDecimal transactionHandlingAmountDue;
            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            BigDecimal subTotalAmountDue;
            BigDecimal vatAmountDue;
            BigDecimal totalAmountDue;
            Instant dateNow = Instant.now();
            int totalDataSuccess = 0;

            BigDecimal vatFee = feeParamService.getValueByName(VAT.getValue());

            // Get Billing Customer
            List<BillingCustomer> customerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            // Process calculate billing
            for (BillingCustomer billingCustomer : customerList) {
                String aid = billingCustomer.getCustomerCode();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                BigDecimal customerMinimumFee = billingCustomer.getCustomerMinimumFee();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingType = billingCustomer.getBillingType();
                String miCode = billingCustomer.getMiCode();
                BigDecimal transactionHandlingFee = billingCustomer.getCustomerTransactionHandling();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, monthName, year);

                List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(aid, monthName, year);

                transactionHandlingValueFrequency = calculateTransactionHandlingValueFrequency(aid, skTransactionList);

                transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(aid, transactionHandlingValueFrequency, transactionHandlingFee);

                safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgMonthlyList);

                safekeepingAmountDue = calculateSafekeepingAmountDue(aid, safekeepingValueFrequency, customerSafekeepingFee);

                subTotalAmountDue = calculateSubTotalAmountDue(aid, transactionHandlingAmountDue, safekeepingAmountDue);

                vatAmountDue = calculateVATAmountDue(aid, subTotalAmountDue, vatFee);

                totalAmountDue = calculateTotalAmountDue(aid, subTotalAmountDue, vatAmountDue);

                coreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                BillingCore billingCore = BillingCore.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .billingStatus(BillingStatus.Generated)
                        .customerCode(aid)
                        .customerName(billingCustomer.getCustomerName())
                        .month(monthName)
                        .year(year)
                        .billingPeriod(monthName + " " + year)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCategory)
                        .billingType(billingType)
                        .billingTemplate(billingCustomer.getBillingTemplate())
                        .investmentManagementName(billingMIDTO.getName())
                        .investmentManagementAddress1(billingMIDTO.getAddress1())
                        .investmentManagementAddress2(billingMIDTO.getAddress2())
                        .investmentManagementAddress3(billingMIDTO.getAddress3())
                        .investmentManagementAddress4(billingMIDTO.getAddress4())
                        .investmentManagementEmail(billingMIDTO.getEmail())

                        .customerMinimumFee(customerMinimumFee)
                        .customerSafekeepingFee(customerSafekeepingFee)

                        .gefuCreated(false)
                        .paid(false)
                        .account(billingCustomer.getAccount())
                        .accountName(billingCustomer.getAccountName())
                        .currency(billingCustomer.getCurrency())

                        .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                        .transactionHandlingFee(transactionHandlingFee)
                        .transactionHandlingAmountDue(transactionHandlingAmountDue)
                        .safekeepingValueFrequency(safekeepingValueFrequency)
                        .safekeepingFee(customerSafekeepingFee)
                        .safekeepingAmountDue(safekeepingAmountDue)
                        .subTotal(subTotalAmountDue)
                        .vatFee(vatFee)
                        .vatAmountDue(vatAmountDue)
                        .totalAmountDue(totalAmountDue)
                        .build();

                String number = billingNumberService.generateSingleNumber(monthNameNow, yearNow);
                billingCore.setBillingNumber(number);
                billingCoreRepository.save(billingCore);
                billingNumberService.saveSingleNumber(number);
                totalDataSuccess++;
            }

            log.info("Finished calculate Billing Core type 9 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Core type 9 with a total: " + totalDataSuccess;
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 9: {}", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 9: " + e.getMessage());
        }
    }


    private static Integer calculateTransactionHandlingValueFrequency(String aid, List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 9] Total transaction handling Aid '{}' is '{}'", aid, totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(String aid, Integer transactionHandlingValueFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = transactionHandlingFee.multiply(new BigDecimal(transactionHandlingValueFrequency).setScale(0, RoundingMode.HALF_UP));
        log.info("[Core Type 9] Transaction handling amount due Aid '{}' is '{}'", aid, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgMonthly> sfValRgMonthlyList) {
        List<SfValRgMonthly> latestEntries = sfValRgMonthlyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgMonthlyList.stream()
                        .map(SfValRgMonthly::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgMonthly latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}'", latestEntry.getDate(), latestEntry.getSecurityName());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgMonthly::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 9] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, BigDecimal safekeepingValueFrequency, BigDecimal customerSafekeepingFee) {
        // customerSafekeepingFee perlu dibagi 100 lagi
        BigDecimal safeKeepingAfterDivide100Percentage = customerSafekeepingFee
                .divide(new BigDecimal(100), 4, RoundingMode.HALF_UP);

        BigDecimal safekeepingAmountDue = safekeepingValueFrequency
                .multiply(safeKeepingAfterDivide100Percentage)
                .divide(new BigDecimal(12), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 9] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateSubTotalAmountDue(String aid, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotalAmountDue = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Core Type 9] Sub total amount due Aid '{}' is '{}'", aid, subTotalAmountDue);
        return subTotalAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotalAmountDue.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 9] VAT amount due Aid '{}' is '{}'", aid, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(String aid, BigDecimal subTotalAmountDue, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotalAmountDue.add(vatAmountDue);
        log.info("[Core Type 9] Total amount due '{}' is '{}'", aid, totalAmountDue);
        return totalAmountDue;
    }

}
