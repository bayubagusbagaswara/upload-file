package com.services.billingservice.model;

import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "bill_template")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingTemplate extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bill_template_name")
    private String templateName; // TEMPLATE_1

    @Column(name = "bill_template_category")
    private String category;

    @Column(name = "bill_template_type")
    private String type; // Type_1

    @Column(name = "currency")
    private String currency;

    @Column(name = "sub_code")
    private String subCode; // EB or ITAMA

    @Column(name = "bill_template_desc")
    private String desc; // Template For Core Type 1


}
