package com.services.billingservice.dto.connectionparameter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateBillingGefuDTO {

    String category;
    String userId;
    String month;
    Integer year;
    List<CustomerCodeDTO> customers;
}

