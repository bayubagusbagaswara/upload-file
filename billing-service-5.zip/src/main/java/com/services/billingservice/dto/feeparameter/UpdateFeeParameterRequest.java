package com.services.billingservice.dto.feeparameter;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateFeeParameterRequest extends InputIdentifierRequest {

    private Long id;

    /* fee code cannot be updated */
    private String feeCode;

    /* fee name cannot be updated */
    private String feeName;

    private String feeDescription;

    private String feeValue;

}
