package com.services.billingservice.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingTemplateResponse {
    private long id;

    private String billingSellingAgent;

    private String billingSellingAgentEmail;

    private String billingSellingAgentDesc;
}
