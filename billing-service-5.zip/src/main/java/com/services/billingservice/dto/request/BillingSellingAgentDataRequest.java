package com.services.billingservice.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingSellingAgentDataRequest {

    private String billingSellingAgentCode;

    private String billingSellingAgentName;

    private String billingSellingAgentGl;

    private String billingSellingAgentGlname;

    private String billingSellingAgentAccount;

    private String billingSellingAgentAccountName;

    private String billingSellingAgentEmail;

    private String billingSellingAgentAlamat;

    private String billingSellingAgentDesc;
}
