package com.services.billingservice.dto.feeparameter;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateFeeParameterRequest extends InputIdentifierRequest {

    @NotBlank(message = "Fee Code cannot be empty")
    private String feeCode;

    @NotBlank(message = "Fee Name cannot be empty")
    private String feeName;

    private String feeDescription;

    @NotBlank(message = "Fee Value cannot be empty")
    private String feeValue;

}
