package com.services.billingservice.dto.mi;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateInvestmentManagementListRequest extends InputIdentifierRequest {

    private List<CreateInvestmentManagementDataListRequest> createInvestmentManagementDataListRequests;

}
