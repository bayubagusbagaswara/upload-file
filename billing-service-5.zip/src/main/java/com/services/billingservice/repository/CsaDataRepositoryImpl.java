package com.services.billingservice.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
@Slf4j
public class CsaDataRepositoryImpl implements CsaDataRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void executeQuerySpRekapAccountBalance() {
        String nativeQuery = "EXEC sp_rekap_account_balance();";
        try {
            entityManager.createNativeQuery(nativeQuery);// Execute update for data manipulation
            log.info("Stored procedure executed successfully (no result set expected)");
        } catch (Exception e) {
            // Handle potential exceptions during query execution
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }

    @Override
    public void executeQuerySpRekapRekapDataTransaksi() {
        String nativeQuery = "EXEC sp_rekap_data_transaksi();";
        try {
            entityManager.createNativeQuery(nativeQuery);// Execute update for data manipulation
            log.info("Stored procedure executed successfully (no result set expected)");
        } catch (Exception e) {
            // Handle potential exceptions during query execution
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }
}
