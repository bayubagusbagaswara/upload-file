package com.services.billingservice.dto.fund;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;

/**
 * data harus sama dengan dto (yg ditampilkan di depan)
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateBillingFundRequest extends BillingFundBaseDTO {

    private Long id;
    private BigDecimal customerFee;
    private BigDecimal accrualCustodialFee;
    private Integer bis4TransactionValueFrequency;
    private BigDecimal bis4TransactionFee;
    private BigDecimal bis4TransactionAmountDue;
    private BigDecimal subTotal;
    private BigDecimal vatFee;
    private BigDecimal vatAmountDue;
    private Integer kseiTransactionValueFrequency;
    private BigDecimal kseiTransactionFee;
    private BigDecimal kseiTransactionAmountDue;
    private BigDecimal totalAmountDue;
}
