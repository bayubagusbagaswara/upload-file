package com.services.billingservice.dto.exchangerate;

public class ExchangeRateApproveRequest {
}
