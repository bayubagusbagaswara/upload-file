package com.services.billingservice.dto.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingSecurityRequest {

    private Long id;

    private String code;

    private String group;

    private String currency;

    private String issuerName;

    private String name;

}
