package com.services.billingservice.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingFeeScheduleResponse {
    private Long id;

    private double feeMin;

    private double feeMax;

    private double feeAmount;
}
