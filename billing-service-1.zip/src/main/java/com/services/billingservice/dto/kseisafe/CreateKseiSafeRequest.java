package com.services.billingservice.dto.kseisafe;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateKseiSafeRequest {

    private String createdDate;

    private String kseiSafeCode;

    private String feeDescription;

    private String amountFee;
}
