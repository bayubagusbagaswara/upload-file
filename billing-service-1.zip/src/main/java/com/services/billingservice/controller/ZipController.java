package com.services.billingservice.controller;

import com.services.billingservice.dto.ZipRequest;
import com.services.billingservice.enums.BillingCategory;
import com.services.billingservice.service.ZipService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;
import java.util.zip.ZipOutputStream;

@RestController
@RequestMapping(path = "/api/download-pdf")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class ZipController {

    @Value("${base.path.billing.fund}")
    private String basePathBillingFund;

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.retail}")
    private String basePathBillingRetail;


    private static final String DELIMITER = "/";

    private final ZipService zipService;
    private final ConvertDateUtil convertDateUtil;

    @GetMapping("/zip")
    public ResponseEntity<InputStreamResource> downloadPdfZip(@RequestParam("category") String category,
                                                              @RequestParam("monthYear") String monthYear,
                                                              @RequestParam("investmentManagementName") String investmentManagementName) {
        Map<String, String> stringStringMap = convertDateUtil.extractMonthYearInformation(monthYear);
        String monthValue = stringStringMap.get("monthValue");
        String year = stringStringMap.get("year");
        String categoryUppercase = category.toUpperCase();
        String investmentManagementNameResult = investmentManagementName;
        String folderPath;
        String zipFileName;
        String basePathBilling;

        if (BillingCategory.FUND.name().equalsIgnoreCase(category)) {
            basePathBilling = basePathBillingFund;
        } else if (BillingCategory.CORE.name().equalsIgnoreCase(category)) {
            basePathBilling = basePathBillingCore;
        } else if (BillingCategory.RETAIL.name().equalsIgnoreCase(category)) {
            basePathBilling = basePathBillingRetail;
        } else {
            System.out.println("Category is not found");
            basePathBilling = "";
        }

        if (investmentManagementNameResult.isEmpty()) {
            folderPath = basePathBilling + year + monthValue;
            zipFileName = category + "_" + year + monthValue + ".zip";
        } else {
            folderPath = basePathBilling + year + monthValue + DELIMITER + investmentManagementNameResult;
            zipFileName = categoryUppercase + "_" + year + monthValue + "_" + investmentManagementNameResult + ".zip";
        }

        try {
            Path folder = Paths.get(folderPath);
            if (!Files.exists(folder) || !Files.isDirectory(folder)) {
                return ResponseEntity.badRequest().body(null);
            }
            zipFileName = zipFileName.replace(" ", "_");

            Path zipFilePath = Files.createTempFile("temp", ".zip");

            try (FileOutputStream fos = new FileOutputStream(zipFilePath.toFile()); ZipOutputStream zos = new ZipOutputStream(fos)) {
                zipService.zipFolder(folder.toFile(), folder.getFileName().toString(), zos);
            }

            InputStreamResource resource = new InputStreamResource(new FileInputStream(zipFilePath.toFile()));
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + zipFileName);

            return ResponseEntity.ok()
                    .headers(headers)
                    .contentLength(Files.size(zipFilePath))
                    .contentType(MediaType.parseMediaType("application/zip"))
                    .body(resource);
        } catch (IOException e) {
            return ResponseEntity.status(500).body(null);
        }
    }

}
