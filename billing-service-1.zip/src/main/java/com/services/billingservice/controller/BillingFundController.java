package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.*;
import com.services.billingservice.service.FundCalculateService;
import com.services.billingservice.service.FundGeneralService;
import com.services.billingservice.service.FundGeneratePDFService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(path = "/api/billing/fund")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingFundController {

    private final FundCalculateService fundCalculateService;
    private final FundGeneratePDFService fundGeneratePDFService;
    private final FundGeneralService fundGeneralService;

    @PostMapping(path = "/calculate")
    public ResponseEntity<ResponseDTO<String>> calculate(@RequestBody List<FeeReportRequest> reportRequests,
                                                         @RequestParam("monthYear") String monthYear) {

        String message = fundCalculateService.calculate(reportRequests, monthYear);

        ResponseDTO<String> responseDTO = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(message)
                .build();

        return ResponseEntity.ok().body(responseDTO);
    }


    @GetMapping(path = "/generate-pdf")
    public ResponseEntity<ResponseDTO<String>> generatePDF(@RequestParam("category") String category,
                                                           @RequestParam("monthYear") String monthYear) {

        String statusGenerate = fundGeneratePDFService.generatePDF(category, monthYear);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(statusGenerate)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingFundDTO>>> getAll() {
        List<BillingFundDTO> billingFundDTOList = fundGeneratePDFService.getAll();

        ResponseDTO<List<BillingFundDTO>> response = ResponseDTO.<List<BillingFundDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingFundDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDTO<List<BillingFundDTO>>> getAllByPeriod(@RequestParam("month") String month,
                                                                            @RequestParam("year") Integer year) {
        List<BillingFundDTO> billingFundDTOList = fundGeneratePDFService.findByMonthAndYear(month, year);

        ResponseDTO<List<BillingFundDTO>> response = ResponseDTO.<List<BillingFundDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingFundDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period/type")
    public ResponseEntity<ResponseDTO<List<BillingFundDTO>>> getAllByPeriodType(@RequestParam("month") String month,
                                                                            @RequestParam("year") Integer year,
                                                                            @RequestParam("category") String category,
                                                                            @RequestParam("type") String type) {
        List<BillingFundDTO> billingFundDTOList = fundGeneratePDFService.findByMonthAndYearAndBillingCategoryAndBillingType(month, year, category, type);

        ResponseDTO<List<BillingFundDTO>> response = ResponseDTO.<List<BillingFundDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingFundDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list/process")
    public ResponseEntity<ResponseDTO<List<BillingFundListProcessDTO>>> getAllListProcess() {
        List<BillingFundListProcessDTO> billingFundDTOList = fundGeneratePDFService.getAllListProcess();

        ResponseDTO<List<BillingFundListProcessDTO>> response = ResponseDTO.<List<BillingFundListProcessDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingFundDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list/pending-approve")
    public ResponseEntity<ResponseDTO<List<BillingFundListProcessDTO>>> getAllListPendingApprove() {
        List<BillingFundListProcessDTO> billingFundDTOList = fundGeneratePDFService.getAllListPendingApprove();

        ResponseDTO<List<BillingFundListProcessDTO>> response = ResponseDTO.<List<BillingFundListProcessDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingFundDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = fundGeneratePDFService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PutMapping(path = "/approval-status")
    public ResponseEntity<ResponseDTO<String>> updateApprovalStatus(@RequestBody UpdateApprovalStatusBillingFundRequest request) {
        String status = fundGeneralService.updateApprovalStatus(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping(path = "/category-type")
    public ResponseEntity<ResponseDTO<String>> deleteByCategoryAndType(@RequestBody CoreCalculateRequest request) {

        String status = fundGeneralService.deleteByCategoryAndTypeAndMonthYear(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<List<BillingFundDTO>>> updateAll(@RequestBody List<UpdateBillingFundRequest> requestList) {
        List<BillingFundDTO> billingFundDTOList = fundGeneralService.updateAll(requestList);

        ResponseDTO<List<BillingFundDTO>> response = ResponseDTO.<List<BillingFundDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingFundDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
