package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.model.SfValCrowdFunding;
import com.services.billingservice.service.SfValCrowdFundingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(path = "/api/crowd-funding")
@RequiredArgsConstructor
public class SfValCrowdFundingController {

    @Value("${file.path.crowd.funding}")
    private String filePath;

    private final SfValCrowdFundingService sfValCrowdFundingService;

    // read and insert
    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDTO<String>> readAndInsert(@RequestParam("monthYear") String monthYear) {
        log.info("Month Year: {}", monthYear);
        String status = sfValCrowdFundingService.readAndInsertToDB(filePath, monthYear);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    // get all
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SfValCrowdFunding>>> getAll() {
        List<SfValCrowdFunding> sfValCrowdFundingList = sfValCrowdFundingService.getAll();

        ResponseDTO<List<SfValCrowdFunding>> response = ResponseDTO.<List<SfValCrowdFunding>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValCrowdFundingList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = sfValCrowdFundingService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }
}
