package com.services.billingservice.utils;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.CTText;

import java.io.*;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class GefuUtil {

    private static Logger _logger = LogManager.getLogger(GefuUtil.class.getName());

    private static DateFormat DF1 = new SimpleDateFormat("yyyyMMdd");
    private static DateFormat DF2 = new SimpleDateFormat("ddMMyy");
    private static DateFormat DF3 = new SimpleDateFormat("dd MMMM yyyy");
    private static DateFormat MF = new SimpleDateFormat("MM");
    private static DateFormat YF = new SimpleDateFormat("yyyy");


    public void createGefuFile(Date paymentDate) {

        final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
                "yyyyMMdd");
        String gefuTransactionName = "CSA_GEFU_Sale_Trx_"
                + DATE_FORMAT.format(paymentDate) + ".hit";

    }

    public static long getMilis(Date date) {
        Calendar calender = Calendar.getInstance();
        calender.setTime(date);

        return calender.getTimeInMillis();
    }
}
