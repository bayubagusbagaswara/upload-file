package com.services.billingservice.mapper;

import com.services.billingservice.dto.assettransfercustomer.AssetTransferCustomerDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingNasabahTransferAsset;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AssetTransferCustomer extends BaseMapper<BillingNasabahTransferAsset, AssetTransferCustomerDTO> {

    private final ConvertDateUtil convertDateUtil;

    public AssetTransferCustomer(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingNasabahTransferAsset, AssetTransferCustomerDTO> getPropertyMap() {
        return new PropertyMap<BillingNasabahTransferAsset, AssetTransferCustomerDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingNasabahTransferAsset mapToEntity(AssetTransferCustomerDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public AssetTransferCustomerDTO mapToDto(BillingNasabahTransferAsset entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<AssetTransferCustomerDTO> mapToDTOList(List<BillingNasabahTransferAsset> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public AssetTransferCustomerDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public AssetTransferCustomerDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingNasabahTransferAsset createEntity(AssetTransferCustomerDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingNasabahTransferAsset updateEntity(BillingNasabahTransferAsset updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(AssetTransferCustomerDTO sourceDto, BillingNasabahTransferAsset targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingNasabahTransferAsset> getEntityClass() {
        return BillingNasabahTransferAsset.class;
    }

    @Override
    protected Class<AssetTransferCustomerDTO> getDtoClass() {
        return AssetTransferCustomerDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingNasabahTransferAsset entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
