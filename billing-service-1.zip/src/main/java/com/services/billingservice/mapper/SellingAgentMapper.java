package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.SellingAgentDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingSellingAgentData;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SellingAgentMapper extends BaseMapper<BillingSellingAgentData, SellingAgentDTO> {

    private final ConvertDateUtil convertDateUtil;

    public SellingAgentMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingSellingAgentData, SellingAgentDTO> getPropertyMap() {
        return new PropertyMap<BillingSellingAgentData, SellingAgentDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingSellingAgentData mapToEntity(SellingAgentDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public SellingAgentDTO mapToDto(BillingSellingAgentData entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<SellingAgentDTO> mapToDTOList(List<BillingSellingAgentData> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public SellingAgentDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public SellingAgentDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingSellingAgentData createEntity(SellingAgentDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingSellingAgentData updateEntity(BillingSellingAgentData updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(SellingAgentDTO sourceDto, BillingSellingAgentData targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingSellingAgentData> getEntityClass() {
        return BillingSellingAgentData.class;
    }

    @Override
    protected Class<SellingAgentDTO> getDtoClass() {
        return SellingAgentDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingSellingAgentData entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }
}
