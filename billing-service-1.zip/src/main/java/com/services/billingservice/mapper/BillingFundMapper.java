package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BillingFundMapper extends BaseMapper<BillingFund, BillingFundDTO> {

    private final ConvertDateUtil convertDateUtil;

    public BillingFundMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingFund, BillingFundDTO> getPropertyMap() {
        return new PropertyMap<BillingFund, BillingFundDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingFund mapToEntity(BillingFundDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public BillingFundDTO mapToDto(BillingFund entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<BillingFundDTO> mapToDTOList(List<BillingFund> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public BillingFundDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public BillingFundDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingFund createEntity(BillingFundDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingFund updateEntity(BillingFund updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(BillingFundDTO sourceDto, BillingFund targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingFund> getEntityClass() {
        return BillingFund.class;
    }

    @Override
    protected Class<BillingFundDTO> getDtoClass() {
        return BillingFundDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingFund entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }
}
