package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeschedule.FeeScheduleDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingFeeSchedule;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class FeeScheduleMapper extends BaseMapper<BillingFeeSchedule, FeeScheduleDTO> {

    private final ConvertDateUtil convertDateUtil;

    public FeeScheduleMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingFeeSchedule, FeeScheduleDTO> getPropertyMap() {
        return new PropertyMap<BillingFeeSchedule, FeeScheduleDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingFeeSchedule mapToEntity(FeeScheduleDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public FeeScheduleDTO mapToDto(BillingFeeSchedule entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<FeeScheduleDTO> mapToDTOList(List<BillingFeeSchedule> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public FeeScheduleDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public FeeScheduleDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingFeeSchedule createEntity(FeeScheduleDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingFeeSchedule updateEntity(BillingFeeSchedule updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(FeeScheduleDTO sourceDto, BillingFeeSchedule targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingFeeSchedule> getEntityClass() {
        return BillingFeeSchedule.class;
    }

    @Override
    protected Class<FeeScheduleDTO> getDtoClass() {
        return FeeScheduleDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingFeeSchedule entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
