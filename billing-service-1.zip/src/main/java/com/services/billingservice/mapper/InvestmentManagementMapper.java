package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingMI;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class InvestmentManagementMapper extends BaseMapper<BillingMI, InvestmentManagementDTO> {

    private final ConvertDateUtil convertDateUtil;

    public InvestmentManagementMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingMI, InvestmentManagementDTO> getPropertyMap() {
        return new PropertyMap<BillingMI, InvestmentManagementDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingMI mapToEntity(InvestmentManagementDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public InvestmentManagementDTO mapToDto(BillingMI entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<InvestmentManagementDTO> mapToDTOList(List<BillingMI> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public InvestmentManagementDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public InvestmentManagementDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingMI createEntity(InvestmentManagementDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingMI updateEntity(BillingMI updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(InvestmentManagementDTO sourceDto, BillingMI targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingMI> getEntityClass() {
        return BillingMI.class;
    }

    @Override
    protected Class<InvestmentManagementDTO> getDtoClass() {
        return InvestmentManagementDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingMI entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }

}
