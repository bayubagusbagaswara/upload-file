package com.services.billingservice.mapper;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BillingRetailMapper extends BaseMapper<BillingRetail, BillingRetailDTO> {

    private final ConvertDateUtil convertDateUtil;

    public BillingRetailMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingRetail, BillingRetailDTO> getPropertyMap() {
        return new PropertyMap<BillingRetail, BillingRetailDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingRetail mapToEntity(BillingRetailDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public BillingRetailDTO mapToDto(BillingRetail entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<BillingRetailDTO> mapToDTOList(List<BillingRetail> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public BillingRetailDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public BillingRetailDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingRetail createEntity(BillingRetailDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingRetail updateEntity(BillingRetail updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(BillingRetailDTO sourceDto, BillingRetail targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingRetail> getEntityClass() {
        return BillingRetail.class;
    }

    @Override
    protected Class<BillingRetailDTO> getDtoClass() {
        return BillingRetailDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingRetail entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }
}
