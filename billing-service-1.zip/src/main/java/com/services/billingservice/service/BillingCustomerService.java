package com.services.billingservice.service;

import com.services.billingservice.dto.customer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.model.BillingCustomer;

import java.util.List;

public interface BillingCustomerService {

    boolean isCodeAlreadyExists(String code);

    List<CustomerDTO> getAll();

    List<BillingCustomer> getAllByBillingCategoryAndBillingType(String billingCategory, String billingType);

    String deleteAll();

    CustomerResponse createSingleData(CreateCustomerRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse createMultipleData(CustomerListRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse createSingleApprove(CustomerApproveRequest createCustomerApproveRequest);

    CustomerResponse updateSingleData(UpdateCustomerRequest request, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse updateMultipleData(CustomerListRequest updateCustomerListRequest, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse updateSingleApprove(CustomerApproveRequest updateCustomerApproveRequest);

    CustomerResponse deleteSingleData(DeleteCustomerRequest deleteCustomerRequest, BillingDataChangeDTO dataChangeDTO);

    CustomerResponse deleteSingleApprove(CustomerApproveRequest deleteCustomerApproveRequest);
}
