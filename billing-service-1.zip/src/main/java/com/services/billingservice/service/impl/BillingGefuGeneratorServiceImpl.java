package com.services.billingservice.service.impl;

import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingCategory;
import com.services.billingservice.enums.GefuTransactionType;
import com.services.billingservice.model.*;
import com.services.billingservice.repository.*;
import com.services.billingservice.service.BillingGefuGeneratorService;
import com.services.billingservice.utils.GefuUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static com.services.billingservice.enums.BillingType.*;
import static com.services.billingservice.enums.BillingTemplate.*;
import static com.services.billingservice.enums.BillingCategory.*;


@Slf4j
@Service
@RequiredArgsConstructor
public class BillingGefuGeneratorServiceImpl implements BillingGefuGeneratorService {

    private final BillingCoreRepository billingCoreRepository;
    private final BillingFundRepository billingFundRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingGefuHistoryRepository billingGefuGeneratorRepository;
    private final BillingGefuDetailRepository billingGefuDetailRepository;
    private final BillingGlCreditRepository billingGlCreditRepository;
    private final BillingCustomerRepository billingCustomerRepository;

    private static DateFormat DF1 = new SimpleDateFormat("yyyyMMdd");
    private static DateFormat DF2 = new SimpleDateFormat("ddMMyy");
    private static DateFormat DF3 = new SimpleDateFormat("dd MMMM yyyy");

    @Override
    public void checkExistGefuFileName(String fileName) {

    }

    @Override
    public void deleteExistGefuFile(String fileName) {

    }

    @Override
    public String createGefu(String category, String month, int year, String customerCode, String userId) {
        String successCode = "00";
        final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(
                "yyyyMMdd");

        long idBilling = 0;
        String template = null;
        String type = null;

        if (CORE.getValue().equalsIgnoreCase(category)) {
            BillingCore billingCores = billingCoreRepository.
                    findByCustomerCodeAndMonthAndYearAndApprovalStatus(
                            month, year, customerCode, ApprovalStatus.Approved.getStatus());
            if (billingCores != null) {
                idBilling = billingCores.getId();
                type = billingCores.getBillingType();
                template = billingCores.getBillingTemplate();
            }
        } else if (FUND.getValue().equalsIgnoreCase(category)) {
            BillingFund billingFund = billingFundRepository.
                    findByCustomerCodeAndMonthAndYearAndApprovalStatus(
                            customerCode, month, year, ApprovalStatus.Approved.getStatus());
            if (billingFund != null) {
                idBilling = billingFund.getId();
                type = billingFund.getBillingType();
                template = billingFund.getBillingTemplate();
            }
        } else if (RETAIL.getValue().equalsIgnoreCase(category)) {
            BillingRetail billingRetail = billingRetailRepository.
                    findByCustomerCodeAndMonthAndYearAndApprovalStatus(
                            customerCode, month, year, ApprovalStatus.Approved.getStatus());
            if (billingRetail != null) {
                idBilling = billingRetail.getId();
                type = billingRetail.getBillingType();
                template = billingRetail.getBillingTemplate();
            }
        }


        if (template != null) {

            String gefufileName = "CSA_GEFU_BILLING_" + month +
                    String.valueOf(year) + "_" + customerCode + "_"
                    + DATE_FORMAT.format(new Date()) + ".hit";

            BillingGefuProcessHistory history = billingGefuGeneratorRepository.
                    findByFileName(gefufileName);


            if (history == null) {
                history = new BillingGefuProcessHistory();
                history.setProcessDate(new Date());
                history.setInputerId(userId);
                history.setInputDate(new Date());
                history.setFileName(gefufileName);
                history.setCategory(BillingCategory.CORE.getValue());
                history.setType(type);
                history.setTemplate(template);
                history.setIdBilling(idBilling);

                billingGefuGeneratorRepository.save(history);


                if (CORE.getValue().equalsIgnoreCase(category)) {
                    gefuCoreGenerator(history, template);
                }


            }


        }

        return successCode;
    }

    @Override
    public void approveAndSendGefu(long gefuProcessHistory, String approverId) {

    }

    @Override
    public void rejectGefu(long gefuProcessHistory, String approverId) {

    }

    @Override
    public void readGefuResponse(List<String> fileNames) {

    }

    @Override
    public String gefuCoreFileGeneratorDirect(BillingGefuProcessHistory gefuHistory, BillingCore billing) {

        String settleDateStr1 = DF1.format(gefuHistory.getProcessDate());
        String settleDateStr2 = DF2.format(gefuHistory.getProcessDate());

        int totalCredit = 0;
        int totalDebit = 0;

        double amountTotalCredit = 0;
        double amountTotalDebit = 0;

        String glNo = "";
        String costCenter = "";
        String trxType = "";
        double amount = 0;

        String txnCode = "";
        String glName = "";
        String trxCodeType = "";
        String typeTxn = "";
        String lobCode = "";

        List<BillingGefuProcessDetail> listGefuDetail = billingGefuDetailRepository.findAllByGefuProcessHistory(gefuHistory.getId());

        StringBuilder sb = new StringBuilder();
        sb.append("1:" + settleDateStr1).append("\r\n");

        for (BillingGefuProcessDetail gefuProcessDetail : listGefuDetail) {

            glNo = gefuProcessDetail.getGLNo().trim();
            costCenter = gefuProcessDetail.getCostCenter().trim();
            amount = gefuProcessDetail.getTotalAmount();

            String result = String.format("%.2f", amount);
            double resultDouble = Double.valueOf(result);

            trxType = gefuProcessDetail.getGefuTransactionType().toString();

            if (trxType.equalsIgnoreCase("Debit")) {
                trxCodeType = "D";
            } else if (trxType.equalsIgnoreCase("Credit")) {
                trxCodeType = "C";
            }

            glName = gefuProcessDetail.getGLName();

            if (glName.contains("Giro") && trxCodeType.equalsIgnoreCase("D")) {
                txnCode = "1060";
            } else if (glName.contains("Custodian")
                    && trxCodeType.equalsIgnoreCase("C")) {
                txnCode = "1460";
            } else if (glName.contains("Custodian")
                    && trxCodeType.equalsIgnoreCase("D")) {
                txnCode = "1060";
            } else if (glName.contains("Titipan")
                    && trxCodeType.equalsIgnoreCase("C")) {
                txnCode = "1460";

            } else if (glName.contains("handling")
                    && trxCodeType.equalsIgnoreCase("C")) {
                txnCode = "1460";
            } else if (glName.contains("PPN")
                    && trxCodeType.equalsIgnoreCase("C")) {
                txnCode = "1460";
            }

            if (glName.contains("Nasabah")) {
                typeTxn = "1";
            } else {
                typeTxn = "3";
            }

            if (glNo.equalsIgnoreCase("111001")) {
                lobCode = "71";
            } else {
                lobCode = "0";
            }

//            String

            sb.append(
                    "2:" + typeTxn + ":" + glNo + ":" + costCenter + ":"
                            + lobCode + ":GFO923400:0:" + txnCode + ":0:"
                            + settleDateStr1 + ":" + trxCodeType + ":"
                            + settleDateStr1 + ":IDR:"
                            + (Math.round(resultDouble * 100)) + ":"
                            + Math.round(resultDouble * 100) + ":" + "1:"
                            + gefuProcessDetail.getReference() + ":1:"
                            + trxCodeType + " " + glNo + " on "
                            + settleDateStr2 + " amt "
                            + Math.round(resultDouble * 100)).append("\r\n");

            if (gefuProcessDetail.getGefuTransactionType().equals(
                    GefuTransactionType.Credit)) {
                totalCredit++;
                amountTotalCredit += Math.round((resultDouble * 100));
            } else {
                totalDebit++;
                amountTotalDebit += Math.round((resultDouble * 100));
            }
        }

        sb.append(
                "3:" + totalDebit + ":"
                        + String.format("%.0f", amountTotalDebit) + ":"
                        + totalCredit + ":"
                        + String.format("%.0f", amountTotalCredit)).append("\r");

        System.out.println(sb.toString());
        return sb.toString();
    }

    @Override
    public void gefuCoreGenerator(BillingGefuProcessHistory gefuHistory, String billTemplate) {
        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        billingGefuGeneratorRepository.save(gfProcessHistory);

        if (TYPE_1.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {

            if (FUND_TEMPLATE.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuFundGeneratorCASA(gefuHistory);
            } else if (RETAIL_TEMPLATE_1_IDR.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorDirectIDR(gefuHistory);
            } else if (RETAIL_TEMPLATE_1_USD.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorDirectUSD(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_2.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {

            if (RETAIL_TEMPLATE_2_IDR.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorCASAIDR(gefuHistory);
            } else if (RETAIL_TEMPLATE_2_USD.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorCASAUSD(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_3.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {

            if (RETAIL_TEMPLATE_3_IDR.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorCASAIDR(gefuHistory);
            } else if (RETAIL_TEMPLATE_3_USD.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorCASAUSD(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_4.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {

            if (RETAIL_TEMPLATE_4_IDR.getValue().equalsIgnoreCase(billTemplate)) {
                //TODO create gefuRetaileneratorCASAIDR(gefuHistory);
            } else if (CORE_TEMPLATE_5.getValue().equalsIgnoreCase(billTemplate)) {
                gefuCoreGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_5.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {

            if (CORE_TEMPLATE_1.getValue().equalsIgnoreCase(billTemplate)) {
                gefuCoreGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }

        } else if (TYPE_6.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {
            if (CORE_TEMPLATE_1.getValue().equalsIgnoreCase(billTemplate)) {
                gefuCoreGeneratorDirect(gefuHistory);
            } else {
                gefuCoreGeneratorCASA(gefuHistory);
            }
        } else if (TYPE_7.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        } else if (TYPE_8.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        } else if (TYPE_9.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        } else if (TYPE_10.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {
            gefuCoreGeneratorDirect(gefuHistory);
        } else if (TYPE_11.getValue().equalsIgnoreCase(gfProcessHistory.getType())) {
            gefuCoreGeneratorCASA(gefuHistory);
        }
    }

    @Override
    public void gefuCoreGeneratorDirect(BillingGefuProcessHistory gefuHistory) {
        BillingCore billing =
                billingCoreRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();


        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuGeneratorRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);


        // GL Nasabah
        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(billingCustomer.getDebitTransfer());
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glDebit);

        BillingGlCredit glCredit =
                billingGlCreditRepository.findByGlBillingTemplate(gefuHistory.getTemplate());

        // GL HAK Operasional Credit
        BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
        glCreditDetail
                .setGefuProcessHistory(gefuHistory);
        glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
        glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
        glCreditDetail.setCostCenter("9207");
        glCreditDetail.setFileName(gefuHistory
                .getFileName());
        glCreditDetail
                .setGefuTransactionType(GefuTransactionType.Credit);
        glCreditDetail.setTotalAmount(settleAmount);
        glCreditDetail.setInputerId(gefuHistory.getInputerId());
        glCreditDetail.setInputDate(new java.util.Date());
        glCreditDetail.setReference("C " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glCreditDetail);
    }

    @Override
    public boolean sendGefu(BillingGefuProcessHistory gefuHistory) {
        return false;
    }

    @Override
    public void gefuCoreGeneratorCASA(BillingGefuProcessHistory gefuHistory) {

        BillingCore billing =
                billingCoreRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuGeneratorRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL / Account Nasabah
        String costCenter = billingCustomer.getDebitTransfer() != null ?
                billingCustomer.getDebitTransfer() : "9207";

        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(costCenter);
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D 0" + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glDebit);

        // GL Dana Custodian Credit

        List<BillingGlCredit> glCreditList =
                billingGlCreditRepository.findAllByGlBillingTemplate(gefuHistory.getTemplate());

        for (BillingGlCredit glCredit : glCreditList) {

            double amount = 0;
            if (glCredit.getGlCreditName().trim().equalsIgnoreCase("GL Dana Custodian")) {
                amount = billing.getTotalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Transaction Handling")) {
                amount = billing.getTransactionHandlingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Safekeeping Fee")) {
                amount = billing.getSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("VAT")) {
                amount = billing.getVatAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Safekeeping Fee + KSEI Fee")) {
                amount = billing.getSafekeepingAmountDue().doubleValue() +
                        billing.getKseiSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("KSEI Fee (Transaction)")) {
                amount = billing.getKseiTransactionAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("BI-SSSS( Transaction )+ KSEI Fee ( Transaction )")) {
                amount = billing.getBis4TransactionAmountDue().doubleValue() +
                        billing.getKseiTransactionAmountDue().doubleValue();
            }


            BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
            glCreditDetail
                    .setGefuProcessHistory(gefuHistory);
            glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
            glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
            glCreditDetail.setCostCenter("9207");
            glCreditDetail.setFileName(gefuHistory
                    .getFileName());

            String initialType = "C ";
            if (glCredit.getJurnalType().equalsIgnoreCase(GefuTransactionType.Credit.name())) {
                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Credit);
            } else {
                initialType = "D ";

                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Debit);
            }


            glCreditDetail.setTotalAmount(amount);
            glCreditDetail.setInputerId(gefuHistory.getInputerId());
            glCreditDetail.setInputDate(new java.util.Date());
            glCreditDetail.setReference(initialType + glCredit.getJurnalSequence() + billing.getBillingNumber() + " " + billing.getCustomerCode());
            billingGefuDetailRepository.save(glCreditDetail);

        }

    }

    @Override
    public void gefuRetailGeneratorDirect(BillingGefuProcessHistory gefuHistory) {
        BillingRetail billing =
                billingRetailRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuGeneratorRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL Nasabah
        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(billingCustomer.getDebitTransfer());
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glDebit);

        BillingGlCredit glCredit =
                billingGlCreditRepository.findByGlBillingTemplate(gefuHistory.getTemplate());

        // GL HAK Operasional Credit
        BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
        glCreditDetail
                .setGefuProcessHistory(gefuHistory);
        glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
        glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
        glCreditDetail.setCostCenter("9207");
        glCreditDetail.setFileName(gefuHistory
                .getFileName());
        glCreditDetail
                .setGefuTransactionType(GefuTransactionType.Credit);
        glCreditDetail.setTotalAmount(settleAmount);
        glCreditDetail.setInputerId(gefuHistory.getInputerId());
        glCreditDetail.setInputDate(new java.util.Date());
        glCreditDetail.setReference("C " + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glCreditDetail);
    }


    @Override
    public void gefuRetailGeneratorCASA(BillingGefuProcessHistory gefuHistory) {

        BillingRetail billing =
                billingRetailRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuGeneratorRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL / Account Nasabah
        String costCenter = billingCustomer.getDebitTransfer() != null ?
                billingCustomer.getDebitTransfer() : "9207";

        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(costCenter);
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D 0" + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glDebit);

        // GL Dana Custodian Credit

        List<BillingGlCredit> glCreditList =
                billingGlCreditRepository.findAllByGlBillingTemplate(gefuHistory.getTemplate());

        for (BillingGlCredit glCredit : glCreditList) {

            double amount = 0;
            if (glCredit.getGlCreditName().trim().equalsIgnoreCase("GL Dana Custodian")) {
                amount = billing.getTotalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Biaya Penyimpanan")) {
                amount = billing.getSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Biaya Penyelesaian Transaksi + Biaya Pihak ketiga")) {
                amount = billing.getTransactionSettlementAmountDue().doubleValue()
                        + billing.getThirdPartyAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("VAT")) {
                amount = billing.getVatAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Transaction Handling + Transaction Handling Internal")) {
                amount = billing.getTransactionHandlingAmountDue().doubleValue() +
                        billing.getTransactionHandlingInternalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Safekeeping Fee")) {
                amount = billing.getSafekeepingAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Biaya Transfer")) {
                amount = billing.getTransferAmountDue().doubleValue();
            }


            BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
            glCreditDetail
                    .setGefuProcessHistory(gefuHistory);
            glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
            glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
            glCreditDetail.setCostCenter("9207");
            glCreditDetail.setFileName(gefuHistory
                    .getFileName());

            String initialType = "C ";
            if (glCredit.getJurnalType().equalsIgnoreCase(GefuTransactionType.Credit.name())) {
                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Credit);
            } else {
                initialType = "D ";

                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Debit);
            }


            glCreditDetail.setTotalAmount(amount);
            glCreditDetail.setInputerId(gefuHistory.getInputerId());
            glCreditDetail.setInputDate(new java.util.Date());
            glCreditDetail.setReference(initialType + glCredit.getJurnalSequence() + billing.getBillingNumber() + " " + billing.getCustomerCode());
            billingGefuDetailRepository.save(glCreditDetail);

        }

    }

    @Override
    public void gefuFundGeneratorCASA(BillingGefuProcessHistory gefuHistory) {

        BillingFund billing =
                billingFundRepository.findById(gefuHistory.getIdBilling()).orElse(null);
        double settleAmount = billing.getTotalAmountDue().doubleValue();

        BillingGefuProcessHistory gfProcessHistory = gefuHistory;
        gfProcessHistory.setGefuGenerated(true);
        gfProcessHistory.setCurrency(billing.getCurrency());
        billingGefuGeneratorRepository.save(gfProcessHistory);

        BillingCustomer billingCustomer = billingCustomerRepository.
                findByCode(billing.getCustomerCode()).orElse(null);

        // GL / Account Nasabah
        String costCenter = billingCustomer.getDebitTransfer() != null ?
                billingCustomer.getDebitTransfer() : "9207";

        BillingGefuProcessDetail glDebit = new BillingGefuProcessDetail();
        glDebit.setGefuProcessHistory(gefuHistory);
        glDebit.setGLName(billingCustomer.getAccountName());
        glDebit.setGLNo(billingCustomer.getAccount());
        glDebit.setCostCenter(costCenter);
        glDebit.setFileName(gefuHistory.getFileName());
        glDebit
                .setGefuTransactionType(GefuTransactionType.Debit);
        glDebit.setTotalAmount(settleAmount);
        glDebit.setInputerId(gefuHistory.getInputerId());
        glDebit.setInputDate(new java.util.Date());
        glDebit.setReference("D 0" + billing.getBillingNumber() + " " + billing.getCustomerCode());
        billingGefuDetailRepository.save(glDebit);

        // GL Dana Custodian Credit

        List<BillingGlCredit> glCreditList =
                billingGlCreditRepository.findAllByGlBillingTemplate(gefuHistory.getTemplate());

        for (BillingGlCredit glCredit : glCreditList) {

            double amount = 0;
            if (glCredit.getGlCreditName().trim().equalsIgnoreCase("GL Dana Custodian")) {
                amount = billing.getTotalAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Accrual Biaya Kustodian")) {
                amount = billing.getAccrualCustodialFee().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("VAT")) {
                amount = billing.getVatAmountDue().doubleValue();
            } else if (glCredit.getGlCreditName().trim().equalsIgnoreCase("Biaya S4+Biaya KSEI")) {
                amount = billing.getBis4TransactionAmountDue().doubleValue() +
                        billing.getKseiTransactionAmountDue().doubleValue();
            }

            BillingGefuProcessDetail glCreditDetail = new BillingGefuProcessDetail();
            glCreditDetail
                    .setGefuProcessHistory(gefuHistory);
            glCreditDetail.setGLName(glCredit.getGlCreditName().trim());
            glCreditDetail.setGLNo(String.valueOf(glCredit.getGlCreditAccountValue()));
            glCreditDetail.setCostCenter("9207");
            glCreditDetail.setFileName(gefuHistory
                    .getFileName());

            String initialType = "C ";
            if (glCredit.getJurnalType().equalsIgnoreCase(GefuTransactionType.Credit.name())) {
                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Credit);
            } else {
                initialType = "D ";

                glCreditDetail
                        .setGefuTransactionType(GefuTransactionType.Debit);
            }


            glCreditDetail.setTotalAmount(amount);
            glCreditDetail.setInputerId(gefuHistory.getInputerId());
            glCreditDetail.setInputDate(new java.util.Date());
            glCreditDetail.setReference(initialType + glCredit.getJurnalSequence() + billing.getBillingNumber() + " " + billing.getCustomerCode());
            billingGefuDetailRepository.save(glCreditDetail);

        }

    }

}
