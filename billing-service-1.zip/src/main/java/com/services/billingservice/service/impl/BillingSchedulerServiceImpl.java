package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingScheduler;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.repository.BillingSchedulerRepository;
import com.services.billingservice.service.BillingCoreGeneralService;
import com.services.billingservice.service.BillingNumberService;
import com.services.billingservice.service.BillingSchedulerService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingSchedulerServiceImpl implements BillingSchedulerService {

    private final BillingSchedulerRepository billingSchRepository;


    @Override
    public void deleteAll() {
        try {
            billingSchRepository.deleteAll();
        } catch (Exception e) {
            log.error("Error when delete all Billing Core : " + e.getMessage(), e);
            throw new ConnectionDatabaseException("Error when delete all Billing Core: " + e.getMessage());
        }
    }

    @Override
    public List<BillingScheduler> getAll(boolean enable) {
        return billingSchRepository.findAllByEnable(
               enable
        );
    }


}
