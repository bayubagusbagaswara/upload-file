package com.services.billingservice.service.impl;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.*;
import com.services.billingservice.repository.BillingSellingAgentDataRepository;
import com.services.billingservice.service.BillingSellingAgentDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingSellingAgentDataImpl implements BillingSellingAgentDataService {

    private final BillingSellingAgentDataRepository billingSellingAgentDataRepository;

    @Override
    public boolean isCodeAlreadyExists(String sellingAgentCode) {
        return billingSellingAgentDataRepository.existsByCode(sellingAgentCode);
    }

    @Override
    public SellingAgentResponse createSingleData(CreateSellingAgentRequest createSellingAgentRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public SellingAgentResponse createSingleApprove(SellingAgentApproveRequest sellingAgentApproveRequest) {
        return null;
    }

    @Override
    public SellingAgentResponse updateSingleData(UpdateSellingAgentRequest updateSellingAgentRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public SellingAgentResponse updateMultipleData(SellingAgentListRequest listRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public SellingAgentResponse updateSingleApprove(SellingAgentApproveRequest sellingAgentApproveRequest) {
        return null;
    }

    @Override
    public SellingAgentDTO getByCode(String code) {
        return null;
    }

    @Override
    public List<SellingAgentDTO> getAll() {
        return null;
    }

    @Override
    public String deleteById(Long id) {
        return null;
    }

    @Override
    public String deleteAll() {
        return null;
    }
}
