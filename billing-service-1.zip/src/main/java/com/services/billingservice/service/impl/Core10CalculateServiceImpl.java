package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * AID = 00N01C
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class Core10CalculateServiceImpl implements Core10CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final SkTranService skTranService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingCoreGeneralService billingCoreGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core type 10 with request : {}", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);
            Instant dateNow = Instant.now();

            // Initialization variable
            Integer transactionHandlingFrequency;
            BigDecimal transactionHandlingAmountDue;
            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            BigDecimal totalAmountDue;
            List<BillingCore> billingCoreList = new ArrayList<>();

            // Get Billing Customer
            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            // Process calculate billing
            for (BillingCustomer billingCustomer : billingCustomerList) {
                String aid = billingCustomer.getCustomerCode();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                BigDecimal customerMinimumFee = billingCustomer.getCustomerMinimumFee();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingType = billingCustomer.getBillingType();
                String miCode = billingCustomer.getMiCode();
                BigDecimal transactionHandlingFee = billingCustomer.getTransactionHandling();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, monthName, year);

                List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(aid, monthName, year);

                transactionHandlingFrequency = calculateTransactionHandlingFrequency(aid, skTransactionList);

                transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(aid, transactionHandlingFrequency, transactionHandlingFee);

                safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgMonthlyList);

                safekeepingAmountDue = calculateSafekeepingAmountDue(aid, safekeepingValueFrequency, customerSafekeepingFee);

                totalAmountDue = calculateTotalAmountDue(aid, transactionHandlingAmountDue, safekeepingAmountDue);

                // check existing billing
                billingCoreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                BillingCore billingCore = BillingCore.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .billingStatus(BillingStatus.Generated)
                        .customerCode(aid)
                        .customerName(billingCustomer.getCustomerName())
                        .month(monthName)
                        .year(year)

                        .billingPeriod(monthName + " " + year)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCategory)
                        .billingType(billingType)
                        .billingTemplate(billingCustomer.getBillingTemplate())
                        .investmentManagementName(billingMIDTO.getName())
                        .investmentManagementAddress1(billingMIDTO.getAddress1())
                        .investmentManagementAddress2(billingMIDTO.getAddress2())
                        .investmentManagementAddress3(billingMIDTO.getAddress3())
                        .investmentManagementAddress4(billingMIDTO.getAddress4())
                        .investmentManagementEmail(billingMIDTO.getEmail())

                        .customerMinimumFee(customerMinimumFee)
                        .customerSafekeepingFee(customerSafekeepingFee)

                        .accountName(billingCustomer.getAccountName())
                        .accountNumber(billingCustomer.getAccount())
                        .costCenter(billingCustomer.getCostCenter())
                        .currency(billingCustomer.getCurrency())

                        .transactionHandlingValueFrequency(transactionHandlingFrequency)
                        .transactionHandlingFee(transactionHandlingFee)
                        .transactionHandlingAmountDue(transactionHandlingAmountDue)
                        .safekeepingValueFrequency(safekeepingValueFrequency)
                        .safekeepingFee(customerSafekeepingFee)
                        .safekeepingAmountDue(safekeepingAmountDue)
                        .totalAmountDue(totalAmountDue)
                        .safekeepingJournal("12345")
                        .transactionHandlingJournal("67890")
                        .build();

                billingCoreList.add(billingCore);
            }

            int billingCoreListSize = billingCoreList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingCoreListSize, monthName, year);

            for (int i = 0; i < billingCoreListSize; i++) {
                BillingCore billingCore = billingCoreList.get(i);
                String number = numberList.get(i);
                billingCore.setBillingNumber(number);
            }

            List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Core type 10 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculate Billing Core type 10 with a total : " + billingCoreListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 10 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 10 : " + e.getMessage());
        }
    }

    private static Integer calculateTransactionHandlingFrequency(String aid, List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 10] Total transaction handling Aid '{}' is '{}'", aid, totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(String aid, Integer transactionHandlingFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingFrequency)
                .multiply(transactionHandlingFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 10] Transaction handling amount due Aid '{}' is '{}'", aid, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgMonthly> sfValRgMonthlyList) {
        List<SfValRgMonthly> latestEntries = sfValRgMonthlyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgMonthlyList.stream()
                        .map(SfValRgMonthly::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgMonthly latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}', Market Value '{}'",
                    latestEntry.getDate(), latestEntry.getSecurityName(), latestEntry.getMarketValue());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgMonthly::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 10] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, BigDecimal safekeepingValueFrequency, BigDecimal customerSafekeepingFee) {
        BigDecimal safeKeepingAfterDivide100Percentage = customerSafekeepingFee
                .divide(new BigDecimal(100), 4, RoundingMode.HALF_UP);

        BigDecimal safekeepingAmountDue = safekeepingValueFrequency
                .multiply(safeKeepingAfterDivide100Percentage)
                .divide(new BigDecimal(12), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 10] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(String aid, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal totalAmountDue = transactionHandlingAmountDue
                .add(safekeepingAmountDue);

        log.info("[Core Type 10] Total amount due Aid '{}' is '{}'", aid, totalAmountDue);
        return totalAmountDue;
    }

}
