package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.exchangerate.ExchangeRateDTO;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValCoreIIG;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.services.billingservice.enums.Currency.USD;
import static com.services.billingservice.enums.FeeParameter.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core8CalculateServiceImpl implements Core8CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final SfValCoreIIGService sfValCoreIIGService;
    private final ExchangeRateService exchangeRateService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingCoreGeneralService billingCoreGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core type 8 with request : {}", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // Initialization variable
            int administrationSetUpItem;
            BigDecimal administrationSetUpAmountDue;
            int signingRepresentationItem;
            BigDecimal signingRepresentationAmountDue;
            int securityAgentItem;
            BigDecimal securityAgentAmountDue;
            int transactionHandlingItem;
            BigDecimal transactionHandlingAmountDue;
            int safekeepingItem;
            BigDecimal safekeepingAmountDueUSD;
            int otherItem = 0;
            BigDecimal otherAmountDue;
            BigDecimal subTotal;
            BigDecimal vatAmountDueUSD;
            BigDecimal totalAmountDue;
            List<BillingCore> billingCoreList = new ArrayList<>();
            Instant dateNow = Instant.now();

            // Get Fee Parameter
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(ADMINISTRATION_SET_UP.getValue());
            feeParamList.add(SIGNING_REPRESENTATION.getValue());
            feeParamList.add(SECURITY_AGENT.getValue());
            feeParamList.add(OTHER.getValue());
            feeParamList.add(VAT.getValue());

            Map<String, BigDecimal> feeParamMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal administrationSetUpFee = feeParamMap.get(ADMINISTRATION_SET_UP.getValue());
            BigDecimal signingRepresentationFee = feeParamMap.get(SIGNING_REPRESENTATION.getValue());
            BigDecimal securityAgentFee = feeParamMap.get(SECURITY_AGENT.getValue());
            BigDecimal otherFee = feeParamMap.get(OTHER.getValue());
            BigDecimal vatFee = feeParamMap.get(VAT.getValue());

            // Get All Billing Customer
            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            // Get Exchange Rate
            ExchangeRateDTO exchangeRateDTO = exchangeRateService.getByCurrency(USD.getValue());
            BigDecimal exchangeRateValue = new BigDecimal(exchangeRateDTO.getValue());

            for (BillingCustomer billingCustomer : billingCustomerList) {
                String aid = billingCustomer.getCustomerCode();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingType = billingCustomer.getBillingType();
                String miCode = billingCustomer.getMiCode();
                BigDecimal transactionHandlingFee = billingCustomer.getTransactionHandling();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                List<SfValCoreIIG> sfValCoreIIGList = sfValCoreIIGService.getAllByAidAndMonthAndYear(aid, monthName, year);

                BigDecimal safekeepingFeeIDR = calculateTotalSafekeepingIDR(aid, sfValCoreIIGList);

                safekeepingAmountDueUSD = calculateTotalSafekeepingUSD(aid, safekeepingFeeIDR, exchangeRateValue);

                administrationSetUpItem = getAdministrationSetUpItem();

                administrationSetUpAmountDue = getAdministrationSetAmountDue();

                signingRepresentationItem = getSigningRepresentationItem();

                signingRepresentationAmountDue = getSigningRepresentationAmountDue();

                securityAgentItem = getSecurityAgentItem();

                securityAgentAmountDue = getSecurityAgentAmountDue();

                transactionHandlingItem = getTransactionHandlingItem();

                transactionHandlingAmountDue = getTransactionHandlingAmountDue();

                safekeepingItem = getSafekeepingItem();

                otherAmountDue = getOtherAmountDue();

                subTotal = calculateSubTotal(
                        aid,
                        administrationSetUpAmountDue, signingRepresentationAmountDue,
                        securityAgentAmountDue, transactionHandlingAmountDue,
                        safekeepingAmountDueUSD, otherAmountDue
                );

                vatAmountDueUSD = calculateVATAmountDueUSD(aid, vatFee, safekeepingAmountDueUSD);

                totalAmountDue = calculateTotalAmountDueUSD(aid, vatAmountDueUSD, safekeepingAmountDueUSD);

                // check existing
                billingCoreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                // Create Billing Core
                BillingCore billingCore = BillingCore.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .billingStatus(BillingStatus.Generated)
                        .customerCode(aid)
                        .customerName(billingCustomer.getCustomerName())
                        .month(monthName)
                        .year(year)

                        .billingPeriod(monthName + " " + year)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCategory)
                        .billingType(billingType)
                        .billingTemplate(billingCustomer.getBillingTemplate())
                        .investmentManagementName(billingMIDTO.getName())
                        .investmentManagementAddress1(billingMIDTO.getAddress1())
                        .investmentManagementAddress2(billingMIDTO.getAddress2())
                        .investmentManagementAddress3(billingMIDTO.getAddress3())
                        .investmentManagementAddress4(billingMIDTO.getAddress4())
                        .investmentManagementEmail(billingMIDTO.getEmail())

                        .customerMinimumFee(billingCustomer.getCustomerMinimumFee())
                        .customerSafekeepingFee(billingCustomer.getCustomerSafekeepingFee())

                        .accountName(billingCustomer.getAccountName())
                        .accountNumber(billingCustomer.getAccount())
                        .costCenter(billingCustomer.getCostCenter())
                        .currency(billingCustomer.getCurrency())
                        .corrBank("5678")
                        .swiftCode("1234")
                        .accountNumberCBEST("account no cbest")

                        .administrationSetUpItem(administrationSetUpItem)
                        .administrationSetUpFee(administrationSetUpFee)
                        .administrationSetUpAmountDue(administrationSetUpAmountDue)

                        .signingRepresentationItem(signingRepresentationItem)
                        .signingRepresentationFee(signingRepresentationFee)
                        .signingRepresentationAmountDue(signingRepresentationAmountDue)

                        .securityAgentItem(securityAgentItem)
                        .securityAgentFee(securityAgentFee)
                        .securityAgentAmountDue(securityAgentAmountDue)

                        .transactionHandlingItem(transactionHandlingItem)
                        .transactionHandlingFee(transactionHandlingFee)
                        .transactionHandlingAmountDue(transactionHandlingAmountDue)

                        .safekeepingItem(safekeepingItem)
                        .safekeepingFee(billingCustomer.getCustomerSafekeepingFee())
                        .safekeepingAmountDue(safekeepingAmountDueUSD)

                        .otherItem(otherItem)
                        .otherFee(otherFee)
                        .otherAmountDue(otherAmountDue)

                        .subTotal(subTotal)

                        .vatFee(vatFee)
                        .vatAmountDue(vatAmountDueUSD)

                        .totalAmountDue(totalAmountDue)
                        .build();

                billingCoreList.add(billingCore);
            }

            int billingCoreListSize = billingCoreList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingCoreListSize, monthName, year);

            for (int i = 0; i < billingCoreListSize; i++) {
                BillingCore billingCore = billingCoreList.get(i);
                String number = numberList.get(i);
                billingCore.setBillingNumber(number);
            }

            List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Core type 8 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Core type 8 with a total : " + billingCoreListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 8 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 8 : " + e.getMessage());
        }
    }

    private static BigDecimal getOtherAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getSafekeepingItem() {
        return 0;
    }

    private static BigDecimal getTransactionHandlingAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getTransactionHandlingItem() {
        return 0;
    }

    private static BigDecimal getSecurityAgentAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getSecurityAgentItem() {
        return 0;
    }

    private static BigDecimal calculateTotalSafekeepingIDR(String aid, List<SfValCoreIIG> sfValCoreIIGList) {
        BigDecimal totalSafekeepingFeeIDR = sfValCoreIIGList.stream()
                .map(SfValCoreIIG::getSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        log.info("[Core Type 8] Safekeeping Fee IDR Aid '{}' is '{}'", aid, totalSafekeepingFeeIDR);
        return totalSafekeepingFeeIDR;
    }

    private static BigDecimal calculateTotalSafekeepingUSD(String aid, BigDecimal safekeepingFeeIDR, BigDecimal exchangeRate) {
        BigDecimal totalSafekeepingFeeUSD = safekeepingFeeIDR
                .divide(exchangeRate, 2, RoundingMode.HALF_UP);
        log.info("[Core Type 8] Safekeeping Fee USD Aid '{}' is '{}'", aid, totalSafekeepingFeeUSD);
        return totalSafekeepingFeeUSD;
    }

    private static BigDecimal calculateSubTotal(String aid, BigDecimal administrationSetUpAmountDue, BigDecimal signingRepresentationAmountDue, BigDecimal securityAgentAmountDue, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue, BigDecimal otherAmountDue) {
        BigDecimal subTotal = administrationSetUpAmountDue
                .add(signingRepresentationAmountDue)
                .add(securityAgentAmountDue)
                .add(transactionHandlingAmountDue)
                .add(safekeepingAmountDue)
                .add(otherAmountDue)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Core Type 8] Sub total Aid '{}' is '{}'", aid, subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDueUSD(String aid, BigDecimal vatFee, BigDecimal safekeepingAmountDueUSD) {
        BigDecimal vatAmountDueUSD = safekeepingAmountDueUSD
                .multiply(vatFee)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Core Type 8] VAT amount USD Aid '{}' is '{}'", aid, vatAmountDueUSD);
        return vatAmountDueUSD;
    }

    private static BigDecimal calculateTotalAmountDueUSD(String aid, BigDecimal vatAmountDueUSD, BigDecimal safekeepingAmountDueUSD) {
        BigDecimal totalAmountDueUSD = safekeepingAmountDueUSD
                .add(vatAmountDueUSD);
        log.info("[Core Type 8] Total amount USD Aid '{}' is '{}'", aid, totalAmountDueUSD);
        return totalAmountDueUSD;
    }

    private static int getAdministrationSetUpItem() {
        return 0;
    }

    private static BigDecimal getAdministrationSetAmountDue() {
        return BigDecimal.ZERO;
    }

    private static int getSigningRepresentationItem() {
        return 0;
    }

    private static BigDecimal getSigningRepresentationAmountDue() {
        return BigDecimal.ZERO;
    }

}
