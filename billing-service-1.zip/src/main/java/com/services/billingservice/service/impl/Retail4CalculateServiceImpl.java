package com.services.billingservice.service.impl;

import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.enums.Currency;
import com.services.billingservice.enums.FeeParameter;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail4CalculateServiceImpl implements Retail4CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final BillingNumberService billingNumberService;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingRetailGeneralService billingRetailGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start calculate Billing Retail with request '{}'", request);
        // create object default value is 0, except for data Fee Parameter
        try {
            // TODO: ONLY IDR Currency
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);
            Instant dateNow = Instant.now();

            List<BillingRetail> billingRetailList = new ArrayList<>();

            // Get Fee Param
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(FeeParameter.VAT.getValue());
            feeParamList.add(FeeParameter.FEE_TRANSFER.getValue());

            Map<String, BigDecimal> feeParamMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal vatFee = feeParamMap.get(FeeParameter.VAT.getValue());
            BigDecimal transferFee = feeParamMap.get(FeeParameter.FEE_TRANSFER.getValue());

            // Get Billing Customer List
            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomer billingCustomerDTO : billingCustomerList) {
                String sellingAgent = billingCustomerDTO.getSellingAgent();
                BigDecimal customerSafekeepingFee = billingCustomerDTO.getCustomerSafekeepingFee();
                String currency = billingCustomerDTO.getCurrency();
                String miCode = billingCustomerDTO.getMiCode();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                // TODO: check billing retail type 4 berdasarkan period yang sudah ada, jika ada data billingnya maka hapus
                billingRetailGeneralService.checkingExistingBillingRetail(sellingAgent, currency, monthName, year);

                // create object Billing Retail, tapi isi datanya dengan 0 (BigDecimal ZERO)
                BillingRetail billingRetail = BillingRetail.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .billingStatus(BillingStatus.Generated)
                        .sellingAgent(sellingAgent)
                        .month(monthName)
                        .year(year)

                        .billingPeriod(monthName + " " + year)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCustomerDTO.getBillingCategory())
                        .billingType(billingCustomerDTO.getBillingType())
                        .billingTemplate(billingCustomerDTO.getBillingTemplate())
                        .investmentManagementName(billingMIDTO.getName())
                        .investmentManagementAddress1(billingMIDTO.getAddress1())
                        .investmentManagementAddress2(billingMIDTO.getAddress2())
                        .investmentManagementAddress3(billingMIDTO.getAddress3())
                        .investmentManagementAddress4(billingMIDTO.getAddress4())
                        .investmentManagementEmail(billingMIDTO.getEmail())

                        .customerCode(billingCustomerDTO.getCustomerCode())
                        .customerName(billingCustomerDTO.getCustomerName())

                        .accountName(billingCustomerDTO.getAccountName())
                        .accountNumber(billingCustomerDTO.getAccount())
                        .costCenter(billingCustomerDTO.getCostCenter())
                        //.accountBank(billingCustomerDTO.getAccountBank())
                        .currency(Currency.IDR.getValue())

                        .safekeepingValueFrequency(BigDecimal.ZERO)
                        .safekeepingFee(customerSafekeepingFee)
                        .safekeepingAmountDue(BigDecimal.ZERO)
                        .vatFee(vatFee)
                        .vatAmountDue(BigDecimal.ZERO)
                        .subTotalAmountDue(BigDecimal.ZERO)
                        .transferValueFrequency(0)
                        .transferFee(transferFee)
                        .transferAmountDue(BigDecimal.ZERO)
                        .totalAmountDue(BigDecimal.ZERO)
                        .build();

                billingRetailList.add(billingRetail);
            }

            int billingRetailListSize = billingRetailList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingRetailListSize, monthName, year);

            for (int i = 0; i < billingRetailListSize; i++) {
                BillingRetail billingRetail = billingRetailList.get(i);
                String number = numberList.get(i);
                billingRetail.setBillingNumber(number);
            }

            List<BillingRetail> billingRetailListSaved = billingRetailRepository.saveAll(billingRetailList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Retail type 4 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculate Billing Retail type 4 with a total : " + billingRetailListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Retail type 4 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Retail type 4 : " + e.getMessage());
        }
    }

}
