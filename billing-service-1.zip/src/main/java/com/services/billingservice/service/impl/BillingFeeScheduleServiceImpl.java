package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeschedule.*;
import com.services.billingservice.repository.BillingFeeScheduleRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingFeeScheduleService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.Validator;

import java.math.BigDecimal;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFeeScheduleServiceImpl implements BillingFeeScheduleService {

    private final BillingFeeScheduleRepository billingFeeScheduleRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;

    @Override
    public FeeScheduleResponse createSingleData(CreateFeeScheduleRequest createFeeScheduleRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public FeeScheduleResponse createSingleApprove(FeeScheduleApproveRequest approveRequest) {
        return null;
    }

    @Override
    public FeeScheduleResponse updateSingleData(UpdateFeeScheduleRequest updateFeeScheduleRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public FeeScheduleResponse updateMultipleData(FeeScheduleListRequest listRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public FeeScheduleResponse updateSingleApprove(FeeScheduleApproveRequest approveRequest) {
        return null;
    }

    @Override
    public FeeScheduleResponse deleteSingleData(DeleteFeeScheduleRequest deleteFeeScheduleRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public FeeScheduleResponse deleteSingleApprove(FeeScheduleApproveRequest approveRequest) {
        return null;
    }

    @Override
    public BigDecimal checkFeeScheduleAndGetFeeValue(BigDecimal amount) {
        return null;
    }

    @Override
    public List<FeeScheduleDTO> getAll() {
        return null;
    }

    @Override
    public String deleteAll() {
        return null;
    }
}
