package com.services.billingservice.service;

import com.services.billingservice.dto.retail.BillingRetailListProcessDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.dto.retail.UpdateApprovalStatusBillingRetailRequest;
import com.services.billingservice.model.BillingRetail;

import java.util.List;

public interface BillingRetailGeneralService {

    // get all
    List<BillingRetail> getAll();

    void checkingExistingBillingRetail(String customerCode, String currency, String monthName, Integer year);

    String deleteAll();

    String deleteByCategoryAndTypeAndMonthYear(RetailCalculateRequest request);

    List<BillingRetailListProcessDTO> getAllListProcess();

    List<BillingRetailListProcessDTO> getAllListPendingApprove();

    List<BillingRetail> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(String month, Integer year, String category, String type, String currency);

    String updateApprovalStatus(UpdateApprovalStatusBillingRetailRequest request);
}
