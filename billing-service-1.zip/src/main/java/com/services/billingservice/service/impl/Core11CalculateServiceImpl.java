package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValCrowdFunding;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.VAT;

/**
 * Urun Dana
 * source file from table Urun Dana
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class Core11CalculateServiceImpl implements Core11CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final SfValCrowdFundingService sfValCrowdFundingService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingCoreGeneralService billingCoreGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core type 11 with request : {}", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            // Initialization variable (Harus sama dengan Core 1, kalau tidak diisi maka tulis 0)
            int transactionHandlingValueFrequency;
            BigDecimal transactionHandlingAmountDue;
            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            BigDecimal subTotal; // hanya berisi safekeepingAmountDue
            BigDecimal vatAmountDue;
            BigDecimal totalAmountDue;
            List<BillingCore> billingCoreList = new ArrayList<>();
            Instant dateNow = Instant.now();

            BigDecimal vatFee = feeParamService.getValueByName(VAT.getValue());

            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);
            
            // Process calculate Billing
            for (BillingCustomer billingCustomer : billingCustomerList) {
                String aid = billingCustomer.getCustomerCode();
                BigDecimal customerMinimumFee = billingCustomer.getCustomerMinimumFee();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingType = billingCustomer.getBillingType();
                String miCode = billingCustomer.getMiCode();
                BigDecimal transactionHandlingFee = billingCustomer.getTransactionHandling();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                List<SfValCrowdFunding> sfValCrowdFundingList = sfValCrowdFundingService.getAllByClientCodeAndMonthAndYear(aid, monthName, year);

                transactionHandlingValueFrequency = 0;
                transactionHandlingAmountDue = BigDecimal.ZERO;

                safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValCrowdFundingList);

                safekeepingAmountDue = calculateSafekeepingAmountDue(aid, customerMinimumFee, customerSafekeepingFee, safekeepingValueFrequency);

                subTotal = calculateSubTotal(transactionHandlingAmountDue, safekeepingAmountDue);

                vatAmountDue = calculateVATAmountDue(vatFee, subTotal);

                totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue);

                billingCoreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                BillingCore billingCore = BillingCore.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .billingStatus(BillingStatus.Generated)
                        .customerCode(billingCustomer.getCustomerCode())
                        .customerName(billingCustomer.getCustomerName())
                        .month(monthName)
                        .year(year)
                        .billingPeriod(monthName + " " + year)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCustomer.getBillingCategory())
                        .billingType(billingCustomer.getBillingType())
                        .billingTemplate(billingCustomer.getBillingTemplate())
                        .investmentManagementName(billingMIDTO.getName())
                        .investmentManagementAddress1(billingMIDTO.getAddress1())
                        .investmentManagementAddress2(billingMIDTO.getAddress2())
                        .investmentManagementAddress3(billingMIDTO.getAddress3())
                        .investmentManagementAddress4(billingMIDTO.getAddress4())
                        .investmentManagementEmail(billingMIDTO.getEmail())

                        .customerMinimumFee(customerMinimumFee)
                        .customerSafekeepingFee(customerSafekeepingFee)

                        .accountName(billingCustomer.getAccountName())
                        .accountNumber(billingCustomer.getAccount())
                        // .accountBank(billingCustomer.getAccountBank())
                        .costCenter(billingCustomer.getCostCenter())
                        .currency(billingCustomer.getCurrency())

                        .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                        .transactionHandlingFee(transactionHandlingFee)
                        .transactionHandlingAmountDue(transactionHandlingAmountDue)
                        .safekeepingValueFrequency(safekeepingValueFrequency)
                        .safekeepingFee(customerSafekeepingFee)
                        .safekeepingAmountDue(safekeepingAmountDue)
                        .subTotal(subTotal)
                        .vatFee(vatFee)
                        .vatAmountDue(vatAmountDue)
                        .totalAmountDue(totalAmountDue)
                        .build();

                billingCoreList.add(billingCore);
            }

            int billingCoreListSize = billingCoreList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingCoreListSize, monthName, year);

            for (int i = 0; i < billingCoreListSize; i++) {
                BillingCore billingCore = billingCoreList.get(i);
                String billingNumber = numberList.get(i);
                billingCore.setBillingNumber(billingNumber);
            }

            List<BillingCore> billingCoreListSaved = billingCoreRepository.saveAll(billingCoreList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Core type 11 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculate Billing Core type 11 with a total : " + billingCoreListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 11 : {}", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 11 : " + e.getMessage());
        }
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValCrowdFunding> sfValCrowdFundingList) {
        List<SfValCrowdFunding> latestEntries = sfValCrowdFundingList.stream()
                .filter(entry -> entry.getSettlementDate().equals(sfValCrowdFundingList.stream()
                        .map(SfValCrowdFunding::getSettlementDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValCrowdFunding latestEntry : latestEntries) {
            System.out.println("Settlement Date : " + latestEntry.getSettlementDate() +
                    "Security Name : " + latestEntry.getSecurityCode() +
                    "Market Value : " + latestEntry.getMarketValue());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValCrowdFunding::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 11] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, BigDecimal customerMinimumFee, BigDecimal customerSafekeepingFee, BigDecimal safekeepingValueFrequency) {
        BigDecimal result = safekeepingValueFrequency
                .multiply(customerSafekeepingFee)
                .setScale(0, RoundingMode.HALF_UP);

        BigDecimal divide = result.divide(new BigDecimal(12), 0, RoundingMode.HALF_UP);

        BigDecimal safekeepingAmountDue = divide.compareTo(customerMinimumFee) < 0 ? customerMinimumFee : divide;

        log.info("[Core Type 11] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateSubTotal(BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotal = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Core Type 11] Sub total '{}'", subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal vatFee, BigDecimal subTotal) {
        BigDecimal vatAmountDue = subTotal.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP);
        log.info("[Core Type 11] VAT amount due '{}'", vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue).setScale(0, BigDecimal.ROUND_HALF_UP);
        log.info("[Core Type 11] Total amount due '{}'", totalAmountDue);
        return totalAmountDue;
    }

}
