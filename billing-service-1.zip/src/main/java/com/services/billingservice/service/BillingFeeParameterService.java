package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface BillingFeeParameterService {

    BigDecimal getValueByName(String name);
    
    Map<String, BigDecimal> getValueByNameList(List<String> nameList);

    FeeParameterResponse createSingleData(CreateFeeParameterRequest createFeeParameterRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse createMultipleData(FeeParameterListRequest createFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse createSingleApprove(FeeParameterApproveRequest createFeeParameterListRequest);

    FeeParameterResponse updateMultipleData(FeeParameterListRequest updateFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO);

    FeeParameterResponse updateSingleApprove(FeeParameterApproveRequest updateFeeParameterListRequest);

    List<FeeParameterDTO> getAll();

    String deleteAll();
}
