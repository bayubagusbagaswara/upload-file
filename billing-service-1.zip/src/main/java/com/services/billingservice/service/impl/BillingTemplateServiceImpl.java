package com.services.billingservice.service.impl;


import com.services.billingservice.dto.BillingTemplateDTO;
import com.services.billingservice.dto.request.BillingTemplateRequest;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingTemplate;
import com.services.billingservice.repository.BillingTemplateRepository;
import com.services.billingservice.service.BillingTemplateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service

public class BillingTemplateServiceImpl implements BillingTemplateService {

    private final BillingTemplateRepository billingTemplateRepository;

    public BillingTemplateServiceImpl(BillingTemplateRepository billingTemplateRepository) {
        this.billingTemplateRepository = billingTemplateRepository;

    }

    @Override
    public BillingTemplateDTO create(BillingTemplateRequest request) {
        BillingTemplate billingTemplate = BillingTemplate.builder()
                .templateName(request.getTemplateName())
                .category(request.getTemplateCategory())
                .templateType(request.getTemplateType())
                .desc(request.getDesc())
                .build();
        BillingTemplate dataSaved = billingTemplateRepository.save(billingTemplate);
        return maptoDTO(dataSaved);
    }

    @Override
    public BillingTemplateDTO getById(String id) {
        BillingTemplate billingTemplate = billingTemplateRepository.findById(Long.valueOf(id))
                .orElseThrow(()-> new DataNotFoundException("Data Not Found"));
        return maptoDTO(billingTemplate);
    }

    @Override
    public List<BillingTemplateDTO> getAll() {
        List<BillingTemplate>billingTemplates = billingTemplateRepository.findAll();

        return mapToDTOList(billingTemplates);
    }

    @Override
    public BillingTemplateDTO updateById(String id, BillingTemplateRequest request) {
       BillingTemplate billingTemplate = billingTemplateRepository.findById(Long.valueOf(id))
               .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

       if(request.getTemplateName() != null){
           billingTemplate.setTemplateName(request.getTemplateName());
       }
       if(request.getTemplateType() != null){
           billingTemplate.setTemplateType(request.getTemplateType());
       }
       if(request.getTemplateCategory() != null){
           billingTemplate.setCategory(request.getTemplateCategory());
       }
       if(request.getDesc() != null){
           billingTemplate.setDesc(request.getDesc());
       }


       BillingTemplate dataSaved = billingTemplateRepository.save(billingTemplate);
       return maptoDTO(dataSaved);
    }

    @Override
    public List<BillingTemplateDTO> getByType(String type) {
        List<BillingTemplate>billingTemplateList = billingTemplateRepository.findByType(type);

        if (billingTemplateList.size() == 0){
            new DataNotFoundException("Data with Type"+type+"Not Found");
        }
        return mapToDTOList(billingTemplateList);
    }

    @Override
    public List<BillingTemplateDTO> getByCategory(String category, String type) {
        List<BillingTemplate>billingTemplateList = billingTemplateRepository.findBycategoryAndType(category, type);

        if (billingTemplateList.size() == 0 ){
            new DataNotFoundException("Data with Type"+category+"Not Found");
        }
        return mapToDTOList(billingTemplateList);
    }

    @Override
    public String delete(String id) {
        BillingTemplate billingTemplate = billingTemplateRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("data not found"));

        BillingTemplate dataSaved = billingTemplateRepository.save(billingTemplate);
        return "delete data successfuly "+ dataSaved.getId();
    }


    private BillingTemplateDTO maptoDTO(BillingTemplate billingTemplate) {
        return BillingTemplateDTO.builder()
                .id(String.valueOf(billingTemplate.getId()))
                .templateName(billingTemplate.getTemplateName())
                .templateType(billingTemplate.getTemplateType())
                .templateCategory(billingTemplate.getCategory())
                .desc(billingTemplate.getDesc())
                .build();
    }

    private List<BillingTemplateDTO> mapToDTOList(List<BillingTemplate> billingTemplateList) {
        return billingTemplateList.stream()
                .map(this::maptoDTO)
                .collect(Collectors.toList());
    }
}
