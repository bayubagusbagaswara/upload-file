package com.services.billingservice.service.impl;

import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.Retail2QueryResultDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.model.RetailTransaction;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.repository.RetailTransactionRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.FeeParameter.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail2CalculateServiceImpl implements Retail2CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final BillingNumberService billingNumberService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingRetailGeneralService billingRetailGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start calculate Billing Retail with request '{}'", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);
            LocalDate dateOfMonthYear = convertDateUtil.getFirstDateOfMonthYear(request.getMonthYear());
            Instant instantNow = Instant.now();

            // Initialization variable
            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            Integer transactionSettlementValueFrequency;
            BigDecimal transactionSettlementAmountDue;
            int adHocReportValueFrequency;
            BigDecimal adHocReportAmountDue;
            Integer thirdPartyValueFrequency;
            BigDecimal thirdPartyAmountDue;
            BigDecimal subTotal;
            BigDecimal vatAmountDue;
            BigDecimal totalAmountDue;
            List<BillingRetail> billingRetailList = new ArrayList<>();

            // Get Fee Param
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(VAT.getValue());
            feeParamList.add(AD_HOC_REPORT.getValue());
            feeParamList.add(THIRD_PARTY.getValue());

            Map<String, BigDecimal> feeParamMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal vatFee = feeParamMap.get(VAT.getValue());

            BigDecimal adHocReportFee = feeParamMap.get(AD_HOC_REPORT.getValue());
            BigDecimal thirdPartyFee = feeParamMap.get(THIRD_PARTY.getValue());

            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomer billingCustomer : billingCustomerList) {
                String sellingAgent = billingCustomer.getSellingAgent();
                BigDecimal safekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                String customerCode = billingCustomer.getCustomerCode();
                String currency = billingCustomer.getCurrency();
                String miCode = billingCustomer.getMiCode();
                BigDecimal transactionHandlingFee = billingCustomer.getTransactionHandling();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                billingRetailGeneralService.checkingExistingBillingRetail(customerCode, currency, monthName, year);

                if (currency.equalsIgnoreCase(IDR.getValue())) {
                    List<Object[]> objects = retailAccountBalanceRepository.getRetailDataBySellingAgentAndCurrency(sellingAgent, currency, dateOfMonthYear);

                    Retail2QueryResultDTO retail2QueryResultDTO = mapToDTO(objects);

                    safekeepingValueFrequency = retail2QueryResultDTO != null ? retail2QueryResultDTO.getLastBalance() : BigDecimal.ZERO;
                    safekeepingAmountDue = retail2QueryResultDTO != null ? retail2QueryResultDTO.getSumFee() : BigDecimal.ZERO;

                    log.info("Safekeeping value frequency Selling Agent '{}' and currency '{}' : '{}'", sellingAgent, currency, safekeepingValueFrequency);
                    log.info("Safekeeping amount due Selling Agent '{}' and currency '{}' : '{}'", sellingAgent, currency, safekeepingAmountDue);

                    List<RetailTransaction> retailTransactionList = retailTransactionRepository.findAllBySellingAgentAndMonthAndYearAndCurrency(sellingAgent, monthName, year, currency);

                    transactionSettlementValueFrequency = calculateTransactionSettlementValueFrequency(sellingAgent, currency, retailTransactionList);

                    transactionSettlementAmountDue = calculateTransactionSettlementAmountDue(sellingAgent, currency, transactionSettlementValueFrequency, transactionHandlingFee);

                    adHocReportValueFrequency = 0;

                    adHocReportAmountDue = BigDecimal.ZERO;

                    thirdPartyValueFrequency = calculateThirdPartyValueFrequency(sellingAgent, currency, transactionSettlementValueFrequency);

                    thirdPartyAmountDue = calculateThirdPartyAmountDue(sellingAgent, currency, thirdPartyValueFrequency, thirdPartyFee);

                    subTotal = calculateSubTotal(sellingAgent, currency, safekeepingAmountDue, transactionSettlementAmountDue, adHocReportAmountDue, thirdPartyAmountDue);

                    vatAmountDue = calculateVATAmountDue(sellingAgent, currency, subTotal, vatFee);

                    totalAmountDue = calculateTotalAmountDue(sellingAgent, currency, subTotal, vatAmountDue);

                    BillingRetail billingRetail = BillingRetail.builder()
                            .createdAt(instantNow)
                            .updatedAt(instantNow)
                            .approvalStatus(ApprovalStatus.Pending)
                            .billingStatus(BillingStatus.Generated)
                            .sellingAgent(sellingAgent)
                            .month(monthName)
                            .year(year)

                            .billingPeriod(monthName + " " + year)
                            .billingStatementDate(ConvertDateUtil.convertInstantToString(instantNow))
                            .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(instantNow))
                            .billingCategory(billingCustomer.getBillingCategory())
                            .billingType(billingCustomer.getBillingType())
                            .billingTemplate(billingCustomer.getBillingTemplate())
                            .investmentManagementName(billingMIDTO.getName())
                            .investmentManagementAddress1(billingMIDTO.getAddress1())
                            .investmentManagementAddress2(billingMIDTO.getAddress2())
                            .investmentManagementAddress3(billingMIDTO.getAddress3())
                            .investmentManagementAddress4(billingMIDTO.getAddress4())
                            .investmentManagementEmail(billingMIDTO.getEmail())

                            .customerCode(billingCustomer.getCustomerCode())
                            .customerName(billingCustomer.getCustomerName())

                            .accountName(billingCustomer.getAccountName())
                            .accountNumber(billingCustomer.getAccount())
                            .costCenter(billingCustomer.getCostCenter())
                            //.accountBank(billingCustomer.getAccountBank())
                            .currency(currency)

                            .safekeepingValueFrequency(safekeepingValueFrequency)
                            .safekeepingFee(safekeepingFee)
                            .safekeepingAmountDue(safekeepingAmountDue)

                            .transactionSettlementValueFrequency(transactionSettlementValueFrequency)
                            .transactionSettlementFee(transactionHandlingFee)
                            .transactionSettlementAmountDue(transactionSettlementAmountDue)

                            .adHocReportValueFrequency(adHocReportValueFrequency)
                            .adHocReportFee(adHocReportFee)
                            .adHocReportAmountDue(adHocReportAmountDue)

                            .thirdPartyValueFrequency(thirdPartyValueFrequency)
                            .thirdPartyFee(thirdPartyFee)
                            .thirdPartyAmountDue(thirdPartyAmountDue)

                            .subTotalAmountDue(subTotal)
                            .vatFee(vatFee)
                            .vatAmountDue(vatAmountDue)
                            .totalAmountDue(totalAmountDue)

                            .build();

                    billingRetailList.add(billingRetail);

                } else {
                    List<Object[]> objects = retailAccountBalanceRepository.getRetailDataBySellingAgentAndCurrency(sellingAgent, currency, dateOfMonthYear);

                    Retail2QueryResultDTO retail2QueryResultDTO = mapToDTO(objects);
                    safekeepingValueFrequency = null != retail2QueryResultDTO ? retail2QueryResultDTO.getLastBalance() : BigDecimal.ZERO;
                    safekeepingAmountDue = null != retail2QueryResultDTO ? retail2QueryResultDTO.getSumFee() : BigDecimal.ZERO;

                    log.info("Safekeeping value frequency Selling Agent '{}' and currency '{}' : '{}'", sellingAgent, currency, safekeepingValueFrequency);
                    log.info("Safekeeping amount due Selling Agent '{}' and currency '{}' : '{}'", sellingAgent, currency, safekeepingAmountDue);

                    List<RetailTransaction> retailTransactionList = retailTransactionRepository.findAllBySellingAgentAndMonthAndYearAndCurrency(sellingAgent, monthName, year, currency);

                    transactionSettlementValueFrequency = calculateTransactionSettlementValueFrequency(sellingAgent, currency, retailTransactionList);

                    transactionSettlementAmountDue = calculateTransactionSettlementAmountDueUSD(sellingAgent, currency, transactionSettlementValueFrequency, transactionHandlingFee);

                    adHocReportValueFrequency = 0;

                    adHocReportAmountDue = BigDecimal.ZERO;

                    thirdPartyValueFrequency = 0;

                    thirdPartyAmountDue = calculateThirdPartyAmountDueUSD(sellingAgent, currency, thirdPartyValueFrequency, thirdPartyFee);

                    subTotal = calculateSubTotalUSD(sellingAgent, currency, safekeepingAmountDue, transactionSettlementAmountDue, adHocReportAmountDue, thirdPartyAmountDue);

                    vatAmountDue = calculateVATAmountDueUSD(sellingAgent, currency, subTotal, vatFee);

                    totalAmountDue = calculateTotalAmountDueUSD(sellingAgent, currency, subTotal, vatAmountDue);

                    BillingRetail billingRetail = BillingRetail.builder()
                            .createdAt(instantNow)
                            .updatedAt(instantNow)
                            .approvalStatus(ApprovalStatus.Pending)
                            .billingStatus(BillingStatus.Generated)
                            .sellingAgent(sellingAgent)
                            .month(monthName)
                            .year(year)

                            .billingPeriod(monthName + " " + year)
                            .billingStatementDate(ConvertDateUtil.convertInstantToString(instantNow))
                            .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(instantNow))
                            .billingCategory(billingCustomer.getBillingCategory())
                            .billingType(billingCustomer.getBillingType())
                            .billingTemplate(billingCustomer.getBillingTemplate())
                            .investmentManagementName(billingMIDTO.getName())
                            .investmentManagementAddress1(billingMIDTO.getAddress1())
                            .investmentManagementAddress2(billingMIDTO.getAddress2())
                            .investmentManagementAddress3(billingMIDTO.getAddress3())
                            .investmentManagementAddress4(billingMIDTO.getAddress4())
                            .investmentManagementEmail(billingMIDTO.getEmail())

                            .customerCode(billingCustomer.getCustomerCode())
                            .customerName(billingCustomer.getCustomerName())

                            .accountName(billingCustomer.getAccountName())
                            .accountNumber(billingCustomer.getAccount())
                            .costCenter(billingCustomer.getCostCenter())
                            //.accountBank(billingCustomer.getAccountBank())
                            .currency(currency)

                            .safekeepingValueFrequency(safekeepingValueFrequency)
                            .safekeepingFee(safekeepingFee)
                            .safekeepingAmountDue(safekeepingAmountDue)

                            .transactionSettlementValueFrequency(transactionSettlementValueFrequency)
                            .transactionSettlementFee(transactionHandlingFee)
                            .transactionSettlementAmountDue(transactionSettlementAmountDue)

                            .adHocReportValueFrequency(adHocReportValueFrequency)
                            .adHocReportFee(adHocReportFee)
                            .adHocReportAmountDue(adHocReportAmountDue)

                            .thirdPartyValueFrequency(thirdPartyValueFrequency)
                            .thirdPartyFee(thirdPartyFee)
                            .thirdPartyAmountDue(thirdPartyAmountDue)

                            .subTotalAmountDue(subTotal)
                            .vatFee(vatFee)
                            .vatAmountDue(vatAmountDue)
                            .totalAmountDue(totalAmountDue)
                            .build();

                    billingRetailList.add(billingRetail);
                }
            }

            int billingRetailListSize = billingRetailList.size();
            List<String> numberList = billingNumberService.generateNumberList(billingRetailListSize, monthName, year);

            for (int i = 0; i < billingRetailListSize; i++) {
                BillingRetail billingRetail = billingRetailList.get(i);
                String number = numberList.get(i);
                billingRetail.setBillingNumber(number);
            }

            List<BillingRetail> billingRetailListSaved = billingRetailRepository.saveAll(billingRetailList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Retail type 2 with month '{}' and year '{}'",  monthName, year);
            return "Successfully calculate Billing Retail type 2 with a total : " + billingRetailListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Retail type 2 : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Retail type 2 : " + e.getMessage());
        }
    }


    private static Integer calculateTransactionSettlementValueFrequency(String sellingAgent, String currency, List<RetailTransaction> retailTransactionList) {
        int totalTransactionSettlement = retailTransactionList.size();
        log.info("[Retail Type 2 {}] Total transaction settlement Selling Agent '{}' is '{}'", currency, sellingAgent, totalTransactionSettlement);
        return totalTransactionSettlement;
    }

    private static BigDecimal calculateTransactionSettlementAmountDue(String sellingAgent, String currency, Integer transactionSettlementValueFrequency, BigDecimal transactionSettlementFee) {
        log.info("Settlement Fee : {}", transactionSettlementFee);
        BigDecimal transactionSettlementAmountDue = new BigDecimal(transactionSettlementValueFrequency)
                .multiply(transactionSettlementFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Transaction settlement amount due Selling Agent '{}' is '{}'", currency, sellingAgent, transactionSettlementAmountDue);
        return transactionSettlementAmountDue;
    }


    private static Integer calculateThirdPartyValueFrequency(String sellingAgent, String currency, Integer transactionSettlementValueFrequency) {
        log.info("[Retail Type 2 {}] Third party value frequency Selling Agent '{}' is '{}'", currency, sellingAgent, transactionSettlementValueFrequency);
        return transactionSettlementValueFrequency;
    }


    private static BigDecimal calculateThirdPartyAmountDue(String sellingAgent, String currency, Integer thirdPartyValueFrequency, BigDecimal thirdPartyFee) {
        BigDecimal thirdPartyAmountDue = new BigDecimal(thirdPartyValueFrequency)
                .multiply(thirdPartyFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Third party amount due Selling Agent '{}' is '{}'", currency, sellingAgent, thirdPartyAmountDue);
        return thirdPartyAmountDue;
    }

    private static BigDecimal calculateSubTotal(String sellingAgent, String currency, BigDecimal safekeepingAmountDue, BigDecimal transactionSettlementAmountDue, BigDecimal adHocReportAmountDue, BigDecimal thirdPartyAmountDue) {
        BigDecimal subTotal = safekeepingAmountDue
                .add(transactionSettlementAmountDue)
                .add(adHocReportAmountDue)
                .add(thirdPartyAmountDue)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Sub total Selling Agent '{}' is '{}'", currency, sellingAgent, subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDue(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] VAT amount due Selling Agent '{}' is '{}'", currency, sellingAgent, subTotal);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Total amount due Selling Agent '{}' is '{}'", currency, sellingAgent, totalAmountDue);
        return totalAmountDue;
    }

    private static BigDecimal calculateTransactionSettlementAmountDueUSD(String sellingAgent, String currency, Integer transactionSettlementValueFrequency, BigDecimal transactionSettlementFeeUSD) {
        BigDecimal settlementAmountDueUSD = new BigDecimal(transactionSettlementValueFrequency)
                .multiply(transactionSettlementFeeUSD)
                .divide(new BigDecimal(100), 0, BigDecimal.ROUND_HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);

        log.info("[Retail Type 2 {}] Settlement amount due Selling Agent '{}' is '{}'", currency, sellingAgent, settlementAmountDueUSD);
        return settlementAmountDueUSD;
    }

    private static BigDecimal calculateThirdPartyAmountDueUSD(String sellingAgent, String currency, Integer thirdPartyValueFrequency, BigDecimal thirdPartyFee) {
        BigDecimal thirdPartyAmountDueUSD = new BigDecimal(thirdPartyValueFrequency)
                .multiply(thirdPartyFee)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Third Party amount due USD Selling Agent '{}' is '{}'", currency, sellingAgent, thirdPartyAmountDueUSD);
        return thirdPartyAmountDueUSD;
    }


    private static BigDecimal calculateSubTotalUSD(String sellingAgent, String currency, BigDecimal safekeepingAmountDue, BigDecimal transactionSettlementAmountDue, BigDecimal adHocReportAmountDue, BigDecimal thirdPartyAmountDue) {
        BigDecimal subTotalUSD = safekeepingAmountDue
                .add(transactionSettlementAmountDue)
                .add(adHocReportAmountDue)
                .add(thirdPartyAmountDue)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Sub total USD Selling Agent '{}' is '{}'", currency, sellingAgent, subTotalUSD);
        return subTotalUSD;
    }


    private static BigDecimal calculateVATAmountDueUSD(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDueUSD = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] VAT amount due USD Selling Agent '{}' is '{}'", currency, sellingAgent, subTotal);
        return vatAmountDueUSD;
    }


    private static BigDecimal calculateTotalAmountDueUSD(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDueUSD = subTotal.add(vatAmountDue)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2 {}] Total amount due USD Selling Agent '{}' is '{}'", currency, sellingAgent, totalAmountDueUSD);
        return totalAmountDueUSD;
    }

    private static List<Retail2QueryResultDTO> mapToDTOList(List<Object[]> result) {
        return result.stream()
                .map(data -> {
                    BigDecimal valueLastBalance = data[3] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[3]);
                    BigDecimal valueSumFee = data[4] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[4]);
                    return Retail2QueryResultDTO.builder()
                                    .year((Integer) data[0])
                                    .month((String) data[1])
                                    .sellingAgent((String) data[2])
                                    .lastBalance(valueLastBalance)
                                    .sumFee(valueSumFee)
                                    .build();
                })
                .collect(Collectors.toList());
    }

    private static Retail2QueryResultDTO mapToDTO(List<Object[]> result) {
        Double lastBalance = (Double) result.get(0)[3];
        Double sumFee = (Double) result.get(0)[4];

        BigDecimal valueLastBalance = lastBalance == null ? BigDecimal.ZERO : BigDecimal.valueOf(lastBalance);
        BigDecimal valueSumFee = sumFee == null ? BigDecimal.ZERO : BigDecimal.valueOf(sumFee);

        return result.isEmpty() ? null : Retail2QueryResultDTO.builder()
                .year((Integer) result.get(0)[0])
                .month((String) result.get(0)[1])
                .sellingAgent((String) result.get(0)[2])
                .lastBalance(valueLastBalance)
                .sumFee(valueSumFee.setScale(2, RoundingMode.HALF_UP))
                .build();
    }

}
