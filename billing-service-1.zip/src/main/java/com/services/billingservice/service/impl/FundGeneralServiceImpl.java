package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.UpdateApprovalStatusBillingFundRequest;
import com.services.billingservice.dto.fund.UpdateBillingFundRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.FundGeneralService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundGeneralServiceImpl implements FundGeneralService {

    private final BillingFundRepository billingFundRepository;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String updateApprovalStatus(UpdateApprovalStatusBillingFundRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            ApprovalStatus approvalStatus;
            BillingStatus billingStatus;

            if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Approved.getStatus())) {
                approvalStatus = ApprovalStatus.Approved;
            } else if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Rejected.getStatus())) {
                approvalStatus = ApprovalStatus.Rejected;
            } else {
                approvalStatus = ApprovalStatus.Pending;
            }

            if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Reviewed.getStatus())) {
                billingStatus = BillingStatus.Reviewed;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Approved.getStatus())) {
                billingStatus = BillingStatus.Approved;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Rejected.getStatus())) {
                billingStatus = BillingStatus.Rejected;
            } else {
                billingStatus = BillingStatus.Generated;
            }

            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingFund billingFund : billingFundList) {
                billingFund.setApprovalStatus(approvalStatus);
                billingFund.setBillingStatus(billingStatus);
                if (!StringUtils.isEmpty(request.getInputerId())) billingFund.setInputerId(request.getInputerId());
                if (!StringUtils.isEmpty(request.getInputerIPAddress())) billingFund.setInputerIPAddress(request.getInputerIPAddress());
                if (!StringUtils.isEmpty(request.getApproverId())) billingFund.setApproverId(request.getApproverId());
                if (!StringUtils.isEmpty(request.getApproverIPAddress())) billingFund.setApproverIPAddress(request.getApproverIPAddress());
            }

            billingFundRepository.saveAll(billingFundList);

            return "Successfully update approval status '" + approvalStatus + "' and billing status '" + billingStatus;
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when update approval status Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingFund billingFund : billingFundList) {
                billingFundRepository.delete(billingFund);
            }

            return "Successfully delete Billing Fund with total : " + billingFundList.size();
        } catch (Exception e) {
            throw new ConnectionDatabaseException("Error when delete Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public List<BillingFundDTO> updateAll(List<UpdateBillingFundRequest> requestList) {
        List<BillingFund> billingFundList = new ArrayList<>();

        // looping request list
        for (UpdateBillingFundRequest request : requestList) {
            Long id = request.getId();

            // find billing fund by id
            BillingFund billingFund = billingFundRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException("Billing Fund with id '" + id + "is not found"));

            BeanUtil.copyNotNullProperties(request, billingFund); // pastikan yg lolos adalah data yang bukan null


            // update object billing fund
            billingFund.setUpdatedAt(Instant.now());

            billingFundList.add(billingFund);
        }

        List<BillingFund> billingFundListSaved = billingFundRepository.saveAll(billingFundList);

        return mapToDTOList(billingFundListSaved);
    }


    private static ApprovalStatus checkEnumApprovalStatus(String approvalStatus) {
        ApprovalStatus status;
        if (ApprovalStatus.Pending.getStatus().equalsIgnoreCase(approvalStatus)) {
            status = ApprovalStatus.Pending;
        } else if (ApprovalStatus.Approved.getStatus().equalsIgnoreCase(approvalStatus)) {
            status = ApprovalStatus.Approved;
        } else {
            status = ApprovalStatus.Rejected;
        }

        return status;
    }

    private static BillingStatus checkEnumBillingStatus(String billingStatus) {
        BillingStatus status;

        if (BillingStatus.Generated.getStatus().equalsIgnoreCase(billingStatus)) {
            status = BillingStatus.Generated;
        } else if (BillingStatus.Reviewed.getStatus().equalsIgnoreCase(billingStatus)) {
            status = BillingStatus.Reviewed;
        } else if (BillingStatus.Approved.getStatus().equalsIgnoreCase(billingStatus)) {
            status = BillingStatus.Approved;
        } else {
            status = BillingStatus.Rejected;
        }

        return status;
    }


    private static BillingFundDTO mapToDTO(BillingFund billingFund) {
        return BillingFundDTO.builder()
                .id(billingFund.getId())
                .createdAt(billingFund.getCreatedAt())
                .updatedAt(billingFund.getUpdatedAt())
                .billingStatus(billingFund.getBillingStatus().getStatus())
                .approvalStatus(billingFund.getApprovalStatus().getStatus())
                .customerCode(billingFund.getCustomerCode())
                .customerName(billingFund.getCustomerName())
                .month(billingFund.getMonth())
                .year(String.valueOf(billingFund.getYear()))
                .billingNumber(billingFund.getBillingNumber())
                .billingPeriod(billingFund.getBillingPeriod())
                .billingStatementDate(billingFund.getBillingStatementDate())
                .billingPaymentDueDate(billingFund.getBillingPaymentDueDate())
                .billingCategory(billingFund.getBillingCategory())
                .billingType(billingFund.getBillingType())
                .billingTemplate(billingFund.getBillingTemplate())
                .investmentManagementName(billingFund.getInvestmentManagementName())
                .investmentManagementAddress1(billingFund.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingFund.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingFund.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingFund.getInvestmentManagementAddress4())
                .productName(billingFund.getAccountName())
                .accountName(billingFund.getAccountName())
                .accountNumber(billingFund.getAccountNumber())
                .customerFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getCustomerFee()))
                .accrualCustodialFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getAccrualCustodialFee()))
                .bis4TransactionValueFrequency(String.valueOf(billingFund.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionFee()))
                .bis4TransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getSubTotal()))
                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatAmountDue()))
                .kseiTransactionValueFrequency(String.valueOf(billingFund.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionFee()))
                .kseiTransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getTotalAmountDue()))
                .build();
    }

    private static List<BillingFundDTO> mapToDTOList(List<BillingFund> billingFundList) {
        return billingFundList.stream()
                .map(FundGeneralServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }
}
