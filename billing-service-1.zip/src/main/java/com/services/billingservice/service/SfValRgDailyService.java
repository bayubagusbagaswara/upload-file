package com.services.billingservice.service;

import com.services.billingservice.model.SfValRgDaily;

import java.time.LocalDate;
import java.util.List;

public interface SfValRgDailyService {

    String readFileAndInsertToDB(String filePath, String monthYear);

    List<SfValRgDaily> getAll();

    List<SfValRgDaily> findByMonthAndYear(String month, Integer year);
    List<SfValRgDaily> findRecapByMonthAndYear(String month, Integer year, LocalDate latestDate);
    List<SfValRgDaily> findRecapByAidAndMonthAndYear(String aid, String month, Integer year, LocalDate latestDate);
    List<SfValRgDaily> getAllByAid(String aid);
    List<SfValRgDaily> findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(String aid, String month, Integer year);
    List<SfValRgDaily> getAllRetailByAidAndTypeAndCurrencyAndPeriod(String aid, String sellingAgent, String currency, LocalDate date);

    List<SfValRgDaily> getAllByAidAndDate(String aid, String date);

    List<SfValRgDaily> getAllByAidAndSecurityName(String aid, String securityName);

    List<SfValRgDaily> findByAidAndSecurityNameAndMonthAndYear(String aid, String securityName, String month, Integer year);

    List<SfValRgDaily> getAllByAidAndMonthAndYear(String aid, String month, Integer year);

    String deleteAll();
}
