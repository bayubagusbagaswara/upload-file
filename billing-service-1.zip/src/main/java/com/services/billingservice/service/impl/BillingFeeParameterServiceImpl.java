package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.*;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.mi.InvestmentManagementResponse;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.mapper.FeeParameterMapper;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.model.BillingMI;
import com.services.billingservice.repository.BillingFeeParamRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingFeeParameterService;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFeeParameterServiceImpl implements BillingFeeParameterService {

    private static final String ID_NOT_FOUND = "Investment Management not found with id: ";
    private static final String CODE_NOT_FOUND = "Investment Management not found with code: ";
    private static final String UNKNOWN = "unknown";

    private final BillingFeeParamRepository feeParameterRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final FeeParameterMapper feeParameterMapper;

    public boolean isCodeAlreadyExists(String code) {
        return feeParameterRepository.existsByFeeCode(code);
    }

    @Override
    public FeeParameterResponse createSingleData(CreateFeeParameterRequest createFeeParameterRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data fee parameter with request: {}", createFeeParameterRequest);
        FeeParameterDTO feeParameterDTO = feeParameterMapper.mapFromCreateRequestToDto(createFeeParameterRequest);
        dataChangeDTO.setInputerId(createFeeParameterRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createFeeParameterRequest.getInputerIPAddress());
        return processFeeParameterCreation(feeParameterDTO, dataChangeDTO);
    }

    @Override
    public FeeParameterResponse createMultipleData(FeeParameterListRequest createFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create multiple fee parameter with request: {}", createFeeParameterListRequest);
        dataChangeDTO.setInputerId(createFeeParameterListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createFeeParameterListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (FeeParameterDTO feeParameterDTO : createFeeParameterListRequest.getFeeParameterDTOList()) {
            FeeParameterResponse response = processFeeParameterCreation(feeParameterDTO, dataChangeDTO);
            totalDataSuccess += response.getTotalDataSuccess();
            totalDataFailed += response.getTotalDataFailed();
            errorMessageList.addAll(response.getErrorMessageDTOList());
        }

        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private FeeParameterResponse processFeeParameterCreation(FeeParameterDTO feeParameterDTO, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            List<String> validationErrors = new ArrayList<>();
            validationCodeAlreadyExists(feeParameterDTO.getCode(), validationErrors);

            dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
            dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
            dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));

            if (validationErrors.isEmpty()) {
                dataChangeService.createChangeActionADD(dataChangeDTO, BillingFeeParam.class);
                totalDataSuccess++;
            } else {
                totalDataFailed++;
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getCode(), validationErrors);
                errorMessageList.add(errorMessageDTO);
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, errorMessageList);
            totalDataFailed++;
        }

        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeParameterResponse createSingleApprove(FeeParameterApproveRequest createFeeParameterListRequest) {
        log.info("Approve single fee parameter with request: {}", createFeeParameterListRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(investmentManagementApproveRequest.getDataChangeId());
        InvestmentManagementDTO investmentManagementDTO = investmentManagementApproveRequest.getData();

        try {
            List<String> errorMessages = new ArrayList<>();
            validationCodeAlreadyExists(investmentManagementDTO.getCode(), errorMessages);

            Errors errors = validateInvestmentManagementUsingValidator(investmentManagementDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(objectError -> errorMessages.add(objectError.getDefaultMessage()));
            }

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(investmentManagementApproveRequest.getDataChangeId());
            dataChangeDTO.setApproverId(investmentManagementApproveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(investmentManagementApproveRequest.getApproverIPAddress());

            if (!errorMessages.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(investmentManagementDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, errorMessages);
                totalDataFailed++;
            } else {
                BillingMI investmentManagement = investmentManagementMapper.createEntity(investmentManagementDTO, dataChangeDTO);
                investmentManagementRepository.save(investmentManagement);

                dataChangeDTO.setDescription("Successfully approve data change and save data investment management");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(investmentManagement)));
                dataChangeDTO.setEntityId(investmentManagement.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(investmentManagementDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new InvestmentManagementResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeParameterResponse updateMultipleData(FeeParameterListRequest updateFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public FeeParameterResponse updateSingleApprove(FeeParameterApproveRequest updateFeeParameterListRequest) {
        return null;
    }

    @Override
    public List<FeeParameterDTO> getAll() {
        List<BillingFeeParam> all = feeParameterRepository.findAll();
        return feeParameterMapper.mapToDTOList(all);
    }

    @Override
    public String deleteAll() {
        feeParameterRepository.deleteAll();
        return "Successfully delete all Fee Parameter";
    }

    @Override
    public BigDecimal getValueByName(String name) {
        BillingFeeParam billingFeeParam = feeParameterRepository.findByFeeName(name)
                .orElseThrow(() -> new DataNotFoundException("Fee Parameter not found with name: " + name));

        return billingFeeParam.getFeeValue();
    }

    @Override
    public Map<String, BigDecimal> getValueByNameList(List<String> nameList) {
        List<BillingFeeParam> feeParameterList = feeParameterRepository.findBillingFeeParamByFeeNameList(nameList);

        Map<String, BigDecimal> collect = feeParameterList.stream()
                .collect(Collectors.toMap(
                        BillingFeeParam::getFeeName,
                        BillingFeeParam::getFeeValue
                ));

        for (String name : nameList) {
            if (!collect.containsKey(name)) {
                throw new DataNotFoundException("Fee Parameter not found with name: " + name);
            }
        }

        return collect;
    }

    private void validationCodeAlreadyExists(String code, List<String> errorMessages) {
        if (isCodeAlreadyExists(code)) {
            errorMessages.add("Fee Parameter is already taken with code: " + code);
        }
    }

    private Errors validateFeeParameterUsingValidator(FeeParameterDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "feeParameterDTO");
        validator.validate(dto, errors);
        return errors;
    }


    private void handleDataNotFoundException(FeeParameterDTO feeParameterDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageList) {
        log.error("Investment Management not found with id: {}", feeParameterDTO != null ? feeParameterDTO.getCode() : UNKNOWN, e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeParameterDTO != null ? feeParameterDTO.getCode() : UNKNOWN, validationErrors));
    }

    private void handleGeneralError(FeeParameterDTO feeParameterDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeParameterDTO != null ? feeParameterDTO.getCode() : UNKNOWN, validationErrors));
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change ids not found");
            throw new DataNotFoundException("Data Change ids not found");
        }
    }

}
