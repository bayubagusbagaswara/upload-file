package com.services.billingservice.service.impl;

import com.services.billingservice.dto.fund.FeeReportRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.*;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.services.billingservice.enums.BillingCategory.FUND;
import static com.services.billingservice.enums.BillingType.TYPE_1;
import static com.services.billingservice.enums.FeeParameter.BI_SSSS;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundCalculateServiceImpl implements FundCalculateService {

    private final BillingCustomerService billingCustomerService;
    private final SkTranService skTranService;
    private final BillingFeeParameterService feeParamService;
    private final BillingNumberService billingNumberService;
    private final BillingFundRepository billingFundRepository;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(List<FeeReportRequest> request, String monthYear) {
        log.info("Start calculate Billing Fund with monthYear '{}'", monthYear);
        try {
            String billingCategory = FUND.getValue();
            String billingType = TYPE_1.getValue();

            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(monthYear);
            String month = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            List<String> nameList = new ArrayList<>();
            nameList.add(BI_SSSS.getValue());
            nameList.add(KSEI.getValue());
            nameList.add(VAT.getValue());

            Map<String, BigDecimal> feeParameterMap = feeParamService.getValueByNameList(nameList);
            BigDecimal bis4TransactionFee = feeParameterMap.get(BI_SSSS.getValue());
            BigDecimal kseiTransactionFee = feeParameterMap.get(KSEI.getValue());
            BigDecimal vatFee = feeParameterMap.get(VAT.getValue());

            List<BillingFund> billingFundList = new ArrayList<>();
            Instant dateNow = Instant.now();

            BigDecimal accrualCustodialFee;
            int transactionBISSSSTotal;
            int transactionCBESTTotal;

            BigDecimal bis4AmountDue;
            BigDecimal subTotal;
            BigDecimal vatAmountDue;
            BigDecimal kseiAmountDue;
            BigDecimal totalAmountDue;

            // TODO: Get Billing customer by AID and month and year
            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(billingCategory, billingType);

            for (FeeReportRequest feeReportRequest : request) {
                String aid = feeReportRequest.getPortfolioCode();
                BigDecimal customerFee = feeReportRequest.getCustomerFee();

                for (BillingCustomer billingCustomer : billingCustomerList) {
                    if (billingCustomer.getCustomerCode().equalsIgnoreCase(aid)) {
                        String miCode = billingCustomer.getMiCode();

                        InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                        List<SkTransaction> skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, month, year);

                        if (!skTransactionList.isEmpty()) {
                            int[] filteredTransactionsType = skTranService.filterTransactionsType(skTransactionList);
                            transactionCBESTTotal = filteredTransactionsType[0];
                            transactionBISSSSTotal = filteredTransactionsType[1];

                            accrualCustodialFee = calculateAccrualCustodialFee(customerFee);

                            bis4AmountDue = calculateBis4AmountDue(transactionBISSSSTotal, bis4TransactionFee);

                            subTotal = calculateSubTotal(accrualCustodialFee, bis4AmountDue);

                            vatAmountDue = calculateVATAmountDue(subTotal, vatFee);

                            kseiAmountDue = calculateKSEIAmountDue(transactionCBESTTotal, kseiTransactionFee);

                            totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue, kseiAmountDue);

                            Optional<BillingFund> existingBillingFund = billingFundRepository.findByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                                    aid, FUND.getValue(), TYPE_1.getValue(), month, year
                            );

                            if (existingBillingFund.isPresent()) {
                                BillingFund existBillingFund = existingBillingFund.get();
                                String billingNumber = existBillingFund.getBillingNumber();
                                billingFundRepository.delete(existBillingFund);
                                billingNumberService.deleteByBillingNumber(billingNumber);
                            }

                            BillingFund billingFund = BillingFund.builder()
                                    .createdAt(dateNow)
                                    .updatedAt(dateNow)
                                    .approvalStatus(ApprovalStatus.Pending)
                                    .billingStatus(BillingStatus.Generated)
                                    .customerCode(billingCustomer.getCustomerCode())
                                    .customerName(billingCustomer.getCustomerName())
                                    .month(month)
                                    .year(year)
                                    .billingPeriod(month + " " + year)
                                    .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                                    .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                                    .billingCategory(billingCustomer.getBillingCategory())
                                    .billingType(billingCustomer.getBillingType())
                                    .billingTemplate(billingCustomer.getBillingTemplate())
                                    .investmentManagementName(billingMIDTO.getName())
                                    .investmentManagementAddress1(billingMIDTO.getAddress1())
                                    .investmentManagementAddress2(billingMIDTO.getAddress2())
                                    .investmentManagementAddress3(billingMIDTO.getAddress3())
                                    .investmentManagementAddress4(billingMIDTO.getAddress4())
                                    .investmentManagementEmail(billingMIDTO.getEmail())
                                    .accountName(billingCustomer.getAccountName())
                                    .accountNumber(billingCustomer.getAccount())
                                    //.accountBank(billingCustomer.getAccountBank())
                                    .currency(billingCustomer.getCurrency())
                                    .customerFee(customerFee)
                                    .accrualCustodialFee(accrualCustodialFee)
                                    .bis4TransactionValueFrequency(transactionBISSSSTotal)
                                    .bis4TransactionFee(bis4TransactionFee)
                                    .bis4TransactionAmountDue(bis4AmountDue)
                                    .subTotal(subTotal)
                                    .vatFee(vatFee)
                                    .vatAmountDue(vatAmountDue)
                                    .kseiTransactionValueFrequency(transactionCBESTTotal)
                                    .kseiTransactionFee(kseiTransactionFee)
                                    .kseiTransactionAmountDue(kseiAmountDue)
                                    .totalAmountDue(totalAmountDue)
                                    .build();
                            billingFundList.add(billingFund);
                        }
                    } else {
                        log.info("AID '{}' is not match with Customer Code", aid);
                    }
                }
            }

            List<String> numberList = billingNumberService.generateNumberList(billingFundList.size(), month, year);

            int billingFundListSize = billingFundList.size();
            for (int i = 0; i < billingFundListSize; i++) {
                BillingFund billingFund = billingFundList.get(i);
                String billingNumber = numberList.get(i);
                billingFund.setBillingNumber(billingNumber);
            }

            List<BillingFund> billingFundListSaved = billingFundRepository.saveAll(billingFundList);
            billingNumberService.saveAll(numberList);

            log.info("Finished calculate Billing Fund with month '{}' and year '{}'", month, year);
            return "Successfully calculated Billing Funds with a total : " + billingFundListSaved.size();
        } catch (Exception e) {
            log.error("Error when calculate Billing Funds : " + e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Funds : " + e.getMessage());
        }
    }

    private static BigDecimal calculateAccrualCustodialFee(BigDecimal customerFee) {
        return customerFee
                .divide(BigDecimal.valueOf(1.11), 4, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateBis4AmountDue(int transactionBISSSSTotal, BigDecimal bis4TransactionFee) {
        return new BigDecimal(transactionBISSSSTotal)
                .multiply(bis4TransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateSubTotal(BigDecimal accrualCustodialFee, BigDecimal bis4AmountDue) {
        return accrualCustodialFee.add(bis4AmountDue).setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal subTotal, BigDecimal vatFee) {
        return subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateKSEIAmountDue(int transactionCBESTTotal, BigDecimal kseiTransactionFee) {
        return new BigDecimal(transactionCBESTTotal)
                .multiply(kseiTransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue, BigDecimal kseiAmountDue) {
        return subTotal
                .add(vatAmountDue)
                .add(kseiAmountDue)
                .setScale(0, RoundingMode.HALF_UP);
    }

}
