package com.services.billingservice.service.impl;

import com.services.billingservice.dto.assettransfercustomer.*;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.repository.BillingNasabahTransferAssetRepository;
import com.services.billingservice.service.BillingNasabahTransferAssetService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor

public class BillingNasabahTransferAssetServiceImpl implements BillingNasabahTransferAssetService {

    private final BillingNasabahTransferAssetRepository nasabahTransferAssetRepository;

    @Override
    public AssetTransferCustomerResponse createSingleData(CreateAssetTransferCustomerRequest createAssetTransferCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public AssetTransferCustomerResponse createSingleApprove(AssetTransferCustomerApproveRequest createAssetTransferCustomerListRequest) {
        return null;
    }

    @Override
    public AssetTransferCustomerResponse updateSingleData(UpdateAssetTransferCustomerRequest updateAssetTransferCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public AssetTransferCustomerResponse updateMultipleData(AssetTransferCustomerListRequest updateAssetTransferCustomerListRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public AssetTransferCustomerResponse updateSingleApprove(AssetTransferCustomerApproveRequest updateAssetTransferCustomerListRequest) {
        return null;
    }

    @Override
    public AssetTransferCustomerResponse deleteSingleData(DeleteAssetTransferCustomerRequest deleteAssetTransferCustomerRequest, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }

    @Override
    public AssetTransferCustomerResponse deleteSingleApprove(AssetTransferCustomerApproveRequest deleteAssetTransferCustomerListRequest) {
        return null;
    }

    @Override
    public String deleteAll() {
        return null;
    }

    @Override
    public List<AssetTransferCustomerDTO> getAll() {
        return null;
    }
}
