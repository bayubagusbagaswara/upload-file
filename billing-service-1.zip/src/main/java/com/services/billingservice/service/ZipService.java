package com.services.billingservice.service;

import java.io.File;
import java.io.IOException;
import java.util.zip.ZipOutputStream;

public interface ZipService {

    void zipFolder(File folder, String parentFolderName, ZipOutputStream zos) throws IOException;

}
