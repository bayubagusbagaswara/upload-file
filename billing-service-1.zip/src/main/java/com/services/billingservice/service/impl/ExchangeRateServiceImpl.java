package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.exchangerate.*;
import com.services.billingservice.exception.DataChangeException;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.ExchangeRate;
import com.services.billingservice.repository.ExchangeRateRepository;
import com.services.billingservice.service.ExchangeRateService;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ExchangeRateServiceImpl implements ExchangeRateService {

    private static final DateTimeFormatter formatter =  DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final ExchangeRateRepository exchangeRateRepository;
    private final Validator validator;
    private final ObjectMapper objectMapper;

    @Override
    public ExchangeRateDTO create(CreateExchangeRateRequest request) {
        String currency = request.getCurrency();
        LocalDate date = ConvertDateUtil.parseDateOrDefault(request.getDate(), formatter);
        BigDecimal value = ConvertBigDecimalUtil.parseBigDecimalOrDefault(request.getValue());

        ExchangeRate exchangeRate = ExchangeRate.builder()
                .date(date)
                .currency(currency)
                .value(value)
                .build();

        return mapToDTO(exchangeRateRepository.save(exchangeRate));
    }

    @Override
    public List<ExchangeRateDTO> getAll() {
        return mapToDTOList(exchangeRateRepository.findAll());
    }

    @Override
    public ExchangeRateDTO getLatestDataByCurrency(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findLatestExchangeRateByCurrency(currency)
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate with currency '" + currency + "' not found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO getLatestData() {
        ExchangeRate exchangeRate = exchangeRateRepository.findLatestExchangeRate()
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate not found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO getByCurrency(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findByCurrency(currency)
                .orElseThrow(() -> new DataNotFoundException("Exchange Rate with currency '" + currency + "' not found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO updateById(String id, CreateExchangeRateRequest request) {
        LocalDate date = ConvertDateUtil.parseDateOrDefault(request.getDate(), formatter);
        BigDecimal value = ConvertBigDecimalUtil.parseBigDecimalOrDefault(request.getValue());

        ExchangeRate exchangeRate = exchangeRateRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Data Not Found"));

        if (request.getDate() != null) {
            exchangeRate.setDate(date);
        }

        if (request.getValue() != null) {
            exchangeRate.setValue(value);
        }

        ExchangeRate dataSaved = exchangeRateRepository.save(exchangeRate);
        return mapToDTO(dataSaved);
    }

    @Override
    public ExchangeRateDTO getById(String id) {
        ExchangeRate exchangeRate = exchangeRateRepository.findById(Long.valueOf(id))
                .orElseThrow(() ->new DataNotFoundException("Data Not Found"));
        return mapToDTO(exchangeRate);
    }

    @Override
    public String deleteByCurrency(String currency) {
        ExchangeRate exchangeRate = exchangeRateRepository.findByCurrency(currency).orElseThrow(() -> new DataNotFoundException("Exchange rate with currency '" + currency + "' not found"));

        exchangeRateRepository.delete(exchangeRate);

        return "Successfully delete exchange rate by currency: " + currency;
    }

    @Override
    public ExchangeRateResponse update(UpdateExchangeRateRequest request, BillingDataChangeDTO dataChangeDTO) {
        return null;
    }


    private Errors validateExchangeRateDTO(ExchangeRateDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "exchangeRateDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private static ExchangeRateDTO mapToDTO(ExchangeRate exchangeRate) {
        return ExchangeRateDTO.builder()
                .id(exchangeRate.getId())
                .date(String.valueOf(exchangeRate.getDate()))
                .currency(exchangeRate.getCurrency())
                .value(exchangeRate.getValue().toString())
                .build();
    }

    private static List<ExchangeRateDTO> mapToDTOList(List<ExchangeRate> exchangeRateList) {
        return exchangeRateList.stream()
                .map(ExchangeRateServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

}
