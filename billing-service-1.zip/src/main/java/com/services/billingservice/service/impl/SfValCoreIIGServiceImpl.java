package com.services.billingservice.service.impl;

import com.services.billingservice.dto.request.CreateSfValCoreIIGRequest;
import com.services.billingservice.exception.ConnectionDatabaseException;
import com.services.billingservice.model.SfValCoreIIG;
import com.services.billingservice.repository.SfValCoreIIGRepository;
import com.services.billingservice.service.SfValCoreIIGService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class SfValCoreIIGServiceImpl implements SfValCoreIIGService {

    private final SfValCoreIIGRepository sfValCoreIIGRepository;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String create(CreateSfValCoreIIGRequest request) {
        String customerCode = request.getCustomerCode();
        String customerName = request.getCustomerName();

        BigDecimal totalHolding = request.getTotalHolding().isEmpty() ? BigDecimal.ZERO : new BigDecimal(request.getTotalHolding());
        Integer priceTRUB = request.getPriceTRUB().isEmpty() ? 0 : Integer.parseInt(request.getPriceTRUB());

        BigDecimal safeFee = new BigDecimal(0.0005);

        BigDecimal totalMarketValue = calculateTotalMarketValue(totalHolding, priceTRUB);
        BigDecimal safekeepingFee = calculateSafekeepingFee(totalMarketValue, safeFee);

        log.info("Customer Code '{}' " +
                "Customer Name '{}' " +
                "Total Holding '{}'", customerCode, customerName, totalHolding);

        List<SfValCoreIIG> sfValCoreIIGList = new ArrayList<>();

        for (int i = 1; i <= 31; i++) {
            SfValCoreIIG sfvalCoreIIG = SfValCoreIIG.builder()
                    .customerCode(customerCode)
                    .customerCodeGroup("IIG")
                    .customerName(customerName)
                    .date(i)
                    .totalHolding(totalHolding)
                    .priceTRUB(priceTRUB)
                    .totalMarketValue(totalMarketValue)
                    .safekeepingFee(safekeepingFee)
                    .build();

            sfValCoreIIGList.add(sfvalCoreIIG);
        }

        // save all to the database
        List<SfValCoreIIG> sfValCoreIIGListSaved = sfValCoreIIGRepository.saveAll(sfValCoreIIGList);

        return "Successfully created sfVal Core IIG with total: " + sfValCoreIIGListSaved.size();
    }

    @Override
    public List<SfValCoreIIG> getAll() {
        log.info("Start get all ");
        return sfValCoreIIGRepository.findAll();
    }

    @Override
    public List<SfValCoreIIG> getAllByCustomerCode(String customerCode) {
        log.info("Start get all by customer code : {}", customerCode);
        return sfValCoreIIGRepository.findAllByCustomerCode(customerCode);
    }

    @Override
    public List<SfValCoreIIG> getAllByAidAndMonthAndYear(String aid, String monthName, Integer year) {
        log.info("Start get all SfVal Core IIG by customer code '{}', month '{}', year '{}'", aid, monthName, year);

        List<SfValCoreIIG> sfValCoreIIGList = sfValCoreIIGRepository.findAllByCustomerCode(aid);

        log.info("SfVal Core IIG List size: {}", sfValCoreIIGList.size());

        String monthYearFormat = monthName + " " + year;
        LocalDate lastDate = convertDateUtil.getLatestDateOfMonthYear(monthYearFormat);

        int dayOfMonth = lastDate.getDayOfMonth();
        log.info("Day of Month : {}", dayOfMonth);

        List<SfValCoreIIG> takenData = sfValCoreIIGList.stream()
                .limit(dayOfMonth)
                .collect(Collectors.toList());

        for (SfValCoreIIG takenDatum : takenData) {
            log.info("Date: {}", takenDatum.getDate());
        }

        log.info("Taken data size : {}", takenData.size());
        return takenData;
    }

    @Override
    public String deleteAll() {
        try {
            sfValCoreIIGRepository.deleteAll();
            return "Successfully deleted all SfVal Core IIG";
        } catch (Exception e) {
            log.error("Error when delete all SfVal Core IIG : " + e.getMessage());
            throw new ConnectionDatabaseException("Error when delete all SfVal Core IIG: " + e.getMessage());
        }
    }

    private static BigDecimal calculateTotalMarketValue(BigDecimal totalHolding, Integer priceTRUB) {
        BigDecimal totalMarketValue = totalHolding
                .multiply(new BigDecimal(priceTRUB))
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[SfVal Core IIG] Total market value '{}'", totalMarketValue);
        return totalMarketValue;
    }

    private static BigDecimal calculateSafekeepingFee(BigDecimal totalMarketValue, BigDecimal safeFee) {
        return totalMarketValue
                .multiply(safeFee)
                .divide(new BigDecimal(365), 2, RoundingMode.HALF_UP);
    }

}
