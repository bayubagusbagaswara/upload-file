package com.services.billingservice.service;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.BillingFundListProcessDTO;
import com.services.billingservice.model.BillingFund;

import java.util.List;

public interface FundGeneratePDFService {

    List<BillingFundDTO> getAll();

    List<BillingFundListProcessDTO> getAllListProcess();

    List<BillingFundListProcessDTO> getAllListPendingApprove();

    List<BillingFundDTO> findByMonthAndYear(String month, Integer year);

    List<BillingFundDTO> findByMonthAndYearAndBillingCategoryAndBillingType(String month, Integer year, String category, String type);

    String generatePDF(String category, String monthYear);

    String deleteAll();

}
