package com.services.billingservice.service;

import com.services.billingservice.dto.BillingNumberDTO;

import java.util.List;

public interface BillingNumberService {

    String saveAll(List<String> numberList);

    Integer getMaxSequenceNumberByMonthAndYear(String month, Integer year);

    List<BillingNumberDTO> getAll();

    List<String> generateNumberList(Integer billingSize, String month, Integer year);

    String deleteByBillingNumber(String billingNumber);
}
