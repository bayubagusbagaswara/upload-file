package com.services.billingservice.repository;

import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingDataChange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillingDataChangeRepository extends JpaRepository<BillingDataChange, Long> {

    List<BillingDataChange> findByApprovalStatus(ApprovalStatus ApprovalStatus);

    List<BillingDataChange> findByEntityClassName(String entityClassName);

    @Query(value = "SELECT * FROM billing_data_change WHERE approval_status = 'Pending'", nativeQuery = true)
    List<BillingDataChange> searchAllByApprovalStatusPending();

    @Query(value = "SELECT * FROM billing_data_change WHERE id = :idData AND approval_status = 'Pending'", nativeQuery = true)
    BillingDataChange searchDataForApproveOrReject(@Param("idData") Long id);

    @Query(value = "SELECT DISTINCT menu FROM billing_data_change WHERE ISNULL(menu, '') != '' ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenu();

    @Query(value = "SELECT DISTINCT menu FROM billing_data_change WHERE ISNULL(menu, '') != '' AND approval_status = :approvalStatus ORDER BY menu ASC", nativeQuery = true)
    List<String> findAllMenuByApprovalStatus(String approvalStatus);

    @Query(value = "SELECT CASE WHEN COUNT(*) = :listSize THEN 1 ELSE 0 END " +
            "FROM bill_data_change WHERE id IN :idList", nativeQuery = true)
    Boolean existsByIdList(@Param("idList") List<Long> idList, @Param("listSize") Integer listSize);

    @Query(value = "SELECT CASE WHEN COUNT(*) = :listSize THEN true ELSE false END " +
            "FROM BillingDataChange WHERE id IN :idList and approvalStatus = :status")
    Boolean existsByIdListAndStatus(@Param("idList") List<Long> idList,
                                    @Param("listSize") Long listSize,
                                    @Param("status") ApprovalStatus status);

    long countByIdIn(List<Long> idList);

    List<BillingDataChange> findByIdIn(List<Long> idList);

    List<BillingDataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus);
}
