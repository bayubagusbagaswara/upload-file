package com.services.billingservice.repository;

import com.services.billingservice.model.SkTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SkTransactionRepository extends JpaRepository<SkTransaction, Long> {


    @Query(value = "SELECT * FROM bill_sktran WHERE portfolio_code = :portfolioCode", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCode(@Param("portfolioCode") String portfolioCode);

    @Query(value = "SELECT * FROM bill_sktran " +
            "WHERE portfolio_code = :portfolioCode " +
            "AND system = :system", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCodeAndSystem(
            @Param("portfolioCode") String portfolioCode,
            @Param("system") String system
    );

    @Query(value = "SELECT * FROM bill_sktran " +
            "WHERE portfolio_code = :portfolioCode " +
            "AND month = :monthName " +
            "AND year = :year " +
            "ORDER BY portfolio_code, security_short_name, trade_date, settlement_date", nativeQuery = true)
    List<SkTransaction> findAllByPortfolioCodeAndMonthAndYear(
            @Param("portfolioCode") String portfolioCode,
            @Param("monthName") String monthName,
            @Param("year") int year);

    @Query(value = "EXEC sp_detail_account_transaction :date, :aid, :sellingAgent, :currency ", nativeQuery = true)
    List<SkTransaction> getAllRetailByAidAndTypeAndCurrencyAndPeriod(
            @Param("aid") String aid,
            @Param("sellingAgent") String sellingAgent,
            @Param("currency") String currency,
            @Param("date") LocalDate date);

    @Modifying
    @Query(value = "DELETE FROM bill_sktran WHERE month = :month AND year = :year", nativeQuery = true)
    void deleteByMonthAndYearNative(@Param("month") String month, @Param("year") Integer year);

}
