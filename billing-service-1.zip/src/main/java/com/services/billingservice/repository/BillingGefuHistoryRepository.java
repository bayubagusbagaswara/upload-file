package com.services.billingservice.repository;

import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingGefuProcessHistory;
import com.services.billingservice.model.BillingNumber;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingGefuHistoryRepository extends JpaRepository<BillingGefuProcessHistory, Long> {

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE fileName = :fileName ", nativeQuery = true)
    BillingGefuProcessHistory findByFileName(
            @Param("fileName") String fileName);

    @Query(value = "SELECT * FROM billing_gefu_process_history  " +
            "WHERE id = :id ", nativeQuery = true)
    BillingGefuProcessHistory findById(
            @Param("id") long id);


}
