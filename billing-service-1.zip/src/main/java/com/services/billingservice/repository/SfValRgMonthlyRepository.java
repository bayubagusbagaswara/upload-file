package com.services.billingservice.repository;

import com.services.billingservice.model.SfValRgMonthly;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SfValRgMonthlyRepository extends JpaRepository<SfValRgMonthly, Long> {


    @Query(value = "SELECT * FROM bill_sfval_rg_monthly WHERE aid = :aid", nativeQuery = true)
    List<SfValRgMonthly> findAllByAid(@Param("aid") String aid);

    @Query(value = "SELECT * FROM bill_sfval_rg_monthly WHERE security_name = :securityName", nativeQuery = true)
    List<SfValRgMonthly> findAllBySecurityName(@Param("securityName") String securityName);

    @Query(value = "SELECT * FROM bill_sfval_rg_monthly WHERE aid = :aid AND security_name = :securityName", nativeQuery = true)
    List<SfValRgMonthly> findAllByAidAndSecurityName(@Param("aid") String aid, @Param("securityName") String securityName);

    @Query(value = "SELECT * FROM bill_sfval_rg_monthly " +
            "WHERE aid = :aid " +
            "AND month = :month " +
            "AND year = :year " +
            "ORDER BY aid, security_name, date", nativeQuery = true)
    List<SfValRgMonthly> findAllByAidAndMonthAndYear(
            @Param("aid") String aid,
            @Param("month") String monthName,
            @Param("year") int year
    );

    List<SfValRgMonthly> findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(String aid, String month, Integer year);

    @Modifying
    @Query(value = "DELETE FROM bill_sfval_rg_monthly WHERE month = :month AND year = :year", nativeQuery = true)
    void deleteByMonthAndYearNative(@Param("month") String month, @Param("year") Integer year);

}
