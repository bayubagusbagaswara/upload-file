package com.services.billingservice.model;


import lombok.Data;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Data
@Table(name = "billing_report_generator")
public class BillingReportGenerator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_at")
    private Instant createdAt;

    @Column(name = "investment_management_name")
    private String investmentManagementName;

    @Column(name = "investment_management_email")
    private String investmentManagementEmail;

    @Column(name = "bill_customer_code")
    private String customerCode;

    @Column(name =  "bill_customer_name")
    private String customerName;

    @Column(name = "bill_category")
    private String category;

    @Column(name =  "bill_type")
    private String type;

    @Column(name = "currency")
    private String currency;

    @Column(name = "bill_file_name")
    private  String fileName;

    @Column(name = "bill_file_path")
    private String filePath;

    @Column(name = "bill_period")
    private String period;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "bill_status")
    private String status;

    @Column(name = "bill_desc")
    private String desc;

}
