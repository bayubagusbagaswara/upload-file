package com.services.billingservice.model;

import com.services.billingservice.enums.GefuTransactionStatus;
import com.services.billingservice.enums.GefuTransactionType;
import com.services.billingservice.model.base.Approvable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_gefu_process_detail")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingGefuProcessDetail extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @ManyToOne
    @JoinColumn(name = "gefuProcessHistory", nullable = false)
    private BillingGefuProcessHistory gefuProcessHistory;

    @Column(nullable = false)
    private String GLName;

    @Column(nullable = false)
    private String GLNo;

    @Column(nullable = false)
    private String costCenter;

    @Column(nullable = false)
    private double totalAmount;

    @Column(nullable = false)
    private String fileName;

    @Column(nullable = false)
    private GefuTransactionType gefuTransactionType;

    @Column(nullable = true)
    private String reference;

    @Enumerated(EnumType.STRING)
    private GefuTransactionStatus status = GefuTransactionStatus.Pending;

    @Column
    private String description;
}
