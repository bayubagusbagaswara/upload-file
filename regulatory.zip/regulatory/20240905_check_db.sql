-- get all data lkpbu data source
select * from reg_lkpbu_data_source

-- drop table lkpbu data source
drop table reg_lkpbu_data_source

-- get all data lkpbu income
select * from reg_lkpbu_income
-- 11BINSFR0089
-- 11MNCAFR0087


select * from reg_lbabk_recon

select * from reg_lbabk_data_source
-- di table data source ada column: flag_recon_isin dan flag_recon_issuer


select * from regulatory_isin_code

select * from regulatory_isin_code

update regulatory_isin_code set country = 'US'


drop table reg_lkpbu_recon

-- 34375000.00
select * from reg_lkpbu_income where portfolio_code = '11BINS'
-- 34375000.00

select * from regulatory_isin_code

select * from regulatory_data_change order by id desc

select * from reg_lbabk_data_source

select * from reg_lkpbu_sample_data

select * from reg_exchange_rate

select * from reg_asset_under_custody;

select 24000 + 2228400.0 + 2795400.0

select * from reg_lkpbu_recon

select * from reg_lkpbu_data_source

select * from regulatory_data_change order by id desc

ALTER TABLE reg_lkpbu_data_source
DROP COLUMN flag_recon_isin;

ALTER TABLE reg_lkpbu_data_source
DROP COLUMN flag_recon_issuer;

select * from reg_data_not_found order by id desc

select * from regulatory_isin_code