# Billing Service


- Bagaimana penanda customer untuk menentukan bahwa customer ini adalah Fund, Core, atau Retail
- Jika termasuk customer Core, maka perlu penanda juga untuk type berapa

# Read File Excel

- membaca file excel KSEI Fee
- Ambil hanya beberapa kolom / cell


```json

[
  {
    "id": "1",
    "product": "FR001",
    "date": "2023-11-29"
  },
  {
    "id": "2",
    "product": "FR002",
    "date": "2023-11-29"
   },
   {
    "id": "3",
    "product": "FR001",
    "date": "2023-11-30"
   },
   {
    "id": "4",
    "product": "FR002",
    "date": "2023-11-30"
   }
]

```

## Generate Billing Core
- Trigger dari depan hanya mengirim type "Core" dan period "Nov 2023"
- Jadi di belakang, harusnya akan men-generate semua customer tipe core (type 1 - 11)

# Format File Billing

- Customer Code"_"Jenis (Fund/Retail/Core)"_"periode (mmyyyy)
- Customer Code adalah AID

# Account4
- Format = GL 812017.0000 CC 0706
- 812017 from field Account
- 0706 from field Cost Center

# Retail Type 4
- setiap throw exception pasti langsung keluar process, tapi data yg diawal bisa kesimpan

@Query("select case when count(c)> 0 then true else false end from BillingCustomer c where lower(c.customerCode) = lower(:customerCode) AND lower(COALESCE(c.subCode,'') = lower(COALESCE(:subCode, ''))")
boolean existsCustomerByCustomerCodeAndSubCode
(@Param("customerCode") String customerCode, @Param("subCode") String subCode);

PROSES INSERT DATA BILLING CUSTOMER TO DATABASE
1. Validation data cannot be empty, and numeric or alphabetic
2. Validation data enum
3. Validation Investment Management Code is existing
4. Validation Customer Code is already taken

select gl_credit_account_value, gl_credit_name from billing_gl_credit where gl_credit_name = 'GL Safekeeping Fee' and gl_billing_template = 'CORE_TEMPLATE_7'

Accrual Biaya Kustodian
BI-SSSS( Transaction )+ KSEI Fee ( Transaction )
Biaya Penyelesaian Transaksi + Biaya Pihak ketiga 
Biaya Penyimpanan 
Biaya S4+Biaya KSEI 
Biaya Transfer 
GL Dana Custodian
GL HAK Operasional
GL Safekeeping Fee
KSEI Fee (Transaction) 
Safekeeping Fee
Safekeeping Fee + KSEI Fee 
TAX/VAT
Transaction Handling
Transaction Handling + Transaction Handling Internal
VAT 

## Insert Data Billing Fee Parameter
```sql
INSERT INTO billing_fee_param(fee_code, fee_name, fee_value, fee_description) 
VALUES ('F001', 'VAT', 11),
      ('F002', 'BI-SSSS', 23000),
      ('F003', 'KSEI', 22200),
      ('F004', 'SECURITY_AGENT', 0),
      ('F005', 'OTHER', 0),
      ('F006', 'AD_HOC_REPORT', 5000),
      ('F007', 'SECURITY_AGENT', 0),
      ('F008', 'THIRD_PARTY', 23000),
      ('F009', 'TRANSACTION_HANDLING_INTERNAL', 10),
      ('F010', 'SETTLEMENT_MINIMUM_CTBC_USD', 200000),
      ('F011', 'FEE_TRANSFER', 50000)

```

## IIG Data

- Alam Manunggal
```json
{
  "customerCode": "IIGAM",
  "customerName": "PT Alam Manunggal",
  "totalHolding": "16139582231",
  "priceTRUB": "50"
}
```

- Indo Infrastruktur
```json
{
  "customerCode": "IIGII",
  "customerName": "PT Indo Infrastruktur",
  "totalHolding": "832268145",
  "priceTRUB": "50"
}
```

- Mandala Kapital
```json
{
  "customerCode": "IIGMK",
  "customerName": "PT Mandala Kapital",
  "totalHolding": "4419235000",
  "priceTRUB": "50"
}
```

# Mapping data between Template and Type

CORE_TEMPLATE_3 => type_1 => daily
CORE_TEMPLATE_3 => type_2 => daily
CORE_TEMPLATE_7 => type_3 => daily
CORE_TEMPLATE_3 => type_4 => daily (17OBAL => ITAMA)
CORE_TEMPLATE_5 => type_4 => daily (17OBAL => EB)
CORE_TEMPLATE_1 => type_5 => daily (without npwp)
CORE_TEMPLATE_4 => type_5 => daily (with npwp)
CORE_TEMPLATE_1 => type_6 => daily (without npwp)
CORE_TEMPLATE_4 => type_6 => daily (with npwp)
CORE_TEMPLATE_2 => type_7 => monthly
CORE_TEMPLATE_6 => type_8 => daily (IIG)
CORE_TEMPLATE_3 => type_9 => monthly (KONI)
CORE_TEMPLATE_8 => type_10 => monthly (Treasury)
CORE_TEMPLATE_3 => type_11 => urun dana

TYPE_4 = ksei safe code mandatory
TYPE_5 = ksei safe code mandatory
TYPE_6 = ksei safe code mandatory
TYPE_7 = ksei safe code mandatory
-- ksei safe code must be exists in type_4, type_5, type_6, type_7. If ksei safe code blank, then throw validation error

ALTER TABLE accounts
MODIFY COLUMN balance DECIMAL(18, 4);