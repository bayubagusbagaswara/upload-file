package com.services.billingservice.model;


import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_fee_schedule")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingFeeSchedule extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "fee_schedule_min")
    private BigDecimal feeMinimum;

    @Column(name = "fee_schedule_max")
    private BigDecimal feeMaximum;

    @Column(name = "fee_amount")
    private BigDecimal feeAmount;

}