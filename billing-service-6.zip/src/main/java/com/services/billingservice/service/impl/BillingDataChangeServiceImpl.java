package com.services.billingservice.service.impl;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ChangeAction;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.exception.InvalidInputException;
import com.services.billingservice.model.BillingDataChange;
import com.services.billingservice.repository.BillingDataChangeRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.utils.StringUtil;
import com.services.billingservice.utils.TableNameResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingDataChangeServiceImpl implements BillingDataChangeService {

    private final BillingDataChangeRepository dataChangeRepository;
    private static final String ERROR_MSG_NOT_FOUND_ID = "Data Change not found with id: ";

    @Override
    public BillingDataChangeDTO getById(Long id) {
        BillingDataChange dataChange = dataChangeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + id));
        return mapToDTO(dataChange);
    }

    @Override
    public List<BillingDataChange> getAll() {
        return dataChangeRepository.findAll();
    }

    @Override
    public String deleteAll() {
        dataChangeRepository.deleteAll();
        return "Successfully delete all data change from table";
    }

    @Override
    public <T> void createChangeActionADD(BillingDataChangeDTO dataChangeDTO, Class<T> clazz) {
        BillingDataChange dataChange = BillingDataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(dataChangeDTO.getInputerId())
                .inputDate(new Date())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Add)
                .entityId("")
                .entityClassName(clazz.getName())
                .tableName(TableNameResolver.getTableName(clazz))
                .jsonDataBefore("")
                .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
        dataChangeRepository.save(dataChange);
    }

    @Override
    public List<String> findAllMenu() {
        return dataChangeRepository.findAllMenu();
    }

    @Override
    public void approvalStatusIsRejected(BillingDataChangeDTO dataChangeDTO, List<String> errorMessageList) {
        BillingDataChange billingDataChange = dataChangeRepository.findById(dataChangeDTO.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + dataChangeDTO.getId()));

        billingDataChange.setApprovalStatus(ApprovalStatus.Rejected);
        billingDataChange.setApproverId(dataChangeDTO.getApproverId());
        billingDataChange.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        billingDataChange.setApproveDate(dataChangeDTO.getApproveDate() == null ? new Date() : dataChangeDTO.getApproveDate());
        billingDataChange.setJsonDataAfter(dataChangeDTO.getJsonDataAfter() == null ? "" : dataChangeDTO.getJsonDataAfter());
        billingDataChange.setJsonDataBefore(dataChangeDTO.getJsonDataBefore() == null ? "" : dataChangeDTO.getJsonDataBefore());
        billingDataChange.setEntityId(dataChangeDTO.getEntityId() == null ? "" : dataChangeDTO.getEntityId());
        billingDataChange.setDescription(StringUtil.joinStrings(errorMessageList));

        dataChangeRepository.save(billingDataChange);
    }

    @Override
    public void approvalStatusIsApproved(BillingDataChangeDTO dataChangeDTO) {
        BillingDataChange billingDataChange = dataChangeRepository.findById(dataChangeDTO.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + dataChangeDTO.getId()));

        billingDataChange.setApprovalStatus(ApprovalStatus.Approved);
        billingDataChange.setApproverId(dataChangeDTO.getApproverId());
        billingDataChange.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        billingDataChange.setApproveDate(dataChangeDTO.getApproveDate() == null ? new Date() : dataChangeDTO.getApproveDate());
        billingDataChange.setJsonDataAfter(dataChangeDTO.getJsonDataAfter() == null ? "" : dataChangeDTO.getJsonDataAfter());
        billingDataChange.setJsonDataBefore(dataChangeDTO.getJsonDataBefore() == null ? "" : dataChangeDTO.getJsonDataBefore());
        billingDataChange.setEntityId(dataChangeDTO.getEntityId());
        billingDataChange.setDescription(dataChangeDTO.getDescription());

        BillingDataChange save = dataChangeRepository.save(billingDataChange);
        log.info("Save data change edit: {}", save);
    }

    @Override
    public <T> void createChangeActionEDIT(BillingDataChangeDTO dataChangeDTO, Class<T> clazz) {
        BillingDataChange dataChange = BillingDataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(dataChangeDTO.getInputerId())
                .inputDate(new Date())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Edit)
                .entityId(dataChangeDTO.getEntityId())
                .entityClassName(clazz.getName())
                .tableName(TableNameResolver.getTableName(clazz))
                .jsonDataBefore(dataChangeDTO.getJsonDataBefore())
                .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
        BillingDataChange save = dataChangeRepository.save(dataChange);
    }

    @Override
    public <T> void createChangeActionDELETE(BillingDataChangeDTO dataChangeDTO, Class<T> clazz) {
        BillingDataChange dataChange = BillingDataChange.builder()
                .approvalStatus(ApprovalStatus.Pending)
                .inputerId(dataChangeDTO.getInputerId())
                .inputDate(new Date())
                .inputerIPAddress(dataChangeDTO.getInputerIPAddress())
                .approverId("")
                .approveDate(null)
                .approverIPAddress("")
                .action(ChangeAction.Delete)
                .entityId(dataChangeDTO.getEntityId())
                .entityClassName(clazz.getName())
                .tableName(TableNameResolver.getTableName(clazz))
                .jsonDataBefore(dataChangeDTO.getJsonDataBefore())
                .jsonDataAfter(dataChangeDTO.getJsonDataAfter())
                .description("")
                .methodHttp(dataChangeDTO.getMethodHttp())
                .endpoint(dataChangeDTO.getEndpoint())
                .isRequestBody(dataChangeDTO.isRequestBody())
                .isRequestParam(dataChangeDTO.isRequestParam())
                .isPathVariable(dataChangeDTO.isPathVariable())
                .menu(dataChangeDTO.getMenu())
                .build();
        dataChangeRepository.save(dataChange);
    }

    @Override
    public Boolean existByIdList(List<Long> idList, Integer idListSize) {
        Boolean existsByIdList = dataChangeRepository.existsByIdList(idList, idListSize);
        log.info("Status Exist by Id list: {}", existsByIdList);
        return existsByIdList;
    }

    @Override
    public Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus status) {
        Boolean existsByIdList = dataChangeRepository.existsByIdListAndStatus(idList, idListSize, status);
        log.info("Status Exist by Id list: {}", existsByIdList);
        return existsByIdList;
    }

    @Override
    public boolean areAllIdsExistInDatabase(List<Long> idList) {
        long countOfExistingIds = dataChangeRepository.countByIdIn(idList);
        List<BillingDataChange> existingDataChanges = dataChangeRepository.findByIdIn(idList);
        Set<Long> existingIds = existingDataChanges.stream()
                .map(BillingDataChange::getId)
                .collect(Collectors.toSet());
        Set<Long> idSet = new HashSet<>(idList);
        return existingIds.equals(idSet) && countOfExistingIds == idList.size();
    }

    @Override
    public boolean existById(Long id) {
        return dataChangeRepository.existsById(id);
    }

    @Override
    public void update(BillingDataChangeDTO dataChangeDTO) {
        log.info("Data Change dto: {}", dataChangeDTO);
        BillingDataChange dataChange = dataChangeRepository.findById(dataChangeDTO.getId())
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + dataChangeDTO.getId()));
        log.info("Data Change: {}", dataChangeDTO);

        dataChange.setApprovalStatus(dataChangeDTO.getApprovalStatus());
        dataChange.setInputerId(dataChangeDTO.getInputerId());
        dataChange.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        dataChange.setInputDate(dataChangeDTO.getInputDate());
        dataChange.setApproverId(dataChangeDTO.getApproverId());
        dataChange.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        dataChange.setApproveDate(dataChangeDTO.getApproveDate());
        dataChange.setDescription(dataChangeDTO.getDescription());
        if (!dataChangeDTO.getJsonDataAfter().isEmpty()) {
            dataChange.setJsonDataAfter(dataChangeDTO.getJsonDataAfter());
        }
        if (!dataChangeDTO.getJsonDataBefore().isEmpty()) {
            dataChange.setJsonDataBefore(dataChangeDTO.getJsonDataBefore());
        }

        dataChangeRepository.save(dataChange);
    }

    @Override
    public List<BillingDataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus) {
        return dataChangeRepository.findByMenuAndApprovalStatus(menu, approvalStatus);
    }

    @Override
    public void reject(Long id) {
        BillingDataChange billingDataChange = dataChangeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ERROR_MSG_NOT_FOUND_ID + id));
        billingDataChange.setApprovalStatus(ApprovalStatus.Rejected);
        dataChangeRepository.save(billingDataChange);
    }

    @Override
    public List<BillingDataChange> getAllByApprovalStatus(String approvalStatus) {
        // validate approvalStatus
        String approvalStatusEnum;
        if (ApprovalStatus.Pending.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = ApprovalStatus.Pending.name();
        } else if (ApprovalStatus.Approved.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = ApprovalStatus.Approved.name();
        } else if (ApprovalStatus.Rejected.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = ApprovalStatus.Rejected.name();
        } else {
            approvalStatusEnum = "";
        }

        if (approvalStatusEnum.isEmpty()) {
            throw new InvalidInputException("Approval Status enum not found: " + approvalStatus);
        }
        return dataChangeRepository.findAllByApprovalStatus(approvalStatusEnum);
    }

    @Override
    public String deleteById(Long id) {
        BillingDataChange dataChange = dataChangeRepository.findById(id).orElseThrow(() -> new DataNotFoundException("Data Change not found with id: " + id));
        dataChangeRepository.delete(dataChange);
        return "Successfully delete Data Change with id: " + id;
    }

    private static BillingDataChangeDTO mapToDTO(BillingDataChange dataChange) {
        return BillingDataChangeDTO.builder()
                .id(dataChange.getId())
                .approvalStatus(dataChange.getApprovalStatus())
                .inputerId(dataChange.getInputerId())
                .inputerIPAddress(dataChange.getInputerIPAddress())
                .inputDate(dataChange.getInputDate())
                .approverId(dataChange.getApproverId())
                .approverIPAddress(dataChange.getApproverIPAddress())
                .approveDate(dataChange.getApproveDate())
                .action(dataChange.getAction())
                .entityId(dataChange.getEntityId())
                .entityClassName(dataChange.getEntityClassName())
                .tableName(dataChange.getTableName())
                .jsonDataBefore(dataChange.getJsonDataBefore())
                .jsonDataAfter(dataChange.getJsonDataAfter())
                .description(dataChange.getDescription())
                .methodHttp(dataChange.getMethodHttp())
                .endpoint(dataChange.getEndpoint())
                .isRequestBody(dataChange.getIsRequestBody())
                .isRequestParam(dataChange.getIsRequestParam())
                .isPathVariable(dataChange.getIsPathVariable())
                .menu(dataChange.getMenu())
                .build();
    }

    private static List<BillingDataChangeDTO> mapToDTOList(List<BillingDataChange> dataChangeList) {
        return dataChangeList.stream()
                .map(BillingDataChangeServiceImpl::mapToDTO)
                .collect(Collectors.toList());
    }

}
