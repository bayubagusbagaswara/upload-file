package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.BillingCoreDTO;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.pdf.GeneratePDFResponse;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingCoreMapper;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.CoreGeneratePDFService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.constant.CoreConstant.*;
import static com.services.billingservice.constant.CoreConstant.SAFEKEEPING_FEE_PERIOD;

@Slf4j
@Service
@RequiredArgsConstructor
public class CoreGeneratePDFServiceImpl implements CoreGeneratePDFService {

    @Value("${base.path.billing.core}")
    private String basePathBillingCore;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private static final String DELIMITER = "/";
    private static final String BANK_ACCOUNT_BDI = "PT Bank Danamon Indonesia";

    private final BillingCoreRepository billingCoreRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingCoreMapper billingCoreMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;

    @Override
    public String generatePDF(CoreCalculateRequest request) {
        log.info("Start generate PDF Billing Core type: {}", request.getType());
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingCore> billingCoreList = billingCoreRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            GeneratePDFResponse generatePDFResponse = generateAndSavePdfStatements(billingCoreList);

            return "Successfully created a PDF file for Billing Fund with total data success: " + generatePDFResponse.getTotalDataSuccess()
                    + ", and total data failed: " + generatePDFResponse.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Core type '" + typeUpperCase + "' : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Core type '" + typeUpperCase + "' : " + e.getMessage());
        }
    }

    private GeneratePDFResponse generateAndSavePdfStatements(List<BillingCore> billingCoreList) {
        log.info("Start generate and save pdf statements Billing Core with size: {}", billingCoreList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        Instant dateNow = Instant.now();
        List<BillingCoreDTO> billingCoreDTOList = billingCoreMapper.mapToDTOList(billingCoreList);

        for (BillingCoreDTO billingCoreDTO : billingCoreDTOList) {
            log.info("Start generate and save PDF statements Billing Core type: {}, and customer Code: {}", billingCoreDTO.getBillingType(), billingCoreDTO.getCustomerCode());

            String investmentManagementCode = billingCoreDTO.getInvestmentManagementCode();
            String investmentManagementName = billingCoreDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingCoreDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = billingCoreDTO.getInvestmentManagementUniqueKey();
            log.info("Unique Key: {}", investmentManagementUniqueKey);
            String customerCode = billingCoreDTO.getCustomerCode();
            String subCode = billingCoreDTO.getSubCode();
            String customerName = billingCoreDTO.getCustomerName();
            String currency = billingCoreDTO.getCurrency();
            String billingCategory = billingCoreDTO.getBillingCategory();
            String billingType = billingCoreDTO.getBillingType();
            String billingPeriod = billingCoreDTO.getBillingPeriod();
            String billingNumber = billingCoreDTO.getBillingNumber();

            Map<String, String> monthYearMap = convertDateUtil.extractMonthYearInformation(billingPeriod);
            String yearMonthFormat = monthYearMap.get("year") + monthYearMap.get("monthValue");
            String filePath;
            String fileName = generateFileName(customerCode, subCode, billingNumber);

            /* get month and year */
            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");

            /* tentukan folder path */
            String folderPath = basePathBillingCore + yearMonthFormat + DELIMITER + investmentManagementCode;

            /* tentukan file path */
            filePath = folderPath + DELIMITER + fileName;

            try {
                /* create folder to save pdf file */
                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                deleteFilesWithCustomerCode(folderPathObj, customerCode, subCode);

                /* render data to thymeleaf and save pdf */
                String htmlContent = renderThymeleafTemplate(billingCoreDTO);
                byte[] pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);
                savePdf(pdfBytes, folderPath, fileName);

                /* check and delete existing report generator */
                billingReportGeneratorService.checkingExistingBillingReportGenerator(
                        customerCode, billingCategory, billingType, currency, billingPeriod
                );

                /* create report generator for saving success process */
                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .fileName(fileName)
                        .filePath(filePath)
                        .status(ReportGeneratorStatus.SUCCESS.getStatus())
                        .desc("Successfully generate and save PDF statements with customer code: " + customerCode)
                        .build();
                billingReportGeneratorService.saveSingleData(reportGenerator);
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: {}", e.getMessage(), e);
                /* create report generator for saving failed process */
                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .fileName(fileName)
                        .filePath(folderPath)
                        .status(ReportGeneratorStatus.FAILED.getStatus())
                        .desc(e.getMessage())
                        .build();
                billingReportGeneratorService.saveSingleData(reportGenerator);
                totalDataFailed++;
            }
        }
        return new GeneratePDFResponse(totalDataSuccess, totalDataFailed);
    }

    private String renderThymeleafTemplate(BillingCoreDTO billingCoreDTO) {
        Context context = new Context();

        context.setVariable(BILLING_NUMBER, billingCoreDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, billingCoreDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, billingCoreDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, billingCoreDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, billingCoreDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, billingCoreDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, billingCoreDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, billingCoreDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, billingCoreDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, billingCoreDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, billingCoreDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, billingCoreDTO.getInvestmentManagementAddress4());
        context.setVariable(ACCOUNT_NAME, billingCoreDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, billingCoreDTO.getAccount());
        context.setVariable(ACCOUNT_BANK, BANK_ACCOUNT_BDI);

        context.setVariable(TRANSACTION_HANDLING_VALUE_FREQUENCY, billingCoreDTO.getTransactionHandlingValueFrequency());
        context.setVariable(TRANSACTION_HANDLING_FEE, billingCoreDTO.getTransactionHandlingFee());
        context.setVariable(TRANSACTION_HANDLING_AMOUNT_DUE, billingCoreDTO.getTransactionHandlingAmountDue());
        context.setVariable(SAFEKEEPING_VALUE_FREQUENCY, billingCoreDTO.getSafekeepingValueFrequency());
        context.setVariable(SAFEKEEPING_FEE, billingCoreDTO.getSafekeepingFee());
        context.setVariable(SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getSafekeepingAmountDue());
        context.setVariable(SUB_TOTAL, billingCoreDTO.getSubTotal());
        context.setVariable(VAT_FEE, billingCoreDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, billingCoreDTO.getVatAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, billingCoreDTO.getTotalAmountDue());

        context.setVariable(JOURNAL_CREDIT_TO, billingCoreDTO.getJournalCreditTo());
        context.setVariable(KSEI_SAFEKEEPING_AMOUNT_DUE, billingCoreDTO.getKseiSafekeepingAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, billingCoreDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getKseiTransactionAmountDue());
        context.setVariable(BIS4_TRANSACTION_VALUE_FREQUENCY, billingCoreDTO.getBis4TransactionValueFrequency());
        context.setVariable(BIS4_TRANSACTION_FEE, billingCoreDTO.getBis4TransactionFee());
        context.setVariable(BIS4_TRANSACTION_AMOUNT_DUE, billingCoreDTO.getBis4TransactionAmountDue());

        context.setVariable(SAFEKEEPING_FEE_JOURNAL, billingCoreDTO.getSafekeepingFeeJournal());
        context.setVariable(TRANSACTION_HANDLING_JOURNAL, billingCoreDTO.getTransactionHandlingJournal());
        // context.setVariable(ACCOUNT_NUMBER_CBEST, billingCoreDTO.getAccNumberCBEST());

        context.setVariable(ADMINISTRATION_SET_UP_ITEM, billingCoreDTO.getAdministrationSetUpItem());
        context.setVariable(ADMINISTRATION_SET_UP_FEE, billingCoreDTO.getAdministrationSetUpFee());
        context.setVariable(ADMINISTRATION_SET_UP_AMOUNT_DUE, billingCoreDTO.getAdministrationSetUpAmountDue());
        context.setVariable(SIGNING_REPRESENTATION_ITEM, billingCoreDTO.getSigningRepresentationItem());
        context.setVariable(SIGNING_REPRESENTATION_FEE, billingCoreDTO.getSigningRepresentationFee());
        context.setVariable(SIGNING_REPRESENTATION_AMOUNT_DUE, billingCoreDTO.getSigningRepresentationAmountDue());
        context.setVariable(SECURITY_AGENT_ITEM, billingCoreDTO.getSecurityAgentItem());
        context.setVariable(SECURITY_AGENT_FEE, billingCoreDTO.getSecurityAgentFee());
        context.setVariable(SECURITY_AGENT_AMOUNT_DUE, billingCoreDTO.getSecurityAgentAmountDue());
        context.setVariable(TRANSACTION_HANDLING_ITEM, billingCoreDTO.getTransactionHandlingItem());
        context.setVariable(SAFEKEEPING_ITEM, billingCoreDTO.getSafekeepingItem());
        context.setVariable(OTHER_ITEM, billingCoreDTO.getOtherItem());
        context.setVariable(OTHER_FEE, billingCoreDTO.getOtherFee());
        context.setVariable(OTHER_AMOUNT_DUE, billingCoreDTO.getOtherAmountDue());

        context.setVariable(SAFEKEEPING_FEE_PERIOD, billingCoreDTO.getBillingPeriod());

        // tambahkan Image URL
        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        String billingTemplate = billingCoreDTO.getBillingTemplate();
        log.info("Billing Template '{}'", billingTemplate);
        return templateEngine.process(billingTemplate, context);
    }

    private String generateFileName(String customerCode, String subCode, String billingNumber) {
        log.info("Sub Code: {}", subCode);
        String fileName;
        String replaceBillingNumber = billingNumber
                .replace("/", "_")
                .replace("-", "_");

        if (!subCode.isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(customerCode)
                    .append("_")
                    .append(subCode)
                    .append("_")
                    .append(replaceBillingNumber)
                    .append(".pdf");
            fileName = String.valueOf(stringBuilder);
        } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(customerCode)
                    .append("_")
                    .append(replaceBillingNumber)
                    .append(".pdf");
            fileName = String.valueOf(stringBuilder);
        }
        return fileName;
    }

    private void savePdf(byte[] pdfBytes, String folderPath, String fileName) throws IOException {
        Path outputPathObj = Paths.get(folderPath).resolve(fileName);
        String outputPath = outputPathObj.toString();
        pdfGenerator.savePdfToFile(pdfBytes, outputPath);
    }

    private void deleteFilesWithCustomerCode(Path folderPathObj, String customerCode, String subCode) throws IOException {
        String customerCodeAndSubCode = customerCode + "_" + subCode;
        log.info("Customer Code and Sub Code: {}", customerCodeAndSubCode);

        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folderPathObj, "*.pdf")) {
            for (Path path : directoryStream) {
                log.info("File Path Name: {}", path.getFileName());
                if (Files.isRegularFile(path)) { // Check for regular file (not folder)
                    String fileName = path.getFileName().toString();
                    if (subCode.isEmpty()) {
                        if (fileName.contains(customerCode)) {
                            Files.delete(path);
                            log.info("Deleted path: {}, file: {}", path, fileName);
                        }
                    } else {
                        if (fileName.contains(subCode)) {
                            Files.delete(path);
                            log.info("Deleted path: {}, file: {}", path, fileName);
                        }
                    }
                }
            }
        }
    }

}
