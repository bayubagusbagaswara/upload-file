package com.services.billingservice.service.impl;

import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.Retail2QueryResultDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.model.RetailTransaction;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.repository.RetailTransactionRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.FeeParameter.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail3CalculateServiceImpl implements Retail3CalculateService {

    private static final String MONTH_TEST = "April";
    private static final Integer YEAR_TEST = 2024;

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final BillingNumberService billingNumberService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final RetailGeneralService retailGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start calculate Billing Retail with request '{}'", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();

            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
//            String monthName = monthMinus1.get("monthName");
//            int year = Integer.parseInt(monthMinus1.get("year"));

            Map<String, String> monthNow = convertDateUtil.getMonthNow();
            String monthNameNow = monthNow.get("monthName");
            int yearNow = Integer.parseInt(monthNow.get("year"));

            LocalDate dateOfMonthYear = convertDateUtil.getFirstDateOfMonthYear(request.getMonthYear());
            Instant instantNow = Instant.now();
            int totalDataSuccess = 0;

            // Initialization variable
            int transactionHandlingValueFrequency;
            BigDecimal transactionHandlingAmountDue;
            int transactionHandlingInternalValueFrequency;
            BigDecimal transactionHandlingInternalAmountDue;

            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;

            BigDecimal subTotal;
            BigDecimal vatAmountDue;
            BigDecimal totalAmountDue;

            // Get Fee Param
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(VAT.getValue());
            feeParamList.add(TRANSACTION_HANDLING_INTERNAL_CTBC_USD.getValue());
            feeParamList.add(SETTLEMENT_MINIMUM_CTBC_USD.getValue());

            Map<String, BigDecimal> feeParamMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal vatFee = feeParamMap.get(VAT.getValue());


            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomer billingCustomer : billingCustomerList) {
                String sellingAgent = billingCustomer.getSellingAgent();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                String customerCode = billingCustomer.getCustomerCode();
                String currency = billingCustomer.getCurrency();
                String miCode = billingCustomer.getMiCode();
                BigDecimal transactionHandlingFee = billingCustomer.getCustomerTransactionHandling();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                retailGeneralService.checkingExistingBillingRetail(customerCode, currency, MONTH_TEST, YEAR_TEST);

                List<Object[]> objects = retailAccountBalanceRepository.getRetailDataBySellingAgentAndCurrency(
                        sellingAgent, currency, dateOfMonthYear
                );

                Retail2QueryResultDTO retail2QueryResultDTO = mapToDTO(objects);
                safekeepingValueFrequency = null != retail2QueryResultDTO ? retail2QueryResultDTO.getLastBalance() : BigDecimal.ZERO;
                safekeepingAmountDue = null != retail2QueryResultDTO ? retail2QueryResultDTO.getSumFee() : BigDecimal.ZERO;

                log.info("Safekeeping value frequency Selling Agent '{}' and currency '{}' : '{}'", sellingAgent, currency, safekeepingValueFrequency);
                log.info("Safekeeping amount due Selling Agent '{}' and currency '{}' : '{}'", sellingAgent, currency, safekeepingAmountDue);

                List<RetailTransaction> retailTransactionList = retailTransactionRepository.findAllBySellingAgentAndMonthAndYearAndCurrency(sellingAgent, MONTH_TEST, YEAR_TEST, currency);

                if (currency.equalsIgnoreCase(IDR.getValue())) {
                    transactionHandlingValueFrequency = calculateTransactionHandlingValueFrequency(sellingAgent, currency, retailTransactionList);

                    transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(sellingAgent, currency, transactionHandlingValueFrequency, transactionHandlingFee);

                    subTotal = calculateSubTotal(sellingAgent, currency, transactionHandlingAmountDue, safekeepingAmountDue);

                    vatAmountDue = calculateVATAmountDue(sellingAgent, currency, subTotal, vatFee);

                    totalAmountDue = calculateTotalAmountDue(sellingAgent, currency, subTotal, vatAmountDue);

                    BillingRetail billingRetail = BillingRetail.builder()
                            .createdAt(instantNow)
                            .updatedAt(instantNow)
                            .sellingAgent(sellingAgent)
                            .approvalStatus(ApprovalStatus.Pending)
                            .billingStatus(BillingStatus.Generated)
                            .month(MONTH_TEST)
                            .year(YEAR_TEST)

                            .billingPeriod(MONTH_TEST + " " + YEAR_TEST)
                            .billingStatementDate(ConvertDateUtil.convertInstantToString(instantNow))
                            .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(instantNow))
                            .billingCategory(billingCustomer.getBillingCategory())
                            .billingType(billingCustomer.getBillingType())
                            .billingTemplate(billingCustomer.getBillingTemplate())
                            .investmentManagementCode(billingMIDTO.getCode())
                            .investmentManagementName(billingMIDTO.getName())
                            .investmentManagementAddress1(billingMIDTO.getAddress1())
                            .investmentManagementAddress2(billingMIDTO.getAddress2())
                            .investmentManagementAddress3(billingMIDTO.getAddress3())
                            .investmentManagementAddress4(billingMIDTO.getAddress4())
                            .investmentManagementEmail(billingMIDTO.getEmail())
                            .investmentManagementUniqueKey(billingMIDTO.getUniqueKey())

                            .customerCode(billingCustomer.getCustomerCode())
                            .subCode(billingCustomer.getSubCode())
                            .customerName(billingCustomer.getCustomerName())

                            .gefuCreated(false)
                            .paid(false)
                            .account(billingCustomer.getAccount())
                            .accountName(billingCustomer.getAccountName())
                            .currency(currency)

                            .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                            .transactionHandlingFee(transactionHandlingFee)
                            .transactionHandlingAmountDue(transactionHandlingAmountDue)

                            .safekeepingValueFrequency(safekeepingValueFrequency)
                            .safekeepingFee(customerSafekeepingFee)
                            .safekeepingAmountDue(safekeepingAmountDue)
                            .subTotalAmountDue(subTotal)
                            .vatAmountDue(vatAmountDue)
                            .vatFee(vatFee)
                            .totalAmountDue(totalAmountDue)
                            .build();

                    String number = billingNumberService.generateSingleNumber(monthNameNow, yearNow);
                    billingRetail.setBillingNumber(number);
                    billingRetailRepository.save(billingRetail);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    BigDecimal transactionHandlingInternalUSDFee = feeParamMap.get(TRANSACTION_HANDLING_INTERNAL_CTBC_USD.getValue());
                    BigDecimal settlementMinimum = feeParamMap.get(SETTLEMENT_MINIMUM_CTBC_USD.getValue());

                    int[] transactionHandlingFrequencyAll = calculateTransactionHandlingFrequencyAll(sellingAgent, currency, retailTransactionList, settlementMinimum);

                    transactionHandlingValueFrequency = transactionHandlingFrequencyAll[0];
                    transactionHandlingInternalValueFrequency = transactionHandlingFrequencyAll[1];

                    transactionHandlingAmountDue = calculateTransactionHandlingAmountDueUSD(sellingAgent, currency, transactionHandlingValueFrequency, transactionHandlingFee);

                    transactionHandlingInternalAmountDue = calculateTransactionHandlingInternalAmountDueUSD(sellingAgent, currency, transactionHandlingInternalValueFrequency, transactionHandlingInternalUSDFee);

                    subTotal = calculateSubTotalUSD(sellingAgent, currency, transactionHandlingAmountDue, transactionHandlingInternalAmountDue, safekeepingAmountDue);

                    vatAmountDue = calculateVATAmountDueUSD(sellingAgent, currency, subTotal, vatFee);

                    totalAmountDue = calculateTotalAmountDueUSD(sellingAgent, currency, subTotal, vatAmountDue);

                    BillingRetail billingRetail = BillingRetail.builder()
                            .createdAt(instantNow)
                            .updatedAt(instantNow)
                            .approvalStatus(ApprovalStatus.Pending)
                            .billingStatus(BillingStatus.Generated)
                            .sellingAgent(sellingAgent)
                            .month(MONTH_TEST)
                            .year(YEAR_TEST)

                            .billingPeriod(MONTH_TEST + " " + YEAR_TEST)
                            .billingStatementDate(ConvertDateUtil.convertInstantToString(instantNow))
                            .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(instantNow))
                            .billingCategory(billingCustomer.getBillingCategory())
                            .billingType(billingCustomer.getBillingType())
                            .billingTemplate(billingCustomer.getBillingTemplate())
                            .investmentManagementCode(billingMIDTO.getCode())
                            .investmentManagementName(billingMIDTO.getName())
                            .investmentManagementAddress1(billingMIDTO.getAddress1())
                            .investmentManagementAddress2(billingMIDTO.getAddress2())
                            .investmentManagementAddress3(billingMIDTO.getAddress3())
                            .investmentManagementAddress4(billingMIDTO.getAddress4())
                            .investmentManagementEmail(billingMIDTO.getEmail())
                            .investmentManagementUniqueKey(billingMIDTO.getUniqueKey())

                            .customerCode(billingCustomer.getCustomerCode())
                            .subCode(billingCustomer.getSubCode())
                            .customerName(billingCustomer.getCustomerName())

                            .gefuCreated(false)
                            .paid(false)
                            .account(billingCustomer.getAccount())
                            .accountName(billingCustomer.getAccountName())
                            .currency(currency)

                            .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                            .transactionHandlingFee(transactionHandlingFee)
                            .transactionHandlingAmountDue(transactionHandlingAmountDue)

                            .transactionHandlingInternalValueFrequency(transactionHandlingInternalValueFrequency)
                            .transactionHandlingInternalFee(transactionHandlingInternalUSDFee)
                            .transactionHandlingInternalAmountDue(transactionHandlingInternalAmountDue)

                            .safekeepingValueFrequency(safekeepingValueFrequency)
                            .safekeepingFee(customerSafekeepingFee)
                            .safekeepingAmountDue(safekeepingAmountDue)
                            .subTotalAmountDue(subTotal)
                            .vatAmountDue(vatAmountDue)
                            .vatFee(vatFee)
                            .totalAmountDue(totalAmountDue)
                            .build();

                    String number = billingNumberService.generateSingleNumber(monthNameNow, yearNow);
                    billingRetail.setBillingNumber(number);
                    billingRetailRepository.save(billingRetail);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                }
            }

            return "Successfully calculate Billing Retail type 3 with a total: " + totalDataSuccess;
        } catch (Exception e) {
            log.error("Error when calculate Billing Retail type 3: {}", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Retail type 3: ", e);
        }
    }

    private int[] calculateTransactionHandlingFrequencyAll(String sellingAgent, String currency, List<RetailTransaction> retailTransactionList, BigDecimal settlementMinimum) {
        int transactionValueFrequency = 0;
        int transactionValueFrequencyInternal = 0;
        for (RetailTransaction retailTransaction : retailTransactionList) {
            BigDecimal nominal = retailTransaction.getNominal().isEmpty() ? BigDecimal.ZERO : new BigDecimal(retailTransaction.getNominal());
            log.info("[Retail 3] Nominal : {}", nominal);

            // Check if nominal is below 200,000
            if (nominal.compareTo(settlementMinimum) < 0) {
                transactionValueFrequencyInternal++;
            } else {
                transactionValueFrequency++;
            }
        }

        log.info("[Retail 3] Total transaction value frequency Selling Agent '{}' and Currency '{}' is : {}", sellingAgent, currency, transactionValueFrequency);
        log.info("[Retail 3] Total transaction value frequency internal Selling Agent '{}' and Currency '{}' is : {}",sellingAgent, currency, transactionValueFrequencyInternal);
        return new int[] {transactionValueFrequency, transactionValueFrequencyInternal};
    }


    private static Integer calculateTransactionHandlingValueFrequency(String sellingAgent, String currency, List<RetailTransaction> retailTransactionList) {
        int totalTransactionHandling = retailTransactionList.size();
        log.info("[Retail Type 3 {}] Total transaction handling Selling Agent '{}' is '{}'", currency, sellingAgent, totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(String sellingAgent, String currency, int transactionHandlingValueFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingValueFrequency)
                .multiply(transactionHandlingFee)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Retail Type 3 {}] Transaction handling amount due Selling Agent '{}' is '{}'", currency, sellingAgent, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSubTotal(String sellingAgent, String currency, BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotal = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Retail Type 3 {}] Sub total Selling Agent '{}' is '{}'", currency, sellingAgent, subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDue(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 3 {}] VAT amount due Selling Agent '{}' is '{}'", currency, sellingAgent, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue);
        log.info("[Retail Type 3 {}] Total amount due Selling Agent '{}' is '{}'", currency, sellingAgent, totalAmountDue);
        return totalAmountDue;
    }

    private static List<Retail2QueryResultDTO> mapToDTOList(List<Object[]> result) {
        return result.stream()
                .map(data -> {
                    BigDecimal valueLastBalance = data[3] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[3]);
                    BigDecimal valueSumFee = data[4] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[4]);
                    return Retail2QueryResultDTO.builder()
                            .year((Integer) data[0])
                            .month((String) data[1])
                            .sellingAgent((String) data[2])
                            .lastBalance(valueLastBalance)
                            .sumFee(valueSumFee)
                            .build();
                })
                .collect(Collectors.toList());
    }

    private static Retail2QueryResultDTO mapToDTO(List<Object[]> result) {
        // handle null pointer for lastBalance and sumFee
        BigDecimal valueLastBalance = result.get(0)[3] == null ? BigDecimal.ZERO : BigDecimal.valueOf((Double) result.get(0)[3]);
        BigDecimal valueSumFee = result.get(0)[4] == null ? BigDecimal.ZERO : BigDecimal.valueOf((Double) result.get(0)[4]);

        return result.isEmpty() ? null : Retail2QueryResultDTO.builder()
                .year((Integer) result.get(0)[0])
                .month((String) result.get(0)[1])
                .sellingAgent((String) result.get(0)[2])
                .lastBalance(valueLastBalance)
                .sumFee(valueSumFee.setScale(2, RoundingMode.HALF_UP))
                .build();
    }


    private static BigDecimal calculateTransactionHandlingAmountDueUSD(String sellingAgent, String currency, int transactionHandlingValueFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingValueFrequency)
                .multiply(transactionHandlingFee)
                .setScale(2, RoundingMode.HALF_UP);

        log.info("[Retail Type 3 {}] Transaction handling amount due Selling Agent '{}' is '{}'", currency, sellingAgent, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }


    private static BigDecimal calculateTransactionHandlingInternalAmountDueUSD(String sellingAgent, String currency, int transactionHandlingInternalValueFrequency, BigDecimal transactionHandlingInternalUSDFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingInternalValueFrequency)
                .multiply(transactionHandlingInternalUSDFee)
                .setScale(2, RoundingMode.HALF_UP);

        log.info("[Retail Type 3 {}] Transaction handling internal amount due Selling Agent '{}' is '{}'", currency, sellingAgent, transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }


    private static BigDecimal calculateSubTotalUSD(String sellingAgent, String currency, BigDecimal transactionHandlingAmountDue, BigDecimal transactionHandlingInternalAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotal = transactionHandlingAmountDue
                .add(transactionHandlingInternalAmountDue)
                .add(safekeepingAmountDue);
        log.info("[Retail Type 3 {}] Sub total Selling Agent '{}' is '{}'", currency, sellingAgent, subTotal);
        return subTotal;
    }


    private static BigDecimal calculateVATAmountDueUSD(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 3 {}] VAT amount due Selling Agent '{}' is '{}'", currency, sellingAgent, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueUSD(String sellingAgent, String currency, BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue);
        log.info("[Retail Type 3 {}] Total amount due Selling Agent '{}' is '{}'", currency, sellingAgent, totalAmountDue);
        return totalAmountDue;
    }

}
