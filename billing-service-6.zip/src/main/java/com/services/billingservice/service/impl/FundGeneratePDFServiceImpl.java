package com.services.billingservice.service.impl;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.FundCalculateRequest;
import com.services.billingservice.dto.pdf.GeneratePDFResponse;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.ReportGeneratorStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.mapper.BillingFundMapper;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.service.FundGeneratePDFService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.constant.FundConstant.*;
import static com.services.billingservice.constant.FundConstant.KSEI_TRANSACTION_AMOUNT_DUE;
import static com.services.billingservice.constant.FundConstant.TOTAL_AMOUNT_DUE;
import static com.services.billingservice.enums.BillingTemplate.FUND_TEMPLATE;

@Service
@Slf4j
@RequiredArgsConstructor
public class FundGeneratePDFServiceImpl implements FundGeneratePDFService {

    @Value("${base.path.billing.fund}")
    private String basePathBillingFund;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private static final String DELIMITER = "/";
    private static final String ACCOUNT_BANK_BDI = "PT Bank Danamon Indonesia";

    private final BillingFundRepository billingFundRepository;
    private final SpringTemplateEngine templateEngine;
    private final PdfGenerator pdfGenerator;
    private final ConvertDateUtil convertDateUtil;
    private final BillingFundMapper billingFundMapper;
    private final BillingReportGeneratorService billingReportGeneratorService;

    @Override
    public String generatePDF(FundCalculateRequest fundCalculateRequest) {
        log.info("Start generate PDF Billing Fund with request: {}", fundCalculateRequest);
        try {
            String category = fundCalculateRequest.getCategory().toUpperCase();
            String monthYear = fundCalculateRequest.getMonthYear();
            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(monthYear);
            String month = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatus(
                    category, month, year, approvalStatus
            );

            GeneratePDFResponse generatePDFResponse = generateAndSavePdfStatements(billingFundList);

            return "Successfully created a PDF file Billing Fund with total data success: " + generatePDFResponse.getTotalDataSuccess() +
                    ", and total data failed: " + generatePDFResponse.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Fund : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Fund : " + e.getMessage());
        }
    }

    private GeneratePDFResponse generateAndSavePdfStatements(List<BillingFund> billingFundList) {
        log.info("Start generate and save pdf statements Billing Fund size: {}", billingFundList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        Instant dateNow = Instant.now();
        List<BillingFundDTO> billingFundDTOList = billingFundMapper.mapToDTOList(billingFundList);

        for (BillingFundDTO billingFundDTO : billingFundDTOList) {
            String investmentManagementCode = billingFundDTO.getInvestmentManagementCode();
            String investmentManagementName = billingFundDTO.getInvestmentManagementName();
            String investmentManagementEmail = billingFundDTO.getInvestmentManagementEmail();
            String investmentManagementUniqueKey = billingFundDTO.getInvestmentManagementUniqueKey();
            String customerCode = billingFundDTO.getCustomerCode();
            String customerName = billingFundDTO.getCustomerName();
            String billingCategory = billingFundDTO.getBillingCategory();
            String billingType = billingFundDTO.getBillingType();
            String billingPeriod = billingFundDTO.getBillingPeriod();
            String currency = billingFundDTO.getCurrency();
            String billingNumber = billingFundDTO.getBillingNumber();

            Map<String, String> monthYearMap = convertDateUtil.extractMonthYearInformation(billingFundDTO.getBillingPeriod());
            int year = Integer.parseInt(monthYearMap.get("year"));
            String monthName = monthYearMap.get("monthName");
            String yearMonthFormat = year + monthYearMap.get("monthValue");

            String filePath;
            String fileName = generateFileName(customerCode, billingNumber);

            String folderPath = basePathBillingFund + yearMonthFormat + DELIMITER +  investmentManagementCode;

            filePath = folderPath + DELIMITER + fileName;

            try {
                /* create folder to save pdf file */
                Path folderPathObj = Paths.get(folderPath);
                Files.createDirectories(folderPathObj);

                /* delete pdf files with customer code */
                deleteFilesWithCustomerCode(folderPathObj, customerCode);

                /* render data to thymeleaf and save pdf */
                String htmlContent = renderThymeleafTemplate(billingFundDTO);
                byte[] pdfBytes = pdfGenerator.generatePdfFromHtml(htmlContent);
                savePdf(pdfBytes, folderPath, fileName);

                /* check and delete existing report generator */
                billingReportGeneratorService.checkingExistingBillingReportGenerator(
                        customerCode, billingCategory, billingType, currency, billingPeriod
                );

                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .currency(currency)
                        .fileName(fileName)
                        .filePath(filePath)
                        .status(ReportGeneratorStatus.SUCCESS.getStatus())
                        .desc("Successfully generate and save PDF statement with customer code: " + customerCode)
                        .build();
                billingReportGeneratorService.saveSingleData(reportGenerator);
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error creating folder or saving PDF: {}", e.getMessage(), e);
                /* create report generator for saving failed process */
                BillingReportGenerator reportGenerator = BillingReportGenerator.builder()
                        .createdAt(dateNow)
                        .investmentManagementName(investmentManagementName)
                        .investmentManagementEmail(investmentManagementEmail)
                        .investmentManagementUniqueKey(investmentManagementUniqueKey)
                        .customerCode(customerCode)
                        .customerName(customerName)
                        .category(billingCategory)
                        .type(billingType)
                        .period(billingPeriod)
                        .month(monthName)
                        .year(year)
                        .fileName(fileName)
                        .filePath(folderPath)
                        .status(ReportGeneratorStatus.FAILED.getStatus())
                        .desc(e.getMessage())
                        .build();
                billingReportGeneratorService.saveSingleData(reportGenerator);
                totalDataFailed++;
            }
        }
        return new GeneratePDFResponse(totalDataSuccess, totalDataFailed);
    }

    private String renderThymeleafTemplate(BillingFundDTO fundDTO) {
        Context context = new Context();
        context.setVariable(BILLING_NUMBER, fundDTO.getBillingNumber());
        context.setVariable(BILLING_PERIOD, fundDTO.getBillingPeriod());
        context.setVariable(BILLING_STATEMENT_DATE, fundDTO.getBillingStatementDate());
        context.setVariable(BILLING_PAYMENT_DUE_DATE, fundDTO.getBillingPaymentDueDate());
        context.setVariable(BILLING_CATEGORY, fundDTO.getBillingCategory());
        context.setVariable(BILLING_TYPE, fundDTO.getBillingType());
        context.setVariable(BILLING_TEMPLATE, fundDTO.getBillingTemplate());
        context.setVariable(INVESTMENT_MANAGEMENT_NAME, fundDTO.getInvestmentManagementName());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_1, fundDTO.getInvestmentManagementAddress1());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_2, fundDTO.getInvestmentManagementAddress2());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_3, fundDTO.getInvestmentManagementAddress3());
        context.setVariable(INVESTMENT_MANAGEMENT_ADDRESS_4, fundDTO.getInvestmentManagementAddress4());
        context.setVariable(ACCOUNT_NAME, fundDTO.getAccountName());
        context.setVariable(ACCOUNT_NUMBER, fundDTO.getAccount());
        context.setVariable(ACCOUNT_BANK, ACCOUNT_BANK_BDI);
        context.setVariable(ACCRUAL_CUSTODIAL_VALUE_FREQUENCY, fundDTO.getAccrualCustodialValueFrequency());
        context.setVariable(ACCRUAL_CUSTODIAL_SAFEKEEPING_FEE, fundDTO.getAccrualCustodialSafekeepingFee());
        context.setVariable(ACCRUAL_CUSTODIAL_FEE, fundDTO.getAccrualCustodialFee());
        context.setVariable(ACCRUAL_CUSTODIAL_FEE, fundDTO.getAccrualCustodialFee());
        context.setVariable(BI_SSSS_TRANSACTION_VALUE_FREQUENCY, fundDTO.getBis4TransactionValueFrequency());
        context.setVariable(BI_SSSS_TRANSACTION_FEE, fundDTO.getBis4TransactionFee());
        context.setVariable(BI_SSSS_TRANSACTION_AMOUNT_DUE, fundDTO.getBis4TransactionAmountDue());
        context.setVariable(SUB_TOTAL, fundDTO.getSubTotal());
        context.setVariable(VAT_FEE, fundDTO.getVatFee());
        context.setVariable(VAT_AMOUNT_DUE, fundDTO.getVatAmountDue());
        context.setVariable(KSEI_TRANSACTION_VALUE_FREQUENCY, fundDTO.getKseiTransactionValueFrequency());
        context.setVariable(KSEI_TRANSACTION_FEE, fundDTO.getKseiTransactionFee());
        context.setVariable(KSEI_TRANSACTION_AMOUNT_DUE, fundDTO.getKseiTransactionAmountDue());
        context.setVariable(TOTAL_AMOUNT_DUE, fundDTO.getTotalAmountDue());

        String imageUrlHeader = "file:///" + folderPathImage + "/logo.png";
        String imageUrlFooter = "file:///" + folderPathImage + "/footer.png";
        context.setVariable("imageUrlHeader", imageUrlHeader);
        context.setVariable("imageUrlFooter", imageUrlFooter);

        return templateEngine.process(FUND_TEMPLATE.getValue(), context);
    }

    private String generateFileName(String customerCode, String billingNumber) {
        String replaceBillingNumber = billingNumber
                .replace("/", "_")
                .replace("-", "_");
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(customerCode)
                .append("_")
                .append(replaceBillingNumber)
                .append(".pdf");
        return String.valueOf(stringBuilder);
    }

    private void savePdf(byte[] pdfBytes, String folderPath, String fileName) throws IOException {
        Path outputPathObj = Paths.get(folderPath).resolve(fileName);
        String outputPath = outputPathObj.toString();
        pdfGenerator.savePdfToFile(pdfBytes, outputPath);
    }

    private void deleteFilesWithCustomerCode(Path folderPathObj, String customerCode) throws IOException {
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folderPathObj, "*.pdf")) {
            for (Path path : directoryStream) {
                if (path.getFileName().toString().contains(customerCode)) {
                    Files.delete(path);
                    log.info("Deleted file: {}", path.getFileName().toString());
                }
            }
        }
    }

}
