package com.services.billingservice.service.impl;

import com.opencsv.exceptions.CsvException;
import com.services.billingservice.exception.*;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.repository.SfValRgDailyRepository;
import com.services.billingservice.service.SfValRgDailyService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.CsvDataMapper;
import com.services.billingservice.utils.CsvReaderUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class SfValRgDailyServiceImpl implements SfValRgDailyService {

    private static final String BASE_FILE_NAME = "RG_Daily_";
    private final SfValRgDailyRepository sfValRgDailyRepository;
    private final ConvertDateUtil convertDateUtil;


    @Override
    public String readFileAndInsertToDB(String filePath, String monthYear) {
        log.info("Start read and insert SfVal RG Daily to the database : {}", filePath);
        try {
            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            String monthValue = monthMinus1.get("monthValue");
            int year = Integer.parseInt(monthMinus1.get("year"));

            String fileName = BASE_FILE_NAME + year + monthValue + ".csv";
            String filePathNew = filePath + fileName;
            log.info("File path new RG Daily: {}", filePathNew);

            File file = new File(filePathNew);
            if (!file.exists()) {
                log.error("File not found: {}", filePathNew);
                throw new DataNotFoundException("RG Daily file not found with path: " + filePathNew);
            }

            sfValRgDailyRepository.deleteByMonthAndYear(monthName, year);

            List<String[]> rows = CsvReaderUtil.readCsvFile(filePathNew);
            List<SfValRgDaily> sfValRgDailyList = CsvDataMapper.mapCsvSfValRgDaily(rows);
            sfValRgDailyRepository.saveAll(sfValRgDailyList);

            return "RG Daily CSV data processed and saved successfully";
        } catch (DataNotFoundException e) {
            log.error("RG Daily file not found: {}", e.getMessage(), e);
            throw new DataNotFoundException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error("RG Daily failed to process CSV data from file: {}", filePath, e);
            throw new CsvProcessingException("SfVal RG Daily failed to process CSV data: " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", filePath, e);
            throw new GeneralException("Unexpected error: " + e.getMessage(), e);
        }
    }

    @Override
    public List<SfValRgDaily> getAll() {
        return sfValRgDailyRepository.findAll();
    }

    @Override
    public List<SfValRgDaily> findByMonthAndYear(String month, Integer year) {
        return sfValRgDailyRepository.findByMonthAndYear(month, year);
    }

    @Override
    public List<SfValRgDaily> findRecapByMonthAndYear(String month, Integer year) {
        return sfValRgDailyRepository.findRecapByMonthAndYear(month, year);
    }

    @Override
    public List<SfValRgDaily> findRecapByAidAndMonthAndYear(String aid, String month, Integer year) {
        return sfValRgDailyRepository.findRecapByAidAndMonthAndYear(aid, month, year);
    }

    @Override
    public List<SfValRgDaily> getAllByAid(String aid) {
        log.info("Start get all SfVal RG Daily with AID : {}", aid);
        return sfValRgDailyRepository.findAllByAid(aid);
    }

    @Override
    public List<SfValRgDaily> findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(String aid, String month, Integer year) {
        return sfValRgDailyRepository.findByAidAndMonthAndYearOrderByAidAscSecurityNameAscDateAsc(aid, month, year);
    }

    @Override
    public List<SfValRgDaily> getAllRetailByAidAndTypeAndCurrencyAndPeriod(String aid, String sellingAgent, String currency, LocalDate date) {
        return sfValRgDailyRepository.getAllRetailByAidAndTypeAndCurrencyAndPeriod(aid, sellingAgent, currency, date);
    }

    @Override
    public List<SfValRgDaily> getAllByAidAndDate(String aid, String date) {
        log.info("Start get all SfVal RG Daily with AID : {}, and date : {}", aid, date);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
        LocalDate localDate = LocalDate.parse(date, dateTimeFormatter);
        log.info("Date : {}", localDate);

        return sfValRgDailyRepository.findAllByAidAndDate(aid, localDate);
    }

    @Override
    public List<SfValRgDaily> getAllByAidAndSecurityName(String aid, String securityName) {
        log.info("Start get all SfVal RG Daily with AID : {}, and Security Name : {}", aid, securityName);
        return sfValRgDailyRepository.findAllByAidAndSecurityName(aid, securityName);
    }

    @Override
    public List<SfValRgDaily> findByAidAndSecurityNameAndMonthAndYear(String aid, String securityName, String month, Integer year) {
        return sfValRgDailyRepository.findByAidAndSecurityNameAndMonthAndYear(aid, securityName, month, year);
    }

    @Override
    public List<SfValRgDaily> getAllByAidAndMonthAndYear(String aid, String month, Integer year) {
        log.info("Get all SfVal Rg Daily by Aid : {}, Month : {}, and Year : {}", aid, month, year);
        return sfValRgDailyRepository.findAllByAidAndMonthAndYear(aid, month, year);
    }

    @Override
    public String deleteAll() {
        try {
            sfValRgDailyRepository.deleteAll();
            return "Successfully deleted all SfVal RG Daily data";
        } catch (Exception e) {
            log.error("Error when delete all SfVal RG Daily : " + e.getMessage(), e);
            throw new RuntimeException("Error when delete all SfVal RG Daily");
        }
    }

}
