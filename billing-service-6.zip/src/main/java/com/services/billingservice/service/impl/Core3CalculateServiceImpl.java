package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingGlCredit;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class Core3CalculateServiceImpl implements Core3CalculateService {

    private static final String MONTH_TEST = "April";
    private static final Integer YEAR_TEST = 2024;
    private static final String GL_SAFEKEEPING_FEE = "GL Safekeeping Fee";

    private final BillingCustomerService billingCustomerService;
    private final CoreGeneralService coreGeneralService;
    private final SfValRgDailyService sfValRgDailyService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;
    private final BillingGLCreditService glCreditService;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core with request : {}", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
//            String monthName = monthMinus1.get("monthName");
//            int year = Integer.parseInt(monthMinus1.get("year"));

            Map<String, String> monthNow = convertDateUtil.getMonthNow();
            String monthNameNow = monthNow.get("monthName");
            int yearNow = Integer.parseInt(monthNow.get("year"));

            int totalDataSuccess = 0;

            BigDecimal safekeepingValueFrequency;
            BigDecimal safekeepingAmountDue;
            Instant dateNow = Instant.now();

            List<BillingCustomer> billingCustomerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomer billingCustomer : billingCustomerList) {
                String aid = billingCustomer.getCustomerCode();
                BigDecimal customerMinimumFee = billingCustomer.getCustomerMinimumFee();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                String billingTemplate = billingCustomer.getBillingTemplate();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingType = billingCustomer.getBillingType();
                String investmentManagementCode = billingCustomer.getMiCode();

                // check and delete existing billing data with the same month and year
                coreGeneralService.checkingExistingBillingCore(MONTH_TEST, YEAR_TEST, aid, billingCategory, billingType);

                // Account + Cost Center Debit
                // String journalCreditTo = "GL 713017 CC 9207";
                String account = billingCustomer.getAccount();
                String costCenterDebit = billingCustomer.getDebitTransfer();
                String accountCostCenterDebit = "GL " + account + " CC " + costCenterDebit;

                BillingGlCredit billingGlCredit = glCreditService.getByBillingTemplateAndGLCreditName(billingTemplate, GL_SAFEKEEPING_FEE);

                int glCreditAccountValue = billingGlCredit.getGlCreditAccountValue();
                String costCenter = billingCustomer.getCostCenter();
                String glAccountCostCenterCredit = "GL " + glCreditAccountValue + " CC " + costCenter;

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(investmentManagementCode);

                List<SfValRgDaily> sfValRgDailyList = sfValRgDailyService.getAllByAidAndMonthAndYear(aid, MONTH_TEST, YEAR_TEST);

                safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgDailyList);

                safekeepingAmountDue = calculateSafekeepingAmountDue(aid, sfValRgDailyList);

                BillingCore billingCore = BillingCore.builder()
                        .createdAt(dateNow)
                        .updatedAt(dateNow)
                        .approvalStatus(ApprovalStatus.Pending)
                        .billingStatus(BillingStatus.Generated)
                        .customerCode(aid)
                        .subCode(billingCustomer.getSubCode())
                        .customerName(billingCustomer.getCustomerName())
                        .month(MONTH_TEST)
                        .year(YEAR_TEST)
                        .billingPeriod(MONTH_TEST + " " + YEAR_TEST)
                        .billingStatementDate(ConvertDateUtil.convertInstantToString(dateNow))
                        .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow))
                        .billingCategory(billingCustomer.getBillingCategory())
                        .billingType(billingCustomer.getBillingType())
                        .billingTemplate(billingCustomer.getBillingTemplate())
                        .investmentManagementCode(billingMIDTO.getCode())
                        .investmentManagementName(billingMIDTO.getName())
                        .investmentManagementAddress1(billingMIDTO.getAddress1())
                        .investmentManagementAddress2(billingMIDTO.getAddress2())
                        .investmentManagementAddress3(billingMIDTO.getAddress3())
                        .investmentManagementAddress4(billingMIDTO.getAddress4())
                        .investmentManagementEmail(billingMIDTO.getEmail())
                        .investmentManagementUniqueKey(billingMIDTO.getUniqueKey())
                        .customerMinimumFee(customerMinimumFee)
                        .customerSafekeepingFee(customerSafekeepingFee)

                        .gefuCreated(false)
                        .paid(false)
                        .account(billingCustomer.getAccount())
                        .accountName(billingCustomer.getAccountName())
                        .currency(billingCustomer.getCurrency())

                        // Cost Center Debit
                        .accountCostCenterDebit(accountCostCenterDebit)
                        .safekeepingValueFrequency(safekeepingValueFrequency)
                        .safekeepingFee(customerSafekeepingFee)
                        .safekeepingAmountDue(safekeepingAmountDue)
                        .safekeepingJournal(glAccountCostCenterCredit)
                        .build();

                String number = billingNumberService.generateSingleNumber(monthNameNow, yearNow);
                billingCore.setBillingNumber(number);
                billingCoreRepository.save(billingCore);
                billingNumberService.saveSingleNumber(number);
                totalDataSuccess++;
            }

            log.info("Finished calculate Billing Core type 3 with month year: {}", request.getMonthYear());
            return "Successfully calculated Billing Core type 3 with a total: " + totalDataSuccess;
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 3: {}", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 3: " + e.getMessage());
        }
    }

    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgDaily> sfValRgDailyList) {
        List<SfValRgDaily> latestEntries = sfValRgDailyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgDailyList.stream()
                        .map(SfValRgDaily::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgDaily latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}'", latestEntry.getDate(), latestEntry.getSecurityName());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgDaily::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 3] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, List<SfValRgDaily> sfValRgDailyList) {
        BigDecimal safekeepingAmountDue = sfValRgDailyList.stream()
                .map(SfValRgDaily::getEstimationSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 3] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

}
