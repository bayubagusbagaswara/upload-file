package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.fund.FeeReportRequest;
import com.services.billingservice.dto.fund.FundTemplate1;
import com.services.billingservice.dto.fund.FundType1Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.*;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.billingservice.enums.BillingCategory.FUND;
import static com.services.billingservice.enums.BillingType.TYPE_1;
import static com.services.billingservice.enums.FeeParameter.BI_SSSS;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundCalculateServiceImpl implements FundCalculateService {

    private final BillingCustomerService customerService;
    private final SkTranService skTransactionService;
    private final BillingFeeParameterService feeParameterService;
    private final BillingNumberService billingNumberService;
    private final BillingFundRepository billingFundRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(List<FeeReportRequest> feeReportRequests, String monthYear) {
        /* initialize billing variable */
        Instant dateNow = Instant.now();
        String billingCategory = FUND.getValue();
        String billingType = TYPE_1.getValue();

        /* initialize response */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get all data fee parameter */
        BigDecimal bis4TransactionFee = feeParameterService.getValueByName(BI_SSSS.getValue());
        BigDecimal kseiTransactionFee = feeParameterService.getValueByName(KSEI.getValue());
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());

        /* start calculation */
        for (FeeReportRequest feeReportRequest : feeReportRequests) {
            String aid = feeReportRequest.getPortfolioCode();
            BigDecimal customerFee = feeReportRequest.getCustomerFee();
            try {
                BillingCustomer customer = customerService.getByCustomerCodeAndSubCodeAndBillingCategoryAndBillingType(aid, "", billingCategory, billingType);
                String miCode = customer.getMiCode();
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(miCode);
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(aid, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                Optional<BillingFund> existingBillingFund = billingFundRepository.findByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(aid, billingCategory, billingType, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                if (!existingBillingFund.isPresent() || Boolean.TRUE.equals(!existingBillingFund.get().getPaid())) {
                    existingBillingFund.ifPresent(this::deleteExistingBillingFund);

                    if (!skTransactionList.isEmpty()) {
                        FundType1Parameter fundType1Parameter = new FundType1Parameter(skTransactionList, customerFee, bis4TransactionFee, kseiTransactionFee, vatFee);

                        FundTemplate1 fundTemplate1 = calculationsWithExistingTransactions(fundType1Parameter, customer);

                        BillingFund billingFund = buildBillingFund(contextDate, customer, investmentManagementDTO, fundTemplate1);

                        String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                        billingFund.setBillingNumber(number);
                        billingFundRepository.save(billingFund);
                        billingNumberService.saveSingleNumber(number);
                        totalDataSuccess++;
                    } else {
                        /* there is no transaction data from the SK Transaction */
                        FundType1Parameter fundType1Parameter = new FundType1Parameter(skTransactionList, customerFee, bis4TransactionFee, kseiTransactionFee, vatFee);

                        FundTemplate1 fundTemplate1 = calculationsWithoutExistingTransactions(fundType1Parameter, customer);

                        BillingFund billingFund = buildBillingFund(contextDate, customer, investmentManagementDTO, fundTemplate1);

                        String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                        billingFund.setBillingNumber(number);
                        billingFundRepository.save(billingFund);
                        billingNumberService.saveSingleNumber(number);
                        totalDataSuccess++;
                    }
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                log.error("Error processing customer code {}: {}", aid, e.getMessage(), e);
                handleGeneralError(aid, e, errorMessageList);
                totalDataFailed++;
            }
        }

        log.info("Total successful calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse response = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + totalDataSuccess + ", total failed calculations: " + totalDataFailed;
    }

    private static BigDecimal calculateAccrualCustodialFee(BigDecimal customerFee) {
        return customerFee
                .divide(BigDecimal.valueOf(1.11), 4, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateBis4AmountDue(int transactionBISSSSTotal, BigDecimal bis4TransactionFee) {
        return new BigDecimal(transactionBISSSSTotal)
                .multiply(bis4TransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateSubTotal(BigDecimal accrualCustodialFee, BigDecimal bis4AmountDue) {
        return accrualCustodialFee.add(bis4AmountDue).setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal subTotal, BigDecimal vatFee) {
        return subTotal.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateKSEIAmountDue(int transactionCBESTTotal, BigDecimal kseiTransactionFee) {
        return new BigDecimal(transactionCBESTTotal)
                .multiply(kseiTransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue, BigDecimal kseiAmountDue) {
        return subTotal.add(vatAmountDue).add(kseiAmountDue).setScale(0, RoundingMode.HALF_UP);
    }

    private FundTemplate1 calculationsWithExistingTransactions(FundType1Parameter params, BillingCustomer customer) {
        int[] filteredTransactionsType = skTransactionService.filterTransactionsType(params.getSkTransactionList());
        int transactionCBESTTotal = filteredTransactionsType[0];
        int transactionBISSSSTotal = filteredTransactionsType[1];

        BigDecimal accrualCustodialAmountDue = calculateAccrualCustodialFee(params.getCustomerFee());
        BigDecimal bis4TransactionAmountDue = calculateBis4AmountDue(transactionBISSSSTotal, params.getBis4TransactionFee());
        BigDecimal subTotal = calculateSubTotal(accrualCustodialAmountDue, bis4TransactionAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(subTotal, params.getVatFee());
        BigDecimal kseiTransactionAmountDue = calculateKSEIAmountDue(transactionCBESTTotal, params.getKseiTransactionFee());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue, kseiTransactionAmountDue);

        return FundTemplate1.builder()
                .accrualCustodialValueFrequency(params.getCustomerFee())
                .accrualCustodialSafekeepingFee(customer.getCustomerSafekeepingFee())
                .accrualCustodialFee(accrualCustodialAmountDue)
                .bis4TransactionValueFrequency(transactionBISSSSTotal)
                .bis4TransactionFee(params.getBis4TransactionFee())
                .bis4TransactionAmountDue(bis4TransactionAmountDue)
                .subTotal(subTotal)
                .vatFee(params.getVatFee())
                .vatAmountDue(vatAmountDue)
                .kseiTransactionValueFrequency(transactionCBESTTotal)
                .kseiTransactionFee(params.getKseiTransactionFee())
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private FundTemplate1 calculationsWithoutExistingTransactions(FundType1Parameter params, BillingCustomer customer) {
        int transactionCBESTTotal = 0;
        int transactionBISSSSTotal = 0;

        BigDecimal accrualCustodialAmountDue = calculateAccrualCustodialFee(params.getCustomerFee());
        BigDecimal bis4TransactionAmountDue = calculateBis4AmountDue(transactionBISSSSTotal, params.getBis4TransactionFee());
        BigDecimal subTotal = calculateSubTotal(accrualCustodialAmountDue, bis4TransactionAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(subTotal, params.getVatFee());
        BigDecimal kseiTransactionAmountDue = calculateKSEIAmountDue(transactionCBESTTotal, params.getKseiTransactionFee());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue, kseiTransactionAmountDue);

        return FundTemplate1.builder()
                .accrualCustodialValueFrequency(params.getCustomerFee())
                .accrualCustodialSafekeepingFee(customer.getCustomerSafekeepingFee())
                .accrualCustodialFee(accrualCustodialAmountDue)
                .bis4TransactionValueFrequency(transactionBISSSSTotal)
                .bis4TransactionFee(params.getBis4TransactionFee())
                .bis4TransactionAmountDue(bis4TransactionAmountDue)
                .subTotal(subTotal)
                .vatFee(params.getVatFee())
                .vatAmountDue(vatAmountDue)
                .kseiTransactionValueFrequency(transactionCBESTTotal)
                .kseiTransactionFee(params.getKseiTransactionFee())
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private BillingFund buildBillingFund(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO, FundTemplate1 fundTemplate1) {
        return BillingFund.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .accrualCustodialValueFrequency(fundTemplate1.getAccrualCustodialValueFrequency())
                .accrualCustodialSafekeepingFee(fundTemplate1.getAccrualCustodialSafekeepingFee())
                .accrualCustodialFee(fundTemplate1.getAccrualCustodialFee())
                .bis4TransactionValueFrequency(fundTemplate1.getBis4TransactionValueFrequency())
                .bis4TransactionFee(fundTemplate1.getBis4TransactionFee())
                .bis4TransactionAmountDue(fundTemplate1.getBis4TransactionAmountDue())
                .subTotal(fundTemplate1.getSubTotal())
                .vatFee(fundTemplate1.getVatFee())
                .vatAmountDue(fundTemplate1.getVatAmountDue())
                .kseiTransactionValueFrequency(fundTemplate1.getKseiTransactionValueFrequency())
                .kseiTransactionFee(fundTemplate1.getKseiTransactionFee())
                .kseiTransactionAmountDue(fundTemplate1.getKseiTransactionAmountDue())
                .totalAmountDue(fundTemplate1.getTotalAmountDue())
                .gefuCreated(false)
                .paid(false)
                .build();
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> calculationErrorMessages, String customerCode, String message) {
        List<String> errorMessages = new ArrayList<>();
        errorMessages.add(message);
        calculationErrorMessages.add(new BillingCalculationErrorMessageDTO(customerCode, errorMessages));
    }

    private void deleteExistingBillingFund(BillingFund existBillingFund) {
        String billingNumber = existBillingFund.getBillingNumber();
        billingFundRepository.delete(existBillingFund);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

}
