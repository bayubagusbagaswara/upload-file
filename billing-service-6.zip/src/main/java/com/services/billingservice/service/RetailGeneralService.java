package com.services.billingservice.service;

import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.dto.retail.BillingRetailListProcessDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.dto.retail.UpdateApprovalStatusBillingRetailRequest;
import com.services.billingservice.model.BillingRetail;

import java.util.List;

public interface RetailGeneralService {

    // get all
    List<BillingRetail> getAll();

    void checkingExistingBillingRetail(String customerCode, String currency, String monthName, Integer year);

    String deleteAll();

    String deleteByCategoryAndTypeAndMonthYear(RetailCalculateRequest request);

    List<BillingRetailListProcessDTO> getAllListProcess();

    List<BillingRetailListProcessDTO> getAllListPendingApprove();

    List<BillingRetailDTO> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(String month, Integer year, String category, String type, String currency);

    List<BillingRetail> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrencyAndCustomerCode(String month, Integer year, String category, String type, String currency, String customerCode);

    String updateApprovalStatus(UpdateApprovalStatusBillingRetailRequest request);

    List<BillingRetailDTO> getAllByCategoryAndMonthYearAndApprovalStatusIsApproved(String category, String monthYear);

    List<BillingRetailDTO> getAllWithAmountGreaterThan5Billion(String category, String monthYear);
}
