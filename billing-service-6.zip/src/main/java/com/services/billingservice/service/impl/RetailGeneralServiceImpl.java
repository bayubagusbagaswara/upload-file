package com.services.billingservice.service.impl;

import com.services.billingservice.dto.retail.BillingRetailDTO;
import com.services.billingservice.dto.retail.BillingRetailListProcessDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.dto.retail.UpdateApprovalStatusBillingRetailRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.GeneralException;
import com.services.billingservice.exception.UnexpectedException;
import com.services.billingservice.mapper.BillingRetailMapper;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.BillingNumberService;
import com.services.billingservice.service.RetailGeneralService;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class RetailGeneralServiceImpl implements RetailGeneralService {

    private final BillingRetailRepository billingRetailRepository;
    private final BillingNumberService billingNumberService;
    private final ConvertDateUtil convertDateUtil;
    private final BillingRetailMapper billingRetailMapper;
    private static final String WORD_PATTERN = "[^\\w_]+";

    @Override
    public List<BillingRetail> getAll() {
        return billingRetailRepository.findAll();
    }

    @Override
    public void checkingExistingBillingRetail(String customerCode, String currency, String monthName, Integer year) {

        Optional<BillingRetail> billingRetailOptional = billingRetailRepository.findByCustomerCodeAndCurrencyAndMonthAndYear(customerCode, currency, monthName, year);

        if (billingRetailOptional.isPresent()) {
            BillingRetail billingRetail = billingRetailOptional.get();
            String billingNumber = billingRetail.getBillingNumber();
            billingRetailRepository.delete(billingRetail);
            billingNumberService.deleteByBillingNumber(billingNumber);
        }
    }

    @Override
    public String deleteAll() {
        try {
            billingRetailRepository.deleteAll();
            return "Successfully deleted all Billing Retail";
        } catch (Exception e) {
            log.error("Error when delete all Billing Retail: " + e.getMessage(), e);
            throw new UnexpectedException("Error when delete all Billing Retail: " + e.getMessage());
        }
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(RetailCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingRetail> billingRetailList = billingRetailRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingRetail billingRetail : billingRetailList) {
                billingRetailRepository.delete(billingRetail);
            }

            return "Successfully delete Billing Retail with total : " + billingRetailList.size();
        } catch (Exception e) {
            throw new UnexpectedException("Error when delete Billing Retail : " + e.getMessage());
        }
    }

    @Override
    public List<BillingRetailListProcessDTO> getAllListPendingApprove() {
        List<BillingRetailListProcessDTO> result = new ArrayList<>();
        billingRetailRepository.getAllListPendingApprove().stream()
                .forEach(f -> {
                    BillingRetailListProcessDTO temp = new BillingRetailListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingRetailListProcessDTO> getAllListProcess() {
        List<BillingRetailListProcessDTO> result = new ArrayList<>();
        billingRetailRepository.getAllListProcess().stream()
                .forEach(f -> {
                    BillingRetailListProcessDTO temp = new BillingRetailListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingRetailDTO> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(String month, Integer year, String category, String type, String currency) {
        List<BillingRetail> billingRetailList = Optional.ofNullable(billingRetailRepository.findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(month, year, category, type, currency))
                .orElse(new ArrayList<>());
        return billingRetailMapper.mapToDTOList(billingRetailList);
    }

    @Override
    public List<BillingRetail> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrencyAndCustomerCode(String month, Integer year, String category, String type, String currency, String customerCode) {
        return Optional.ofNullable(billingRetailRepository.findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrencyAndCustomerCode(month, year, category, type, currency, customerCode))
                .orElse(new ArrayList<>());
    }

    @Override
    public String updateApprovalStatus(UpdateApprovalStatusBillingRetailRequest request) {
        try {
            final String[] typeAndCcy = request.getType().trim().split(WORD_PATTERN);
            final String typeRetail = typeAndCcy[0];
            final String currency = typeAndCcy[1];
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(typeRetail);

            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            ApprovalStatus approvalStatus;
            BillingStatus billingStatus;

            if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Approved.getStatus())) {
                approvalStatus = ApprovalStatus.Approved;
            } else if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Rejected.getStatus())) {
                approvalStatus = ApprovalStatus.Rejected;
            } else {
                approvalStatus = ApprovalStatus.Pending;
            }

            if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Reviewed.getStatus())) {
                billingStatus = BillingStatus.Reviewed;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Approved.getStatus())) {
                billingStatus = BillingStatus.Approved;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Rejected.getStatus())) {
                billingStatus = BillingStatus.Rejected;
            } else {
                billingStatus = BillingStatus.Generated;
            }

            List<BillingRetail> billingRetailList = billingRetailRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndCcy(categoryUpperCase, typeUpperCase, monthName, year, currency);

            for (BillingRetail billingRetail : billingRetailList) {
                billingRetail.setApprovalStatus(approvalStatus);
                billingRetail.setBillingStatus(billingStatus);
                if (!StringUtils.isEmpty(request.getInputerId())) billingRetail.setInputerId(request.getInputerId());
                if (!StringUtils.isEmpty(request.getInputerIPAddress())) billingRetail.setInputerIPAddress(request.getInputerIPAddress());
                if (!StringUtils.isEmpty(request.getApproverId())) billingRetail.setApproverId(request.getApproverId());
                if (!StringUtils.isEmpty(request.getApproverIPAddress())) billingRetail.setApproverIPAddress(request.getApproverIPAddress());
            }

            List<BillingRetail> billingCoreListSaved = billingRetailRepository.saveAll(billingRetailList);

            return "Successfully update Billing Core with approval status '" + approvalStatus + "' and billing status '" + billingStatus + " total: '" + billingCoreListSaved.size() + "'";
        } catch (Exception e) {
            throw new UnexpectedException("Error when update approval status Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public List<BillingRetailDTO> getAllByCategoryAndMonthYearAndApprovalStatusIsApproved(String category, String monthYear) {
        try {
            String categoryUpperCase = category.toUpperCase();
            String approvalStatusIsApproved = ApprovalStatus.Approved.getStatus();
            Map<String, String> stringMap = convertDateUtil.extractMonthYearInformation(monthYear);
            String monthName = stringMap.get("monthName");
            int year = Integer.parseInt(stringMap.get("year"));

            List<BillingRetail> retailList = billingRetailRepository.findAllByCategoryAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, monthName, year, approvalStatusIsApproved
            );

            return billingRetailMapper.mapToDTOList(retailList);
        } catch (Exception e) {
            log.error("Error when get all billing retail by category {}, month year {}, and approval status is approved: {}", category, monthYear, e.getMessage(), e);
            throw new GeneralException("Error when get all billing retail by category and month year and approval status: " + e.getMessage());
        }
    }

    @Override
    public List<BillingRetailDTO> getAllWithAmountGreaterThan5Billion(String category, String monthYear) {
        try {
            String categoryUpperCase = category.toUpperCase();
            String approvalStatusIsApproved = ApprovalStatus.Approved.getStatus();
            Map<String, String> stringMap = convertDateUtil.extractMonthYearInformation(monthYear);
            String monthName = stringMap.get("monthName");
            int year = Integer.parseInt(stringMap.get("year"));

            BigDecimal amount = new BigDecimal(5_000_000);

            List<BillingRetail> retailList = billingRetailRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatusAndAmount(categoryUpperCase, monthName, year, approvalStatusIsApproved, amount);
            return billingRetailMapper.mapToDTOList(retailList);
        } catch (Exception e) {
            log.error("Error when get all billing retail value more than 5 billion: {}", e.getMessage(), e);
            throw new GeneralException("Error when get all billing retail value more than 5 billion: " + e.getMessage());
        }
    }

}
