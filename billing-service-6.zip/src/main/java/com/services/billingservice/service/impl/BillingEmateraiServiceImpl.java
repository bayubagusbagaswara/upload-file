package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingEmateraiDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingEmaterai;
import com.services.billingservice.repository.BillingEmateraiRepository;
import com.services.billingservice.service.BillingEmateraiService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;


@Slf4j
@Service
@RequiredArgsConstructor

public class BillingEmateraiServiceImpl implements BillingEmateraiService {


    private final BillingEmateraiRepository billingEmateraiRepository;

    @Override
    public List<BillingEmateraiDTO> getByCategory(String category) {
        List<BillingEmaterai> billingEmateraiList = billingEmateraiRepository.findBycategory(category);

        if (billingEmateraiList.size() == 0){

        }
        return mapToDTOList(billingEmateraiList);
    }

    private BillingEmateraiDTO mapToDTO(BillingEmaterai billingEmaterai) {
        return BillingEmateraiDTO.builder()
                .customerCode(billingEmaterai.getCustomerCode())
                .securityCode(billingEmaterai.getSecurityCode())
                .period(billingEmaterai.getPeriod())
                .build();
    }

    private List<BillingEmateraiDTO> mapToDTOList(List<BillingEmaterai> billingEmateraiList) {
        return billingEmateraiList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
