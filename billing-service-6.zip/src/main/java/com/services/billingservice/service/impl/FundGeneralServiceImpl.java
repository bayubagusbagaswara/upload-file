package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.dto.fund.BillingFundListProcessDTO;
import com.services.billingservice.dto.fund.UpdateApprovalStatusBillingFundRequest;
import com.services.billingservice.dto.fund.UpdateBillingFundRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.exception.GeneralException;
import com.services.billingservice.exception.UnexpectedException;
import com.services.billingservice.mapper.BillingFundMapper;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.FundGeneralService;
import com.services.billingservice.utils.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class FundGeneralServiceImpl implements FundGeneralService {

    private final BillingFundRepository billingFundRepository;
    private final ConvertDateUtil convertDateUtil;
    private final BillingFundMapper billingFundMapper;

    @Override
    public String updateApprovalStatus(UpdateApprovalStatusBillingFundRequest request) {
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
            String monthName = monthFormat[0];
            int year = Integer.parseInt(monthFormat[1]);

            ApprovalStatus approvalStatus;
            BillingStatus billingStatus;

            // mapping Approval Status
            if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Approved.getStatus())) {
                approvalStatus = ApprovalStatus.Approved;
            } else if (request.getApprovalStatus().equalsIgnoreCase(ApprovalStatus.Rejected.getStatus())) {
                approvalStatus = ApprovalStatus.Rejected;
            } else {
                approvalStatus = ApprovalStatus.Pending;
            }

            // mapping Billing Status
            if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Reviewed.getStatus())) {
                billingStatus = BillingStatus.Reviewed;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Approved.getStatus())) {
                billingStatus = BillingStatus.Approved;
            } else if (request.getBillingStatus().equalsIgnoreCase(BillingStatus.Rejected.getStatus())) {
                billingStatus = BillingStatus.Rejected;
            } else {
                billingStatus = BillingStatus.Generated;
            }

            // ketika billingStatus = Reviewed, maka insert inputDate
            // ketika approvalStatus = Approved dan Rejected, maka insert approveDate

            // Get billing fund list
            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            /* set billing status */
            for (BillingFund billingFund : billingFundList) {
                billingFund.setApprovalStatus(approvalStatus);
                billingFund.setBillingStatus(billingStatus);

                if (billingFund.getBillingStatus().name().equalsIgnoreCase(BillingStatus.Reviewed.name())) {
                    billingFund.setInputDate(convertDateUtil.getDate());
                }

//                if (billingFund.getApprovalStatus().name().equalsIgnoreCase(BillingStatus.))
//
                if (!StringUtils.isEmpty(request.getInputerId())) billingFund.setInputerId(request.getInputerId());
                if (!StringUtils.isEmpty(request.getInputerIPAddress())) billingFund.setInputerIPAddress(request.getInputerIPAddress());
                if (!StringUtils.isEmpty(request.getApproverId())) billingFund.setApproverId(request.getApproverId());
                if (!StringUtils.isEmpty(request.getApproverIPAddress())) billingFund.setApproverIPAddress(request.getApproverIPAddress());
            }

            billingFundRepository.saveAll(billingFundList);

            return "Successfully update approval status '" + approvalStatus + "' and billing status '" + billingStatus;
        } catch (Exception e) {
            throw new UnexpectedException("Error when update approval status Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public String deleteByCategoryAndTypeAndMonthYear(CoreCalculateRequest request) {
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            List<BillingFund> billingFundList = billingFundRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYear(categoryUpperCase, typeUpperCase, monthName, year);

            for (BillingFund billingFund : billingFundList) {
                billingFundRepository.delete(billingFund);
            }

            return "Successfully delete Billing Fund with total : " + billingFundList.size();
        } catch (Exception e) {
            throw new UnexpectedException("Error when delete Billing Fund : " + e.getMessage());
        }
    }

    @Override
    public List<BillingFundDTO> updateAll(List<UpdateBillingFundRequest> requestList) {
        List<BillingFund> billingFundList = new ArrayList<>();

        // looping request list
        for (UpdateBillingFundRequest request : requestList) {
            Long id = request.getId();

            // find billing fund by id
            BillingFund billingFund = billingFundRepository.findById(id)
                    .orElseThrow(() -> new DataNotFoundException("Billing Fund with id '" + id + "is not found"));

            BeanUtil.copyNotNullProperties(request, billingFund); // pastikan yg lolos adalah data yang bukan null


            // update object billing fund
            billingFund.setUpdatedAt(Instant.now());

            billingFundList.add(billingFund);
        }

        List<BillingFund> billingFundListSaved = billingFundRepository.saveAll(billingFundList);

        return billingFundMapper.mapToDTOList(billingFundListSaved);
    }


    private static ApprovalStatus checkEnumApprovalStatus(String approvalStatus) {
        ApprovalStatus status;
        if (ApprovalStatus.Pending.getStatus().equalsIgnoreCase(approvalStatus)) {
            status = ApprovalStatus.Pending;
        } else if (ApprovalStatus.Approved.getStatus().equalsIgnoreCase(approvalStatus)) {
            status = ApprovalStatus.Approved;
        } else {
            status = ApprovalStatus.Rejected;
        }

        return status;
    }

    private static BillingStatus checkEnumBillingStatus(String billingStatus) {
        BillingStatus status;

        if (BillingStatus.Generated.getStatus().equalsIgnoreCase(billingStatus)) {
            status = BillingStatus.Generated;
        } else if (BillingStatus.Reviewed.getStatus().equalsIgnoreCase(billingStatus)) {
            status = BillingStatus.Reviewed;
        } else if (BillingStatus.Approved.getStatus().equalsIgnoreCase(billingStatus)) {
            status = BillingStatus.Approved;
        } else {
            status = BillingStatus.Rejected;
        }

        return status;
    }

    @Override
    public List<BillingFundDTO> getAll() {
        List<BillingFund> billingFundList = billingFundRepository.findAll();
        return billingFundMapper.mapToDTOList(billingFundList);
    }

    @Override
    public List<BillingFundListProcessDTO> getAllListProcess() {
        List<BillingFundListProcessDTO> result = new ArrayList<>();
        billingFundRepository.getAllListProcess().stream()
                .forEach(f -> {
                    BillingFundListProcessDTO temp = new BillingFundListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingFundListProcessDTO> getAllListPendingApprove() {
        List<BillingFundListProcessDTO> result = new ArrayList<>();
        billingFundRepository.getAllListPendingApprove().stream()
                .forEach(f -> {
                    BillingFundListProcessDTO temp = new BillingFundListProcessDTO();
                    BeanUtil.copyAllProperties(f, temp);
                    result.add(temp);
                });
        return result;
    }

    @Override
    public List<BillingFundDTO> findByMonthAndYear(String month, Integer year) {
        List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYear(month, year);
        return billingFundMapper.mapToDTOList(billingFundList);
    }

    @Override
    public List<BillingFundDTO> findByMonthAndYearAndBillingCategoryAndBillingType(String month, Integer year, String category, String type) {
        List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYearAndBillingCategoryAndBillingType(month, year, category, type);
        return billingFundMapper.mapToDTOList(billingFundList);
    }

    @Override
    public List<BillingFundDTO> findByMonthAndYearAndBillingCategoryAndBillingTypeAndCustomerCode(String month, Integer year, String category, String type, String customerCode) {
        List<BillingFund> billingFundList = billingFundRepository.findByMonthAndYearAndBillingCategoryAndBillingTypeAndCustomerCode(month, year, category, type, customerCode);
        return billingFundMapper.mapToDTOList(billingFundList);
    }

    @Override
    public String deleteAll() {
        try {
            billingFundRepository.deleteAll();
            return "Successfully delete all Billing Fund";
        } catch (Exception e) {
            log.error("Error when delete all Billing Funds : " + e.getMessage(), e);
            throw new UnexpectedException("Error when delete all Billing Funds : " + e.getMessage());
        }
    }

    @Override
    public List<BillingFundDTO> getAllByCategoryAndMonthYearAndApprovalStatusIsApproved(String category, String monthYear) {
        try {
            String categoryUpperCase = category.toUpperCase();
            String approvalStatusIsApproved = ApprovalStatus.Approved.getStatus();
            Map<String, String> stringMap = convertDateUtil.extractMonthYearInformation(monthYear);
            String monthName = stringMap.get("monthName");
            int year = Integer.parseInt(stringMap.get("year"));

            List<BillingFund> fundList = billingFundRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatus(categoryUpperCase, monthName, year, approvalStatusIsApproved);

            return billingFundMapper.mapToDTOList(fundList);
        } catch (Exception e) {
            log.error("Error when get all billing fund by category {}, month year {}, and approval status is approved: {}", category, monthYear, e.getMessage(), e);
            throw new GeneralException("Error when get all billing fund by category and month year and approval status: " + e.getMessage());
        }
    }

    @Override
    public List<BillingFundDTO> getAllWithAmountGreaterThan5Billion(String category, String monthYear) {
        try {
            String categoryUpperCase = category.toUpperCase();
            String approvalStatusIsApproved = ApprovalStatus.Approved.getStatus();
            Map<String, String> stringMap = convertDateUtil.extractMonthYearInformation(monthYear);
            String monthName = stringMap.get("monthName");
            int year = Integer.parseInt(stringMap.get("year"));

            BigDecimal amount = new BigDecimal(5_000_000);

            List<BillingFund> fundList = billingFundRepository.findAllByBillingCategoryAndMonthAndYearAndApprovalStatusAndAmount(categoryUpperCase, monthName, year, approvalStatusIsApproved, amount);
            return billingFundMapper.mapToDTOList(fundList);
        } catch (Exception e) {
            log.error("Error when get all billing fund value more than 5 billion: {}", e.getMessage(), e);
            throw new GeneralException("Error when get all billing fund value more than 5 billion: " + e.getMessage());
        }
    }

}
