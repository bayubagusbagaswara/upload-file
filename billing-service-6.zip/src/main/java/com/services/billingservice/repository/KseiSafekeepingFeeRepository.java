package com.services.billingservice.repository;

import com.services.billingservice.model.KseiSafekeepingFee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface KseiSafekeepingFeeRepository extends JpaRepository<KseiSafekeepingFee, Long> {

    @Query(value = "SELECT * FROM bill_ksei_safe WHERE ksei_safe_code = :kseiSafeCode", nativeQuery = true)
    List<KseiSafekeepingFee> findAllByKseiSafeCode(@Param("kseiSafeCode") String kseiSafeCode);

    @Query(value = "SELECT * FROM bill_ksei_safe " +
            "WHERE ksei_safe_code = :kseiSafeCode " +
            "AND month = :month " +
            "AND year = :year " +
            "AND ksei_safe_code <> ''", nativeQuery = true)
    Optional<KseiSafekeepingFee> findByKseiSafeCodeAndMonthAndYear(
            @Param("kseiSafeCode") String kseiSafeCode,
            @Param("month") String monthName,
            @Param("year") int year
    );

    @Query(value = "SELECT * FROM bill_ksei_safe " +
            "WHERE ksei_safe_code = :kseiSafeCode " +
            "AND created_date BETWEEN :startDate AND :endDate", nativeQuery = true)
    List<KseiSafekeepingFee> findByKseiSafeCodeAndDateBetweenNative(
            @Param("kseiSafeCode") String kseiSafeCode,
            @Param("startDate") LocalDate startDate,
            @Param("endDate") LocalDate endDate);

    @Query(value = "SELECT * FROM bill_ksei_safe AS k " +
            "WHERE k.ksei_safe_code = :kseiSafeCode " +
            "AND k.month IN :monthList AND k.year IN :yearList", nativeQuery = true)
    List<KseiSafekeepingFee> findByKseiSafeCodeAndMonthListAndYearList(
            @Param("kseiSafeCode") String kseiSafeCode,
            @Param("monthList") List<String> monthList,
            @Param("yearList") List<Integer> yearList);

    @Query(value = "SELECT * FROM bill_ksei_safe " +
            "WHERE month = :month " +
            "AND year = :year", nativeQuery = true)
    List<KseiSafekeepingFee> findAllByMonthAndYear(@Param("month") String month, @Param("year") Integer year);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM KseiSafekeepingFee k WHERE k.month = :month AND k.year = :year")
    void deleteByMonthAndYear(@Param("month") String month, @Param("year") Integer year);

}
