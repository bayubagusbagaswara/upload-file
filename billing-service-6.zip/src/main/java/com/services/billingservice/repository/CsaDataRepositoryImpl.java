package com.services.billingservice.repository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

@Repository
@Slf4j
@RequiredArgsConstructor
public class CsaDataRepositoryImpl implements CsaDataRepository {

    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;

    @Override
    public void executeQuerySpRekapAccountBalance() {
        try {
            retailAccountBalanceRepository.execSPAccountBalance();
            log.info("Stored procedure executed successfully");
        } catch (Exception e) {
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }

    @Override
    public void executeQuerySpRekapRekapDataTransaksi() {
        try {
            retailTransactionRepository.execSPRekapDataTransaksi();
            log.info("Stored procedure executed successfully");
        } catch (Exception e) {
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }
}
