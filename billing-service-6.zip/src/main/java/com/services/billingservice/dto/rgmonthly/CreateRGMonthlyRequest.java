package com.services.billingservice.dto.rgmonthly;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateRGMonthlyRequest {

    private String batch;
    private String date;
    private String aid;
    private String securityName;
    private String faceValue;
    private String marketPrice;
    private String marketValue;
    private String estimationSafekeepingFee;

}
