package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailCalculateRequest {

    private String category;

    private String type; //  nanti bisa diisi sellingAgent

    private String monthYear; // formatted November 2023

}
