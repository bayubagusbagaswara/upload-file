package com.services.billingservice.controller;

import com.services.billingservice.dto.BillingReportGeneratorDTO;
import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.service.BillingReportGeneratorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/report-generator")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor

public class BillingReportGeneratorController {
    private final BillingReportGeneratorService billingReportGeneratorService;

    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDTO<BillingReportGeneratorDTO>> getById(@PathVariable("id") String id){
        BillingReportGeneratorDTO billingReportGeneratorDTO = billingReportGeneratorService.getById(id);

        ResponseDTO<BillingReportGeneratorDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingReportGeneratorDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDTO<List<BillingReportGeneratorDTO>>> getAllByPeriod(@RequestParam("period") String period) {
        List<BillingReportGeneratorDTO> billingReportGeneratorDTOList = billingReportGeneratorService.getAllByPeriod(period);

        ResponseDTO<List<BillingReportGeneratorDTO>> response = ResponseDTO.<List<BillingReportGeneratorDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingReportGeneratorDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingReportGeneratorDTO>>> getAll(){
        List<BillingReportGeneratorDTO>billingReportGeneratorDTOList = billingReportGeneratorService.getAll();

        ResponseDTO<List<BillingReportGeneratorDTO>>response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(billingReportGeneratorDTOList);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = billingReportGeneratorService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/category")
    public ResponseEntity<ResponseDTO<List<BillingReportGeneratorDTO>>> getAllByPeriodAndCategory(@RequestParam("period") String period,
                                                                                                  @RequestParam("category") String category,
                                                                                                  @RequestParam("miName") String miName) {
        List<BillingReportGeneratorDTO> billingReportGeneratorDTOList = billingReportGeneratorService.getAllByPeriodAndCategory(period, category, miName);

        ResponseDTO<List<BillingReportGeneratorDTO>> response = ResponseDTO.<List<BillingReportGeneratorDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingReportGeneratorDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

}