package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.*;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.exception.GeneralException;
import com.services.billingservice.mapper.FeeParameterMapper;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.repository.BillingFeeParamRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingFeeParameterService;
import com.services.billingservice.utils.BeanUtil;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingFeeParameterServiceImpl implements BillingFeeParameterService {

    private static final String ID_NOT_FOUND = "Fee Parameter not found with id: ";
    private static final String CODE_NOT_FOUND = "Fee Parameter not found with code: ";
    private static final String UNKNOWN = "unknown";

    private final BillingFeeParamRepository feeParameterRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final FeeParameterMapper feeParameterMapper;

    @Override
    public boolean isCodeAlreadyExists(String code) {
        return feeParameterRepository.existsByFeeCode(code);
    }

    @Override
    public boolean isNameAlreadyExists(String name) {
        return feeParameterRepository.existsByFeeName(name);
    }

    @Override
    public FeeParameterResponse createSingleData(CreateFeeParameterRequest createFeeParameterRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data fee parameter with request: {}", createFeeParameterRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        FeeParameterDTO feeParameterDTO = null;

        try {
            /* mapping data from request to dto */
            feeParameterDTO = feeParameterMapper.mapCreateRequestToDto(createFeeParameterRequest);
            log.info("[Create Single] Map create request to dto: {}", feeParameterDTO);

            /* validating for each column dto */
            Errors errors = validateFeeParameterUsingValidator(feeParameterDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* validating code already exists */
            validationCodeAlreadyExists(feeParameterDTO.getFeeCode(), validationErrors);

            /* validating name already exists */
            validationNameAlreadyExists(feeParameterDTO.getFeeName(), validationErrors);

            /* set data input id for data change */
            dataChangeDTO.setInputerId(createFeeParameterRequest.getInputerId());

            /* check validation errors for custom response */
            if (validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeService.createChangeActionADD(dataChangeDTO, BillingFeeParam.class);
                totalDataSuccess++;
            } else {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getFeeCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public FeeParameterResponse createMultipleData(CreateFeeParameterListRequest createFeeParameterListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create multiple fee parameter with request: {}", createFeeParameterListRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (CreateFeeParameterDataListRequest createFeeParameterDataListRequest : createFeeParameterListRequest.getCreateFeeParameterDataListRequests()) {
            FeeParameterDTO feeParameterDTO = null;
            List<String> validationErrors = new ArrayList<>();

            try {
                // Mapping data from request to DTO
                feeParameterDTO = feeParameterMapper.mapCreateListRequestToDTO(createFeeParameterDataListRequest);
                log.info("Fee Parameter DTO: {}", feeParameterDTO);

                // Validating each column in DTO
                Errors errors = validateFeeParameterUsingValidator(feeParameterDTO);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                // Validating code already exists
                validationCodeAlreadyExists(feeParameterDTO.getFeeCode(), validationErrors);

                // Validating name already exists
                validationNameAlreadyExists(feeParameterDTO.getFeeName(), validationErrors);

                // Set input ID to data change
                dataChangeDTO.setInputerId(createFeeParameterListRequest.getInputerId());

                // Check validation errors for custom response
                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getFeeCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    // Prepare data change
                    dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                    // Create change action ADD
                    dataChangeService.createChangeActionADD(dataChangeDTO, BillingFeeParam.class);
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(feeParameterDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public FeeParameterResponse createSingleApprove(FeeParameterApproveRequest approveRequest, String clientIP) {
        log.info("Approve single fee parameter with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        FeeParameterDTO feeParameterDTO = null;

        try {
            /* validate data change id */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* mapping from JSON Data After to class dto */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            feeParameterDTO = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), FeeParameterDTO.class);

            /* check validation code already exists */
            validationCodeAlreadyExists(feeParameterDTO.getFeeCode(), validationErrors);

            /* check validation name already exists */
            validationNameAlreadyExists(feeParameterDTO.getFeeName(), validationErrors);

            /* set data change for approve id and approve ip address */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);

            /* check validation errors for custom response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingFeeParam feeParameter = feeParameterMapper.createEntity(feeParameterDTO, dataChangeDTO);
                feeParameterRepository.save(feeParameter);
                dataChangeDTO.setDescription("Successfully approve data change and save data fee parameter with id: " + feeParameter.getId());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameter)));
                dataChangeDTO.setEntityId(feeParameter.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public FeeParameterResponse updateSingleData(UpdateFeeParameterRequest updateFeeParameterRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data fee parameter with request: {}", updateFeeParameterRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        FeeParameterDTO clonedDTO = null;

        try {
            FeeParameterDTO feeParameterDTO = feeParameterMapper.mapUpdateRequestToDto(updateFeeParameterRequest);
            clonedDTO = new FeeParameterDTO();
            BeanUtil.copyAllProperties(feeParameterDTO, clonedDTO);
            log.info("[Update Single] Result mapping request to dto: {}", feeParameterDTO);

            /* get fee parameter by id */
            BillingFeeParam feeParameter = feeParameterRepository.findById(feeParameterDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeParameterDTO.getId()));

            /* data yang akan di validator */
            copyNonNullOrEmptyFields(feeParameter, clonedDTO);
            log.info("[Update Single] Result map object entity to dto: {}", clonedDTO);

            /* check validator for data request after mapping to dto */
            Errors errors = validateFeeParameterUsingValidator(clonedDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* set input id for data change */
            dataChangeDTO.setInputerId(updateFeeParameterRequest.getInputerId());

            /* check validation errors for custom response */
            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getFeeCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameter)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonDataUpdate(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeDTO.setEntityId(feeParameter.getId().toString());
                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingFeeParam.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(clonedDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public FeeParameterResponse updateMultipleData(UpdateFeeParameterListRequest feeParameterListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple data fee parameter with request: {}", feeParameterListRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        /* repeat data one by one */
        for (UpdateFeeParameterDataListRequest updateFeeParameterDataListRequest : feeParameterListRequest.getUpdateFeeParameterDataListRequests()) {
            List<String> validationErrors = new ArrayList<>();
            FeeParameterDTO feeParameterDTO = null;

            try {
                /* mapping data from request to dto */
                feeParameterDTO = feeParameterMapper.mapUpdateListRequestToDTO(updateFeeParameterDataListRequest);
                log.info("[Update Multiple] Result mapping from request to dto: {}", feeParameterDTO);

                /* get data by code */
                FeeParameterDTO finalFeeParameterDTO = feeParameterDTO;
                BillingFeeParam feeParameter = feeParameterRepository.findByCode(feeParameterDTO.getFeeCode())
                        .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + finalFeeParameterDTO.getFeeCode()));
                log.info("Entity: {}", feeParameter);

                /* map data from dto to entity, to overwrite new data */
                feeParameterMapper.mapObjectsDtoToEntity(feeParameterDTO, feeParameter);
                log.info("[Update Multiple] Result map object dto to entity: {}", feeParameter);
                FeeParameterDTO dto = feeParameterMapper.mapToDto(feeParameter);
                log.info("[Update Multiple] Result map object entity to dto: {}", dto);

                /* check validation data dto */
                Errors errors = validateFeeParameterUsingValidator(dto);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                /* set input id to data change */
                dataChangeDTO.setInputerId(feeParameterListRequest.getInputerId());

                /* check validation errors for custom response */
                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(feeParameterDTO.getFeeCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameter)));
                    dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonDataUpdate(objectMapper.writeValueAsString(feeParameterDTO)));
                    dataChangeDTO.setEntityId(feeParameter.getId().toString());
                    dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingFeeParam.class);
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(feeParameterDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }


    @Override
    public FeeParameterResponse updateSingleApprove(FeeParameterApproveRequest approveRequest, String clientIP) {
        log.info("Approve when update fee parameter with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        FeeParameterDTO feeParameterDTO = null;

        try {
            /* validate data change id */
            validateDataChangeId(approveRequest.getDataChangeId());

            /* get data change by id and get json data after data */
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            Long entityId = Long.valueOf(dataChangeDTO.getEntityId());
            FeeParameterDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), FeeParameterDTO.class);
            log.info("[Update Approve] Map data from JSON data after data change: {}", dto);

            /* get data by id */
            BillingFeeParam feeParameter = feeParameterRepository.findById(entityId)
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + entityId));

            feeParameterMapper.mapObjectsDtoToEntity(dto, feeParameter);
            log.info("[Update Approve] Map object dto to entity: {}", feeParameter);

            feeParameterDTO = feeParameterMapper.mapToDto(feeParameter);
            log.info("[Update Approve] Map from entity to dto: {}", feeParameterDTO);

            /* check validation each column dto */
            Errors errors = validateFeeParameterUsingValidator(feeParameterDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* set data change approve id and approve ip address */
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(clientIP);
            dataChangeDTO.setEntityId(feeParameter.getId().toString());

            /* check validation errors for custom response */
            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingFeeParam feeParameterUpdated = feeParameterMapper.updateEntity(feeParameter, dataChangeDTO);
                BillingFeeParam feeParameterSaved = feeParameterRepository.save(feeParameterUpdated);
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeParameterSaved)));
                dataChangeDTO.setDescription("Successfully approve data change and update data entity with id: " + feeParameterSaved.getId());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeParameterDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new FeeParameterResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public List<FeeParameterDTO> getAll() {
        List<BillingFeeParam> all = feeParameterRepository.findAll();
        return feeParameterMapper.mapToDTOList(all);
    }

    @Override
    public FeeParameterDTO getByCode(String code) {
        BillingFeeParam billingFeeParam  = feeParameterRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + code));
        return feeParameterMapper.mapToDto(billingFeeParam);
    }

    @Override
    public FeeParameterDTO findById(Long id) {
        BillingFeeParam billingFeeParam  = feeParameterRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        return feeParameterMapper.mapToDto(billingFeeParam);
    }

    @Override
    public String deleteAll() {
        feeParameterRepository.deleteAll();
        return "Successfully delete all Fee Parameter";
    }

    @Override
    public BigDecimal getValueByName(String name) {
        BillingFeeParam billingFeeParam = feeParameterRepository.findByFeeName(name)
                .orElseThrow(() -> new DataNotFoundException("Fee Parameter not found with name: " + name));
        return billingFeeParam.getFeeValue();
    }

    @Override
    public Map<String, BigDecimal> getValueByNameList(List<String> nameList) {
        List<BillingFeeParam> feeParameterList = feeParameterRepository.findBillingFeeParamByFeeNameList(nameList);
        Map<String, BigDecimal> collect = feeParameterList.stream()
                .collect(Collectors.toMap(
                        BillingFeeParam::getFeeName,
                        BillingFeeParam::getFeeValue
                ));
        for (String name : nameList) {
            if (!collect.containsKey(name)) {
                throw new DataNotFoundException("Fee Parameter not found with name: " + name);
            }
        }
        return collect;
    }

    private void validationCodeAlreadyExists(String code, List<String> validationErrors) {
        if (isCodeAlreadyExists(code)) {
            validationErrors.add("Fee Parameter is already taken with code: " + code);
        }
    }

    private void validationNameAlreadyExists(String name, List<String> validationErrors) {
        if (isNameAlreadyExists(name)) {
            validationErrors.add("Fee Parameter is already taken with name: " + name);
        }
    }

    private Errors validateFeeParameterUsingValidator(FeeParameterDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "feeParameterDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void handleGeneralError(FeeParameterDTO feeParameterDTO, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeParameterDTO != null ? feeParameterDTO.getFeeCode() : UNKNOWN, validationErrors));
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change ids not found");
            throw new DataNotFoundException("Data Change ids not found");
        }
    }

    private void copyNonNullOrEmptyFields(BillingFeeParam feeParameter, FeeParameterDTO feeParameterDTO) {
        try {
            Map<String, String> entityProperties = BeanUtils.describe(feeParameter);

            for (Map.Entry<String, String> entry : entityProperties.entrySet()) {
                String propertyName = entry.getKey();
                String entityValue = entry.getValue();

                String dtoValue = BeanUtils.getProperty(feeParameterDTO, propertyName);

                if (isNullOrEmpty(dtoValue) && entityValue != null) {
                    BeanUtils.setProperty(feeParameterDTO, propertyName, entityValue);
                }
            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            throw new GeneralException("Failed while processing copy non null or empty fields", e);
        }
    }

    private boolean isNullOrEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

}
