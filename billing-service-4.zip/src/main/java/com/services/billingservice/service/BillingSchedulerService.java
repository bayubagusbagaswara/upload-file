package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingScheduler;

import java.util.List;

public interface BillingSchedulerService {

    void deleteAll();
    
    List<BillingScheduler> getAll(boolean enable);


}
