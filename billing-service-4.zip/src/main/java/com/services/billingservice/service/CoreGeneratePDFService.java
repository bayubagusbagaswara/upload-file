package com.services.billingservice.service;

import com.services.billingservice.dto.core.CoreCalculateRequest;

public interface CoreGeneratePDFService {

    String generatePDF(CoreCalculateRequest request);
}
