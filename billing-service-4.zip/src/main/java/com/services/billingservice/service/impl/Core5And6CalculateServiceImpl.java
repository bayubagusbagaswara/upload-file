package com.services.billingservice.service.impl;

import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.enums.BillingTemplate;
import com.services.billingservice.enums.Currency;
import com.services.billingservice.exception.CalculateBillingException;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.BI_SSSS;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core5And6CalculateServiceImpl implements Core5And6CalculateService {

    private final BillingCustomerService billingCustomerService;
    private final BillingFeeParameterService feeParamService;
    private final SkTranService skTranService;
    private final SfValRgDailyService sfValRgDailyService;
    private final KseiSafeService kseiSafeService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final CoreGeneralService coreGeneralService;
    private final BillingMIService billingMIService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start calculate Billing Core with request '{}'", request);
        try {
            String categoryUpperCase = request.getCategory().toUpperCase();
            String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

            Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            String monthName = monthMinus1.get("monthName");
            int year = Integer.parseInt(monthMinus1.get("year"));

            // Initialization variable
            List<SkTransaction> skTransactionList;
            List<SfValRgDaily> sfValRgDailyList;
            BigDecimal kseiAmountFee;
            List<BillingCore> billingCoreList = new ArrayList<>();
            Instant dateNow = Instant.now();
            int totalDataSuccess = 0;

            // Get Fee Parameter
            List<String> feeParamList = new ArrayList<>();
            feeParamList.add(KSEI.getValue());
            feeParamList.add(BI_SSSS.getValue());
            feeParamList.add(VAT.getValue());

            Map<String, BigDecimal> feeParameterMap = feeParamService.getValueByNameList(feeParamList);
            BigDecimal kseiTransactionFee = feeParameterMap.get(KSEI.getValue());
            BigDecimal bis4TransactionFee = feeParameterMap.get(BI_SSSS.getValue());
            BigDecimal vatFee = feeParameterMap.get(VAT.getValue());

            // Get Billing Customer
            List<BillingCustomer> customerList = billingCustomerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

            for (BillingCustomer billingCustomer : customerList) {
                String aid = billingCustomer.getCustomerCode();
                String customerName = billingCustomer.getCustomerName();
                BigDecimal customerSafekeepingFee = billingCustomer.getCustomerSafekeepingFee();
                BigDecimal customerMinimumFee = billingCustomer.getCustomerMinimumFee();
                String kseiSafeCode = billingCustomer.getKseiSafeCode();
                String billingType = billingCustomer.getBillingType();
                String billingCategory = billingCustomer.getBillingCategory();
                String billingTemplate = billingCustomer.getBillingTemplate();
                String miCode = billingCustomer.getMiCode();

                InvestmentManagementDTO billingMIDTO = billingMIService.getByCode(miCode);

                skTransactionList = skTranService.getAllByAidAndMonthAndYear(aid, monthName, year);

                sfValRgDailyList = sfValRgDailyService.getAllByAidAndMonthAndYear(aid, monthName, year);

                kseiAmountFee = kseiSafeService.calculateAmountFeeByKseiSafeCodeAndMonthAndYear(kseiSafeCode, monthName, year);

                coreGeneralService.checkingExistingBillingCore(monthName, year, aid, billingCategory, billingType);

                BillingCore billingCore;

                if (BillingTemplate.CORE_TEMPLATE_1.getValue().equalsIgnoreCase(billingTemplate)) {
                    billingCore = calculateWithoutNPWP(aid, customerName, customerSafekeepingFee, kseiAmountFee, kseiTransactionFee, bis4TransactionFee, sfValRgDailyList);
                } else {
                    billingCore = calculateWithNPWP(aid, customerName, customerSafekeepingFee, kseiAmountFee, vatFee, kseiTransactionFee, bis4TransactionFee, skTransactionList, sfValRgDailyList);
                }

                billingCore.setCreatedAt(dateNow);
                billingCore.setUpdatedAt(dateNow);
                billingCore.setApprovalStatus(ApprovalStatus.Pending);
                billingCore.setBillingStatus(BillingStatus.Generated);
                billingCore.setMonth(monthName);
                billingCore.setYear(year);
                billingCore.setBillingPeriod(monthName + " " + year);
                billingCore.setBillingStatementDate(ConvertDateUtil.convertInstantToString(dateNow));
                billingCore.setBillingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(dateNow));
                billingCore.setBillingCategory(billingCategory);
                billingCore.setBillingType(billingType);
                billingCore.setBillingTemplate(billingTemplate);
                billingCore.setInvestmentManagementName(billingMIDTO.getName());
                billingCore.setInvestmentManagementAddress1(billingMIDTO.getAddress1());
                billingCore.setInvestmentManagementAddress2(billingMIDTO.getAddress2());
                billingCore.setInvestmentManagementAddress3(billingMIDTO.getAddress3());
                billingCore.setInvestmentManagementAddress4(billingMIDTO.getAddress4());
                billingCore.setInvestmentManagementEmail(billingMIDTO.getEmail());
                billingCore.setInvestmentManagementUniqueKey(billingMIDTO.getUniqueKey());

                billingCore.setCustomerMinimumFee(customerMinimumFee);

                billingCore.setGefuCreated(false);
                billingCore.setPaid(false);
                billingCore.setAccount(billingCustomer.getAccount());
                billingCore.setAccountName(billingCustomer.getAccountName());
                billingCore.setCurrency(Currency.IDR.getValue());

                String number = billingNumberService.generateSingleNumber(monthName, year);
                billingCore.setBillingNumber(number);
                billingCoreRepository.save(billingCore);
                billingNumberService.saveSingleNumber(number);
                totalDataSuccess++;
            }

            log.info("Finished calculate Billing Core type 5 or 6 with month '{}' and year '{}'", monthName, year);
            return "Successfully calculated Billing Core type 5 or 6 with a total: " + totalDataSuccess;
        } catch (Exception e) {
            log.error("Error when calculate Billing Core type 5 or 6: {}", e.getMessage(), e);
            throw new CalculateBillingException("Error when calculate Billing Core type 5 or 6: ", e);
        }
    }


    private static BigDecimal calculateSafekeepingValueFrequency(String aid, List<SfValRgDaily> sfValRgDailyList) {
        List<SfValRgDaily> latestEntries = sfValRgDailyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgDailyList.stream()
                        .map(SfValRgDaily::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        for (SfValRgDaily latestEntry : latestEntries) {
            log.info("Date '{}', Security Name '{}'", latestEntry.getDate(), latestEntry.getSecurityName());
        }

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgDaily::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 5] Safekeeping value frequency Aid '{}' is '{}'", aid, safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(String aid, List<SfValRgDaily> sfValRgDailyList) {
        BigDecimal safekeepingAmountDue = sfValRgDailyList.stream()
                .map(SfValRgDaily::getEstimationSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 5] Safekeeping amount due Aid '{}' is '{}'", aid, safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueWithoutNPWP(String aid, BigDecimal safekeepingAmountDue, BigDecimal kseiAmountFee) {
        BigDecimal totalAmountDue = safekeepingAmountDue.add(kseiAmountFee);
        log.info("[Core Type 5] Total amount due Aid '{}' is '{}'", aid, totalAmountDue);
        return totalAmountDue;
    }

    private static BillingCore calculateWithoutNPWP(String aid, String customerName, BigDecimal customerSafekeepingFee, BigDecimal kseiAmountFee, BigDecimal kseiTransactionFee, BigDecimal bis4TransactionFee, List<SfValRgDaily> sfValRgDailyList) {
        // calculate safekeeping value frequency
        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgDailyList);

        // calculate safekeeping amount due (must not be null)
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(aid, sfValRgDailyList);

        // calculate total amount due
        BigDecimal totalAmountDue = calculateTotalAmountDueWithoutNPWP(aid, safekeepingAmountDue, kseiAmountFee);

        return BillingCore.builder()
                .customerCode(aid)
                .customerName(customerName)
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(customerSafekeepingFee)
                .safekeepingAmountDue(safekeepingAmountDue)
                .kseiTransactionValueFrequency(0)
                .kseiTransactionFee(kseiTransactionFee)
                .kseiTransactionAmountDue(BigDecimal.ZERO)
                .bis4TransactionValueFrequency(0)
                .bis4TransactionFee(bis4TransactionFee)
                .bis4TransactionAmountDue(BigDecimal.ZERO)
                .kseiSafekeepingAmountDue(kseiAmountFee)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private static BigDecimal calculateKseiTransactionAmountDue(String aid, Integer transactionCBESTTotal, BigDecimal kseiTransactionFee) {
        BigDecimal kseiTransactionAmountDue = new BigDecimal(transactionCBESTTotal)
                .multiply(kseiTransactionFee).setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 5] KSEI transaction amount due Aid '{}' is '{}'", aid, kseiTransactionAmountDue);
        return kseiTransactionAmountDue;
    }

    private static BigDecimal calculateBis4TransactionAmountDue(String aid, int transactionBISSSSTotal, BigDecimal bis4TransactionFee) {
        BigDecimal bis4TransactionAmountDue = new BigDecimal(transactionBISSSSTotal)
                .multiply(bis4TransactionFee).setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 5] BI-SSSS transaction amount due Aid '{}' is '{}'", aid, bis4TransactionAmountDue);
        return bis4TransactionAmountDue;
    }

    private static BigDecimal calculateSubTotalAmountDue(String aid, BigDecimal safekeepingAmountDue, BigDecimal bis4TransactionAmountDue) {
        BigDecimal subTotalAmountDue = safekeepingAmountDue
                .add(bis4TransactionAmountDue);
        log.info("[Core Type 5] Sub total amount due Aid '{}' is '{}'", aid, subTotalAmountDue);
        return subTotalAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(String aid, BigDecimal vatFee, BigDecimal subTotalAmountDue) {
        BigDecimal vatAmountDue = subTotalAmountDue
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 5] VAT amount due Aid '{}' is '{}'", aid, vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueWithNPWP(String aid, BigDecimal subTotalAmountDue, BigDecimal vatAmountDue, BigDecimal kseiTransactionAmountDue, BigDecimal kseiAmountFee) {
        BigDecimal totalAmountDue = subTotalAmountDue
                .add(vatAmountDue)
                .add(kseiTransactionAmountDue)
                .add(kseiAmountFee);
        log.info("[Core Type 5] Total amount due Aid '{}' is '{}'", aid, totalAmountDue);
        return totalAmountDue;
    }

    private BillingCore calculateWithNPWP(String aid, String customerName, BigDecimal customerSafekeepingFee, BigDecimal kseiAmountFee, BigDecimal vatFee, BigDecimal kseiTransactionFee, BigDecimal bis4TransactionFee, List<SkTransaction> skTransactionList, List<SfValRgDaily> sfValRgDailyList) {
        // calculate safekeeping value frequency
        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(aid, sfValRgDailyList);

        // calculate safekeeping amount due
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(aid, sfValRgDailyList);

        // Filtered transaction type
        int[] filteredTransactionsType = skTranService.filterTransactionsType(skTransactionList);
        int transactionCBESTTotal = filteredTransactionsType[0];
        int transactionBISSSSTotal = filteredTransactionsType[1];

        // calculate KSEI Transaction Amount Due
        BigDecimal kseiTransactionAmountDue = calculateKseiTransactionAmountDue(aid, transactionCBESTTotal, kseiTransactionFee);

        // calculate BIS4 Transaction Amount Due
        BigDecimal bis4TransactionAmountDue = calculateBis4TransactionAmountDue(aid, transactionBISSSSTotal, bis4TransactionFee);

        // calculate Sub Total
        BigDecimal subTotalAmountDue = calculateSubTotalAmountDue(aid, safekeepingAmountDue, bis4TransactionAmountDue);

        // calculate VAT Amount Due
        BigDecimal vatAmountDue = calculateVATAmountDue(aid, vatFee, subTotalAmountDue);

        // calculate Total Amount Due
        BigDecimal totalAmountDue = calculateTotalAmountDueWithNPWP(aid, subTotalAmountDue, vatAmountDue, kseiTransactionAmountDue, kseiAmountFee);

        return BillingCore.builder()
                .customerCode(aid)
                .customerName(customerName)
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(customerSafekeepingFee)
                .safekeepingAmountDue(safekeepingAmountDue)
                .kseiTransactionValueFrequency(transactionCBESTTotal)
                .kseiTransactionFee(kseiTransactionFee)
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .bis4TransactionValueFrequency(transactionBISSSSTotal)
                .bis4TransactionFee(bis4TransactionFee)
                .bis4TransactionAmountDue(bis4TransactionAmountDue)
                .subTotal(subTotalAmountDue)
                .vatFee(vatFee)
                .vatAmountDue(vatAmountDue)
                .kseiSafekeepingAmountDue(kseiAmountFee)
                .totalAmountDue(totalAmountDue)
                .build();
    }

}
