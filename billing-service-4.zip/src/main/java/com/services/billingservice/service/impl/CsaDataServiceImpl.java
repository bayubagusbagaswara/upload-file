package com.services.billingservice.service.impl;

import com.services.billingservice.repository.CsaDataRepository;
import com.services.billingservice.service.CsaDataService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class CsaDataServiceImpl implements CsaDataService {

    private final CsaDataRepository csaDataRepository;

    @Override
    public String executeQuerySP() {
        csaDataRepository.executeQuerySpRekapAccountBalance();
        csaDataRepository.executeQuerySpRekapRekapDataTransaksi();
        return "Successfully execute query SP CSA data";
    }
}
