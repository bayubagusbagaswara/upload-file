package com.services.billingservice.controller;

import com.services.billingservice.service.AssetTransferCustomerService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/api/asset-transfer-customer")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class AssetTransferCustomerController {

    private static final String MENU_ASSET_TRANSFER_CUSTOMER = "Asset Transfer Customer";

    private final AssetTransferCustomerService assetTransferCustomerService;

}
