package com.services.billingservice.utils;

import org.springframework.stereotype.Component;

@Component
public class NumericValidator {

    private static final String NUMERIC_REGEX = "^\\d*$";
    private static final String BIGDECIMAL_REGEX = "^\\d+(?:\\.\\d+)?$";
    private static final String ALPHANUMERIC_REGEX = "^[a-zA-Z0-9]*$";

    public boolean isValidNumeric(String numeric) {
        return numeric != null && numeric.matches(NUMERIC_REGEX);
    }

    public boolean isValidBigDecimal(String value) {
        return value != null && value.matches(BIGDECIMAL_REGEX);
    }

    public boolean isValidAlphaNumeric(String numeric) {
        return numeric != null && numeric.matches(ALPHANUMERIC_REGEX);
    }
}
