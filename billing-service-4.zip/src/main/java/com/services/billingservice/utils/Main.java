package com.services.billingservice.utils;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        LocalDate currentDate = LocalDate.of(2024, 3, 1);
        int currentMonth = currentDate.getMonthValue();
        int currentYear = currentDate.getYear();

        int newMonth = currentMonth - 1;
        if (newMonth == 0) {
            newMonth = 12;
            currentYear--;
        }

        LocalDate previousMonthYear = LocalDate.of(currentYear, newMonth, 1);
        String monthName = previousMonthYear.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
        int year = previousMonthYear.getYear();

        Map<String, String> monthYear = new HashMap<>();
        monthYear.put("monthName", monthName);
        monthYear.put("year", String.valueOf(year));

        System.out.println(monthYear.get("monthName"));
        System.out.println(monthYear.get("year"));
    }

}
