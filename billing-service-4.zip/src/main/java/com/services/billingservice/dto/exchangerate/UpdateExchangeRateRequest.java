package com.services.billingservice.dto.exchangerate;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import java.math.BigDecimal;
import java.time.LocalDate;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateExchangeRateRequest extends InputIdentifierRequest {

    private Long id;

    private LocalDate date;

    private String currency;

    private String value;
}
