package com.services.billingservice.dto.sellingagent;

import com.services.billingservice.dto.approval.ApprovalIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SellingAgentApproveRequest extends ApprovalIdentifierRequest {

    private String dataChangeId;

}
