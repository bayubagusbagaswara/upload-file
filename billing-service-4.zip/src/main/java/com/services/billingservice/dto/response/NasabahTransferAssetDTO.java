package com.services.billingservice.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NasabahTransferAssetDTO {

    private String id;

    private String customerCode;

    private String securityCode;

    private double amount;

    private String effectiveDate;

    private String transferAssetType;

    private boolean enable;

//    private LocalDateTime createdAt;

    private boolean deleted;

}
