package com.services.billingservice.dto.fund;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateApprovalStatusBillingFundRequest {

    private String inputerId;

    private String inputerIPAddress;

    private String approverId;

    private String approverIPAddress;

    private String category;

    private String type;

    private String monthYear;

    private String approvalStatus;

    private String billingStatus;
}
