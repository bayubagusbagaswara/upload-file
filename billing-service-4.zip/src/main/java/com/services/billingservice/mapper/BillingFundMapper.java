package com.services.billingservice.mapper;

import com.services.billingservice.dto.fund.BillingFundDTO;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class BillingFundMapper {

    public BillingFundDTO mapToDTO(BillingFund billingFund) {
        return BillingFundDTO.builder()
                .id(billingFund.getId())
                .createdAt(billingFund.getCreatedAt())
                .updatedAt(billingFund.getUpdatedAt())
                .billingStatus(billingFund.getBillingStatus().getStatus())
                .approvalStatus(billingFund.getApprovalStatus().getStatus())
                .customerCode(billingFund.getCustomerCode())
                .customerName(billingFund.getCustomerName())
                .month(billingFund.getMonth())
                .year(String.valueOf(billingFund.getYear()))
                .billingNumber(billingFund.getBillingNumber())
                .billingPeriod(billingFund.getBillingPeriod())
                .billingStatementDate(billingFund.getBillingStatementDate())
                .billingPaymentDueDate(billingFund.getBillingPaymentDueDate())
                .billingCategory(billingFund.getBillingCategory())
                .billingType(billingFund.getBillingType())
                .billingTemplate(billingFund.getBillingTemplate())
                .investmentManagementName(billingFund.getInvestmentManagementName())
                .investmentManagementAddress1(billingFund.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingFund.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingFund.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingFund.getInvestmentManagementAddress4())
                .investmentManagementEmail(billingFund.getInvestmentManagementEmail())

                .account(billingFund.getAccount())
                .accountName(billingFund.getAccountName())
                .currency(billingFund.getCurrency())

                .customerFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getCustomerFee()))
                .accrualCustodialFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getAccrualCustodialFee()))
                .bis4TransactionValueFrequency(String.valueOf(billingFund.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionFee()))
                .bis4TransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getBis4TransactionAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getSubTotal()))
                .vatFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatFee()))
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getVatAmountDue()))
                .kseiTransactionValueFrequency(String.valueOf(billingFund.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionFee()))
                .kseiTransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getKseiTransactionAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingFund.getTotalAmountDue()))
                .build();
    }

    public List<BillingFundDTO> mapToDTOList(List<BillingFund> billingFundList) {
        return billingFundList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

}
