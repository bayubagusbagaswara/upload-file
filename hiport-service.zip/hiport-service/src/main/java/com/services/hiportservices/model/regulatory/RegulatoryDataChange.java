package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.regulatory.approval.RegulatoryApproval;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "regulatory_data_change")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegulatoryDataChange extends RegulatoryApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "action")
    private ChangeAction action;

    @Column(name = "entity_class_name")
    private String entityClassName;

    @Column(name = "entity_id")
    private String entityId;

    @Column(name = "table_name")
    private String tableName;

    @Lob
    @Column(name = "data_before", columnDefinition = "nvarchar(max)")
    private String jsonDataBefore;

    @Lob
    @Column(name = "data_after", columnDefinition = "nvarchar(max)")
    private String jsonDataAfter;

    @Column(name = "description")
    private String description;

    @Column(name = "method")
    private String methodHttp;

    @Column(name = "endpoint")
    private String endpoint;

    @Column(name = "is_request_body")
    private Boolean isRequestBody;

    @Column(name = "is_request_param")
    private Boolean isRequestParam;

    @Column(name = "is_path_variable")
    private Boolean isPathVariable;

    @Column(name = "menu")
    private String menu;

}
