package com.services.hiportservices.dto.regulatory.securitiesisincode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteSecuritiesISINCodeRequest extends InputIdentifierRequest {

    private Long id;

}
