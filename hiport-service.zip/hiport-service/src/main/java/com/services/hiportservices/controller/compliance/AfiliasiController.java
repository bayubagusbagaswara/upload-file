package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.AfiliasiRequestDTO;
import com.services.hiportservices.dto.request.compliance.KINVReksadanaRequestDTO;
import com.services.hiportservices.service.compliance.AfiliasiService;
import com.services.hiportservices.service.compliance.KINVReksadanaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/afiliasi")
public class AfiliasiController {
    @Autowired
    AfiliasiService afiliasiService;

    @PostMapping
    public ResponseEntity<ResponseDto> saveListAfiliasi(@RequestBody List<AfiliasiRequestDTO> afiliasiRequestDTOS)  {
        return afiliasiService.insertListAfiliasi(afiliasiRequestDTOS);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> searchPortfolio(@RequestParam String findByCode)  {
        return afiliasiService.searchPihakTerafiliasi(findByCode);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ResponseDto> getById(@PathVariable Long id)  {
        return afiliasiService.getById(id);
    }

    @GetMapping("/byReksadana/{code}")
    public ResponseEntity<ResponseDto> getById(@PathVariable String code)  {
        return afiliasiService.findAllAfiliasiReksadana(code);
    }

    @PutMapping("/delete/{id}")
    public ResponseEntity<ResponseDto> deleteById(@PathVariable Long id)  {
        return afiliasiService.deleteById(id);
    }

    @PutMapping("/upload/{param}")
    public ResponseEntity<ResponseDto> uploadFileMappingPortfolio(@PathVariable String param, @RequestBody List<Map<String, String>> afiliasiList) {
        return afiliasiService.insertAfiliasiUpload(param, afiliasiList);
    }

    @GetMapping("/pending")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return afiliasiService.allPendingDataAfiliasi();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return afiliasiService.approveDataAfiliasi(codeList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithCode(@RequestBody Map<String, List<String>> codeList) {
        return afiliasiService.rejectDataAfiliasi(codeList);
    }
}
