package com.services.hiportservices.controller.emonitoring;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.services.hiportservices.model.emonitoring.OrchidXd12;
import com.services.hiportservices.service.emonitoring.OrchidXd12Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd12")
public class OrchidXD12Controller {
    @Autowired
    OrchidXd12Service orchidXd12Service;

    @GetMapping("/updateAndInsert")
    public List<OrchidXd12> getXd12(
            @RequestParam(name = "date") String date,
            @RequestParam(name = "portofolio",required = false) String pf,
            @RequestParam(name = "group", required = false) String group

    ) throws  ClassNotFoundException, SQLException, IOException {


        return orchidXd12Service.insertOrUpdateAll(date,pf, group);
    }

    @GetMapping("/getDataXD12")
    public List<OrchidXd12> getDataXD12(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd12Service.getDataXD12(date, pf);
    }
}
