package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.NabKPD;
import com.services.hiportservices.model.compliance.XD14KPD;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.repository.compliance.XD14KPDRepository;
import com.services.hiportservices.utils.CsvReader;
import com.services.hiportservices.utils.StringPadder;
import com.services.hiportservices.utils.UserIdUtil;
import lombok.Cleanup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class XD14KPDService {

    @Autowired
    XD14KPDRepository xd14KPDRepository;

    @Autowired
    EntityManager entityManager;

    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat formatApprove = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatUpload = new SimpleDateFormat("dd/MM/yy");

    @Transactional
    public ResponseEntity<ResponseDto> insertDataXd14Kpd(MultipartFile file) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        String message = "";
        ResponseDto responseDto = new ResponseDto();
        try {


            @Cleanup
            BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));

            char dell = ',';
            CsvReader deleteFile = new CsvReader(br, dell);
            while (deleteFile.readRecord()) {

                Date dateParm = sdf.parse(deleteFile.get(0));
                String kode = deleteFile.get(1);

                xd14KPDRepository.deleteXd14(dateParm, kode);
            }

            @Cleanup
            BufferedReader br2 = new BufferedReader(new InputStreamReader(file.getInputStream()));
            CsvReader xd14 = new CsvReader(br2, dell);

            List<XD14KPD> xd14KpdList = new ArrayList<>();
            while (xd14.readRecord()) {
                System.out.println("kesini ?");

                Date dateParm = sdf.parse(xd14.get(0));
                String kode = xd14.get(1);

                String portfolioCode = xd14.get(2);
                String securityCategory = xd14.get(3);
                BigDecimal nilaiBeli = toDoubleValue(xd14.get(4));
                BigDecimal jumlah = toDoubleValue(xd14.get(5));
                Date maturityDate = new Date();

                if (!xd14.get(6).isEmpty() && xd14.get(6).length() == 6) {
                    maturityDate = sdf.parse(xd14.get(6));
                }

                BigDecimal nilai = toDoubleValue(xd14.get(7));
                BigDecimal total = toDoubleValue(xd14.get(8));
                BigDecimal percenAsset = toDoubleValue(xd14.get(9));
                System.out.println(xd14.get(10));
                BigDecimal accruedInterest = toDoubleValue(xd14.get(10));
                String reportGroup = xd14.get(11);
                String issuer = xd14.get(12);


                XD14KPD xd14KPD = new XD14KPD();


                if (securityCategory.equalsIgnoreCase("ZL")) {
                    reportGroup = "97";
                }

                reportGroup = StringPadder.leftPad(reportGroup, "0", 3);

                String portfolioXD14Final = "";
                if (securityCategory.
                        equalsIgnoreCase("ZL") && reportGroup.contains("97")) {
                    System.out.println("kesini");
                    String portfolioXD14Add = issuer.trim();
                    String portfolioXD14AfterSubstring = portfolioCode.length() > 7 ? portfolioCode.substring(0, 7)
                            : portfolioCode;
                    portfolioXD14Final = portfolioXD14Add + portfolioXD14AfterSubstring;
                } else {
                    portfolioXD14Final = portfolioCode.trim();
                }


                xd14KPD.setDateProc(new Date());
                xd14KPD.setKode(kode);
                xd14KPD.setTanggal(dateParm);
                xd14KPD.setPortofolio(portfolioCode);
                xd14KPD.setSectype(securityCategory);
                xd14KPD.setDsplyPorto(portfolioXD14Final);
                xd14KPD.setBunga(accruedInterest);
                xd14KPD.setNilaiBeli(nilaiBeli);
                xd14KPD.setJumlah(jumlah);
                xd14KPD.setTjTempo(maturityDate);
                xd14KPD.setNilai(nilai);
                xd14KPD.setTotal(total);
                xd14KPD.setReportGroup(reportGroup);
                xd14KPD.setIssuerCode(issuer);
                xd14KPD.setPersenAsset(percenAsset);
                xd14KPD.setApprovalStatus(ApprovalStatus.Pending);
                xd14KPD.setInputerId(UserIdUtil.getUser());
                xd14KPD.setInputDate(new Date());

                xd14KPDRepository.save(xd14KPD);

            }


            message = "Uploaded the file successfully: " + file.getOriginalFilename();
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        } catch (Exception e) {
            message = "Could not upload the file: " + file.getOriginalFilename() + ". Error: " + e.getMessage();
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(message);

            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    private BigDecimal toDoubleValue(String data) {
        String doubleData = "0.00";
        if (data != null) {
            if (data.isEmpty())
                data = "0.00";
            else
                doubleData = data.contains("-") ?
                        "-" + data.replace("-", "").trim()
                        : data.trim();
        } else {
            data = "0.00";
        }

        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    public ResponseEntity<ResponseDto> findDataAt(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatApprove.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println(dateOfData);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
//        responseDto.setPayload(xd14KPDRepository.searchApproveXd14KpdDataByDate(dateOfData));
        responseDto.setPayload(xd14KPDRepository.searchAllXd14KpdDataByDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataXd14Kpd() {
        List<Map<String, Object>> listPendingDataFairPrice = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                    "select Tanggal, count(*), inputer_id from comp_xd14_kpd " +
                            "where approval_status = 'Pending' " +
                            "group by Tanggal, inputer_id");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("date", data[0]);
                eachColumn.put("totalData", data[1]);
                eachColumn.put("inputerId", data[2]);

                listPendingDataFairPrice.add(eachColumn);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(listPendingDataFairPrice);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataxd14Kpd(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        System.out.println(approverId);
        List<String> dateList = dates.get("dateList");
        for (String date : dateList) {
            xd14KPDRepository.approveOrRejectXD14KPD("Approved", new Date(), approverId, date);
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataXd14Kpd(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        List<String> dateList = dates.get("dateList");
        for (String date : dateList) {
            xd14KPDRepository.approveOrRejectXD14KPD("Rejected", new Date(), approverId, date);
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> viewPendingData(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatApprove.parse(date);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(xd14KPDRepository.searchPendingXd14KpdDataByDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
