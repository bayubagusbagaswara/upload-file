package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.issuercodeplacementbank.*;
import com.services.hiportservices.repository.regulatory.IssuerCodePlacementBankRepository;
import com.services.hiportservices.service.regulatory.IssuerCodePlacementBankService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class IssuerCodePlacementBankServiceImpl implements IssuerCodePlacementBankService {

    private final IssuerCodePlacementBankRepository issuerCodePlacementBankRepository;

    @Override
    public IssuerCodePlacementBankResponse uploadData(UploadIssuerCodePlacementBankListRequest uploadIssuerCodePlacementBankListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankResponse createApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankResponse updateById(UpdateIssuerCodePlacementBankRequest issuerCodePlacementBankRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankResponse updateApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankResponse deleteById(DeleteIssuerCodePlacementBankRequest deleteIssuerCodePlacementBankRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankResponse deleteApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankDTO getById(Long id) {
        return null;
    }

    @Override
    public IssuerCodePlacementBankDTO getByCode(String code) {
        return null;
    }

    @Override
    public List<IssuerCodePlacementBankDTO> getAll() {
        return null;
    }
}
