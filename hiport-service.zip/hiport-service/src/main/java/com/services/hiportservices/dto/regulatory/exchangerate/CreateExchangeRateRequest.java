package com.services.hiportservices.dto.regulatory.exchangerate;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

import javax.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateExchangeRateRequest extends InputIdentifierRequest {

    @NotBlank(message = "Currency Code cannot be empty")
    private String currencyCode;

    @NotBlank(message = "Currency Name cannot be empty")
    private String currencyName;

    @NotBlank(message = "Rate Value cannot be empty")
    private String exchangeRate;

}
