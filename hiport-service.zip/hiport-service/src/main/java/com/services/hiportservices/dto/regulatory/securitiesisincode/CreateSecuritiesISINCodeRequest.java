package com.services.hiportservices.dto.regulatory.securitiesisincode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

/**
 * untuk anotasi validasi ditaruh disini
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateSecuritiesISINCodeRequest extends InputIdentifierRequest {

    private String externalCode;

    private String currency;

    private String isinLKPBU;

    private String isinLBABK;

}
