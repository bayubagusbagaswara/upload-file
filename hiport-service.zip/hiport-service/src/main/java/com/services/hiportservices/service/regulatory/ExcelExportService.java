package com.services.hiportservices.service.regulatory;

import java.io.ByteArrayInputStream;
import java.io.IOException;

public interface ExcelExportService {

    ByteArrayInputStream exportToExcel() throws IOException;

}
