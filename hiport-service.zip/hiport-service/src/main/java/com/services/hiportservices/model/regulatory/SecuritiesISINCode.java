package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.Approvable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "regulatory_securities_isin_code")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SecuritiesISINCode extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "external_code_2")
    private String externalCode2;

    @Column(name = "currency")
    private String currency;

    @Column(name = "isin_lkpbu")
    private String isinLKPBU;

    @Column(name = "isin_lbabk")
    private String isinLBABK;

}
