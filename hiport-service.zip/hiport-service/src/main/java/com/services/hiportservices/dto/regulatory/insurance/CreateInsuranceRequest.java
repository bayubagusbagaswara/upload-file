package com.services.hiportservices.dto.regulatory.insurance;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateInsuranceRequest {

    private String portfolioCode;

    private String portfolioName;

    private String regulatorName;

    private String referenceInsurancePensionFund;

    private String guaranteeFund;

}
