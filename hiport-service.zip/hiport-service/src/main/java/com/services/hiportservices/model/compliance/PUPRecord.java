
package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_pup_record")
public class PUPRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "breach_started")
    private Date breachStarted;

    @Column(name = "breach_ended")
    private Date breachEnded;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "changes_date")
    private Date changesDate;

    @Column(name = "previous_days_total")
    private int previousDaysTotal;

    @Column(name = "days_total")
    private int daysTotal;

    @Column(name = "pup_total")
    private int pupTotal;


}
