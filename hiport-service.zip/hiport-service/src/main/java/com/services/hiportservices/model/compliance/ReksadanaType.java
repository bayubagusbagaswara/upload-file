package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Data
@Table(name = "comp_reksadana_type")
public class ReksadanaType extends Approvable {
    @Id
    @Column(name = "reksadana_type")
    private String reksadanaType;

    @Column(name = "name")
    private String name;

    @Column(name = "isDelete")
    private boolean delete;
}
