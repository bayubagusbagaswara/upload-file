package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.*;

@Service
public class ComplianceDataChangeService {

    @Autowired
    ReksadanaRepository reksadanaRepository;
    @Autowired
    PortfolioRepository portfolioRepository;
    @Autowired
    KINVReksadanaRepository kinvReksadanaRepository;
    @Autowired
    AfiliasiRepository afiliasiRepository;
    @Autowired
    PortfolioTypeRepository portfolioTypeRepository;
    @Autowired
    ReksadanaTypeRepository reksadanaTypeRepository;
    @Autowired
    PortfolioKINVGroupingRepository portfolioKINVGroupingRepository;
    @Autowired
    MasterKebijakanInvestasiRepository masterKebijakanInvestasiRepository;
    @Autowired
    KinvDetailsRepository kinvDetailsRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;

    public ResponseEntity<ResponseDto> getPendingData() {
        ResponseDto responseDto = new ResponseDto();
        try {
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(complianceDataChangeRepository.searchAllByApprovalStatusPending());

        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<ResponseDto> approveDataChange(Map<String, List<String>> ids) {
        ResponseDto responseDto = new ResponseDto();
        List<String> idList = ids.get("idList");
        System.out.println("MASUK APPROVE DATA CHANGE, LIST: " + idList);
        try {
            ObjectMapper mapper = new ObjectMapper();
            for (String id : idList){
                ComplianceDataChange dataChange = complianceDataChangeRepository.getById(Long.valueOf(id));

                if (dataChange != null) {
                    if (dataChange.getEntityClassName().equalsIgnoreCase(Portfolio.class.getName())) {
                        Portfolio portfolio = portfolioRepository.findByCode(dataChange.getEntityId());

                        Portfolio dto = mapper.readValue(dataChange.getDataChange(),
                                Portfolio.class);

                        portfolio.setApprovalStatus(ApprovalStatus.Approved);
                        portfolio.setApproveDate(new Date());
                        portfolio.setApproverId(UserIdUtil.getUser());
                        portfolio.setInputDate(dataChange.getInputDate());
                        portfolio.setInputerId(dataChange.getInputerId());

                        if(dataChange.getAction() == ChangeAction.Edit){
                            portfolio.setDelete(dto.isDelete());
                            portfolio.setName(dto.getName());
                            portfolio.setIssuer(dto.getIssuer());
                            portfolio.setExternalCode(dto.getExternalCode());
                            portfolio.setPortfolioType(dto.getPortfolioType());
                            portfolio.setDescription(dto.getDescription());
                            portfolio.setSyariah(dto.isSyariah());
                            portfolio.setConventional(dto.isConventional());

                        } else if (dataChange.getAction() == ChangeAction.Delete){
                            portfolio.setDelete(dto.isDelete());
                        }
                        portfolioRepository.save(portfolio);


                    } else if (dataChange.getEntityClassName().equalsIgnoreCase(MasterKebijakanInvestasi.class.getName())) {
                        MasterKebijakanInvestasi masterKebijakanInvestasi = masterKebijakanInvestasiRepository.findByKinvCode(dataChange.getEntityId());

                        MasterKebijakanInvestasi dto = mapper.readValue(dataChange.getDataChange(),
                                MasterKebijakanInvestasi.class);
                        MasterKebijakanInvestasi dataBefore = mapper.readValue(dataChange.getDataBefore(),
                                MasterKebijakanInvestasi.class);

                        masterKebijakanInvestasi.setApprovalStatus(ApprovalStatus.Approved);
                        masterKebijakanInvestasi.setApproveDate(new Date());
                        masterKebijakanInvestasi.setApproverId(UserIdUtil.getUser());
                        masterKebijakanInvestasi.setInputDate(dataChange.getInputDate());
                        masterKebijakanInvestasi.setInputerId(dataChange.getInputerId());

                        if (dataChange.getAction() == ChangeAction.Edit){
                            masterKebijakanInvestasi.setDelete(dto.isDelete());
                            masterKebijakanInvestasi.setKinvCode(dto.getKinvCode());
                            masterKebijakanInvestasi.setKebijakanName(dto.getKebijakanName());
                            masterKebijakanInvestasi.setTypes(dto.getTypes());

                            List<KinvDetails> kinvDetailsListAdd = new ArrayList<>();
                            List<KinvDetails> kinvDetailsListRemove = new ArrayList<>();

                            List<String> portfolioTypesBefore = new ArrayList<String>(Arrays.asList(dataBefore.getTypes().split(",")));
                            List<String> portfolioTypeAfter = new ArrayList<String>(Arrays.asList(dto.getTypes().split(",")));
                            System.out.println("portfolioTypesBefore: " + portfolioTypesBefore);
                            System.out.println("portfolioTypeAfter: " + portfolioTypeAfter);

                            List<String> portfolioTypeListRemove = new ArrayList<>();
                            List<String> portfolioTypeListAdd = new ArrayList<>();

                            for (String type : portfolioTypesBefore){
                                if(!portfolioTypeAfter.contains(type)){
                                    portfolioTypeListRemove.add(type);
                                }
                            }

                            for (String type : portfolioTypeAfter){
                                if(!portfolioTypesBefore.contains(type)){
                                    portfolioTypeListAdd.add(type);
                                }
                            }

                            System.out.println("portfolioTypeListAdd: " + portfolioTypeListAdd);
                            System.out.println("portfolioTypeListRemove: " + portfolioTypeListRemove);

                            if(portfolioTypeListAdd.size() > 0){
                                for (String types : portfolioTypeListAdd) {
                                    PortfolioType portfolioTypeCheck = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(types));
                                    if(portfolioTypeCheck != null){
                                        KinvDetails newKinvDetail = kinvDetailsRepository.findByKinvCodeAndPortfolioType(dto.getKinvCode(), Integer.valueOf(types));
                                        if (newKinvDetail == null) {
                                            KinvDetails kinvDetail = new KinvDetails();
                                            kinvDetail.setKinvCode(dto.getKinvCode());
                                            kinvDetail.setPortfolioType(portfolioTypeCheck.getPortfolioType());
                                            kinvDetailsListAdd.add(kinvDetail);
                                        }
                                    }else {
                                        throw new Exception("Portfolio type is not exist! Please reject this and edit master kebijakan investasi!");
                                    }
                                }
                            }

                            if(portfolioTypeListRemove.size() > 0){
                                for (String types : portfolioTypeListRemove) {
                                    PortfolioType portfolioTypeCheck = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(types));
                                    if(portfolioTypeCheck != null) {
                                        KinvDetails newKinvDetail = kinvDetailsRepository.findByKinvCodeAndPortfolioType(dto.getKinvCode(), Integer.valueOf(types));
                                        if (newKinvDetail != null) {
                                            kinvDetailsListRemove.add(newKinvDetail);
                                        }
                                    } else {
                                        throw new Exception("Portfolio type is not exist! Please reject this and edit master kebijakan investasi!");
                                    }

                                }
                            }

                            kinvDetailsRepository.saveAll(kinvDetailsListAdd);
                            kinvDetailsRepository.deleteAll(kinvDetailsListRemove);

                        } else if (dataChange.getAction() == ChangeAction.Delete){
                            masterKebijakanInvestasi.setDelete(dto.isDelete());
                            kinvDetailsRepository.deleteAllKinvDetails(dto.getKinvCode());

                        }
                        masterKebijakanInvestasiRepository.save(masterKebijakanInvestasi);

                    } else if(dataChange.getEntityClassName().equalsIgnoreCase(Reksadana.class.getName())){
                        Reksadana reksadana = reksadanaRepository.findByCode(dataChange.getEntityId());

                        Reksadana dto = mapper.readValue(dataChange.getDataChange(),
                                Reksadana.class);

                        reksadana.setApprovalStatus(ApprovalStatus.Approved);
                        reksadana.setApproveDate(new Date());
                        reksadana.setApproverId(UserIdUtil.getUser());
                        reksadana.setInputDate(dataChange.getInputDate());
                        reksadana.setInputerId(dataChange.getInputerId());

                        if(dataChange.getAction() == ChangeAction.Edit){
                            reksadana.setDelete(dto.isDelete());
                            reksadana.setExternalCode(dto.getExternalCode());
                            reksadana.setName(dto.getName());
                            reksadana.setEmail(dto.getEmail());
                            reksadana.setManajerInvestasi(dto.getManajerInvestasi());
                            reksadana.setPic(dto.getPic());
                            reksadana.setReksadanaType(dto.getReksadanaType());
                            reksadana.setPercentageModal(dto.getPercentageModal());
                            reksadana.setTnabMinimum(dto.getTnabMinimum());
                            reksadana.setConventional(dto.isConventional());
                            reksadana.setSyariah(dto.isSyariah());
                            reksadana.setAddress(dto.getAddress());
                        } else if(dataChange.getAction() == ChangeAction.Delete){
                            reksadana.setDelete(dto.isDelete());
                        }

                        reksadanaRepository.save(reksadana);

                    } else if(dataChange.getEntityClassName().equalsIgnoreCase(KINVReksadana.class.getName())){
                        KINVReksadana kinvReksadana = kinvReksadanaRepository.getById(Long.valueOf(dataChange.getEntityId()));

                        KINVReksadana dto = mapper.readValue(dataChange.getDataChange(),
                                KINVReksadana.class);

                        if(dataChange.getAction() == ChangeAction.Edit){
                            kinvReksadana.setApprovalStatus(ApprovalStatus.Approved);
                            kinvReksadana.setApproveDate(new Date());
                            kinvReksadana.setApproverId(UserIdUtil.getUser());
                            kinvReksadana.setInputDate(dataChange.getInputDate());
                            kinvReksadana.setInputerId(dataChange.getInputerId());
                            kinvReksadana.setReksadanaCode(dto.getReksadanaCode());
                            kinvReksadana.setRdExternalCode(dto.getRdExternalCode());
                            kinvReksadana.setKinvCode(dto.getKinvCode());
                            kinvReksadana.setKinvMin(dto.getKinvMin());
                            kinvReksadana.setKinvMax(dto.getKinvMax());
                            kinvReksadanaRepository.save(kinvReksadana);
                        } else if(dataChange.getAction() == ChangeAction.Delete){
                            kinvReksadanaRepository.delete(kinvReksadana);
                        }

                    } else if(dataChange.getEntityClassName().equalsIgnoreCase(PortfolioKINVGrouping.class.getName())){
                        PortfolioKINVGrouping portfolioKINVGrouping = portfolioKINVGroupingRepository.getById(Long.valueOf(dataChange.getEntityId()));

                        PortfolioKINVGrouping dto = mapper.readValue(dataChange.getDataChange(),
                                PortfolioKINVGrouping.class);

                        if(dataChange.getAction() == ChangeAction.Edit){
                            portfolioKINVGrouping.setApprovalStatus(ApprovalStatus.Approved);
                            portfolioKINVGrouping.setApproveDate(new Date());
                            portfolioKINVGrouping.setApproverId(UserIdUtil.getUser());
                            portfolioKINVGrouping.setInputDate(dataChange.getInputDate());
                            portfolioKINVGrouping.setInputerId(dataChange.getInputerId());
                            portfolioKINVGrouping.setReksadanaCode(dto.getReksadanaCode());
                            portfolioKINVGrouping.setRdExternalCode(dto.getRdExternalCode());
                            portfolioKINVGrouping.setPortfolio(dto.getPortfolio());
                            portfolioKINVGrouping.setPortfolioType(dto.getPortfolioType());
                            portfolioKINVGroupingRepository.save(portfolioKINVGrouping);
                        } else if(dataChange.getAction() == ChangeAction.Delete){
                            portfolioKINVGroupingRepository.delete(portfolioKINVGrouping);
                        }

                    } else if(dataChange.getEntityClassName().equalsIgnoreCase(PortfolioType.class.getName())){
                        PortfolioType portfolioType = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(dataChange.getEntityId()));

                        PortfolioType dto = mapper.readValue(dataChange.getDataChange(),
                                PortfolioType.class);

                        portfolioType.setApprovalStatus(ApprovalStatus.Approved);
                        portfolioType.setApproveDate(new Date());
                        portfolioType.setApproverId(UserIdUtil.getUser());
                        portfolioType.setInputDate(dataChange.getInputDate());
                        portfolioType.setInputerId(dataChange.getInputerId());
                        if(dataChange.getAction() == ChangeAction.Edit){
                            portfolioType.setName(dto.getName());
                            portfolioType.setDescription(dto.getDescription());
                            portfolioType.setDelete(dto.isDelete());
                        } else if(dataChange.getAction() == ChangeAction.Delete){
                            portfolioType.setDelete(dto.isDelete());
                        }

                        portfolioTypeRepository.save(portfolioType);

                    } else if(dataChange.getEntityClassName().equalsIgnoreCase(ReksadanaType.class.getName())){
                        ReksadanaType reksadanaType = reksadanaTypeRepository.findByReksadanaType(dataChange.getEntityId());

                        ReksadanaType dto = mapper.readValue(dataChange.getDataChange(),
                                ReksadanaType.class);

                        reksadanaType.setApprovalStatus(ApprovalStatus.Approved);
                        reksadanaType.setApproveDate(new Date());
                        reksadanaType.setApproverId(UserIdUtil.getUser());
                        reksadanaType.setInputDate(dataChange.getInputDate());
                        reksadanaType.setInputerId(dataChange.getInputerId());
                        if(dataChange.getAction() == ChangeAction.Edit){
                            reksadanaType.setName(dto.getName());
                            reksadanaType.setDelete(dto.isDelete());
                        } else if(dataChange.getAction() == ChangeAction.Delete){
                            reksadanaType.setDelete(dto.isDelete());
                        }

                        reksadanaTypeRepository.save(reksadanaType);

                    } else if(dataChange.getEntityClassName().equalsIgnoreCase(Afiliasi.class.getName())){
                        Afiliasi afiliasi = afiliasiRepository.findById(Long.valueOf(dataChange.getEntityId())).orElseThrow(() -> new RuntimeException("Data Not Found!"));
                        System.out.println(afiliasi.getId());
                        afiliasiRepository.delete(afiliasi);

                    }

                    dataChange.setApprovalStatus(ApprovalStatus.Approved);
                    dataChange.setApproveDate(new Date());
                    dataChange.setApproverId(UserIdUtil.getUser());
                    complianceDataChangeRepository.save(dataChange);

                }
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Save Data Change Success!");
        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataChange(Map<String, List<String>> ids) {
        ResponseDto responseDto = new ResponseDto();
        List<String> idList = ids.get("idList");
        System.out.println("MASUK REJECT DATA CHANGE, LIST: " + idList);
        try {
            for (String id : idList){
                ComplianceDataChange dataChange = complianceDataChangeRepository.getById(Long.valueOf(id));

                if (dataChange != null) {

                    if(dataChange.getEntityClassName().equalsIgnoreCase(KINVReksadana.class.getName())){
                        //Ini save karena bisa aja reksadananya di approve tapi kinvReksadananya di Reject dan ternyata ada perubahan external code
                        ObjectMapper mapper = new ObjectMapper();
                        KINVReksadana kinvReksadana = mapper.readValue(dataChange.getDataBefore(), KINVReksadana.class);
                        Reksadana reksadana = reksadanaRepository.findByCode(kinvReksadana.getReksadanaCode().getCode());
                        kinvReksadanaRepository.updateExternalCodeWhereCode(reksadana.getExternalCode(), kinvReksadana.getReksadanaCode().getCode());
                    }

                    dataChange.setApprovalStatus(ApprovalStatus.Rejected);
                    dataChange.setApproveDate(new Date());
                    dataChange.setApproverId(UserIdUtil.getUser());
                    complianceDataChangeRepository.save(dataChange);

                }
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Save Data Change Success!");
        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getDataBeforAfter(String id) {
        ResponseDto responseDto = new ResponseDto();
        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> passingData = new HashMap<>();
            ComplianceDataChange dataChange = complianceDataChangeRepository.getById(Long.valueOf(id));
            if (dataChange.getEntityClassName().equalsIgnoreCase(ReksadanaType.class.getName())){
                ReksadanaType reksadanaType = mapper.readValue(dataChange.getDataBefore(),
                        ReksadanaType.class);
                ReksadanaType dto = mapper.readValue(dataChange.getDataChange(),
                        ReksadanaType.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", reksadanaType);
                passingData.put("dataAfter", dto);

            } else if (dataChange.getEntityClassName().equalsIgnoreCase(Portfolio.class.getName())) {
                Portfolio dto = mapper.readValue(dataChange.getDataChange(),
                        Portfolio.class);
                Portfolio portfolio = mapper.readValue(dataChange.getDataBefore(),
                        Portfolio.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", portfolio);
                passingData.put("dataAfter", dto);

            } else if (dataChange.getEntityClassName().equalsIgnoreCase(MasterKebijakanInvestasi.class.getName())) {
                MasterKebijakanInvestasi dto = mapper.readValue(dataChange.getDataChange(),
                        MasterKebijakanInvestasi.class);
                MasterKebijakanInvestasi dataBefore = mapper.readValue(dataChange.getDataBefore(),
                        MasterKebijakanInvestasi.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", dataBefore);
                passingData.put("dataAfter", dto);

            } else if(dataChange.getEntityClassName().equalsIgnoreCase(Reksadana.class.getName())){
                Reksadana reksadana = mapper.readValue(dataChange.getDataBefore(),
                        Reksadana.class);
                Reksadana dto = mapper.readValue(dataChange.getDataChange(),
                        Reksadana.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", reksadana);
                passingData.put("dataAfter", dto);

            } else if(dataChange.getEntityClassName().equalsIgnoreCase(KINVReksadana.class.getName())){
                KINVReksadana kinvReksadana = mapper.readValue(dataChange.getDataBefore(),
                        KINVReksadana.class);
                KINVReksadana dto = mapper.readValue(dataChange.getDataChange(),
                        KINVReksadana.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", kinvReksadana);
                passingData.put("dataAfter", dto);

            } else if(dataChange.getEntityClassName().equalsIgnoreCase(PortfolioKINVGrouping.class.getName())){
                PortfolioKINVGrouping portfolioKINVGrouping = mapper.readValue(dataChange.getDataBefore(),
                        PortfolioKINVGrouping.class);
                PortfolioKINVGrouping dto = mapper.readValue(dataChange.getDataChange(),
                        PortfolioKINVGrouping.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", portfolioKINVGrouping);
                passingData.put("dataAfter", dto);

            } else if(dataChange.getEntityClassName().equalsIgnoreCase(PortfolioType.class.getName())){
                PortfolioType portfolioType = mapper.readValue(dataChange.getDataBefore(),
                        PortfolioType.class);
                PortfolioType dto = mapper.readValue(dataChange.getDataChange(),
                        PortfolioType.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", portfolioType);
                passingData.put("dataAfter", dto);

            } else if(dataChange.getEntityClassName().equalsIgnoreCase(Afiliasi.class.getName())){
                Afiliasi afiliasi = mapper.readValue(dataChange.getDataBefore(),
                        Afiliasi.class);
                Afiliasi dto = mapper.readValue(dataChange.getDataChange(),
                        Afiliasi.class);

                passingData.put("id", dataChange.getId());
                passingData.put("action", dataChange.getAction());
                passingData.put("dataBefore", afiliasi);
                passingData.put("dataAfter", dto);

            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(passingData);

        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
