package com.services.hiportservices.dto.request.emonitoring;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Xd14RequestDto {
    String Date;
    String Portofolio;
}
