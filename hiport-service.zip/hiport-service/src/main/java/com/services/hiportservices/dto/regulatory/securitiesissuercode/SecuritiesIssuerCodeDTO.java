package com.services.hiportservices.dto.regulatory.securitiesissuercode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SecuritiesIssuerCodeDTO {

    private Long id;

    private String externalCode2;

    private String currency;

    private String issuerLBABK;

    private String issuerLKPBU;

}
