package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesisincode.*;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.UploadSecuritiesIssuerCodeListRequest;
import com.services.hiportservices.repository.regulatory.SecuritiesISINCodeRepository;
import com.services.hiportservices.service.regulatory.SecuritiesISINCodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecuritiesISINCodeServiceImpl implements SecuritiesISINCodeService {

    private final SecuritiesISINCodeRepository securitiesISINCodeRepository;

    @Override
    public SecuritiesISINCodeResponse uploadData(UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public SecuritiesISINCodeResponse create(CreateSecuritiesISINCodeRequest createSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public SecuritiesISINCodeResponse createApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public SecuritiesISINCodeResponse updateById(UpdateSecuritiesISINCodeRequest updateSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public SecuritiesISINCodeResponse updateApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public SecuritiesISINCodeResponse deleteById(DeleteSecuritiesISINCodeRequest deleteSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public SecuritiesISINCodeResponse deleteApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public SecuritiesISINCodeDTO getById(Long id) {
        return null;
    }

    @Override
    public SecuritiesISINCodeDTO getByExternalCode(String externalCode) {
        return null;
    }

    @Override
    public List<SecuritiesISINCodeDTO> getAll() {
        return null;
    }
}
