package com.services.hiportservices.dto.regulatory.securitiesissuercode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Ini adalah Isi data dari file upload Securities Issuer Code
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadSecuritiesIssuerCodeDataRequest {

    @JsonProperty(value = "External Code 2")
    private String externalCode;

    @JsonProperty(value = "Currency")
    private String currency;

    @JsonProperty(value = "Issuer LBABK")
    private String issuerLBABK;

    @JsonProperty(value = "Issuer LKPBU")
    private String issuerLKPBU;

}
