package com.services.hiportservices.dto.regulatory.lkpbu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * data untuk report LKPBU
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBU2DTO {

    private String number;

    private String kodeKomponen;

    private String securitiesOwnerGolongan;
    private String securitiesOwnerSandiPerusahaan;
    private String securitiesOwnerNegaraAsal;

    private String securitiesIssuerGolongan;
    private String securitiesIssuerNegaraAsal;

    private String securitiesKode;
    private String securitiesJenis;
    private String securitiesKodeEfek;
    private String securitiesLembarUnit;
    private String securitiesInterestRate;
    private String securitiesKeterangan;
    private String securitiesDanaJaminan;

    private String jenisValuta;

    private String issuerDate;
    private String issuerDueDate;

    private String nilaiValutaAsal;

    private String pembayaranKupon;

}
