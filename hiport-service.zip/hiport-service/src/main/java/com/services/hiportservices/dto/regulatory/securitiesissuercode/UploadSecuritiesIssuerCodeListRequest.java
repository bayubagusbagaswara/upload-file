package com.services.hiportservices.dto.regulatory.securitiesissuercode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadSecuritiesIssuerCodeListRequest extends InputIdentifierRequest {

    private List<UploadSecuritiesIssuerCodeDataRequest> uploadIssuerCodeDataListRequest;

}
