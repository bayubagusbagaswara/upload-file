package com.services.hiportservices.dto.regulatory.ownergroup;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OwnerGroupDTO {

    private Long id;

    private String portfolioCode;

    private String portfolioName;

    private String sInvestCode;

    private String opposingGroupReference;

    private String countryReference;

}
