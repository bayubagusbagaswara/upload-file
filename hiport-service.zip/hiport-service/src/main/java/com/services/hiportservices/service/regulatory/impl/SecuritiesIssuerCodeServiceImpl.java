package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.*;
import com.services.hiportservices.repository.regulatory.SecuritiesIssuerCodeRepository;
import com.services.hiportservices.service.regulatory.SecuritiesIssuerCodeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecuritiesIssuerCodeServiceImpl implements SecuritiesIssuerCodeService {

    private final SecuritiesIssuerCodeRepository securitiesIssuerCodeRepository;

    @Override
    public SecuritiesIssuerCodeResponse uploadData(UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public SecuritiesIssuerCodeResponse createApprove(ApproveSecuritiesIssuerCodeRequest approveRequest, String clientIP) {
        return null;
    }

    @Override
    public SecuritiesIssuerCodeResponse updateApprove(ApproveSecuritiesIssuerCodeRequest approveRequest, String clientIP) {
        return null;
    }

    @Override
    public SecuritiesIssuerCodeResponse deleteById(DeleteSecuritiesIssuerCodeRequest deleteSecuritiesIssuerCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public SecuritiesIssuerCodeResponse deleteApprove(ApproveSecuritiesIssuerCodeRequest approveSecuritiesIssuerCodeRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public SecuritiesIssuerCodeDTO getById(Long id) {
        return null;
    }

    @Override
    public SecuritiesIssuerCodeDTO getByExternalCode(String externalCode) {
        return null;
    }

    @Override
    public List<SecuritiesIssuerCodeDTO> getAll() {
        return null;
    }
}
