package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

import javax.persistence.Column;

@Data
public class PortfolioTypeRequestDTO {
    private int portfolioType;
    private String name;
    private String description;
    private boolean delete;
}
