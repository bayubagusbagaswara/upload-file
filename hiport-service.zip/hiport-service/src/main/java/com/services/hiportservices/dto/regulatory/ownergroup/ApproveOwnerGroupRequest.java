package com.services.hiportservices.dto.regulatory.ownergroup;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveOwnerGroupRequest extends ApprovalIdentifierRequest {

    private Long dataChangeId;

}
