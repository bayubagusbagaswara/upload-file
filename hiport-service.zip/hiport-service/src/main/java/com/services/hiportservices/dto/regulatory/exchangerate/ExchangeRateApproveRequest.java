package com.services.hiportservices.dto.regulatory.exchangerate;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class ExchangeRateApproveRequest extends ApprovalIdentifierRequest {

    private String dataChangeId;

}
