package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.KebijakanInvRequestDto;
import com.services.hiportservices.dto.request.compliance.PortfolioTypeRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.DataChange;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.DataChangeRepository;
import com.services.hiportservices.repository.compliance.ComplianceDataChangeRepository;
import com.services.hiportservices.repository.compliance.KinvDetailsRepository;
import com.services.hiportservices.repository.compliance.MasterKebijakanInvestasiRepository;
import com.services.hiportservices.repository.compliance.PortfolioTypeRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.enums.Enum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class MasterKebijakanService {

    @Autowired
    MasterKebijakanInvestasiRepository masterKebijakanInvestasiRepository;
    @Autowired
    KinvDetailsRepository kinvDetailsRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;
    @Autowired
    PortfolioTypeRepository portfolioTypeRepository;

    public ResponseEntity<ResponseDto> insertMasterKebijakan(KebijakanInvRequestDto kebijakanInvRequestDto) {
        ResponseDto responseDto = new com.services.hiportservices.dto.ResponseDto();
        String message = "";
        MasterKebijakanInvestasi masterKebijakanInvestasi = masterKebijakanInvestasiRepository.findByKinvCode(kebijakanInvRequestDto.getKinvCode());
        try {
            if (masterKebijakanInvestasi == null) {
                masterKebijakanInvestasi = new MasterKebijakanInvestasi();
                masterKebijakanInvestasi.setApprovalStatus(ApprovalStatus.Pending);
                masterKebijakanInvestasi.setInputDate(new Date());
                masterKebijakanInvestasi.setInputerId(UserIdUtil.getUser());
                masterKebijakanInvestasi.setDelete(false);
                masterKebijakanInvestasi.setKinvCode(kebijakanInvRequestDto.getKinvCode());
                masterKebijakanInvestasi.setKebijakanName(kebijakanInvRequestDto.getKebijakanName());
                masterKebijakanInvestasi.setTypes(kebijakanInvRequestDto.getTypes());
                masterKebijakanInvestasiRepository.save(masterKebijakanInvestasi);

                message = "Success insert new kebijakan investasi";

            } else {
                MasterKebijakanInvestasi masterKebijakanInvestasiAfter = new MasterKebijakanInvestasi();
                masterKebijakanInvestasiAfter.setInputDate(new Date());
                masterKebijakanInvestasiAfter.setInputerId(UserIdUtil.getUser());
                masterKebijakanInvestasiAfter.setDelete(false);
                masterKebijakanInvestasiAfter.setKinvCode(kebijakanInvRequestDto.getKinvCode());
                masterKebijakanInvestasiAfter.setKebijakanName(kebijakanInvRequestDto.getKebijakanName());
                masterKebijakanInvestasiAfter.setTypes(kebijakanInvRequestDto.getTypes());

                ObjectMapper Obj = new ObjectMapper();
                String jsonbefore = Obj.writeValueAsString(masterKebijakanInvestasi);
                ObjectMapper ObjAfter = new ObjectMapper();
                String jsonAfter = ObjAfter.writeValueAsString(masterKebijakanInvestasiAfter);

                ComplianceDataChange dataChange = new ComplianceDataChange();
                dataChange.setApprovalStatus(ApprovalStatus.Pending);
                dataChange.setInputerId(UserIdUtil.getUser());
                dataChange.setInputDate(new Date());
                dataChange.setAction(ChangeAction.Edit);
                dataChange.setEntityId(masterKebijakanInvestasi.getKinvCode());
                dataChange.setTableName("comp_master_kinv");
                dataChange.setEntityClassName(MasterKebijakanInvestasi.class.getName());
                dataChange.setDataBefore(jsonbefore);
                dataChange.setDataChange(jsonAfter);

                complianceDataChangeRepository.save(dataChange);
                message = "Success update master kebijakan investasi!";
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);

        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getAllByDelete() {

        ResponseDto responseDto = new com.services.hiportservices.dto.ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(masterKebijakanInvestasiRepository.findAllByDeleteAndApprovalStatus(false, ApprovalStatus.Approved));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> deleteByCode(String code) {
        ResponseDto responseDto = new com.services.hiportservices.dto.ResponseDto();
        try {
            MasterKebijakanInvestasi masterKebijakanInvestasi = masterKebijakanInvestasiRepository.findByKinvCode(code);

            MasterKebijakanInvestasi masterKebijakanInvestasiAfter = new MasterKebijakanInvestasi();
            masterKebijakanInvestasiAfter.setApprovalStatus(ApprovalStatus.Pending);
            masterKebijakanInvestasiAfter.setInputDate(new Date());
            masterKebijakanInvestasiAfter.setInputerId(UserIdUtil.getUser());
            masterKebijakanInvestasiAfter.setDelete(true);

            ObjectMapper Obj = new ObjectMapper();
            String jsonbefore = Obj.writeValueAsString(masterKebijakanInvestasi);
            ObjectMapper ObjAfter = new ObjectMapper();
            String jsonAfter = ObjAfter.writeValueAsString(masterKebijakanInvestasiAfter);

            ComplianceDataChange dataChange = new ComplianceDataChange();
            dataChange.setApprovalStatus(ApprovalStatus.Pending);
            dataChange.setInputerId(UserIdUtil.getUser());
            dataChange.setInputDate(new Date());
            dataChange.setAction(ChangeAction.Delete);
            dataChange.setEntityId(masterKebijakanInvestasi.getKinvCode());
            dataChange.setTableName("comp_master_kinv");
            dataChange.setEntityClassName(MasterKebijakanInvestasi.class.getName());
            dataChange.setDataBefore(jsonbefore);
            dataChange.setDataChange(jsonAfter);

            complianceDataChangeRepository.save(dataChange);

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Delete Success where code " + code + "!");

        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getByCode(String code) {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(masterKebijakanInvestasiRepository.findByKinvCode(code));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataKinv() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(masterKebijakanInvestasiRepository.searchPendingData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }


    @Transactional
    public ResponseEntity<ResponseDto> approveDataKinv(Map<String, List<String>> kinvList) {
        ResponseDto responseDto = new ResponseDto();
        String approverId = UserIdUtil.getUser();
        List<String> kinnvs = kinvList.get("idList");
        try {
            for (String kinv : kinnvs){
                masterKebijakanInvestasiRepository.approveOrRejectMasterKinv("Approved", new Date(), approverId, kinv);
                MasterKebijakanInvestasi mstKinv = masterKebijakanInvestasiRepository.findByKinvCode(kinv);
                if (mstKinv != null){
                    String[] portfolioTypes = mstKinv.getTypes().split(",");
                    List<String> portfolioTypeList = Arrays.asList(portfolioTypes);
                    List<KinvDetails> kinvDetailsList = new ArrayList<>();
                    for (String portfolioType : portfolioTypeList) {
                        PortfolioType portfolioTypeCheck = portfolioTypeRepository.findByPortfolioType(Integer.valueOf(portfolioType));
                        if (portfolioTypeCheck != null){
                            KinvDetails kinvDetail = kinvDetailsRepository.findByKinvCodeAndPortfolioType(mstKinv.getKinvCode(), Integer.valueOf(portfolioType));
                            if (kinvDetail == null) {
                                kinvDetail = new KinvDetails();
                                kinvDetail.setKinvCode(mstKinv.getKinvCode());
                                kinvDetail.setPortfolioType(portfolioTypeCheck.getPortfolioType());
                                kinvDetailsList.add(kinvDetail);
                            }
                        } else {
                            throw new Exception("Portfolio type is not exist! Please edit master kebijakan investasi!");
                        }
                    }
                    kinvDetailsRepository.saveAll(kinvDetailsList);
                } else {
                    throw new Exception("Master KINV is not exist!");
                }
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have approved!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataKinv(Map<String, List<String>> kinvList) {
        String approverId = UserIdUtil.getUser();
        ResponseDto responseDto = new ResponseDto();
        List<String> kinvs = kinvList.get("idList");
        System.out.println(kinvList);
        try {
            for (String kinv : kinvs){
                masterKebijakanInvestasiRepository.deleteByKinvCode(kinv);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have rejected!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

}
