package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.model.emonitoring.OrchidXd15;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;


public interface OrchidXd11Repository extends JpaRepository<OrchidXd11,Long> {
//    List<OrchidXd11> findAllByPortofolio(String portofolio);

    List<OrchidXd11> findAllByTanggal(Date tanggal);

    OrchidXd11 findByTanggalAndKode(Date tanggal, String code);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDXD11 WHERE Tanggal = :tgl and ReksadanaCode = :rekCode", nativeQuery = true)
    void deleteOrchidXd11(@Param("tgl") Date tgl,
                          @Param("rekCode") String rekCode);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDXD11 WHERE Tanggal = :tgl", nativeQuery = true)
    void deleteAllOrchidXd11(@Param("tgl") Date tgl);

    @Query(value = "SELECT * FROM ORCHIDXD11 WHERE tanggal = :date and ( Kode = :code or ReksadanaCode = :code)", nativeQuery = true)
    OrchidXd11 searchDataBy(
            @Param("date") String date,
            @Param("code") String code);

}
