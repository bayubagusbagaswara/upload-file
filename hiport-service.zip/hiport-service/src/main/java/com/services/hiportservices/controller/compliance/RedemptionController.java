package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.IDXPriceService;
import com.services.hiportservices.service.compliance.RedemptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/redemption")
public class RedemptionController {

    @Autowired
    RedemptionService redemptionService;

    @PostMapping("/upload")
    public ResponseEntity<ResponseDto> uploadFileIdx(@RequestBody List<Map<String, String>> redemptionList) {
        return redemptionService.insertDataRedemption(redemptionList);
    }

    @GetMapping("/{date}")
    public ResponseEntity<ResponseDto> getAllDataAt(@PathVariable String date) {
        return redemptionService.findDataAt(date);
    }

    @GetMapping("/viewPending/{date}")
    public ResponseEntity<ResponseDto> viewPendingData(@PathVariable String date) {
        return redemptionService.viewPendingData(date);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return redemptionService.allPendingDataRedemption();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataAt(@RequestBody Map<String, List<String>> dates) {
        return redemptionService.approveDataRedemption(dates);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataAt(@RequestBody Map<String, List<String>> dates) {
        return redemptionService.rejectDataRedemption(dates);
    }
}
