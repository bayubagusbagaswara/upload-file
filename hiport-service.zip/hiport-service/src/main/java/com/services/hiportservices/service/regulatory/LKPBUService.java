package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUDTO;
import com.services.hiportservices.dto.regulatory.lkpbu.LKPBU2DTO;

import java.util.List;

public interface LKPBUService {

    List<LKPBUDTO> getAllDataMock();

    List<LKPBU2DTO> getAllDataMock2();



}
