package com.services.hiportservices.dto.regulatory.insurancepensionfund;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadInsurancePensionFundListRequest extends InputIdentifierRequest {

    private List<UploadInsurancePensionFundDataRequest> uploadInsurancePensionFundDataRequests;

}
