package com.services.hiportservices.service.emonitoring;


import com.services.hiportservices.model.emonitoring.OrchidXdAktif;
import com.services.hiportservices.repository.emonitoring.OrchidXdActiveRepository;
import com.services.hiportservices.utils.ConfigPropertiesUtil;
import com.services.hiportservices.utils.StringPadder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class OrchidAktifService {
    @Autowired
    OrchidXdActiveRepository orchidAktifRepository;

    public List<OrchidXdAktif> getDataAktif(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXdAktif> listOrchid = new ArrayList<>();
        System.out.println("get code adalah: " + pfCode);
        try {
            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {
                listOrchid.addAll(orchidAktifRepository.findAllByProcessDate(dateParm));
            } else {
                listOrchid.add(orchidAktifRepository.searchDataAt(date, pfCode));
                System.out.println(listOrchid.size());
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }


    public List<OrchidXdAktif> insertOrUpdateAll(String date, String pf, String group)
            throws SQLException, ClassNotFoundException, IOException {

        List<OrchidXdAktif> listOrchid = new ArrayList<>();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        String className = ConfigPropertiesUtil.getProperty("hiport.className", "connection.properties");
        String ip = ConfigPropertiesUtil.getProperty("hiport.ip", "connection.properties");
        String port = ConfigPropertiesUtil.getProperty("hiport.port", "connection.properties");
        String dataSource = ConfigPropertiesUtil.getProperty("hiport.ServerDataSource", "connection.properties");
        String user = ConfigPropertiesUtil.getProperty("hiport.user", "connection.properties");
        String pass = ConfigPropertiesUtil.getProperty("hiport.password", "connection.properties");

        try {
            Date dateParm = sdf.parse(date);

            if (pf == null || pf.isEmpty()) {
                orchidAktifRepository.deleteAllOrchidAktif(dateParm);
            } else {
                orchidAktifRepository.deleteOrchidAktifByCode(dateParm, pf);
            }

            Class.forName(className);

            String urlConn = "jdbc:DRO://" + ip + ":" + port +
                    ";ServerDataSource=" + dataSource + ";USER=" + user + ";PASSWORD=" + pass;
            System.out.println(urlConn);

            Connection con = DriverManager.getConnection(urlConn);
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(queryInsert(date, pf, group));


            while (rs.next()) {

                if (rs.getString("Kode") != null) {
                    System.out.println(rs.getString("PFCODE"));
                    OrchidXdAktif orchidAktif = new OrchidXdAktif();

                    orchidAktif.setPortfolioCode(rs.getString("Kode"));
                    orchidAktif.setReksadanaCode(rs.getString("PFCODE"));
                    orchidAktif.setProcessDate(rs.getDate("Tanggal"));
                    orchidAktif.setAktiva(rs.getBigDecimal("AKTIVA"));
                    orchidAktif.setRedemption(rs.getBigDecimal("REDEMPTION"));
                    orchidAktif.setSubscription(rs.getBigDecimal("SUBSCRIPTION"));
                    orchidAktif.setTotal(rs.getBigDecimal("TOTALUNIT"));
                    orchidAktif.setNavPerUnit(rs.getBigDecimal("NAVPERUNIT"));

                    listOrchid.add(orchidAktif);
                }
            }

            stmt.close();
            rs.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orchidAktifRepository.saveAll(listOrchid);
    }


    private BigDecimal toDoubleValue(String data) {
        String doubleData = "0.00";
        if (data != null) {
            if (data.isEmpty())
                data = "0.00";
            else
                doubleData = data.contains("-") ?
                        "-" + data.replace("-", "").trim()
                        : data.trim();
        } else {
            data = "0.00";
        }

        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    private String queryInsert(String date, String pf, String group) throws Exception {
        String param = " ";
        if (pf != null && !pf.isEmpty()) {
            param = "   PortfolioCode in ('" + pf + "')\n" +
                    "   AND \n";
        }

        String query = ConfigPropertiesUtil.getAllValue("aktif.properties");
        query = query.replace("PORTFOLIOPARAM", param);
        query = query.replace("DATEPARAM", date);
        query = query.replace("GROUPPARAM", group);
        System.out.println(query);

        return query;
    }

}
