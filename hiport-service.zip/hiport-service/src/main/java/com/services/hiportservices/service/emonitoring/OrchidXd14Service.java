package com.services.hiportservices.service.emonitoring;


import com.services.hiportservices.model.emonitoring.OrchidIssuerMapping;
import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.model.emonitoring.OrchidXd14Recon;
import com.services.hiportservices.repository.emonitoring.OrchidIssuerMappingRepository;
import com.services.hiportservices.repository.emonitoring.OrchidXd14ReconRepository;
import com.services.hiportservices.repository.emonitoring.OrchidXd14Repository;
import com.services.hiportservices.utils.ConfigPropertiesUtil;
import com.services.hiportservices.utils.StringPadder;
import org.apache.logging.log4j.Level;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.sound.midi.Soundbank;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Service
public class OrchidXd14Service {

    @Autowired
    OrchidXd14Repository orchidXd14Repository;

    @Autowired
    OrchidXd14ReconRepository reconRepository;

    @Autowired
    OrchidIssuerMappingRepository issuerMappingRepository;

    public List<OrchidXd14> getDataXD14(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd14> listOrchid = new ArrayList<>();

        try {
            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {
                listOrchid.addAll(orchidXd14Repository.findAllByTanggal(dateParm));

                System.out.println(listOrchid.size());
            } else {
                listOrchid.addAll(orchidXd14Repository.searchDataAt(dateParm,
                        pfCode));
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }


    public List<OrchidXd14> doProcessEachData(String date, String pfCode, String group)  {

        List<Map<String, String>> allPortofolioData = new ArrayList<>();
        List<Map<String, String>> pfolio = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd14> listOrchid = new ArrayList<>();

        try {

            String className = ConfigPropertiesUtil.getProperty("hiport.className", "connection.properties");
            String ip = ConfigPropertiesUtil.getProperty("hiport.ip", "connection.properties");
            String port = ConfigPropertiesUtil.getProperty("hiport.port", "connection.properties");
            String dataSource = ConfigPropertiesUtil.getProperty("hiport.ServerDataSource", "connection.properties");
            String user = ConfigPropertiesUtil.getProperty("hiport.user", "connection.properties");
            String pass = ConfigPropertiesUtil.getProperty("hiport.password", "connection.properties");


            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {
                orchidXd14Repository.deleteAllOrchidXd14(dateParm);
            } else {
                System.out.println("pf " + pfCode);
                orchidXd14Repository.deleteOrchidXd14(dateParm, pfCode);

            }

            Class.forName(className);

            String urlConn = "jdbc:DRO://" + ip + ":" + port +
                    ";ServerDataSource=" + dataSource + ";USER=" + user + ";PASSWORD=" + pass;
            System.out.println(urlConn);

            Connection con = DriverManager.getConnection(urlConn);

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(querygetPFCodeAndTime(pfCode, group));
            while (rs.next()) {
                String time = rs.getString("RunAsAtTime").replaceAll("[^\\dA-Za-z ]", ":").replaceAll("\\s+", ":");
                String code = rs.getString("code");


                try {

                    Statement stmt2 = con.createStatement();
                    ResultSet rs2 = stmt2.executeQuery(queryInsert(date, code, time));
                    while (rs2.next()) {

                        String kode = rs2.getString("UserDefinedField28").trim();
                        String portfolioCode = rs2.getString("ExternalCode1").trim();
                        String securityCategory = rs2.getString("SecurityCategory").trim();
                        BigDecimal accruedInterest = rs2.getBigDecimal("AccruedInterest");
                        BigDecimal nilaiBeli = rs2.getBigDecimal("CostPfolio");
                        BigDecimal jumlah = rs2.getBigDecimal("UnitHolding");
                        java.sql.Date maturityDate = rs2.getDate("MaturityDate");
                        BigDecimal nilai = rs2.getBigDecimal("MarketPrice");
                        BigDecimal total = rs2.getBigDecimal("CapitalValue");
                        String reportGroup = rs2.getString("ReportGroup").trim();
                        String issuer = rs2.getString("issuer").trim();


                        OrchidXd14 orchidXd14 = new OrchidXd14();


                        if (securityCategory.equalsIgnoreCase("ZL")) {
                            System.out.println(reportGroup);
                            reportGroup = "97";

                        }

                        reportGroup = StringPadder.leftPad(reportGroup, "0", 3);

                        String portfolioXD14Final = "";
                        if (securityCategory.
                                equalsIgnoreCase("ZL") && reportGroup.contains("97")) {

                            String portfolioXD14Add = issuer.trim();
                            String portfolioXD14AfterSubstring = portfolioCode.length() > 7 ? portfolioCode.substring(0, 7)
                                    : portfolioCode;
                            portfolioXD14Final = portfolioXD14Add + portfolioXD14AfterSubstring;
                        } else {
                            portfolioXD14Final = portfolioCode.trim();
                        }

                        int count = orchidXd14Repository.count(dateParm, kode, portfolioCode, securityCategory, reportGroup);

                        System.out.println(kode + " - " + portfolioCode + " - " + count);

                        orchidXd14.setDateProc(new Date());
                        orchidXd14.setStatProc("P");
                        orchidXd14.setKode(kode);
                        orchidXd14.setTanggal(dateParm);
                        orchidXd14.setPortofolio(portfolioCode);
                        orchidXd14.setSectype(securityCategory);
                        orchidXd14.setDsplyPorto(portfolioXD14Final);
                        orchidXd14.setCounter(String.valueOf(count));
                        orchidXd14.setBunga(accruedInterest);
                        orchidXd14.setNilaiBeli(nilaiBeli);
                        orchidXd14.setJumlah(jumlah);
                        orchidXd14.setTjTempo(maturityDate);
                        orchidXd14.setNilai(nilai);
                        orchidXd14.setTotal(total);
                        orchidXd14.setReportGroup(reportGroup);
                        orchidXd14.setIssuerCode(issuer);
                        orchidXd14.setReksadanaCode(code);


                        if (!portfolioCode.contains("INT ACCR")) {

                            if (securityCategory.equalsIgnoreCase("ZL")) {
                                OrchidIssuerMapping issuerMapping = issuerMappingRepository.searchData(portfolioXD14Final);
                                if (issuerMapping == null) {
                                    OrchidXd14Recon recon = new OrchidXd14Recon();
                                    recon.setDateProc(new Date());
                                    recon.setDsplyPorto(portfolioXD14Final);
                                    recon.setIssuerCode(issuer);
                                    recon.setKode(kode);
                                    recon.setPortofolio(portfolioCode);
                                    recon.setReksadanaCode(code);
                                    recon.setDesc("Issuer Code Not Found, Plase check Issue Code Mapping or issuer code XD14 from HIPORT");
                                    recon.setTanggal(dateParm);

                                    reconRepository.save(recon);
                                }
                            }


                            orchidXd14Repository.save(orchidXd14);
                            listOrchid.add(orchidXd14);
                        }
                    }

                    stmt2.close();
                    rs2.close();


                } catch (Exception e) {
                    System.out.println(queryInsert(date, code, time));

                    e.printStackTrace();
                }

            }

            stmt.close();
            rs.close();
            con.close();

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    private String querygetPFCodeAndTime(String pfCode, String group) {
        String qry = "";

        if (pfCode == null || pfCode.isEmpty()) {
            System.out.println("with port");
            qry = "SELECT pfG.PfCode as code, CONCAT(c.UserDefinedField27,':00') as RunAsAtTime" +
                    "    FROM PORTFOLIOGROUP pfG" +
                    "    JOIN PORTFOLIO p on pfG.PfCode = p.CODE" +
                    "         and p.ActiveFlag = 1 and pfG.Code = '" + group + "'\n" +
                    "    JOIN portfoliouserdefined c " +
                    "        on pfG.PfCode = c.Code";
        } else {
            System.out.println("tanpa port");
            qry = "SELECT code, CONCAT(UserDefinedField27,':00') as RunAsAtTime" +
                    " from portfoliouserdefined" +
                    " where Code = '" + pfCode.trim() + "'";
        }
        System.out.println(qry);

        return qry;
    }


    private BigDecimal toDoubleValue(String data) {
        String doubleData = data.contains("-") ?
                "-" + data.replace("-", "").trim()
                : data.trim();
        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    private String queryInsert(String date, String pf, String time) throws Exception {
        String param = " ";
        if (pf != null && !pf.isEmpty()) {
            param = " a.PortfolioCode in ('" + pf.trim() + "') AND ";
        }

        System.out.println(param);
        System.out.println(time);
        if (time.equalsIgnoreCase("24:00:00"))
            time = "23:59:59";

//        String query = "SELECT  a.RunAsAtDate, c.UserDefinedField28, CASE WHEN a.SecurityCategory = 'ZL' \n" +
//                "THEN a.InstrumentCode ELSE a.ExternalCode1 END AS ExternalCode1, a.SecurityCategory, \n" +
//                "a.CostPfolio, CASE WHEN a.SecurityCategory = 'ZL'\n" +
//                " THEN a.MarketValuePfolio ELSE  a.UnitHolding END AS UnitHolding, \n" +
//                "CASE WHEN a.SecurityCategory = 'FI' THEN b.MaturityDate\n" +
//                "ELSE a.MaturityDate\n" +
//                "END as MaturityDate\n" +
//                ", CASE WHEN a.SecurityCategory = 'ZL' THEN 100.00\n" +
//                "                     ELSE a.MarketPrice\n" +
//                "                    END as MarketPrice, a.MarketValuePfolio, 0 AS '%pfolio',\n" +
//                " a.AccruedInterest, CASE WHEN a.SecurityCategory = 'FI' THEN (a.MarketValuePfolio-a.AccruedInterest)\n" +
//                "                     ELSE a.MarketValuePfolio\n" +
//                "                    END as CapitalValue , a.ReportGroup, CONCAT(b.zIDIssuer, ac.IssuerCode) as issuer \n" +
//                "FROM VALUATIONNOANAL a " +
//                "lEFT JOIN SECURITY b on a.InstrumentCode = b.Code " +
//                "LEFT JOIN portfoliouserdefined c  " +
//                "        on a.PortfolioCode = c.Code " +
//                "LEFT JOIN ACCOUNT ac on a.InstrumentCode = ac.Code " +
//                "WHERE " + param +
//                "a.RunAsAtDate = '" + date + "' " +
//                "AND a.RunAsAtTime = '" + time + "' " +
//                "AND a.RunValuationParameterCode = 'EMON' " +
//                "and a.MarketValuePfolio <> 0 " +
//                "and a.AccountGroup in ('','02') ";

        String query = ConfigPropertiesUtil.getAllValue("xd14.properties");
        query = query.replace("PFPARAM", param);
        query = query.replace("DATEPARAM", date);
        query = query.replace("TIMEPARAM", time);

        System.out.println(query);

        return query;
    }


}
