package com.services.hiportservices.service.regulatory.impl;

import com.opencsv.exceptions.CsvException;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.exception.CsvHandleException;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.exception.GeneralHandleException;
import com.services.hiportservices.model.regulatory.LKPBUValuation;
import com.services.hiportservices.repository.regulatory.LKPBUValuationRepository;
import com.services.hiportservices.service.regulatory.LKPBUValuationService;
import com.services.hiportservices.utils.regulatory.CsvDataMapper;
import com.services.hiportservices.utils.regulatory.CsvReaderUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class LKPBUValuationServiceImpl implements LKPBUValuationService {

    @Value("${file.path.lkpbuv}")
    private String filePath;

    private static final String BASE_FILE_NAME = "Lkpbuv_";

    private final LKPBUValuationRepository lkpbuValuationRepository;
    private final DateUtil dateUtil;

    @Override
    public String readAndInsertToDB() {
        log.info("Start read and insert LKPBU Valuation data to the database");
        String filePathNew = "";
        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());
            String monthNameMinus1 = contextDate.getMonthNameMinus1();
            String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
            Integer yearMinus1 = contextDate.getYearMinus1();

            String fileName = BASE_FILE_NAME + yearMinus1 + monthNameMinus1Value + ".csv";
            filePathNew = filePath + fileName;

            File file = new File(filePathNew);
            if (!file.exists()) {
                throw new DataNotFoundHandleException("LKPBU Valuation file not found with path: " + filePathNew);
            }

            lkpbuValuationRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

            List<String[]> rows = CsvReaderUtil.readCsvFileAndSkipFirstLine(filePathNew);
            List<LKPBUValuation> lkpbuValuationList = CsvDataMapper.mapCsvLKPBUValuation(rows);

            lkpbuValuationRepository.saveAll(lkpbuValuationList);

            return "LKPBU Valuation data processed and save successfully";
        } catch (DataNotFoundHandleException e) {
            log.error("LKPBU Valuation file not found: {}", e.getMessage(), e);
            throw new DataNotFoundHandleException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error("LKPBU Valuation failed to process CSV data from file: {}", filePathNew, e);
            throw new CsvHandleException("Deposit failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", filePathNew, e);
            throw new GeneralHandleException("LKPBU Valuation unexpected error: " + e.getMessage());
        }
    }

}
