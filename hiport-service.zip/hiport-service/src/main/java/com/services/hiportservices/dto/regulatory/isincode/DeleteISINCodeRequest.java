package com.services.hiportservices.dto.regulatory.isincode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteISINCodeRequest extends InputIdentifierRequest {

    private Long id;

}
