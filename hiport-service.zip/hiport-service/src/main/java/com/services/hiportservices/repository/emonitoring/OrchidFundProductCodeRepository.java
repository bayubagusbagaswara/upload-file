package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidFundProductCode;
import com.services.hiportservices.model.emonitoring.OrchidXd11;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;


public interface OrchidFundProductCodeRepository extends JpaRepository<OrchidFundProductCode, Long> {

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM ORCHIDFUNDPRODUCTCODE", nativeQuery = true)
    void deleteAllFundProductCode();

    @Transactional
    @Modifying
    @Query(value="INSERT INTO ORCHIDFUNDPRODUCTCODE "
            + " VALUES ( :fundCode , '' )", nativeQuery = true)
    void insertIntoFund(@Param("fundCode") String funcode);


}
