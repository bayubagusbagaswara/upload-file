package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.*;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.mapper.OwnerGroupMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.OwnerGroup;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.repository.regulatory.OwnerGroupRepository;
import com.services.hiportservices.service.regulatory.OwnerGroupService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class OwnerGroupServiceImpl implements OwnerGroupService {

    private static final String ID_NOT_FOUND = "Owner Group not found with id: ";
    private static final String UNKNOWN = "unknown";

    private final OwnerGroupRepository ownerGroupRepository;
    private final OwnerGroupMapper ownerGroupMapper;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper regulatoryDataChangeMapper;
    private final ValidationData validationData;
    private final ObjectMapper objectMapper;

    @Override
    public OwnerGroupResponse uploadData(UploadOwnerGroupListRequest uploadOwnerGroupListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start upload data owner group: {}, {}", uploadOwnerGroupListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadOwnerGroupDataRequest uploadOwnerGroupDataRequest : uploadOwnerGroupListRequest.getUploadOwnerGroupDataRequests()) {
            List<String> validationErrors = new ArrayList<>();
            OwnerGroupDTO ownerGroupDTO = null;

            try {
                // validation errors for each upload owner group data request

                // Check if the entity exists by Portfolio Code
                if (uploadOwnerGroupDataRequest.getPortfolioCode() != null) {

                    Optional<OwnerGroup> ownerGroup = ownerGroupRepository.findByPortfolioCode(uploadOwnerGroupDataRequest.getPortfolioCode());

                    if (ownerGroup.isPresent()) {

                        // map dari updateRequest ke ownerGroupDTO. Ini untuk memastikan bahwa data null, akan diisi oleh string kosong
                        // TODO: nanti coba, jika dari depan diisi null, apakah di owner group dto menjadi String kosong
                        ownerGroupDTO = ownerGroupMapper.mapUploadRequestToDTO(uploadOwnerGroupDataRequest);
                        log.info("Owner Group DTO: {}", ownerGroupDTO);

                        // disini ownerGroupDTO sudah handle string kosong
                        // sebelum insert ke DataChange kita remove data yg string kosong


                    } else {
                        // owner group not found
                    }

                } else {
                    // create new entity, then save to data change
                    // owner group not found
                }

            } catch (Exception e) {
                // owner group dto digunakan untuk mengambil data code (untuk validation error)
                handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public OwnerGroupResponse createApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress) {
        log.info("Start create approve: {}, {}", approveOwnerGroupRequest, approveIPAddress);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        OwnerGroupDTO ownerGroupDTO = null;

        try {
            // langsung get data change by id, kalau throw exception langsung ditampung error message
            RegulatoryDataChange regulatoryDataChange = regulatoryDataChangeService.getById(approveOwnerGroupRequest.getDataChangeId());

            // ambil jsonDataAfter dari object regulatoryDataChange,
            // lalu mapping ke object dto
            ownerGroupDTO = objectMapper.readValue(regulatoryDataChange.getJsonDataAfter(), OwnerGroupDTO.class);

            // validasi apakah portfolio code sudah ada di database


            // set approveId dan approveIPAddress to object RegulatoryDataChange
            regulatoryDataChange.setApproverId(approveOwnerGroupRequest.getApproverId());
            regulatoryDataChange.setApproveIPAddress(approveIPAddress);

            /* check the number of content of the ValidationErrors object, then map it to the response */
            if(!validationErrors.isEmpty()) {
                // jika ada error, atur status persetujuan menjadi "Rejected"
                regulatoryDataChangeService.setApprovalStatusIsRejected(regulatoryDataChange, validationErrors);
                totalDataFailed++;
            } else {
                // Jika tidak ada error, lanjutkan dengan persetujuan
                OwnerGroup ownerGroup = ownerGroupMapper.toModel(ownerGroupDTO);
                ownerGroupRepository.save(ownerGroup);
                regulatoryDataChangeService.setApprovalStatusIsApproved(regulatoryDataChange);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public OwnerGroupResponse updateApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress) {
        log.info("Start update approve Owner Group: {}, {}", approveOwnerGroupRequest, approveIPAddress);

        return null;
    }

    @Override
    public OwnerGroupResponse deleteById(DeleteOwnerGroupRequest deleteOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public OwnerGroupResponse deleteApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String clientIP) {
        return null;
    }

    @Override
    public OwnerGroupDTO getById(Long id) {
        log.info("Start get Owner Group by id: {}", id);
        OwnerGroup ownerGroup = ownerGroupRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));
        return ownerGroupMapper.toDTO(ownerGroup);
    }

    @Override
    public OwnerGroupDTO getByPortfolioCode(String portfolioCode) {
        log.info("Start get Owner Group by portfolio code: {}", portfolioCode);
        OwnerGroup ownerGroup = ownerGroupRepository.findByPortfolioCode(portfolioCode)
                .orElseThrow(() -> new DataNotFoundHandleException("Owner Group not found with portfolio code: " + portfolioCode));
        return ownerGroupMapper.toDTO(ownerGroup);
    }

    @Override
    public List<OwnerGroupDTO> getAll() {
        log.info("Start get all owner group");
        List<OwnerGroup> all = ownerGroupRepository.findAll();
        return ownerGroupMapper.toDTOList(all);
    }

    private void handleGeneralError(OwnerGroupDTO ownerGroupDTO, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        ownerGroupDTO != null ? ownerGroupDTO.getPortfolioCode() : UNKNOWN, validationErrors
                )
        );
    }

}
