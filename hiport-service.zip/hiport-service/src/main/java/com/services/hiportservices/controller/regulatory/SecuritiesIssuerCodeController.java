package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.*;
import com.services.hiportservices.service.regulatory.SecuritiesIssuerCodeService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Untuk maintenance Kode Issuer Efek
 */
@RestController
@RequestMapping(path = "/api/regulatory/issuer-code")
@Slf4j
@RequiredArgsConstructor
public class SecuritiesIssuerCodeController {

    private static final String MENU_SECURITIES_ISSUER_CODE = "Kode Issuer Efek";
    private static final String BASE_URL_SECURITIES_ISSUER_CODE = "/api/regulator/issuer-code";

    private final SecuritiesIssuerCodeService securitiesIssuerCodeService;

    /* upload file for Create or Update */
    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeResponse>> uploadData(@RequestBody UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(inputIPAddress)
                .methodHttp(HttpMethod.POST.name())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_SECURITIES_ISSUER_CODE)
                .build();
        SecuritiesIssuerCodeResponse uploadList = securitiesIssuerCodeService.uploadData(uploadSecuritiesIssuerCodeListRequest, regulatoryDataChangeDTO);
        ResponseDto<SecuritiesIssuerCodeResponse> response = ResponseDto.<SecuritiesIssuerCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(uploadList)
                .build();
        return ResponseEntity.ok(response);
    }

    /* create approve */
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeResponse>> createApprove(@RequestBody ApproveSecuritiesIssuerCodeRequest approveRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        SecuritiesIssuerCodeResponse createSingleApprove = securitiesIssuerCodeService.createApprove(approveRequest, clientIP);
        ResponseDto<SecuritiesIssuerCodeResponse> response = ResponseDto.<SecuritiesIssuerCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createSingleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* update approve */
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeResponse>> updateApprove(@RequestBody ApproveSecuritiesIssuerCodeRequest approveRequest, HttpServletRequest servletRequest) {
        String clientIP = ClientIPUtil.getClientIP(servletRequest);
        SecuritiesIssuerCodeResponse updateSingleApprove = securitiesIssuerCodeService.updateApprove(approveRequest, clientIP);
        ResponseDto<SecuritiesIssuerCodeResponse> response = ResponseDto.<SecuritiesIssuerCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateSingleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    /* delete by id */
    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeResponse>> deleteById(@RequestBody DeleteSecuritiesIssuerCodeRequest deleteSecuritiesIssuerCodeRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(inputIPAddress)
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_SECURITIES_ISSUER_CODE + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_SECURITIES_ISSUER_CODE)
                .build();

        SecuritiesIssuerCodeResponse singleData = securitiesIssuerCodeService.deleteById(deleteSecuritiesIssuerCodeRequest, regulatoryDataChangeDTO);
        ResponseDto<SecuritiesIssuerCodeResponse> response = ResponseDto.<SecuritiesIssuerCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleData)
                .build();
        return ResponseEntity.ok(response);
    }

    /* delete approve */
    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeResponse>> deleteApprove(@RequestBody ApproveSecuritiesIssuerCodeRequest approveSecuritiesIssuerCodeRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        SecuritiesIssuerCodeResponse securitiesIssuerCodeResponse = securitiesIssuerCodeService.deleteApprove(approveSecuritiesIssuerCodeRequest, approveIPAddress);
        ResponseDto<SecuritiesIssuerCodeResponse> response = ResponseDto.<SecuritiesIssuerCodeResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(securitiesIssuerCodeResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // get by id
    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeDTO>> getById(@PathVariable("id") Long id) {
        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = securitiesIssuerCodeService.getById(id);
        ResponseDto<SecuritiesIssuerCodeDTO> response = ResponseDto.<SecuritiesIssuerCodeDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(securitiesIssuerCodeDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    // get by external code
    @GetMapping(path = "/externalCode")
    public ResponseEntity<ResponseDto<SecuritiesIssuerCodeDTO>> getByExternalCode(@RequestParam("externalCode") String externalCode) {
        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = securitiesIssuerCodeService.getByExternalCode(externalCode);
        ResponseDto<SecuritiesIssuerCodeDTO> response = ResponseDto.<SecuritiesIssuerCodeDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(securitiesIssuerCodeDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    // get all
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<SecuritiesIssuerCodeDTO>>> getAll() {
        List<SecuritiesIssuerCodeDTO> all = securitiesIssuerCodeService.getAll();
        ResponseDto<List<SecuritiesIssuerCodeDTO>> response = ResponseDto.<List<SecuritiesIssuerCodeDTO>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(all)
                .build();
        return ResponseEntity.ok(response);
    }

}
