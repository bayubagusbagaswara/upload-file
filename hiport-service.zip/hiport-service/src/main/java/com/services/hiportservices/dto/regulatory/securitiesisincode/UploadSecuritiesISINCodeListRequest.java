package com.services.hiportservices.dto.regulatory.securitiesisincode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadSecuritiesISINCodeListRequest extends InputIdentifierRequest {

    private List<UploadSecuritiesISINCodeDataRequest> uploadSecuritiesISINCodeDataRequestList;

}
