package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesisincode.*;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.UploadSecuritiesIssuerCodeListRequest;

import java.util.List;

public interface SecuritiesISINCodeService {

    SecuritiesISINCodeResponse uploadData(UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    SecuritiesISINCodeResponse create(CreateSecuritiesISINCodeRequest createSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    SecuritiesISINCodeResponse createApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress);

    SecuritiesISINCodeResponse updateById(UpdateSecuritiesISINCodeRequest updateSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    SecuritiesISINCodeResponse updateApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress);

    SecuritiesISINCodeResponse deleteById(DeleteSecuritiesISINCodeRequest deleteSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    SecuritiesISINCodeResponse deleteApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress);

    SecuritiesISINCodeDTO getById(Long id);

    SecuritiesISINCodeDTO getByExternalCode(String externalCode);

    List<SecuritiesISINCodeDTO> getAll();

}
