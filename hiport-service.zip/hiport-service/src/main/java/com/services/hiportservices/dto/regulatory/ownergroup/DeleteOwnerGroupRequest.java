package com.services.hiportservices.dto.regulatory.ownergroup;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteOwnerGroupRequest extends InputIdentifierRequest {

    private Long id;

}
