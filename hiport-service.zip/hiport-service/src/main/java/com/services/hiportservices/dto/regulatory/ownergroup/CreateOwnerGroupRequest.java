package com.services.hiportservices.dto.regulatory.ownergroup;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateOwnerGroupRequest extends InputIdentifierRequest {

    private String portfolioCode;

    private String portfolioName;

    // S-Kode Invest

    // Referensi Golongan Pihak Lawan

    // Referensi Negara
}
