package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

@Entity
@Data
@Table(name = "ORCHIDAKTIF")
public class OrchidXdAktif {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "PORTFOLIOCODE")
    private String portfolioCode;

    @Column(name = "PROCESSDATE")
    @Getter(AccessLevel.NONE)
    private Date processDate;

    @Transient
    @Getter(AccessLevel.NONE)
    private String processDateStr;

    @Column(name = "SUBSCRIPTION")
    private BigDecimal subscription = BigDecimal.ZERO;

    @Column(name = "REDEMPTION")
    private BigDecimal redemption = BigDecimal.ZERO;

    @Column(name = "AKTIVA")
    private BigDecimal aktiva = BigDecimal.ZERO;

    @Column(name = "TOTALUNIT")
    private BigDecimal total = BigDecimal.ZERO;

    @Column(name = "NAVPERUNIT")
    private BigDecimal navPerUnit = BigDecimal.ZERO;

    @Column(name = "REKSADANA_CODE")
    private String reksadanaCode;

    public String getProcessDateStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(processDate);
    }
}
