package com.services.hiportservices.dto.regulatory.issuercodeplacementbank;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveIssuerCodePlacementBankRequest extends ApprovalIdentifierRequest {

    private Long dataChangeId;

}
