package com.services.hiportservices.dto.request.compliance;

import com.services.hiportservices.model.compliance.PortfolioType;
import lombok.Data;

@Data
public class PortfolioRequestDTO {
    private String code;
    private String externalCode;
    private String name;
    private String issuer;
    private int portfolioType;
    private boolean syariah;
    private boolean conventional;
    private String description;
    private boolean delete;
}
