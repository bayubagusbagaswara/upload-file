package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.MasterKebijakanInvestasi;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.compliance.ReksadanaType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface ReksadanaTypeRepository extends JpaRepository<ReksadanaType,Long> {
    ReksadanaType findByReksadanaType(String type);

    @Query("SELECT u FROM ReksadanaType u WHERE u.approvalStatus = :approvalStatus and u.delete = false ")
    List<ReksadanaType> findAllData(
            @Param("approvalStatus") ApprovalStatus approvalStatus);

    @Query("SELECT u FROM ReksadanaType u WHERE u.approvalStatus = :approvalStatus and u.delete = false and u.reksadanaType like %:reksadanaType%")
    List<ReksadanaType> searchByReksadanaType(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("reksadanaType") String reksadanaType);

    List<ReksadanaType> findAllByApprovalStatusAndAndDelete(ApprovalStatus approvalStatus, boolean isDelete);

    @Query("SELECT u FROM ReksadanaType u WHERE  u.approvalStatus = 'Pending' and u.delete = false")
    List<ReksadanaType> searchPendingData();

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_reksadana_type SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE reksadana_type = :code", nativeQuery = true)
    void approveOrRejectReksadanaType(@Param("approvalStatus") String approvalStatus,
                                  @Param("approveDate") Date approveDate,
                                  @Param("approverId") String approverId,
                                  @Param("code") String reksadanaCode);
}
