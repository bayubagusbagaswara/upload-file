package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.lbabk.LBABKDTO;
import com.services.hiportservices.model.regulatory.LBABKCustomerActivity;
import com.services.hiportservices.service.regulatory.LBABKService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class LBABKServiceImpl implements LBABKService {

    @Override
    public List<LBABKDTO> getAllDataMock() {
        return null;
    }

    @Override
    public List<LBABKCustomerActivity> getAllForSheet1(String monthYear) {
        // kita ambil data LBABKCustomerActivityRepository berdasarkan month and year
        // harusnya otomatis H-1 bulan
        return null;
    }

    @Override
    public List<LBABKCustomerActivity> getAllForSheet2(String monthYear) {
        return null;
    }


}
