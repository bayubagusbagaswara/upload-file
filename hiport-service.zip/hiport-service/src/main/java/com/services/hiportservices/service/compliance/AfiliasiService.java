package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.AfiliasiRequestDTO;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class AfiliasiService {

    @Autowired
    ReksadanaRepository reksadanaRepository;
    @Autowired
    AfiliasiRepository afiliasiRepository;
    @Autowired
    PortfolioRepository portfolioRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;


    public ResponseEntity<ResponseDto> getById(Long id) {

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(afiliasiRepository.findById(id));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> deleteById(Long id) {
        ResponseDto responseDto = new ResponseDto();
        try {
            Afiliasi afiliasi = afiliasiRepository.findById(id).orElseThrow(()-> new RuntimeException("Data Not Found!"));
            Afiliasi afiliasiAfter = new Afiliasi();

            ObjectMapper Obj = new ObjectMapper();
            String jsonbefore = Obj.writeValueAsString(afiliasi);
            ObjectMapper ObjAfter = new ObjectMapper();
            String jsonAfter = ObjAfter.writeValueAsString(afiliasiAfter);

            ComplianceDataChange dataChange = new ComplianceDataChange();
            dataChange.setApprovalStatus(ApprovalStatus.Pending);
            dataChange.setInputerId(UserIdUtil.getUser());
            dataChange.setInputDate(new Date());
            dataChange.setAction(ChangeAction.Delete);
            dataChange.setEntityId(String.valueOf(afiliasi.getId()));
            dataChange.setTableName("comp_afiliasi");
            dataChange.setEntityClassName(Afiliasi.class.getName());
            dataChange.setDataBefore(jsonbefore);
            dataChange.setDataChange(jsonAfter);
            complianceDataChangeRepository.save(dataChange);

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Delete Pihak Terafiliasi Sukses! Wait for Approval!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> searchPihakTerafiliasi(String findByCode) {
        Reksadana reksadana = reksadanaRepository.findByCode(findByCode);
        List<Afiliasi> afiliasiList = afiliasiRepository.searchByReksadanaCodeLike(ApprovalStatus.Approved, reksadana);

        if (afiliasiList.size() == 0){
            afiliasiList = afiliasiRepository.searchByReksadanaNameLike(ApprovalStatus.Approved, findByCode);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(afiliasiList);

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> insertListAfiliasi(List<AfiliasiRequestDTO> afiliasiRequestDTOS) {
        ResponseDto responseDto =new ResponseDto();
        Reksadana reksadana = reksadanaRepository.findByCode(afiliasiRequestDTOS.get(0).getReksadanaCode());

        try {
            for (AfiliasiRequestDTO afiliasiRequestDTO : afiliasiRequestDTOS){
                Portfolio portfolio = portfolioRepository.findByCode(afiliasiRequestDTO.getKodeEfek());
                Afiliasi afiliasi = new Afiliasi();
                afiliasi.setApprovalStatus(ApprovalStatus.Pending);
                afiliasi.setInputDate(new Date());
                afiliasi.setInputerId(UserIdUtil.getUser());
                afiliasi.setKodeEfek(afiliasiRequestDTO.getKodeEfek());
                afiliasi.setReksadanaCode(reksadana);
                afiliasi.setReksadanaName(reksadana.getName());
                afiliasi.setRdExternalCode(reksadana.getExternalCode());
                afiliasi.setAfiliasi(portfolio.getName());
                afiliasiRepository.save(afiliasi);
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Success insert new afiliasi");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findAllAfiliasiReksadana(String code) {
        Reksadana reksadana = reksadanaRepository.findByCode(code);
        List<Afiliasi> afiliasiList = afiliasiRepository.searchByReksadanaCode(ApprovalStatus.Approved, reksadana);
        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(afiliasiList);

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<ResponseDto> insertAfiliasiUpload(String param, List<Map<String, String>> afiliasiList) {
        String message = "Input data success!";
        ResponseDto responseDto = new ResponseDto();
        List<Afiliasi> newAfiliasiList =  new ArrayList<>();
        List<ComplianceDataChange> newComplianceDataChangeList = new ArrayList<>();
        try {
            if (param.equalsIgnoreCase("new")) {
                int row = 1;
                for (Map<String, String> afiliasiString : afiliasiList) {
                    row += 1;
                    String reksadanaCode = afiliasiString.get("reksadanaCode").trim();
                    String reksadanaName = afiliasiString.get("reksadanaName");
                    String pihakAfiliasi = afiliasiString.get("pihakAfiliasi");
                    String kodeEfek = afiliasiString.get("kodeEfek").trim();

                    if (reksadanaCode == "" || reksadanaCode == null || reksadanaCode.isEmpty() ||
                            kodeEfek == "" || kodeEfek == null || kodeEfek.isEmpty()) {
                        throw new Exception("Required properties are missing in Row: " + row);
                    }

                    Reksadana reksadana = reksadanaRepository.findByCodeAndDelete(reksadanaCode, false);
                    Portfolio portfolio = portfolioRepository.findByCode(kodeEfek);

                    if (reksadana == null) {
                        throw new Exception("Row: " + row + " Reksadana " + reksadanaCode + " not exist!");
                    }

                    if (portfolio == null) {
                        throw new Exception("Row: " + row + " Kode Efek " + kodeEfek + " not exist!");
                    }

                    Afiliasi afiliasi = afiliasiRepository.searchByReksadanaCodeAndKodeEfek(ApprovalStatus.Approved, reksadana, kodeEfek);
                    if (afiliasi == null){
                        afiliasi = new Afiliasi();
                        afiliasi.setKodeEfek(kodeEfek);
                        afiliasi.setReksadanaCode(reksadana);
                    }

                    afiliasi.setRdExternalCode(reksadana.getExternalCode());

                    if (reksadanaName == null || reksadanaName == "" || reksadanaName.isEmpty()){
                        if (reksadana.getName() == null || reksadana.getName() == ""){
                            afiliasi.setReksadanaName("");
                        } else {
                            afiliasi.setReksadanaName(reksadana.getName());
                        }
                    } else {
                        afiliasi.setReksadanaName(reksadanaName);
                    }

                    if (pihakAfiliasi == null || pihakAfiliasi == "" || pihakAfiliasi.isEmpty()){
                        if (portfolio.getName() == null || portfolio.getName() == ""){
                            afiliasi.setAfiliasi("");
                        } else {
                            afiliasi.setAfiliasi(portfolio.getName());
                        }
                    } else {
                        afiliasi.setAfiliasi(pihakAfiliasi);
                    }

                    afiliasi.setApprovalStatus(ApprovalStatus.Pending);
                    afiliasi.setInputerId(UserIdUtil.getUser());
                    afiliasi.setInputDate(new Date());

                    newAfiliasiList.add(afiliasi);
                }
                afiliasiRepository.saveAll(newAfiliasiList);
            } else {
                int row = 1;
                for (Map<String, String> afiliasiString : afiliasiList) {
                    row += 1;
                    String reksadanaCode = afiliasiString.get("reksadanaCode").trim();
                    String reksadanaName = afiliasiString.get("reksadanaName");
                    String pihakAfiliasi = afiliasiString.get("pihakAfiliasi");
                    String kodeEfek = afiliasiString.get("kodeEfek").trim();

                    if (reksadanaCode == "" || reksadanaCode == null || kodeEfek == "" || kodeEfek == null) {
                        throw new Exception("Required properties are missing in Row: " + row);
                    }

                    Reksadana reksadana = reksadanaRepository.findByCodeAndDelete(reksadanaCode, false);
                    if (reksadana == null) {
                        throw new Exception("Row: " + row + " Reksadana " + reksadanaCode + " not exist!");
                    }

                    Portfolio portfolio = portfolioRepository.findByCode(kodeEfek);
                    if (portfolio == null) {
                        throw new Exception("Row: " + row + " Portfolio " + kodeEfek + " not exist!");
                    }

                    Afiliasi afiliasi = afiliasiRepository.searchByReksadanaCodeAndKodeEfek(ApprovalStatus.Approved, reksadana,kodeEfek);
                    Afiliasi afiliasiAfter = new Afiliasi();

                    ObjectMapper Obj = new ObjectMapper();
                    String jsonbefore = Obj.writeValueAsString(afiliasi);
                    ObjectMapper ObjAfter = new ObjectMapper();
                    String jsonAfter = ObjAfter.writeValueAsString(afiliasiAfter);

                    ComplianceDataChange dataChange = new ComplianceDataChange();
                    dataChange.setApprovalStatus(ApprovalStatus.Pending);
                    dataChange.setInputerId(UserIdUtil.getUser());
                    dataChange.setInputDate(new Date());
                    dataChange.setAction(ChangeAction.Delete);
                    dataChange.setEntityId(String.valueOf(afiliasi.getId()));
                    dataChange.setTableName("comp_afiliasi");
                    dataChange.setEntityClassName(Afiliasi.class.getName());
                    dataChange.setDataBefore(jsonbefore);
                    dataChange.setDataChange(jsonAfter);
                    newComplianceDataChangeList.add(dataChange);
                }
                message = "Delete data success! Waiting Approval";
                complianceDataChangeRepository.saveAll(newComplianceDataChangeList);
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);

        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataAfiliasi() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(afiliasiRepository.searchPendingAfiliasiData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataAfiliasi(Map<String, List<String>> codeList) {
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            afiliasiRepository.approveOrRejectAfiliasi("Approved", new Date(), approverId, Long.valueOf(code));
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataAfiliasi(Map<String, List<String>> codeList) {
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            Afiliasi afiliasi = afiliasiRepository.findById(Long.valueOf(code)).orElseThrow(()-> new RuntimeException("Data Not Found!"));
            if (afiliasi != null){
                afiliasiRepository.delete(afiliasi);
            }
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
