package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.model.emonitoring.OrchidXd16;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

public interface OrchidXd16Repository extends JpaRepository<OrchidXd16, Long> {
    List<OrchidXd16> findAllByPortfolioCode(String portofolio);

    List<OrchidXd16> findAllByDate1(String tanggal);

    OrchidXd16 findByPortfolioCodeAndDate1(String tanggal, String code);

    OrchidXd16 findByReksadanaAndDate1(String code, String tanggal);

    @Query("SELECT u FROM OrchidXd16 u WHERE u.date1 = :date and u.portfolioCode = :reksadanaCode")
    OrchidXd16 searchByReksadanaCodeAndDate(
            @Param("date") String date,
            @Param("reksadanaCode") String reksadanaCode);

    @Query(value="SELECT * FROM ORCHIDXD16 WHERE DATE1 = :date and (PORTFOLIOCODE = :reksadanaCode or  ReksadanaCode= :reksadanaCode)", nativeQuery = true)
    List<OrchidXd16> searchDataAt(
            @Param("date") String date,
            @Param("reksadanaCode") String reksadanaCode);

}
