
package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_portfolio")
public class Portfolio extends Approvable {
    //Short Code
    @Id
    @Column(name = "code")
    private String code;

    //Long Code
    @Column(name = "external_code")
    private String externalCode;

    @Column(name = "name")
    private String name;

    @Column(name = "issuer")
    private String issuer;

    @ManyToOne
    @JoinColumn(name="portfolio_type", nullable=false)
    private PortfolioType portfolioType;

    @Column(name = "isSyariah")
    private boolean syariah;

    @Column(name = "isConventional")
    private boolean conventional;

    @Column(name = "description")
    private String description;

    @Column(name = "isDelete")
    private boolean delete;
}
