package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

@Entity
@Data
@Table(name = "ORCHIDFUNDPRODUCTCODE")
public class OrchidFundProductCode {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "code")
    private String code;

    @Column(name = "SInvestCode")
    private String SInvestCode = "";

}
