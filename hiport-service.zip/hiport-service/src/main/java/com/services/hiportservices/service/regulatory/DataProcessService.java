package com.services.hiportservices.service.regulatory;

/**
 * disini adalah triger untuk melakukan proses data yang akan ditampilkan di report
 */
public interface DataProcessService {

    // process or calculate
    void processData();
}
