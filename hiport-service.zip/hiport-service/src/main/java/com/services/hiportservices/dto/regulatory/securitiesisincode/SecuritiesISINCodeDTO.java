package com.services.hiportservices.dto.regulatory.securitiesisincode;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SecuritiesISINCodeDTO {

    private String exernalCode;

    private String currency;

    private String isinLKPBU;

    private String isinLBABK;

}
