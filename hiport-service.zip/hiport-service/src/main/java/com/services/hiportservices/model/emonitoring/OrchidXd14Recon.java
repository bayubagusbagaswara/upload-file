package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Data
@Table(name = "ORCHIDXD14_RECON")
public class OrchidXd14Recon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "DATE_PROC")
    private Date dateProc = new Date();

    @Column(name = "Tanggal")
    private Date tanggal;

    @Transient
    @Getter(AccessLevel.NONE)
    private String tanggalStr;

    @Column(name = "Kode")
    private String kode;

    @Column(name = "Portofolio")
    private String portofolio;

    @Column(name = "displayPortfolio")
    private String dsplyPorto = "";

    @Column(name = "IssuerCode")
    private String issuerCode = "";

    @Column(name = "ReksadanaCode")
    private String reksadanaCode = "";

    @Column(name = "Description")
    private String desc = "";

    public String getTanggalStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(tanggal);
    }


}
