package com.services.hiportservices.dto.regulatory.ownergroup;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadOwnerGroupListRequest extends InputIdentifierRequest {

    private List<UploadOwnerGroupDataRequest> uploadOwnerGroupDataRequests;

}
