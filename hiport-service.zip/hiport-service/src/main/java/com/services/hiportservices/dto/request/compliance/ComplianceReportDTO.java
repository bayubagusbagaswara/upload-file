package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class ComplianceReportDTO {
    private Long id;
    private String reksadanaName;
    private String reksadanaCode;
    private String breachType;
    private String percentage;
    private String remarks;
}
