package com.services.hiportservices.dto.regulatory.insurancepensionfund;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * data JsonProperty sesuai dengan header file
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadInsurancePensionFundDataRequest {

    @JsonProperty(value = "Portfolio Code")
    private String portfolioCode;

    @JsonProperty(value = "Portfolio Name")
    private String portfolioName;

    @JsonProperty(value = "Regulator Name")
    private String regulatoryName;

    @JsonProperty(value = "Referensi Dana Pensiun dan Asuransi")
    private String insurancePensionFundReference;

    @JsonProperty(value = "Dana Jaminan")
    private String guaranteeFund;
}
