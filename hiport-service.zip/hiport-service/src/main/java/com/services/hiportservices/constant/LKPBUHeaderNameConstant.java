package com.services.hiportservices.constant;

public class LKPBUHeaderNameConstant {

    // 1
    public static final String FLAG_DETAIL = "Flag Detail";

    // 2
    public static final String KODE_KOMPONEN = "Kode Komponen";

    // 3
    public static final String GOLONGAN_1 = "Golongan 1";

    // 4
    public static final String SANDI_PERUSAHAAN = "Sandi Perusahaan Asuransi/Reasuransi/Dana Pensiun *)";

    // 5
    public static final String NAMA_PERUSAHAAN  = "Nama Perusahaan Asuransi/Reasuransi/Dana Pensiun *)";

    // 6
    public static final String KODE_EFEK = "Kode Efek";

    // 7
    public static final String JENIS = "Jenis";

    // 8
    public static final String NOMOR_BILYET = "Nomor Bilyet/Nomor Seri *)";

    // 9
    public static final String NAMA_SURAT_BERHARGA = "Nama Surat Berharga *)";

    // 10
    public static final String LEMBAR_UNIT = "Lembar/Unit *)";

    // 11
    public static final String INTEREST_RATE = "Interest Rate/Kupon *)";

    // 12
    public static final String KETERANGAN = "Keterangan **)";

    // 13
    public static final String DANA_JAMINAN = "Dana Jaminan/Investasi *)";

    // 14
    public static final String JENIS_VALUTA = "Jenis Valuta";

    // 15
    public static final String NILAI_VALUTA_ASAL = "Nilai Valuta Asal";

    // 16
    public static final String TANGGAL_PENERBITAN = "Tanggal Penerbitan";

    // 17
    public static final String JATUH_TEMPO = "Jatuh Tempo";

    // 18
    public static final String GOLONGAN_2 = "Golongan 2";

    // 19
    public static final String SANDI_PENERBIT = "Sandi Penerbit";

    // 20
    public static final String NAMA_PENERBIT = "Nama Penerbit";

    // 21
    public static final String NEGARA_ASAL = "Negara Asal";

    // 22
    public static final String PEMBAYARAN_KUPON = "Pembayaran Kupon/Deviden/Bunga/Diskonto";

}
