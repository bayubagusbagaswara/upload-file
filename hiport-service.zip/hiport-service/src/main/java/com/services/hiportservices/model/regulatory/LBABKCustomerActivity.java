package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * untuk sheet 1 dan sheet 2
 */
@Entity
@Table(name = "regulatory_lbabk_cusact")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABKCustomerActivity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kode_komponen")
    private String kodeKomponen;

}
