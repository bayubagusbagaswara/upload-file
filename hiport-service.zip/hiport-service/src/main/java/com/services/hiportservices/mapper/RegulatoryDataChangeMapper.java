package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RegulatoryDataChangeMapper {

    RegulatoryDataChangeDTO toDTO(RegulatoryDataChange regulatoryDataChange);

    RegulatoryDataChange toModel(RegulatoryDataChangeDTO regulatoryDataChangeDTO);

}
