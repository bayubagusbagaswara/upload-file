package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.insurancepensionfund.*;
import com.services.hiportservices.repository.regulatory.InsurancePensionFundRepository;
import com.services.hiportservices.service.regulatory.InsurancePensionFundService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class InsurancePensionFundServiceImpl implements InsurancePensionFundService {

    private final InsurancePensionFundRepository insurancePensionFundRepository;

    @Override
    public InsurancePensionFundResponse uploadData(UploadInsurancePensionFundListRequest uploadInsurancePensionFundListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public InsurancePensionFundResponse approveCreate(CreateInsurancePensionFundRequest createInsurancePensionFundRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public InsurancePensionFundResponse updateById(UpdateInsurancePensionFundRequest updateInsurancePensionFundRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public InsurancePensionFundResponse updateApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public InsurancePensionFundResponse deleteById(DeleteInsurancePensionFundRequest deleteInsurancePensionFundRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        return null;
    }

    @Override
    public InsurancePensionFundResponse deleteApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress) {
        return null;
    }

    @Override
    public InsurancePensionFundDTO getById(Long id) {
        return null;
    }

    @Override
    public InsurancePensionFundDTO getByCode(String code) {
        return null;
    }

    @Override
    public List<InsurancePensionFundDTO> getAll() {
        return null;
    }
}
