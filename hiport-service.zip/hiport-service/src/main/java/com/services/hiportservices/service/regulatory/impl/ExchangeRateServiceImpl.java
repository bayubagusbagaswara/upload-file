package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.exchangerate.*;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.mapper.ExchangeRateMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.ExchangeRate;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.repository.regulatory.ExchangeRateRepository;
import com.services.hiportservices.service.regulatory.ExchangeRateService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExchangeRateServiceImpl implements ExchangeRateService {

    private static final String ID_NOT_FOUND = "Exchange Rate not found with id: ";
    private static final String UNKNOWN = "unknown";

    private final ExchangeRateRepository exchangeRateRepository;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final ValidationData validationData;
    private final ObjectMapper objectMapper;
    private final ExchangeRateMapper exchangeRateMapper;
    private final RegulatoryDataChangeMapper regulatoryDataChangeMapper;

    @Override
    public boolean isExistsByCode(String code) {
        log.info("Check the existing exchange rate with the code: {}", code);
        return exchangeRateRepository.existsByCode(code);
    }

    @Override
    public ExchangeRateResponse create(CreateExchangeRateRequest createExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start create exchange rate with request: {}, {}", createExchangeRateRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        ExchangeRateDTO exchangeRateDTO = null;

        try {
            /* maps request data to DTO */
            Errors errors = validationData.validateObject(createExchangeRateRequest);
            errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));

            // map from create exchange rate request to exchange rate dto
            exchangeRateDTO = exchangeRateMapper.toDTO(createExchangeRateRequest);

            /* validate whether the currency code already exists */
            validationCurrencyCodeAlreadyExists(exchangeRateDTO.getCurrencyCode(), validationErrors);

            /* sets inputId to a DataChange object (from data request) */
            regulatoryDataChangeDTO.setInputerId(createExchangeRateRequest.getInputerId());

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(exchangeRateDTO.getCurrencyCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                // data yang inti aja yg akan disimpan ke JSON Data After
                regulatoryDataChangeDTO.setJsonDataAfter(objectMapper.writeValueAsString(exchangeRateDTO));

                // convert regulatoryDataChangeDTO to regulatoryDataChange model
                RegulatoryDataChange regulatoryDataChange = regulatoryDataChangeMapper.toModel(regulatoryDataChangeDTO);

                // create action Add
                regulatoryDataChangeService.createChangeActionAdd(regulatoryDataChange, ExchangeRate.class);

                // total data success yang disimpan ke table DataChange
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(exchangeRateDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }

        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public ExchangeRateResponse createApprove(ApproveExchangeRateRequest approveExchangeRateRequest, String approveIPAddress) {
        log.info("Create Approve exchange rate with request: {}, {}", approveExchangeRateRequest, approveIPAddress);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        ExchangeRateDTO exchangeRateDTO;

        try {
            /* langsung get data change by dataChangeId, kalau throw exception langsung ditampung */
            RegulatoryDataChange regulatoryDataChange = regulatoryDataChangeService.getById(approveExchangeRateRequest.getDataChangeId());

            /* ambil data jsonDataAfter dari regulatoryDataChange, lalu mapping ke object ExchangeRateDTO */
            exchangeRateDTO = objectMapper.readValue(regulatoryDataChange.getJsonDataAfter(), ExchangeRateDTO.class);

            /* validasi apakah exchangeRate code sudah ada di database */
            if (isExistsByCode(exchangeRateDTO.getCurrencyCode())) {
                validationErrors.add("Exchange rate code already exists: " + exchangeRateDTO.getCurrencyCode());
            }

            /* set approveId dan approveIPAddress to object RegulatoryDataChange */
            regulatoryDataChange.setApproverId(approveExchangeRateRequest.getApproverId());
            regulatoryDataChange.setApproveIPAddress(approveIPAddress);

            /* check the number of contents of the ValidationErrors object, then map it to the response */
            if (!validationErrors.isEmpty()) {
                // Jika ada error, atur status persetujuan menjadi "Rejected"
                regulatoryDataChangeService.setApprovalStatusIsRejected(regulatoryDataChange, validationErrors);
                totalDataFailed++;
            } else {
                // Jika tidak ada error, lanjutkan dengan persetujuan
                ExchangeRate exchangeRate = exchangeRateMapper.toModel(exchangeRateDTO);
                exchangeRateRepository.save(exchangeRate);
                regulatoryDataChangeService.setApprovalStatusIsApproved(regulatoryDataChange);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            log.error("Error during exchange rate approval: {}", e.getMessage());
//            errorMessageDTOList.add(new ErrorMessageDTO("Error processing exchange rate approval", e.getMessage()));
            totalDataFailed++;
        }

        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public ExchangeRateResponse updateById(UpdateExchangeRateRequest updateExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start update exchange rate by id: {}", updateExchangeRateRequest.getId());
        // yg bisa diupdate adalah value/nilainya
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();

        try {
            /* validasi data request */
            Errors errors = validationData.validateObject(updateExchangeRateRequest);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            /* get data by id */
            Long id = updateExchangeRateRequest.getId();
            ExchangeRate exchangeRate = exchangeRateRepository.findById(id).orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));

            /* replace data request to entity */
            if (updateExchangeRateRequest.getCode() != null) {
                exchangeRate.setCode(updateExchangeRateRequest.getCode());
            }
            if (updateExchangeRateRequest.getName() != null) {
                exchangeRate.setName(updateExchangeRateRequest.getName());
            }
            if (updateExchangeRateRequest.getValue() != null) {
                exchangeRate.setExchangeRate(new BigDecimal(updateExchangeRateRequest.getValue()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(updateExchangeRateRequest.getCode(), validationErrors);
                errorMessageDTOList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                // simpan ke data change
                regulatoryDataChangeDTO.setJsonDataBefore(
                        JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(exchangeRate))
                );
                regulatoryDataChangeDTO.setJsonDataAfter(
                        JsonUtil.cleanedJsonDataUpdate(objectMapper.writeValueAsString(updateExchangeRateRequest))
                );

                regulatoryDataChangeDTO.setEntityId(exchangeRate.getId().toString());

                RegulatoryDataChange regulatoryDataChange = regulatoryDataChangeMapper.toModel(regulatoryDataChangeDTO);
                regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, ExchangeRate.class);
            }
        } catch (Exception e) {
            // handle general error
            totalDataFailed++;
        }
        return new ExchangeRateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public ExchangeRateResponse updateApprove(ApproveExchangeRateRequest approveExchangeRateRequest, String approveIPAddress) {
        log.info("Start update approve exchange rate: {}, {}", approveExchangeRateRequest, approveIPAddress);
        return null;
    }

    @Override
    public ExchangeRateResponse deleteById(DeleteExchangeRateRequest deleteExchangeRateRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start delete exchange rate by id: {}, {}", deleteExchangeRateRequest, regulatoryDataChangeDTO);
        return null;
    }

    @Override
    public ExchangeRateResponse deleteApprove(ApproveExchangeRateRequest approveExchangeRateRequest, String approveIPAddress) {
        log.info("Start delete approve exchange rate: {}, {}", approveExchangeRateRequest, approveIPAddress);
        return null;
    }

    @Override
    public ExchangeRateDTO getById(Long id) {
        log.info("Start get exchange rate by id: {}", id);
        ExchangeRate exchangeRate = exchangeRateRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException("Exchange rate not found with id: " + id));
        return exchangeRateMapper.toDTO(exchangeRate);
    }

    @Override
    public ExchangeRateDTO getByCurrencyCode(String currencyCode) {
        log.info("Start get exchange rate by currency code: {}", currencyCode);
        ExchangeRate exchangeRate = exchangeRateRepository.findByCode(currencyCode)
                .orElseThrow(() -> new DataNotFoundHandleException("Exchange rate not found with code: " + currencyCode));
        return exchangeRateMapper.toDTO(exchangeRate);
    }

    @Override
    public List<ExchangeRateDTO> getAll() {
        log.info("Start get all exchange rate");
        List<ExchangeRate> all = exchangeRateRepository.findAll();
        return exchangeRateMapper.toDTOList(all);
    }

    private void validationCurrencyCodeAlreadyExists(String currencyCode, List<String> validationErrors) {
        if (isExistsByCode(currencyCode)) {
            validationErrors.add("Exchange Rate is already taken with code: " + currencyCode);
        }
    }

    private void validateDataChangeId(Long dataChangeId) {
        if (!regulatoryDataChangeService.existById(dataChangeId)) {
            log.info("Regulatory data change not found with id: {}", dataChangeId);
            throw new DataNotFoundHandleException("Regulatory data change not found with id: " + dataChangeId);
        }
    }

    private void handleGeneralError(ExchangeRateDTO exchangeRateDTO, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(new ErrorMessageDTO(exchangeRateDTO != null ? exchangeRateDTO.getCurrencyCode() : UNKNOWN, validationErrors));
    }

}
