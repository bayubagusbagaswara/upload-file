package com.services.hiportservices.service.regulatory;

public interface ISSUERCodeService {

    void getISSUERCode(String issuerCode);

}
