package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "regulatory_lbabk_auc")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABKAssetUnderCustody {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "kode_komponen")
    private String kodeKomponen;


}
