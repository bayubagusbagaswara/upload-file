package com.services.hiportservices.dto.regulatory.ownergroup;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateOwnerGroupRequest extends InputIdentifierRequest {

    private Long id; // can be Request Param

    private String portfolioCode;

    private String portfolioName;

    private String sInvestCode;

    private String opposingGroupReference;

    private String countryReference;

}
