package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.UploadOwnerGroupDataRequest;
import com.services.hiportservices.model.regulatory.OwnerGroup;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OwnerGroupMapper {

    //@Mapping(source = "SInvestCode", target = "sInvestCode")
    OwnerGroupDTO toDTO(OwnerGroup ownerGroup);

    OwnerGroup toModel(OwnerGroupDTO ownerGroupDTO);

    List<OwnerGroupDTO> toDTOList(List<OwnerGroup> ownerGroupList);

    @Mapping(source = "portfolioName", target = "portfolioName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "SInvestCode", target = "sInvestCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "opposingGroupReference", target = "opposingGroupReference", qualifiedByName = "nullToEmpty")
    @Mapping(source = "countryReference", target = "countryReference",  qualifiedByName = "nullToEmpty")
    OwnerGroupDTO mapUploadRequestToDTO(UploadOwnerGroupDataRequest uploadOwnerGroupDataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

}
