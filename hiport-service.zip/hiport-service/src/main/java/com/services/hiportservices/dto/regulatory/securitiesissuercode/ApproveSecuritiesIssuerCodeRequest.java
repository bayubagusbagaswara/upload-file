package com.services.hiportservices.dto.regulatory.securitiesissuercode;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveSecuritiesIssuerCodeRequest extends ApprovalIdentifierRequest {

    private String dataChangeId;

}
