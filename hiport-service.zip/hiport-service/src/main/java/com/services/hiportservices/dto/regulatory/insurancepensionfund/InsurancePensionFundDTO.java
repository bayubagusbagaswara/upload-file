package com.services.hiportservices.dto.regulatory.insurancepensionfund;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InsurancePensionFundDTO {

    private Long id;

    private String portfolioCode;

    private String portfolioName;

    private String regulatoryName;

    private String insurancePensionFundReference;

    private String guaranteeFund;

}
