package com.services.hiportservices.service.regulatory.impl;

import com.opencsv.exceptions.CsvException;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.exception.CsvHandleException;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.exception.GeneralHandleException;
import com.services.hiportservices.model.regulatory.Deposit;
import com.services.hiportservices.repository.regulatory.DepositRepository;
import com.services.hiportservices.service.regulatory.DepositService;
import com.services.hiportservices.utils.regulatory.CsvDataMapper;
import com.services.hiportservices.utils.regulatory.CsvReaderUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class DepositServiceImpl implements DepositService {

    @Value("${file.path.deposit}")
    private String filePath;

    private static final String BASE_FILE_NAME = "Deposito_";

    private final DepositRepository depositRepository;
    private final DateUtil dateUtil;

    @Override
    public String readAndInsertToDB() {
        log.info("Start read and insert Deposit data to the database");
        String filePathNew = "";
        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());
            String monthNameMinus1 = contextDate.getMonthNameMinus1();
            String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
            Integer yearMinus1 = contextDate.getYearMinus1();

            String fileName = BASE_FILE_NAME + yearMinus1 + monthNameMinus1Value + ".csv";
            filePathNew = filePath + fileName;

            File file = new File(filePathNew);
            if (!file.exists()) {
                throw new DataNotFoundHandleException("Deposit file not found with path: " + filePathNew);
            }

            depositRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

            List<String[]> rows = CsvReaderUtil.readCsvFileAndSkipFirstLine(filePathNew);
            List<Deposit> depositList = CsvDataMapper.mapCsvDeposit(rows);

            depositRepository.saveAll(depositList);

            return "Deposit data processed and save successfully";
        } catch (DataNotFoundHandleException e) {
            log.error("Deposit file not found: {}", e.getMessage(), e);
            throw new DataNotFoundHandleException(e.getMessage() );
        } catch (IOException | CsvException e) {
            log.error("Deposit failed to process CSV data from file: {}", filePathNew, e);
            throw new CsvHandleException("Deposit failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", filePathNew, e);
            throw new GeneralHandleException("Deposit unexpected error: " + e.getMessage());
        }
    }

}
