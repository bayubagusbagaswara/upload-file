package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.IDXPrice;
import com.services.hiportservices.model.compliance.Redemption;
import com.services.hiportservices.repository.compliance.IDXPriceRepository;
import com.services.hiportservices.repository.compliance.RedemptionRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class RedemptionService {

    @Autowired
    RedemptionRepository redemptionRepository;
    @Autowired
    EntityManager entityManager;

    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat formatFront = new SimpleDateFormat("yyyy-MM-dd");


    public ResponseEntity<ResponseDto> insertDataRedemption(List<Map<String, String>> redemptionList) {
        ResponseDto responseDto =new ResponseDto();
        String message = "Input data success!";
        try {
            List<Redemption> redemptions = new ArrayList<>();
            for (Map<String, String> redemption : redemptionList){
                Date transactionDate = format.parse(redemption.get("Transaction Date"));
                String transactionType = redemption.get("Transaction Type");
                String saCode = redemption.get("SA Code");
                String saName = redemption.get("SA Name");
                String fundCode = redemption.get("Fund Code");
                String fundName = redemption.get("Fund Name");
                String imCode = redemption.get("IM Code");
                String imName = redemption.get("IM Name");
                String cbCode = redemption.get("CB Code");
                String cbName= redemption.get("CB Name");
                String fundCcy = redemption.get("Fund CCY");
                double amountNominal;
                if(redemption.get("Amount (Nominal)") == "" || redemption.get("Amount (Nominal)") == null || redemption.get("Amount (Nominal)").isEmpty()){
                    amountNominal = 0;
                }else{
                    amountNominal = Double.valueOf(redemption.get("Amount (Nominal)"));
                }
                double amountUnit;
                if(redemption.get("Amount (Unit)") == "" || redemption.get("Amount (Unit)") == null || redemption.get("Amount (Unit)").isEmpty()){
                    amountUnit = 0;
                }else{
                    amountUnit = Double.valueOf(redemption.get("Amount (Unit)"));
                }
                String amountAllUnits = redemption.get("Amount (All Units)");
                double feeNominal;
                if(redemption.get("Fee (Nominal)") == "" || redemption.get("Fee (Nominal)") == null || redemption.get("Fee (Nominal)").isEmpty()){
                    feeNominal = 0;
                }else{
                    feeNominal = Double.valueOf(redemption.get("Fee (Nominal)"));
                }
                double feeUnit;
                if(redemption.get("Fee (Unit)") == "" || redemption.get("Fee (Unit)") == null || redemption.get("Fee (Unit)").isEmpty()){
                    feeUnit = 0;
                }else{
                    feeUnit = Double.valueOf(redemption.get("Fee (Unit)"));
                }
                double feePercent;
                if(redemption.get("Fee (%)") == "" || redemption.get("Fee (%)") == null || redemption.get("Fee (%)").isEmpty()){
                    feePercent = 0;
                }else{
                    feePercent = Double.valueOf(redemption.get("Fee (%)"));
                }

                String reference = redemption.get("Reference No.");
                Redemption redem = redemptionRepository.searchForChecking(transactionDate, fundCode, reference);
                if (redem == null){
                    redem = new Redemption();
                    redem.setTransactionDate(transactionDate);
                    redem.setReferenceNo(reference);
                    redem.setFundCode(fundCode);
                }
                redem.setApprovalStatus(ApprovalStatus.Pending);
                redem.setApproveDate(null);
                redem.setApproverId(null);
                redem.setInputerId(UserIdUtil.getUser());
                redem.setInputDate(new Date());
                redem.setTransactionType(transactionType);

                redem.setSaCode(saCode);
                redem.setSaName(saName);
                redem.setFundName(fundName);
                redem.setImCode(imCode);
                redem.setImName(imName);
                redem.setCbCode(cbCode);
                redem.setCbName(cbName);
                redem.setFundCcy(fundCcy);
                redem.setAmountNominal(amountNominal);
                redem.setAmountUnit(amountUnit);
                redem.setAmountAllUnits(amountAllUnits);
                redem.setFeeNominal(feeNominal);
                redem.setFeeUnit(feeUnit);
                redem.setFeePercent(feePercent);
                redemptions.add(redem);
            }
            redemptionRepository.saveAll(redemptions);
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(message);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findDataAt(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatFront.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(redemptionRepository.searchByDataDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataRedemption() {
        List<Map<String, Object>> listPendingDataFairPrice = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                    "select transaction_date, count(*), inputer_id from comp_redemption " +
                            "where approval_status = 'Pending' " +
                            "group by transaction_date, inputer_id");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("date", data[0]);
                eachColumn.put("totalData", data[1]);
                eachColumn.put("inputerId", data[2]);
                listPendingDataFairPrice.add(eachColumn);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(listPendingDataFairPrice);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataRedemption(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        System.out.println(approverId);
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            redemptionRepository.approveOrRejectFairPrice("Approved", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataRedemption(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            redemptionRepository.approveOrRejectFairPrice("Rejected", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> viewPendingData(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatFront.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(redemptionRepository.searchPendingData(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
