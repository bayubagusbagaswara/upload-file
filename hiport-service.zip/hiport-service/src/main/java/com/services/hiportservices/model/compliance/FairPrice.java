
package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_fair_price")
public class FairPrice extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "security_desc")
    private String securityDesc;

    @Column(name = "lower_price")
    private double lowerPrice;

    @Column(name = "today_price")
    private double todayPrice;

    @Column(name = "upper_price")
    private double upperPrice;

    @Column(name = "stdev")
    private double stdev;
}
