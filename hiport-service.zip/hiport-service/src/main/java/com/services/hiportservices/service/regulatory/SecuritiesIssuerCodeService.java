package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.*;

import java.util.List;

public interface SecuritiesIssuerCodeService {

    SecuritiesIssuerCodeResponse uploadData(UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    SecuritiesIssuerCodeResponse createApprove(ApproveSecuritiesIssuerCodeRequest approveRequest, String clientIP);

    SecuritiesIssuerCodeResponse updateApprove(ApproveSecuritiesIssuerCodeRequest approveRequest, String clientIP);

    SecuritiesIssuerCodeResponse deleteById(DeleteSecuritiesIssuerCodeRequest deleteSecuritiesIssuerCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    SecuritiesIssuerCodeResponse deleteApprove(ApproveSecuritiesIssuerCodeRequest approveSecuritiesIssuerCodeRequest, String approveIPAddress);

    SecuritiesIssuerCodeDTO getById(Long id);

    SecuritiesIssuerCodeDTO getByExternalCode(String externalCode);

    List<SecuritiesIssuerCodeDTO> getAll();

}
