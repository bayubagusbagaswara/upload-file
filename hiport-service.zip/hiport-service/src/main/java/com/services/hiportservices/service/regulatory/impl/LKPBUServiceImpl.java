package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUDTO;
import com.services.hiportservices.dto.regulatory.lkpbu.LKPBU2DTO;
import com.services.hiportservices.service.regulatory.LKPBUService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class LKPBUServiceImpl implements LKPBUService {

    @Override
    public List<LKPBUDTO> getAllDataMock() {
        return createLKPBUList();
    }

    @Override
    public List<LKPBU2DTO> getAllDataMock2() {
        return createDataList();
    }

    private List<LKPBUDTO> createLKPBUList() {
        List<LKPBUDTO> lkpbudtoList = new ArrayList<>();

        LKPBUDTO lkpbudto = LKPBUDTO.builder()
                .flagDetail("D01")
                .componentCode("010001")
                .group("S12802")
                .companyCode("2000003836")
                .companyName("BCA")
                .effectCode("BCAP03BCN1")

                .settlementTransactionBuyFrequency(1)
                .settlementTransactionBuyVolume(new BigDecimal("2000000000"))
                .settlementTransactionBuyAmount(new BigDecimal("2000020000"))
                .settlementTransactionBuyInvestorIndonesia(new BigDecimal("100"))

                .settlementTransactionSellFrequency(0)
                .settlementTransactionSellVolume(new BigDecimal("0"))
                .settlementTransactionSellAmount(new BigDecimal("0"))
                .settlementTransactionSellInvestorIndonesia(new BigDecimal("0"))
                .build();

        lkpbudtoList.add(lkpbudto);

        return lkpbudtoList;
    }

    private List<LKPBU2DTO> createDataList() {

        LKPBU2DTO data1 = LKPBU2DTO.builder()
                .number("12487")
                .kodeKomponen("010001")
                .securitiesOwnerGolongan("S125020523L")
                .securitiesOwnerSandiPerusahaan("")
                .securitiesOwnerNegaraAsal("ID")

                .securitiesIssuerGolongan("S122")
                .securitiesIssuerNegaraAsal("ID")

                .securitiesKode("BJBS1TDS0425")
                .securitiesJenis("F110202")
                .securitiesKodeEfek("")
                .securitiesLembarUnit("")
                .securitiesInterestRate("")
                .securitiesKeterangan("")
                .securitiesDanaJaminan("")

                .jenisValuta("IDR")

                .issuerDate("20240623")
                .issuerDueDate("20240723")

                .nilaiValutaAsal("800000000")
                .pembayaranKupon("0")
                .build();

        LKPBU2DTO data2 = LKPBU2DTO.builder()
                .number("")
                .kodeKomponen("")
                .securitiesOwnerGolongan("")
                .securitiesOwnerSandiPerusahaan("")
                .securitiesOwnerNegaraAsal("")

                .securitiesIssuerGolongan("")
                .securitiesIssuerNegaraAsal("")

                .securitiesKode("BCIC1TDC0095")
                .securitiesJenis("F110201")
                .securitiesKodeEfek("")
                .securitiesLembarUnit("")
                .securitiesInterestRate("")
                .securitiesKeterangan("")
                .securitiesDanaJaminan("")

                .jenisValuta("IDR")

                .issuerDate("20240626")
                .issuerDueDate("20240726")

                .nilaiValutaAsal("1000000000")
                .pembayaranKupon("0")
                .build();

        LKPBU2DTO data3 = LKPBU2DTO.builder()
                .number("")
                .kodeKomponen("")
                .securitiesOwnerGolongan("")
                .securitiesOwnerSandiPerusahaan("")
                .securitiesOwnerNegaraAsal("")

                .securitiesIssuerGolongan("")
                .securitiesIssuerNegaraAsal("")

                .securitiesKode("BEKS1TDC0137")
                .securitiesJenis("F110201")
                .securitiesKodeEfek("")
                .securitiesLembarUnit("")
                .securitiesInterestRate("")
                .securitiesKeterangan("")
                .securitiesDanaJaminan("")

                .jenisValuta("IDR")

                .issuerDate("20240629")
                .issuerDueDate("20240729")

                .nilaiValutaAsal("500000000")
                .pembayaranKupon("0")
                .build();

        return Arrays.asList(data1, data2, data3);
    }
}
