package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.insurancepensionfund.*;

import java.util.List;

/**
 * for maintenance Asuransi dan Dana Pensiun
 */
public interface InsurancePensionFundService {

    InsurancePensionFundResponse uploadData(UploadInsurancePensionFundListRequest uploadInsurancePensionFundListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    InsurancePensionFundResponse approveCreate(CreateInsurancePensionFundRequest createInsurancePensionFundRequest, String approveIPAddress);

    InsurancePensionFundResponse updateById(UpdateInsurancePensionFundRequest updateInsurancePensionFundRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    InsurancePensionFundResponse updateApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress);

    InsurancePensionFundResponse deleteById(DeleteInsurancePensionFundRequest deleteInsurancePensionFundRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    InsurancePensionFundResponse deleteApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress);

    InsurancePensionFundDTO getById(Long id);

    InsurancePensionFundDTO getByCode(String code);

    List<InsurancePensionFundDTO> getAll();
}
