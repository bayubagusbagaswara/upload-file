package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.issuercodeplacementbank.*;

import java.util.List;

public interface IssuerCodePlacementBankService {

    IssuerCodePlacementBankResponse uploadData(UploadIssuerCodePlacementBankListRequest uploadIssuerCodePlacementBankListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    IssuerCodePlacementBankResponse createApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress);

    IssuerCodePlacementBankResponse updateById(UpdateIssuerCodePlacementBankRequest issuerCodePlacementBankRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    IssuerCodePlacementBankResponse updateApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress);

    IssuerCodePlacementBankResponse deleteById(DeleteIssuerCodePlacementBankRequest deleteIssuerCodePlacementBankRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    IssuerCodePlacementBankResponse deleteApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress);

    IssuerCodePlacementBankDTO getById(Long id);

    IssuerCodePlacementBankDTO getByCode(String code);

    List<IssuerCodePlacementBankDTO> getAll();

}
