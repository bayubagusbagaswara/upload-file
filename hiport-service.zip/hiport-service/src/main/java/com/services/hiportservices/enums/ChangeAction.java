package com.services.hiportservices.enums;

public enum  ChangeAction {
        Add, Edit, Delete
}
