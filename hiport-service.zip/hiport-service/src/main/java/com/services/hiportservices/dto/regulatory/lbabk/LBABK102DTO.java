package com.services.hiportservices.dto.regulatory.lbabk;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABK102DTO {

    private String flagDetail;

    private String kodeKomponen;

    private String kodeTipeEfek;

    private String keteranganTipeEfek;

    private String nilaiRupiah;

}
