package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.exchangerate.CreateExchangeRateRequest;
import com.services.hiportservices.dto.regulatory.exchangerate.ExchangeRateDTO;
import com.services.hiportservices.model.regulatory.ExchangeRate;
import com.services.hiportservices.utils.regulatory.ConversionUtil;
import org.mapstruct.*;

import java.math.BigDecimal;
import java.util.List;

@Mapper(componentModel = "spring")
public interface ExchangeRateMapper {

//    ExchangeRateMapper INSTANCE = Mappers.getMapper(ExchangeRateMapper.class);

    @Mapping(source = "currencyCode", target = "currencyCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currencyName", target = "currencyName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "exchangeRate", target = "exchangeRate", qualifiedByName = "stringToBigDecimal")
    ExchangeRateDTO toDTO(CreateExchangeRateRequest request);

    @Mapping(source = "currencyCode", target = "code", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currencyName", target = "name", qualifiedByName = "nullToEmpty")
    @Mapping(source = "exchangeRate", target = "exchangeRate", qualifiedByName = "stringToBigDecimal")
    ExchangeRate toModel(ExchangeRateDTO exchangeRateDTO);

    @BeanMapping(ignoreUnmappedSourceProperties = {
            "approvalStatus", "inputerId", "inputDate", "approverId",
            "approveDate", "inputIPAddress", "approveIPAddress"
    })
    @Mapping(source = "id", target = "id")
    @Mapping(source = "code", target = "currencyCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "name", target = "currencyName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "exchangeRate", target = "exchangeRate", qualifiedByName = "bigDecimalToString")
    ExchangeRateDTO toDTO(ExchangeRate exchangeRate);

    List<ExchangeRateDTO> toDTOList(List<ExchangeRate> exchangeRateList);

    List<ExchangeRate> toModelList(List<ExchangeRateDTO> exchangeRateDTOList);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    @Named("stringToBigDecimal")
    default BigDecimal stringToBigDecimal(String value) {
        return ConversionUtil.stringToBigDecimal(value);
    }

    @Named("bigDecimalToString")
    default String bigDecimalToString(BigDecimal value) {
        return ConversionUtil.bigDecimalToString(value);
    }

//    ExchangeRateMapper INSTANCE = Mappers.getMapper(ExchangeRateMapper.class);
//
//    @Mapping(target = "code", source = "code", defaultValue = "")
//    @Mapping(target = "name", source = "name", defaultValue = "")
//    @Mapping(target = "exchangeRate", source = "exchangeRate", defaultExpression = "java(BigDecimal.ZERO)")
//    ExchangeRate toEntity(UpdateExchangeRateRequest dto);

    @AfterMapping
    default void setDefaults(@MappingTarget ExchangeRateDTO dto) {
        if (dto.getCurrencyCode() == null) {
            dto.setCurrencyCode("");
        }
        if (dto.getCurrencyName() == null) {
            dto.setCurrencyName("");
        }
        if (dto.getExchangeRate() == null) {
            dto.setExchangeRate("");
        }
    }

}
