package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.AmortizationPriceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/amortization")
public class AmortizationPriceController {

    @Autowired
    AmortizationPriceService amortizationPriceService;

    @PostMapping("/upload")
    public ResponseEntity<ResponseDto> uploadFileAmortization(@RequestBody List<Map<String, String>> amortizationPriceList) {
        return amortizationPriceService.insertDataAmortizationPrice(amortizationPriceList);
    }

    @GetMapping
    public ResponseEntity<ResponseDto> getAllDataAt(@RequestParam String startDate, @RequestParam String endDate) {
        return amortizationPriceService.findDataAt(startDate, endDate);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return amortizationPriceService.allPendingDataAmortization();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataWithId(@RequestBody Map<String, List<String>> idList) {
        return amortizationPriceService.approveDataAmortization(idList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataWithId(@RequestBody Map<String, List<String>> idList) {
        return amortizationPriceService.rejectDataAmortization(idList);
    }
}
