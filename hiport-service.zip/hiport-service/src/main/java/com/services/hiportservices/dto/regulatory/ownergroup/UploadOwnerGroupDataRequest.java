package com.services.hiportservices.dto.regulatory.ownergroup;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadOwnerGroupDataRequest {

    @JsonProperty(value = "Portfolio Code")
    private String portfolioCode;

    @JsonProperty(value = "Portfolio Name")
    private String portfolioName;

    @JsonProperty(value = "Kode S-Invest")
    private String sInvestCode;

    @JsonProperty(value = "Referensi Golongan Pihak Lawan")
    private String opposingGroupReference;

    @JsonProperty(value = "Referensi Negara")
    private String countryReference;
}
