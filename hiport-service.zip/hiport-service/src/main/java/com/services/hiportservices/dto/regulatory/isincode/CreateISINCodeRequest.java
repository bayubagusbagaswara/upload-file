package com.services.hiportservices.dto.regulatory.isincode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * untuk anotasi validasi ditaruh disini
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateISINCodeRequest extends InputIdentifierRequest {

    private String externalCode;

    private String currency;

    private String isinLKPBU;

    private String isinLBABK;

}
