package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class ReksadanaTypeRequestDTO {
    private String reksadanaType;
    private String name;
    private boolean delete;
}
