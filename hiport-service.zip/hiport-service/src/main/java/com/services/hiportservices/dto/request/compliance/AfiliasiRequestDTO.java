package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class AfiliasiRequestDTO {
    private Long id;
    private String reksadanaCode;
    private String rdExternalCode;
    private String reksadanaName;
    private String afiliasi;
    private String kodeEfek;
}
