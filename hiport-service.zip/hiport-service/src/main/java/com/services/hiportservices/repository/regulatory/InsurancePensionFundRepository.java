package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.InsurancePensionFund;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InsurancePensionFundRepository extends JpaRepository<InsurancePensionFund, Long> {
}
