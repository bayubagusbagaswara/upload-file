package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.DeleteOwnerGroupRequest;
import com.services.hiportservices.dto.regulatory.ownergroup.ApproveOwnerGroupRequest;
import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupResponse;
import com.services.hiportservices.dto.regulatory.ownergroup.UploadOwnerGroupListRequest;

import java.util.List;

public interface OwnerGroupService {

    OwnerGroupResponse uploadData(UploadOwnerGroupListRequest uploadOwnerGroupListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    OwnerGroupResponse createApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress);

    OwnerGroupResponse updateApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress);

    OwnerGroupResponse deleteById(DeleteOwnerGroupRequest deleteOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    OwnerGroupResponse deleteApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress);

    OwnerGroupDTO getById(Long id);

    OwnerGroupDTO getByPortfolioCode(String portfolioCode);

    List<OwnerGroupDTO> getAll();

}
