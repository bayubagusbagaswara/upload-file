package com.services.hiportservices.dto.regulatory.insurancepensionfund;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

/**
 * create satuan
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateInsurancePensionFundRequest extends InputIdentifierRequest {

    private String portfolioCode;

    private String portfolioName;

    private String regulatoryName; // regulator name

    private String insurancePensionFundReference; // referensi dapen dan asuransi

    private String guaranteeFund; // dana jaminan/investasi

}
