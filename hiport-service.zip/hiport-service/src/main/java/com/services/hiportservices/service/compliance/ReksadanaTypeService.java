package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.PortfolioRequestDTO;
import com.services.hiportservices.dto.request.compliance.ReksadanaTypeRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.ComplianceDataChangeRepository;
import com.services.hiportservices.repository.compliance.PortfolioRepository;
import com.services.hiportservices.repository.compliance.PortfolioTypeRepository;
import com.services.hiportservices.repository.compliance.ReksadanaTypeRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class ReksadanaTypeService {

    @Autowired
    ReksadanaTypeRepository reksadanaTypeRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;

    public ResponseEntity<ResponseDto> insertReksadanaType(ReksadanaTypeRequestDTO reksadanaTypeRequestDTO) {
        String message = "Success update reksadana type";
        ResponseDto responseDto = new ResponseDto();
        ReksadanaType reksadanaType = reksadanaTypeRepository.findByReksadanaType(reksadanaTypeRequestDTO.getReksadanaType());

        try{
            if(reksadanaType == null){
                reksadanaType = new ReksadanaType();
                reksadanaType.setReksadanaType(reksadanaTypeRequestDTO.getReksadanaType());
                reksadanaType.setApprovalStatus(ApprovalStatus.Pending);
                reksadanaType.setInputDate(new Date());
                reksadanaType.setInputerId(UserIdUtil.getUser());
                reksadanaType.setDelete(false);
                reksadanaType.setName(reksadanaTypeRequestDTO.getName());
                reksadanaTypeRepository.save(reksadanaType);
                message = "Success insert new reksadana type";
            } else {
                ReksadanaType reksadanaTypeAfter = new ReksadanaType();
                reksadanaTypeAfter.setInputDate(new Date());
                reksadanaTypeAfter.setInputerId(UserIdUtil.getUser());
                reksadanaTypeAfter.setDelete(false);
                reksadanaTypeAfter.setName(reksadanaTypeRequestDTO.getName());

                ObjectMapper Obj = new ObjectMapper();
                String jsonbefore = Obj.writeValueAsString(reksadanaType);
                ObjectMapper ObjAfter = new ObjectMapper();
                String jsonAfter = ObjAfter.writeValueAsString(reksadanaTypeAfter);

                ComplianceDataChange dataChange = new ComplianceDataChange();
                dataChange.setApprovalStatus(ApprovalStatus.Pending);
                dataChange.setInputerId(UserIdUtil.getUser());
                dataChange.setInputDate(new Date());
                dataChange.setAction(ChangeAction.Edit);
                dataChange.setEntityId(reksadanaType.getReksadanaType());
                dataChange.setTableName("comp_reksadana_type");
                dataChange.setEntityClassName(ReksadanaType.class.getName());
                dataChange.setDataBefore(jsonbefore);
                dataChange.setDataChange(jsonAfter);
                complianceDataChangeRepository.save(dataChange);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }


    public ResponseEntity<ResponseDto> getByReksadanaType(String code) {

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(reksadanaTypeRepository.findByReksadanaType(code));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> deleteByReksadanaCode(String code) {
        ResponseDto responseDto = new ResponseDto();
        try {
            ReksadanaType reksadanaType = reksadanaTypeRepository.findByReksadanaType(code);
            if (reksadanaType != null){
                ReksadanaType reksadanaTypeAfter = new ReksadanaType();
                reksadanaTypeAfter.setInputDate(new Date());
                reksadanaTypeAfter.setInputerId(UserIdUtil.getUser());
                reksadanaTypeAfter.setDelete(true);

                ObjectMapper Obj = new ObjectMapper();
                String jsonbefore = Obj.writeValueAsString(reksadanaType);
                ObjectMapper ObjAfter = new ObjectMapper();
                String jsonAfter = ObjAfter.writeValueAsString(reksadanaTypeAfter);

                ComplianceDataChange dataChange = new ComplianceDataChange();
                dataChange.setApprovalStatus(ApprovalStatus.Pending);
                dataChange.setInputerId(UserIdUtil.getUser());
                dataChange.setInputDate(new Date());
                dataChange.setAction(ChangeAction.Delete);
                dataChange.setEntityId(reksadanaType.getReksadanaType());
                dataChange.setTableName("comp_reksadana_type");
                dataChange.setEntityClassName(ReksadanaType.class.getName());
                dataChange.setDataBefore(jsonbefore);
                dataChange.setDataChange(jsonAfter);
                complianceDataChangeRepository.save(dataChange);
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Delete success where reksadana type " + code + "! Need Approval!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> getAllReksadanaType() {

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(reksadanaTypeRepository.findAllByApprovalStatusAndAndDelete(ApprovalStatus.Approved, false));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataReksadanaType() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(reksadanaTypeRepository.searchPendingData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataReksadanaType(Map<String, List<String>> codeList) {
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            reksadanaTypeRepository.approveOrRejectReksadanaType("Approved", new Date(), approverId, code);
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataReksadanaType(Map<String, List<String>> codeList) {
        String approverId = UserIdUtil.getUser();
        List<String> codes = codeList.get("idList");
        for (String code : codes){
            ReksadanaType reksadanaType = reksadanaTypeRepository.findByReksadanaType(code);
            reksadanaTypeRepository.delete(reksadanaType);
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
