package com.services.hiportservices.constant;

public class LBABKHeaderNameConstant {

    // 1
    public static final String FLAG_DETAIL = "Flag Detail";

    // 2
    public static final String KODE_KOMPONEN = "Kode Komponen";

    // 3
    public static final String TANGGAL_TRANSAKSI = "Tanggal Transaksi";

    // 4
    public static final String KODE_TIPE_EFEK = "Kode Tipe Efek";

    // 5
    public static final String KETERANGAN_TIPE_EFEK = "Keterangan Tipe Efek";

    // 6
    public static final String ISIN_CODE = "ISIN Code";

    // 7
    public static final String SECURITY_NAME = "Security Name";

    // 8
    public static final String ISSUER_CODE = "Issuer Code";

    // 9
    public static final String NAMA_ISSUER = "Issuer Name";

    // 10
    public static final String KODE_MATA_UANG = "Kode Mata Uang";

    // 11
    public static final String TRANSACTION_COMPLETION_BUY_FREQUENCY = "Penyelesaian Transaksi Beli - Frekuensi";

    // 12
    public static final String TRANSACTION_COMPLETION_BUY_VOLUME = "Penyelesaian Transaksi Beli - Volume (Unit)";

    // 13
    public static final String TRANSACTION_COMPLETION_BUY_VALUE = "Penyelesaian Transaksi Beli - Nilai";

    // 14
    public static final String TRANSACTION_COMPLETION_BUY_INDONESIA_INVESTOR = "% Penyelesaian Transaksi Beli - Investor Indonesia";

    // 15
    public static final String TRANSACTION_COMPLETION_BUY_FOREIGN_INVESTOR = "% Penyelesaian Transaksi Beli - Investor Asing";

    // 16
    public static final String TRANSACTION_COMPLETION_BUY_CONFIRM_INVESTOR = "% Penyelesaian Transaksi Beli - Konfirmasi Investor Tepat Waktu";

    // 17
    public static final String TRANSACTION_COMPLETION_SELL_FREQUENCY = "Penyelesaian Transaksi Jual - Frekuensi";

    // 18
    public static final String TRANSACTION_COMPLETION_SELL_VOLUME = "Penyelesaian Transaksi Jual - Volume (Unit)";

    // 19
    public static final String TRANSACTION_COMPLETION_SELL_VALUE = "Penyelesaian Transaksi Jual - Nilai";

    // 20
    public static final String TRANSACTION_COMPLETION_SELL_INDONESIA_INVESTOR = "% Penyelesaian Transaksi Jual - Investor Indonesia";

    // 21
    public static final String TRANSACTION_COMPLETION_SELL_FOREIGN_INVESTOR = "% Penyelesaian Transaksi Jual - Investor Asing";

    // 22
    public static final String TRANSACTION_COMPLETION_SELL_CONFIRM_INVESTOR = "% Penyelesaian Transaksi Jual - Konfirmasi Investor Tepat Waktu";

    // 23
    public static final String NILAI_RUPIAH = "Nilai Rupiah";

}
