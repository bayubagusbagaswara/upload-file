package com.services.hiportservices.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class DataNotFoundHandleException extends RuntimeException {

    public DataNotFoundHandleException() {
        super();
    }

    public DataNotFoundHandleException(String message) {
        super(message);
    }

    public DataNotFoundHandleException(String message, Throwable cause) {
        super(message, cause);
    }

}
