package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.exception.BadRequestException;
import com.services.hiportservices.exception.DataNotFoundHandleException;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.repository.regulatory.RegulatoryDataChangeRepository;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.StringUtil;
import com.services.hiportservices.utils.regulatory.TableNameResolver;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.enums.ApprovalStatus.Approved;
import static com.services.hiportservices.enums.ApprovalStatus.Pending;
import static com.services.hiportservices.enums.ApprovalStatus.Rejected;
import static com.services.hiportservices.enums.ChangeAction.Add;
import static com.services.hiportservices.enums.ChangeAction.Delete;
import static com.services.hiportservices.enums.ChangeAction.Edit;

@Service
@Slf4j
@RequiredArgsConstructor
public class RegulatoryDataChangeServiceImpl implements RegulatoryDataChangeService {

    private static final String ERROR_MESSAGE_NOT_FOUND_ID = "Data Change not found with id: ";

    private final RegulatoryDataChangeRepository regulatoryDataChangeRepository;

    @Override
    public RegulatoryDataChange getById(Long id) {
        log.info("Start regulatory get data change by id");
        return regulatoryDataChangeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ERROR_MESSAGE_NOT_FOUND_ID + id));
    }

    @Override
    public List<RegulatoryDataChange> getAll() {
        log.info("Start get all regulatory data change");
        return regulatoryDataChangeRepository.findAll();
    }

    @Override
    public List<String> findAllMenu() {
        log.info("Start get all menu regulatory data change");
        return regulatoryDataChangeRepository.findAllMenu();
    }

    @Override
    public String deleteAll() {
        log.info("Start delete all regulatory data change");
        regulatoryDataChangeRepository.deleteAll();
        return "Successfully delete all regulatory data change from table";
    }

    @Override
    public synchronized void setApprovalStatusIsRejected(RegulatoryDataChange dataChange, List<String> errorMessageList) {
        log.info("Start set approval status is Rejected");
        RegulatoryDataChange regulatoryDataChange = getById(dataChange.getId());

        regulatoryDataChange.setApprovalStatus(Rejected);
        regulatoryDataChange.setApproverId(dataChange.getApproverId());
        regulatoryDataChange.setApproveIPAddress(dataChange.getApproveIPAddress());
        regulatoryDataChange.setApproveDate(
                Optional.ofNullable(dataChange.getApproveDate()).orElse(LocalDateTime.now())
        );
        regulatoryDataChange.setJsonDataAfter(
                Optional.ofNullable(dataChange.getJsonDataAfter()).orElse("")
        );
        regulatoryDataChange.setJsonDataBefore(
                Optional.ofNullable(dataChange.getJsonDataBefore()).orElse("")
        );
        regulatoryDataChange.setEntityId(
                Optional.ofNullable(dataChange.getEntityId()).orElse("")
        );
        regulatoryDataChange.setDescription(StringUtil.joinStrings(errorMessageList));

        RegulatoryDataChange save = regulatoryDataChangeRepository.save(regulatoryDataChange);
        log.info("Successfully set approval status Rejected with id: " + save.getId());
    }

    @Override
    public synchronized void setApprovalStatusIsApproved(RegulatoryDataChange dataChange) {
        log.info("Start set approval status is Approved");
        RegulatoryDataChange regulatoryDataChange = getById(dataChange.getId());

        regulatoryDataChange.setApprovalStatus(Approved);
        regulatoryDataChange.setApproverId(dataChange.getApproverId());
        regulatoryDataChange.setApproveIPAddress(dataChange.getApproveIPAddress());
        regulatoryDataChange.setApproveDate(
                Optional.ofNullable(dataChange.getApproveDate()).orElse(LocalDateTime.now())
        );
        regulatoryDataChange.setJsonDataAfter(
                Optional.ofNullable(dataChange.getJsonDataAfter()).orElse("")
        );
        regulatoryDataChange.setJsonDataBefore(
                Optional.ofNullable(dataChange.getJsonDataBefore()).orElse("")
        );
        regulatoryDataChange.setEntityId(dataChange.getEntityId());
        regulatoryDataChange.setDescription(dataChange.getDescription());

        RegulatoryDataChange save = regulatoryDataChangeRepository.save(regulatoryDataChange);
        log.info("Successfully set approval status Approved with id: " + save.getId());
    }

    @Override
    public synchronized <T> void createChangeActionAdd(RegulatoryDataChange dataChange, Class<T> clazz) {
        dataChange.setAction(Add);
        dataChange.setEntityId("");
        dataChange.setEntityClassName(clazz.getName());
        dataChange.setTableName(TableNameResolver.getTableName(clazz));
        dataChange.setJsonDataBefore("");
        dataChange.setDescription("");

        RegulatoryDataChange save = regulatoryDataChangeRepository.save(dataChange);
        log.info("Successfully save create change action Add with id: " + save.getId());
    }

    @Override
    public synchronized <T> void createChangeActionEdit(RegulatoryDataChange dataChange, Class<T> clazz) {
        log.info("Start create change action Edit: {}", dataChange);
        dataChange.setAction(Edit);
        dataChange.setEntityClassName(clazz.getName());
        dataChange.setTableName(TableNameResolver.getTableName(clazz));
        dataChange.setDescription("");

        RegulatoryDataChange save = regulatoryDataChangeRepository.save(dataChange);
        log.info("Successfully save create change action Edit with id: " + save.getId());
    }

    @Override
    public synchronized <T> void createChangeActionDelete(RegulatoryDataChange dataChange, Class<T> clazz) {
        log.info("Start create change action Delete: {}", dataChange);
        dataChange.setAction(Delete);
        dataChange.setEntityClassName(clazz.getName());
        dataChange.setTableName(TableNameResolver.getTableName(clazz));
        dataChange.setDescription("");

        RegulatoryDataChange save = regulatoryDataChangeRepository.save(dataChange);
        log.info("Successfully save create change action Delete with id: " + save.getId());
    }

    @Override
    public Boolean existByIdListAndStatus(List<Long> idList, Long idListSize, ApprovalStatus approvalStatus) {
//        Boolean existsByIdListAndStatus = regulatoryDataChangeRepository.existsByIdListAndStatus(idList, idListSize, approvalStatus);
//        log.info("Status exist by id list: {}", existsByIdListAndStatus);
//        return existsByIdListAndStatus;
        return false;
    }

    @Override
    public boolean existById(Long id) {
        boolean existsById = regulatoryDataChangeRepository.existsById(id);
        log.info("Exist by id: {}", existsById);
        return existsById;
    }


    @Override
    public List<RegulatoryDataChange> findByMenuAndApprovalStatus(String menu, ApprovalStatus approvalStatus) {
        log.info("Start get all regulatory data change by menu and approval status");
        List<RegulatoryDataChange> menuAndApprovalStatus = regulatoryDataChangeRepository.findByMenuAndApprovalStatus(menu, approvalStatus);
        log.info("Size get all regulatory data change: {}", menuAndApprovalStatus.size());
        return menuAndApprovalStatus;
    }

    @Override
    public void reject(Long id) {
        log.info("Start reject process for regulatory data change by id: {}", id);
        RegulatoryDataChange regulatoryDataChange = getById(id);
        regulatoryDataChange.setApprovalStatus(Rejected);
        RegulatoryDataChange save = regulatoryDataChangeRepository.save(regulatoryDataChange);
        log.info("Successfully update regulatory data change approval status is Rejected by id: {}", save.getId());
    }

    @Override
    public List<RegulatoryDataChange> getAllByApprovalStatus(String approvalStatus) {
        log.info("Start get all regulatory data change by approval status: {}", approvalStatus);
        String approvalStatusEnum = "";
        if (Pending.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum  = Pending.name();
        } else if (Approved.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = Approved.name();
        } else if (Rejected.name().equalsIgnoreCase(approvalStatus)) {
            approvalStatusEnum = Rejected.name();
        }

        if (approvalStatusEnum.isEmpty()) {
            throw new BadRequestException("Approval status enum not matching: " + approvalStatusEnum);
        }

        return regulatoryDataChangeRepository.findAllByApprovalStatus(approvalStatusEnum);
    }

    @Override
    public String deleteById(Long id) {
        log.info("Start delete regulatory data change by id: {}", id);
        RegulatoryDataChange regulatoryDataChange = getById(id);
        regulatoryDataChangeRepository.delete(regulatoryDataChange);
        return "Successfully delete regulatory data change with id: " + id;
    }

}
