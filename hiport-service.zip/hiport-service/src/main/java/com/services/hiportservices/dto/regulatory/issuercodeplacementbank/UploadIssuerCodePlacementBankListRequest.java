package com.services.hiportservices.dto.regulatory.issuercodeplacementbank;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadIssuerCodePlacementBankListRequest extends InputIdentifierRequest {

    private List<UploadIssuerCodePlacementBankDataRequest> uploadIssuerCodePlacementBankDataRequestList;

}
