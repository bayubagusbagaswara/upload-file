package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.sql.Date;
import java.text.SimpleDateFormat;

@Entity
@Data
@Table(name = "ORCHIDXD13")
public class OrchidXd13 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "DATE_PROC")
    private String dateProc;

    @Column(name = "STAT_PROC")
    private String statProc;

    @Column(name = "Tanggal")
    private Date tanggal;

    @Column(name = "Kode")
    private String kode;

    @Column(name = "PInvestasi")
    private String pInvestasi;

    @Column(name = "RInvestasi")
    private String rInvestasi;

    @Column(name = "Penyesuaian")
    private String penyesuaian;

    @Column(name = "Perubahan")
    private String perubahan;

    @Column(name = "TOTAL")
    private String total;

    @Column(name = "Distribusi")
    private String distribusi;

    @Column(name = "Penjualan")
    private String penjualan;

    @Column(name = "Redemption")
    private String redemtion;

    @Column(name = "PBersih")
    private String pbersih;

    @Column(name = "ReksadanaCode")
    private String reksadanaCode;

    @Transient
    @Getter(AccessLevel.NONE)
    private String tanggalStr;

    public String getTanggalStr() {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(tanggal);
    }
}
