package com.services.hiportservices.model.emonitoring;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;

@Entity
@Data
@Table(name = "ORCHIDXD16")
public class OrchidXd16 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "PORTFOLIOCODE")
    private String portfolioCode;

    @Column(name = "REKSADANA")
    private String reksadana;

    @Column(name = "DATE1")
    private String date1;

    @Column(name = "DATE2")
    private String date2;

    @Column(name = "DATE3")
    private String date3;

    @Column(name = "VALUE1")
    private String val1;

    @Column(name = "VALUE2")
    private String val2;

    @Column(name = "VALUE3")
    private String val3;

    @Column(name = "VALUE4")
    private String val4;

    @Column(name = "DESC1")
    private String DESC1;

    @Column(name = "ReksadanaCode")
    private String reksadanaCode;

}
