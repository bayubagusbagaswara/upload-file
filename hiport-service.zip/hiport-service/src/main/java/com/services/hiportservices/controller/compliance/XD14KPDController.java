package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.NabKPDService;
import com.services.hiportservices.service.compliance.XD14KPDService;
import com.services.hiportservices.service.emonitoring.OrchidXd14Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/xd14kpd")
public class XD14KPDController {

    @Autowired
    XD14KPDService xd14KPDService;

    @PostMapping("/upload")
    public ResponseEntity<ResponseDto> uploadFile(@RequestParam("file") MultipartFile file) {
        return xd14KPDService.insertDataXd14Kpd(file);
    }

    @GetMapping("/{date}")
    public ResponseEntity<ResponseDto> getAllDataAt(@PathVariable String date) {
        System.out.println(date);
        return xd14KPDService.findDataAt(date);
    }
//
    @GetMapping("/viewPending/{date}")
    public ResponseEntity<ResponseDto> viewPendingData(@PathVariable String date) {
        return xd14KPDService.viewPendingData(date);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return xd14KPDService.allPendingDataXd14Kpd();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataAt(@RequestBody Map<String, List<String>> dates) {
        return xd14KPDService.approveDataxd14Kpd(dates);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataAt(@RequestBody Map<String, List<String>> dates) {
        return xd14KPDService.rejectDataXd14Kpd(dates);
    }

}
