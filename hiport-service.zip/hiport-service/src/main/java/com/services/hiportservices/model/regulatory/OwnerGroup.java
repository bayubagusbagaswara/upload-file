package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.regulatory.approval.RegulatoryApproval;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Maintenance Golongan Pemilik
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "regulatory_owner_group")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OwnerGroup extends RegulatoryApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "portfolio_name")
    private String portfolioName;

    @Column(name = "s_invest_code")
    private String sInvestCode;

    @Column(name = "opposing_group_reference")
    private String opposingGroupReference; // referensi golongan pihak lawan

    @Column(name = "country_reference")
    private String countryReference; // referensi negara

}
