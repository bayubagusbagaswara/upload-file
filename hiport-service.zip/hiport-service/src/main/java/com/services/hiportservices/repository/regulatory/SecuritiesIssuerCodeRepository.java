package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.SecuritiesIssuerCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SecuritiesIssuerCodeRepository extends JpaRepository<SecuritiesIssuerCode, Long> {
}
