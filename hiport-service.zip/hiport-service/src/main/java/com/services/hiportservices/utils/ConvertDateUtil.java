package com.services.hiportservices.utils;

public class ConvertDateUtil {
    public String convertDate(String date) {
        String convert = date.replace("/", "-");
        return convert;
    }
}
