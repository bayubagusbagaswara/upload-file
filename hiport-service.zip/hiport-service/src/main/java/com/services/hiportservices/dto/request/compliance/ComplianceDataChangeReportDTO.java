package com.services.hiportservices.dto.request.compliance;

import com.services.hiportservices.enums.ChangeAction;
import lombok.Data;

@Data
public class ComplianceDataChangeReportDTO {
    private long id;
    private ChangeAction action;
    private String entityClassName;
    private String entityId;
    private String dataBefore;
    private String dataChange;
}
