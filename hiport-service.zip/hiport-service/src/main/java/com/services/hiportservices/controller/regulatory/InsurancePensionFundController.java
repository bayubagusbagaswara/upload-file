package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.insurancepensionfund.*;
import com.services.hiportservices.service.regulatory.InsurancePensionFundService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/asuransi-dana-pensiun")
@Slf4j
@RequiredArgsConstructor
public class InsurancePensionFundController {

    private static final String BASE_URL_INSURANCE = "/api/regulatory/asuransi-dana-pensiun";
    private static final String MENU_ASURANSI_DANA_PENSIUN = "Asuransi dan Dana Pensiun";

    private final InsurancePensionFundService insurancePensionFundService;

    // upload file
    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDto<InsurancePensionFundResponse>> uploadData(@RequestBody UploadInsurancePensionFundListRequest uploadInsurancePensionFundListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(inputIPAddress)
                .methodHttp(HttpMethod.POST.name())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ASURANSI_DANA_PENSIUN)
                .build();

        InsurancePensionFundResponse insurancePensionFundResponse = insurancePensionFundService.uploadData(uploadInsurancePensionFundListRequest, regulatoryDataChangeDTO);
        ResponseDto<InsurancePensionFundResponse> response = ResponseDto.<InsurancePensionFundResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // create approve
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDto<InsurancePensionFundResponse>> approveCreate(@RequestBody CreateInsurancePensionFundRequest createInsurancePensionFundRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        InsurancePensionFundResponse insurancePensionFundResponse = insurancePensionFundService.approveCreate(createInsurancePensionFundRequest, approveIPAddress);
        ResponseDto<InsurancePensionFundResponse> response = ResponseDto.<InsurancePensionFundResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // update by id (in addition)
    @PutMapping(path = "/updateById")
    public ResponseEntity<ResponseDto<InsurancePensionFundResponse>> updateById(@RequestBody UpdateInsurancePensionFundRequest updateInsurancePensionFundRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(inputIPAddress)
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(BASE_URL_INSURANCE + "/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ASURANSI_DANA_PENSIUN)
                .build();
        InsurancePensionFundResponse insurancePensionFundResponse = insurancePensionFundService.updateById(updateInsurancePensionFundRequest, regulatoryDataChangeDTO);
        ResponseDto<InsurancePensionFundResponse> response = ResponseDto.<InsurancePensionFundResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // update approve
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDto<InsurancePensionFundResponse>> updateApprove(@RequestBody ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        InsurancePensionFundResponse insurancePensionFundResponse = insurancePensionFundService.updateApprove(approveInsurancePensionFundRequest, approveIPAddress);
        ResponseDto<InsurancePensionFundResponse> response = ResponseDto.<InsurancePensionFundResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // delete single
    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDto<InsurancePensionFundResponse>> deleteById(@RequestBody DeleteInsurancePensionFundRequest deleteInsurancePensionFundRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputIPAddress(inputIPAddress)
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_INSURANCE + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ASURANSI_DANA_PENSIUN)
                .build();
        InsurancePensionFundResponse insurancePensionFundResponse = insurancePensionFundService.deleteById(deleteInsurancePensionFundRequest, regulatoryDataChangeDTO);
        ResponseDto<InsurancePensionFundResponse> response = ResponseDto.<InsurancePensionFundResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // delete approve
    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDto<InsurancePensionFundResponse>> deleteApprove(@RequestBody ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        InsurancePensionFundResponse insurancePensionFundResponse = insurancePensionFundService.deleteApprove(approveInsurancePensionFundRequest, approveIPAddress);
        ResponseDto<InsurancePensionFundResponse> response = ResponseDto.<InsurancePensionFundResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // get by id
    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDto<InsurancePensionFundDTO>> getById(@PathVariable("id") Long id) {
        InsurancePensionFundDTO insurancePensionFundDTO = insurancePensionFundService.getById(id);
        ResponseDto<InsurancePensionFundDTO> response = ResponseDto.<InsurancePensionFundDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    // get by code
    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDto<InsurancePensionFundDTO>> getByCode(@RequestParam("code") String code) {
        InsurancePensionFundDTO insurancePensionFundDTO = insurancePensionFundService.getByCode(code);
        ResponseDto<InsurancePensionFundDTO> response = ResponseDto.<InsurancePensionFundDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    // get all
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<InsurancePensionFundDTO>>> getAll() {
        List<InsurancePensionFundDTO> insurancePensionFundDTOList = insurancePensionFundService.getAll();
        ResponseDto<List<InsurancePensionFundDTO>> response = ResponseDto.<List<InsurancePensionFundDTO>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(insurancePensionFundDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
