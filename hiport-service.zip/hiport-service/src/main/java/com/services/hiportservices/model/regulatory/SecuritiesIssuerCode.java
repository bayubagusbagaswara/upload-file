package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.regulatory.approval.RegulatoryApproval;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "regulatory_issuer_code")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SecuritiesIssuerCode extends RegulatoryApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /* TODO: Make sure external code data is Unique */
    @Column(name = "external_code_2")
    private String externalCode2;

    @Column(name = "currency")
    private String currency;

    @Column(name = "issuer_lbabk")
    private String issuerLBABK;

    @Column(name = "issuer_lkpbu")
    private String issuerLKPBU;

}
