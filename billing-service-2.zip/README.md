# Billing Service


- Bagaimana penanda customer untuk menentukan bahwa customer ini adalah Fund, Core, atau Retail
- Jika termasuk customer Core, maka perlu penanda juga untuk type berapa

# Read File Excel

- membaca file excel KSEI Fee
- Ambil hanya beberapa kolom / cell


```json

[
  {
    "id": "1",
    "product": "FR001",
    "date": "2023-11-29"
  },
  {
    "id": "2",
    "product": "FR002",
    "date": "2023-11-29"
   },
   {
    "id": "3",
    "product": "FR001",
    "date": "2023-11-30"
   },
   {
    "id": "4",
    "product": "FR002",
    "date": "2023-11-30"
   }
]

```

## Generate Billing Core
- Trigger dari depan hanya mengirim type "Core" dan period "Nov 2023"
- Jadi di belakang, harusnya akan men-generate semua customer tipe core (type 1 - 11)

# Format File Billing

- Customer Code"_"Jenis (Fund/Retail/Core)"_"periode (mmyyyy)
- Customer Code adalah AID

# Account4
- Format = GL 812017.0000 CC 0706
- 812017 from field Account
- 0706 from field Cost Center

# Retail Type 4
- setiap throw exception pasti langsung keluar process, tapi data yg diawal bisa kesimpan

@Query("select case when count(c)> 0 then true else false end from BillingCustomer c where lower(c.customerCode) = lower(:customerCode) AND lower(COALESCE(c.subCode,'') = lower(COALESCE(:subCode, ''))")
boolean existsCustomerByCustomerCodeAndSubCode
(@Param("customerCode") String customerCode, @Param("subCode") String subCode);

PROSES INSERT DATA BILLING CUSTOMER TO DATABASE
1. Validation data cannot be empty, and numeric or alphabetic
2. Validation data enum
3. Validation Investment Management Code is existing
4. Validation Customer Code is already taken

select gl_credit_account_value, gl_credit_name from billing_gl_credit where gl_credit_name = 'GL Safekeeping Fee' and gl_billing_template = 'CORE_TEMPLATE_7'

Accrual Biaya Kustodian
BI-SSSS( Transaction )+ KSEI Fee ( Transaction )
Biaya Penyelesaian Transaksi + Biaya Pihak ketiga 
Biaya Penyimpanan 
Biaya S4+Biaya KSEI 
Biaya Transfer 
GL Dana Custodian
GL HAK Operasional
GL Safekeeping Fee
KSEI Fee (Transaction) 
Safekeeping Fee
Safekeeping Fee + KSEI Fee 
TAX/VAT
Transaction Handling
Transaction Handling + Transaction Handling Internal
VAT 