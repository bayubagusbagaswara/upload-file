package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeschedule.*;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.mapper.FeeScheduleMapper;
import com.services.billingservice.model.BillingFeeSchedule;
import com.services.billingservice.repository.BillingFeeScheduleRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingFeeScheduleService;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingFeeScheduleServiceImpl implements BillingFeeScheduleService {

    private static final String ID_NOT_FOUND = "Fee Schedule not found with id: ";
    private static final String UNKNOWN = "unknown";

    private final BillingFeeScheduleRepository feeScheduleRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final FeeScheduleMapper feeScheduleMapper;

    @Override
    public FeeScheduleResponse createSingleData(CreateFeeScheduleRequest createRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data fee schedule with request: {}", createRequest);
        FeeScheduleDTO feeScheduleDTO = feeScheduleMapper.mapFromCreateRequestToDto(createRequest);
        dataChangeDTO.setInputerId(createRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createRequest.getInputerIPAddress());
        return processFeeScheduleCreation(feeScheduleDTO, dataChangeDTO);
    }

    private FeeScheduleResponse processFeeScheduleCreation(FeeScheduleDTO feeScheduleDTO, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            // tambahkan validation errors
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateFeeScheduleUsingValidator(feeScheduleDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = ErrorMessageDTO.builder()
                        .code(feeScheduleDTO.getId().toString())
                        .errorMessages(validationErrors)
                        .build();
                errorMessageList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeScheduleDTO)));
                dataChangeService.createChangeActionADD(dataChangeDTO, BillingFeeSchedule.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeScheduleResponse createSingleApprove(FeeScheduleApproveRequest approveRequest) {
        log.info("Approve when create investment management with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        FeeScheduleDTO feeScheduleDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> errorMessages = new ArrayList<>();

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);

            // mapping to dto from json data after data change
            // FeeScheduleDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), FeeScheduleDTO.class);

            Errors errors = validateFeeScheduleUsingValidator(feeScheduleDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(objectError -> errorMessages.add(objectError.getDefaultMessage()));
            }

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());

            if (!errorMessages.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeScheduleDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, errorMessages);
                totalDataFailed++;
            } else {
                BillingFeeSchedule feeSchedule = feeScheduleMapper.createEntity(feeScheduleDTO, dataChangeDTO);
                BillingFeeSchedule feeScheduleSaved = feeScheduleRepository.save(feeSchedule);

                dataChangeDTO.setDescription("Successfully approve data change and save data fee schedule");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeScheduleSaved)));
                dataChangeDTO.setEntityId(feeScheduleSaved.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeScheduleResponse updateSingleData(UpdateFeeScheduleRequest updateRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data fee schedule with request: {}", updateRequest);
        dataChangeDTO.setInputerId(updateRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        FeeScheduleDTO feeScheduleDTO = feeScheduleMapper.mapFromUpdateRequestToDto(updateRequest);
        try {
            BillingFeeSchedule feeSchedule = feeScheduleRepository.findById(feeScheduleDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeScheduleDTO.getId()));

            AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
            AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

            processUpdateFeeSchedule(feeSchedule, feeScheduleDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

            totalDataSuccess = successCounter.get();
            totalDataFailed = failedCounter.get();
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeScheduleResponse updateMultipleData(FeeScheduleListRequest updateListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple data fee schedule with request: {}", updateListRequest);
        dataChangeDTO.setInputerId(updateListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (FeeScheduleDTO feeScheduleDTO : updateListRequest.getFeeScheduleDTOList()) {
            try {
                BillingFeeSchedule feeSchedule = feeScheduleRepository.findById(feeScheduleDTO.getId())
                        .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeScheduleDTO.getId()));

                AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
                AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

                processUpdateFeeSchedule(feeSchedule, feeScheduleDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

                totalDataSuccess = successCounter.get();
                totalDataFailed = failedCounter.get();
            } catch (Exception e) {
                handleGeneralError(feeScheduleDTO, e, errorMessageList);
                totalDataFailed++;
            }
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private void processUpdateFeeSchedule(BillingFeeSchedule feeSchedule,
                                          FeeScheduleDTO feeScheduleDTO,
                                          BillingDataChangeDTO dataChangeDTO,
                                          List<ErrorMessageDTO> errorMessageList,
                                          AtomicInteger successCounter,
                                          AtomicInteger failedCounter) {
        try {
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateFeeScheduleUsingValidator(feeScheduleDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = ErrorMessageDTO.builder()
                        .code(feeScheduleDTO.getId().toString())
                        .errorMessages(validationErrors)
                        .build();
                errorMessageList.add(errorMessageDTO);
                failedCounter.incrementAndGet();
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeSchedule)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeScheduleDTO)));
                dataChangeDTO.setEntityId(feeSchedule.getId().toString());

                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingFeeSchedule.class);
                successCounter.incrementAndGet(); // Increment totalDataSuccess
            }
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            failedCounter.incrementAndGet(); // Increment totalDataFailed
        }
    }

    @Override
    public FeeScheduleResponse updateSingleApprove(FeeScheduleApproveRequest approveRequest) {
        log.info("Approve when update fee schedule with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        FeeScheduleDTO feeScheduleDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            Errors errors = validateFeeScheduleUsingValidator(feeScheduleDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            BillingFeeSchedule feeSchedule = feeScheduleRepository.findById(feeScheduleDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeScheduleDTO.getId()));

            // Copy data from DTO to Entity
            feeScheduleMapper.mapObjects(feeScheduleDTO, feeSchedule);
            log.info("Fee Schedule after copy properties: {}", feeSchedule);

            // Retrieve and set billing data change
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setEntityId(feeSchedule.getId().toString());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeScheduleDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingFeeSchedule feeScheduleUpdated = feeScheduleMapper.updateEntity(feeSchedule, dataChangeDTO);
                BillingFeeSchedule feeScheduleSaved = feeScheduleRepository.save(feeScheduleUpdated);

                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeScheduleSaved)));
                dataChangeDTO.setDescription("Successfully approve data change and update data entity");
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeScheduleResponse deleteSingleData(DeleteFeeScheduleRequest deleteRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete single fee schedule with request: {}", deleteRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        FeeScheduleDTO feeScheduleDTO = FeeScheduleDTO.builder()
                .id(deleteRequest.getId())
                .build();
        try {
            BillingFeeSchedule feeSchedule = feeScheduleRepository.findById(feeScheduleDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeScheduleDTO.getId()));

            dataChangeDTO.setInputerId(deleteRequest.getInputerId());
            dataChangeDTO.setInputerIPAddress(deleteRequest.getInputerIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeSchedule)));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(feeSchedule.getId().toString());

            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingFeeSchedule.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public FeeScheduleResponse deleteSingleApprove(FeeScheduleApproveRequest approveRequest) {
        log.info("Approve when delete fee schedule t with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());

        FeeScheduleDTO feeScheduleDTO = approveRequest.getData();
        BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(Long.valueOf(approveRequest.getDataChangeId()));
        try {
            BillingFeeSchedule feeSchedule = feeScheduleRepository.findById(feeScheduleDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + feeScheduleDTO.getId()));

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(feeSchedule)));
            dataChangeDTO.setDescription("Successfully approve data change and delete data entity");

            dataChangeService.approvalStatusIsApproved(dataChangeDTO);
            feeScheduleRepository.delete(feeSchedule);
            totalDataSuccess++;

        } catch (DataNotFoundException e) {
            handleDataNotFoundException(feeScheduleDTO, e, errorMessageList);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            List<String> validationErrors = new ArrayList<>();
            validationErrors.add(ID_NOT_FOUND + feeScheduleDTO.getId());

            dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(feeScheduleDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new FeeScheduleResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public BigDecimal checkFeeScheduleAndGetFeeValue(BigDecimal amount) {
        double amountFee = feeScheduleRepository.checkFeeScheduleAndGetFeeValue(amount);
        return new BigDecimal(amountFee);
    }

    @Override
    public List<FeeScheduleDTO> getAll() {
        List<BillingFeeSchedule> all = feeScheduleRepository.findAll();
        return feeScheduleMapper.mapToDTOList(all);
    }

    @Override
    public String deleteAll() {
        feeScheduleRepository.deleteAll();
        return "Successfully delete all Fee Schedule";
    }

    private Errors validateFeeScheduleUsingValidator(FeeScheduleDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "feeScheduleDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change not found with id: {}", dataChangeId);
            throw new DataNotFoundException("Data Change id not found with id: " + dataChangeId);
        }
    }

    private void handleDataNotFoundException(FeeScheduleDTO feeScheduleDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageList) {
        log.error("Fee Schedule not found with id: {}", feeScheduleDTO != null ? feeScheduleDTO.getId() : UNKNOWN, e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeScheduleDTO!= null ? String.valueOf(feeScheduleDTO.getId()) : UNKNOWN, validationErrors));
    }

    private void handleGeneralError(FeeScheduleDTO feeScheduleDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(feeScheduleDTO != null ? String.valueOf(feeScheduleDTO.getId()) : UNKNOWN, validationErrors));
    }
}
