package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingReportGeneratorDTO;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingReportGenerator;
import com.services.billingservice.repository.BillingReportGeneratorRepository;
import com.services.billingservice.service.BillingReportGeneratorService;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class BillingReportGeneratorServiceImpl implements BillingReportGeneratorService {

    private final BillingReportGeneratorRepository billingReportGeneratorRepository;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public BillingReportGeneratorDTO getById(String id) {
        BillingReportGenerator billingReportGenerator = billingReportGeneratorRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException("data not found"));
        return mapToDTO(billingReportGenerator);
    }

    @Override
    public List<BillingReportGeneratorDTO> getAll() {
        List<BillingReportGenerator> billingReportList = billingReportGeneratorRepository.findAll();

        return mapToDTOList(billingReportList);
    }

    @Override
    public List<BillingReportGenerator> saveAll(List<BillingReportGenerator> billingReportGeneratorList) {
        return billingReportGeneratorRepository.saveAll(billingReportGeneratorList);
    }

    @Override
    public List<BillingReportGeneratorDTO> getAllByPeriod(String period) {
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(period);
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        List<BillingReportGenerator> billingReportGeneratorList = billingReportGeneratorRepository.findAllByMonthAndYear(monthName, year);

        return mapToDTOList(billingReportGeneratorList);
    }

    @Override
    public String deleteAll() {
        try {
            billingReportGeneratorRepository.deleteAll();
            return "Successfully deleted all Billing Report Generator";
        } catch (Exception e) {
            log.error("Error when delete all Billing Report Generator : " + e.getMessage());
            throw new RuntimeException("Error when delete all Billing Report Generator");
        }
    }

    @Override
    public void checkingExistingBillingReportGenerator(String customerCode, String category, String type, String currency, String period) {
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(period);
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        List<BillingReportGenerator> billingReportGeneratorList = billingReportGeneratorRepository.findAllByCustomerCodeAndCategoryAndTypeAndCurrencyAndMonthAndYear(
                customerCode, category, type, currency, monthName, year
        );

        log.info("Existing Billing Report Generator: '{}'", billingReportGeneratorList.size());

        for (BillingReportGenerator billingReportGenerator : billingReportGeneratorList) {
            billingReportGeneratorRepository.delete(billingReportGenerator);
        }
    }

    private BillingReportGeneratorDTO mapToDTO(BillingReportGenerator billingReportGenerator){
        return BillingReportGeneratorDTO.builder()
                .id(billingReportGenerator.getId())
                .investmentManagementName(billingReportGenerator.getInvestmentManagementName())
                .customerCode(billingReportGenerator.getCustomerCode())
                .customerName(billingReportGenerator.getCustomerName())
                .category(billingReportGenerator.getCategory())
                .type((billingReportGenerator.getType()))
                .fileName(billingReportGenerator.getFileName())
                .filePath(billingReportGenerator.getFilePath())
                .period(billingReportGenerator.getPeriod())
                .status(billingReportGenerator.getStatus())
                .desc(billingReportGenerator.getDesc())
                .build();
    }

    private List<BillingReportGeneratorDTO> mapToDTOList(List<BillingReportGenerator> billingReportGeneratorList){
        return billingReportGeneratorList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
}
