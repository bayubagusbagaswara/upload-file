package com.services.billingservice.service.impl;

import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.exception.GeneratePDFBillingException;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.RetailGeneratePDFService;
import com.services.billingservice.utils.BillingRetailGeneratePDFService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class RetailGeneratePDFServiceImpl implements RetailGeneratePDFService {

    @Value("${base.path.billing.retail}")
    private String basePathBillingRetail;

    @Value("${base.path.billing.image}")
    private String folderPathImage;

    private final BillingRetailRepository billingRetailRepository;
    private final BillingRetailGeneratePDFService billingRetailGeneratePDFService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String generatePDF(RetailCalculateRequest request) {
        log.info("Start generate PDF Billing Retail type: {}", request.getType());
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(request.getMonthYear());
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        try {
            // TODO: Change Approval Status to Approved
            String approvalStatus = ApprovalStatus.Approved.getStatus();

            List<BillingRetail> billingRetailList = billingRetailRepository.findAllByBillingCategoryAndBillingTypeAndMonthAndYearAndApprovalStatus(
                    categoryUpperCase, typeUpperCase, monthName, year, approvalStatus
            );

            billingRetailGeneratePDFService.generateAndSavePdfStatements(billingRetailList);

            log.info("Finished generate PDF Billing Retail type '{}'", categoryUpperCase);
            return "Successfully created a PDF file for Billing Core type: " + typeUpperCase;
        } catch (Exception e) {
            log.error("Error when generate PDF Billing Retail type '" + typeUpperCase + "' : " + e.getMessage(), e);
            throw new GeneratePDFBillingException("Error when generate PDF Billing Retail type '" + typeUpperCase + "' : " + e.getMessage());
        }
    }

}
