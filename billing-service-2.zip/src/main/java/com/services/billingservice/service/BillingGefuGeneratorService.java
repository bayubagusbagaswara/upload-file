package com.services.billingservice.service;

import com.services.billingservice.dto.core.*;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.BillingGefuProcessHistory;
import com.services.billingservice.model.BillingRetail;

import java.util.List;

public interface BillingGefuGeneratorService {

    void checkExistGefuFileName(String fileName);

    void deleteExistGefuFile(String fileName);

    String createGefu(String category, String month, int year, String customerCode, String userId);

    boolean approveAndSendGefu(long gefuProcessHistory, String approverId);

    void rejectGefu(long gefuProcessHistory, String approverId);

    boolean readGefuResponse();

    String gefuCoreFileGenerator(BillingGefuProcessHistory gefuHistory, BillingCore billing);

    String gefuRetailFileGenerator(BillingGefuProcessHistory gefuHistory, BillingRetail billing);

    String gefuFundFileGenerator(BillingGefuProcessHistory gefuHistory, BillingFund billing);

    void gefuCoreGenerator(BillingGefuProcessHistory gefuHistory,String billTemplate);

    void gefuCoreGeneratorDirect(BillingGefuProcessHistory gefuHistory);

    void gefuCoreGeneratorCASA(BillingGefuProcessHistory gefuHistory);

    boolean sendGefu(BillingGefuProcessHistory gefuHistory);

    void gefuRetailGeneratorDirect(BillingGefuProcessHistory gefuHistory);

    void gefuRetailGeneratorCASA(BillingGefuProcessHistory gefuHistory);

    void gefuFundGeneratorCASA(BillingGefuProcessHistory gefuHistory);


}
