package com.services.billingservice.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.billingservice.dto.ErrorMessageDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.*;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.mapper.SellingAgentMapper;
import com.services.billingservice.model.BillingSellingAgentData;
import com.services.billingservice.repository.BillingSellingAgentDataRepository;
import com.services.billingservice.service.BillingDataChangeService;
import com.services.billingservice.service.BillingSellingAgentDataService;
import com.services.billingservice.utils.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
@Slf4j
public class BillingSellingAgentDataImpl implements BillingSellingAgentDataService {

    private static final String ID_NOT_FOUND = "Selling Agent not found with id: ";
    private static final String CODE_NOT_FOUND = "Selling Agent not found with code: ";
    private static final String UNKNOWN = "unknown";

    private final BillingSellingAgentDataRepository sellingAgentRepository;
    private final BillingDataChangeService dataChangeService;
    private final Validator validator;
    private final ObjectMapper objectMapper;
    private final SellingAgentMapper sellingAgentMapper;

    @Override
    public boolean isCodeAlreadyExists(String sellingAgentCode) {
        return sellingAgentRepository.existsByCode(sellingAgentCode);
    }

    @Override
    public SellingAgentResponse createSingleData(CreateSellingAgentRequest createRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Create single data selling agent with request: {}", createRequest);
        SellingAgentDTO sellingAgentDTO = sellingAgentMapper.mapFromCreateRequestToDto(createRequest);
        dataChangeDTO.setInputerId(createRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(createRequest.getInputerIPAddress());
        return processSellingAgentCreation(sellingAgentDTO, dataChangeDTO);
    }

    private SellingAgentResponse processSellingAgentCreation(SellingAgentDTO sellingAgentDTO, BillingDataChangeDTO dataChangeDTO) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        try {
            // cek
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateSellingAgentUsingValidator(sellingAgentDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = ErrorMessageDTO.builder()
                        .code(sellingAgentDTO.getCode())
                        .errorMessages(validationErrors)
                        .build();
                errorMessageList.add(errorMessageDTO);
                totalDataFailed++;
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgentDTO)));

                dataChangeService.createChangeActionADD(dataChangeDTO, BillingSellingAgentData.class);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            totalDataFailed++;
        }

        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public SellingAgentResponse createSingleApprove(SellingAgentApproveRequest approveRequest) {
        log.info("Approve when create selling agent with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        SellingAgentDTO sellingAgentDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> errorMessages = new ArrayList<>();

            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);

            // SellingAgentDTO dto = objectMapper.readValue(dataChangeDTO.getJsonDataAfter(), FeeScheduleDTO.class);

            Errors errors = validateSellingAgentUsingValidator(sellingAgentDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(objectError -> errorMessages.add(objectError.getDefaultMessage()));
            }

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());

            if (!errorMessages.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgentDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, errorMessages);
                totalDataFailed++;
            } else {
                BillingSellingAgentData sellingAgent = sellingAgentMapper.createEntity(sellingAgentDTO, dataChangeDTO);
                BillingSellingAgentData sellingAgentSaved = sellingAgentRepository.save(sellingAgent);

                dataChangeDTO.setDescription("Successfully approve data change and save data selling agent");
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgentSaved)));
                dataChangeDTO.setEntityId(sellingAgentSaved.getId().toString());
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public SellingAgentResponse updateSingleData(UpdateSellingAgentRequest updateRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update single data selling agent with request: {}", updateRequest);
        dataChangeDTO.setInputerId(updateRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        SellingAgentDTO sellingAgentDTO = sellingAgentMapper.mapFromUpdateRequestToDto(updateRequest);
        try {
            BillingSellingAgentData feeSchedule = sellingAgentRepository.findById(sellingAgentDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + sellingAgentDTO.getId()));

            AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
            AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

            processUpdateSellingAgent(feeSchedule, sellingAgentDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

            totalDataSuccess = successCounter.get();
            totalDataFailed = failedCounter.get();
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public SellingAgentResponse updateMultipleData(SellingAgentListRequest updateListRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Update multiple data fee schedule with request: {}", updateListRequest);
        dataChangeDTO.setInputerId(updateListRequest.getInputerId());
        dataChangeDTO.setInputerIPAddress(updateListRequest.getInputerIPAddress());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        for (SellingAgentDTO sellingAgentDTO : updateListRequest.getSellingAgentDTOList()) {
            try {
                BillingSellingAgentData sellingAgent = sellingAgentRepository.findById(sellingAgentDTO.getId())
                        .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + sellingAgentDTO.getId()));

                AtomicInteger successCounter = new AtomicInteger(totalDataSuccess);
                AtomicInteger failedCounter = new AtomicInteger(totalDataFailed);

                processUpdateSellingAgent(sellingAgent, sellingAgentDTO, dataChangeDTO, errorMessageList, successCounter, failedCounter);

                totalDataSuccess = successCounter.get();
                totalDataFailed = failedCounter.get();
            } catch (Exception e) {
                handleGeneralError(sellingAgentDTO, e, errorMessageList);
                totalDataFailed++;
            }
        }
        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    private void processUpdateSellingAgent(BillingSellingAgentData sellingAgent,
                                          SellingAgentDTO sellingAgentDTO,
                                          BillingDataChangeDTO dataChangeDTO,
                                          List<ErrorMessageDTO> errorMessageList,
                                          AtomicInteger successCounter,
                                          AtomicInteger failedCounter) {
        try {
            List<String> validationErrors = new ArrayList<>();
            Errors errors = validateSellingAgentUsingValidator(sellingAgentDTO);

            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            if (!validationErrors.isEmpty()) {
                ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(sellingAgentDTO.getCode(), validationErrors);
                errorMessageList.add(errorMessageDTO);
                failedCounter.getAndIncrement();
            } else {
                dataChangeDTO.setInputerId(dataChangeDTO.getInputerId());
                dataChangeDTO.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
                dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgent)));
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgentDTO)));
                dataChangeDTO.setEntityId(sellingAgent.getId().toString());

                dataChangeService.createChangeActionEDIT(dataChangeDTO, BillingSellingAgentData.class);
                successCounter.incrementAndGet(); // Increment totalDataSuccess
            }
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            failedCounter.incrementAndGet(); // Increment totalDataFailed
        }
    }

    @Override
    public SellingAgentResponse updateSingleApprove(SellingAgentApproveRequest approveRequest) {
        log.info("Approve when update selling agent with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());
        SellingAgentDTO sellingAgentDTO = approveRequest.getData();
        try {
            Long dataChangeId = Long.valueOf(approveRequest.getDataChangeId());
            List<String> validationErrors = new ArrayList<>();

            Errors errors = validateSellingAgentUsingValidator(sellingAgentDTO);
            if (errors.hasErrors()) {
                errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
            }

            BillingSellingAgentData sellingAgent = sellingAgentRepository.findById(sellingAgentDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + sellingAgentDTO.getId()));

            // Copy data from DTO to Entity
            sellingAgentMapper.mapObjects(sellingAgentDTO, sellingAgent);
            log.info("Fee Schedule after copy properties: {}", sellingAgent);

            // Retrieve and set billing data change
            BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(dataChangeId);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setEntityId(sellingAgent.getId().toString());

            if (!validationErrors.isEmpty()) {
                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgentDTO)));
                dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
                totalDataFailed++;
            } else {
                BillingSellingAgentData sellingAgentUpdated = sellingAgentMapper.updateEntity(sellingAgent, dataChangeDTO);
                BillingSellingAgentData sellingAgentSaved = sellingAgentRepository.save(sellingAgentUpdated);

                dataChangeDTO.setJsonDataAfter(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgentSaved)));
                dataChangeDTO.setDescription("Successfully approve data change and update data entity");
                dataChangeService.approvalStatusIsApproved(dataChangeDTO);
                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public SellingAgentResponse deleteSingleData(DeleteSellingAgentRequest deleteRequest, BillingDataChangeDTO dataChangeDTO) {
        log.info("Delete single selling agent with request: {}", deleteRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        SellingAgentDTO sellingAgentDTO = SellingAgentDTO.builder()
                .id(deleteRequest.getId())
                .build();
        try {
            BillingSellingAgentData sellingAgent = sellingAgentRepository.findById(sellingAgentDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + sellingAgentDTO.getId()));

            dataChangeDTO.setInputerId(deleteRequest.getInputerId());
            dataChangeDTO.setInputerIPAddress(deleteRequest.getInputerIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgent)));
            dataChangeDTO.setJsonDataAfter("");
            dataChangeDTO.setEntityId(sellingAgent.getId().toString());

            dataChangeService.createChangeActionDELETE(dataChangeDTO, BillingSellingAgentData.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public SellingAgentResponse deleteSingleApprove(SellingAgentApproveRequest approveRequest) {
        log.info("Approve when delete selling agent with request: {}", approveRequest);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageList = new ArrayList<>();

        validateDataChangeId(approveRequest.getDataChangeId());

        SellingAgentDTO sellingAgentDTO = approveRequest.getData();

        BillingDataChangeDTO dataChangeDTO = dataChangeService.getById(Long.valueOf(approveRequest.getDataChangeId()));
        try {
            BillingSellingAgentData sellingAgent = sellingAgentRepository.findById(sellingAgentDTO.getId())
                    .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + sellingAgentDTO.getId()));

            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            dataChangeDTO.setJsonDataBefore(JsonUtil.cleanedJsonData(objectMapper.writeValueAsString(sellingAgent)));
            dataChangeDTO.setDescription("Successfully approve data change and delete data entity");

            dataChangeService.approvalStatusIsApproved(dataChangeDTO);
            sellingAgentRepository.delete(sellingAgent);
            totalDataSuccess++;

        } catch (DataNotFoundException e) {
            handleDataNotFoundException(sellingAgentDTO, e, errorMessageList);
            dataChangeDTO.setApproverId(approveRequest.getApproverId());
            dataChangeDTO.setApproverIPAddress(approveRequest.getApproverIPAddress());
            List<String> validationErrors = new ArrayList<>();
            validationErrors.add(ID_NOT_FOUND + sellingAgentDTO.getId());

            dataChangeService.approvalStatusIsRejected(dataChangeDTO, validationErrors);
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(sellingAgentDTO, e, errorMessageList);
            totalDataFailed++;
        }
        return new SellingAgentResponse(totalDataSuccess, totalDataFailed, errorMessageList);
    }

    @Override
    public SellingAgentDTO getByCode(String code) {
        BillingSellingAgentData billingSellingAgentData = sellingAgentRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundException(CODE_NOT_FOUND + code));
        return sellingAgentMapper.mapToDto(billingSellingAgentData);
    }

    @Override
    public List<SellingAgentDTO> getAll() {
        List<BillingSellingAgentData> all = sellingAgentRepository.findAll();
        return sellingAgentMapper.mapToDTOList(all);
    }

    @Override
    public String deleteById(Long id) {
        BillingSellingAgentData sellingAgent = sellingAgentRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundException(ID_NOT_FOUND + id));
        sellingAgentRepository.delete(sellingAgent);
        return "Successfully delete by id: " + id;
    }

    @Override
    public String deleteAll() {
        sellingAgentRepository.deleteAll();
        return "Successfully delete all Selling Agent";
    }

    private Errors validateSellingAgentUsingValidator(SellingAgentDTO dto) {
        Errors errors = new BeanPropertyBindingResult(dto, "sellingAgentDTO");
        validator.validate(dto, errors);
        return errors;
    }

    private void validateDataChangeId(String dataChangeId) {
        if (!dataChangeService.existById(Long.valueOf(dataChangeId))) {
            log.info("Data Change not found with id: {}", dataChangeId);
            throw new DataNotFoundException("Data Change id not found with id: " + dataChangeId);
        }
    }

    private void handleDataNotFoundException(SellingAgentDTO sellingAgentDTO, DataNotFoundException e, List<ErrorMessageDTO> errorMessageList) {
        log.error("Fee Schedule not found with id: {}", sellingAgentDTO != null ? sellingAgentDTO.getId() : UNKNOWN, e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add(e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(sellingAgentDTO!= null ? String.valueOf(sellingAgentDTO.getId()) : UNKNOWN, validationErrors));
    }

    private void handleGeneralError(SellingAgentDTO sellingAgentDTO, Exception e, List<ErrorMessageDTO> errorMessageList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        List<String> validationErrors = new ArrayList<>();
        validationErrors.add("An unexpected error occurred: " + e.getMessage());
        errorMessageList.add(new ErrorMessageDTO(sellingAgentDTO != null ? String.valueOf(sellingAgentDTO.getId()) : UNKNOWN, validationErrors));
    }
}
