package com.services.billingservice.service;

import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.exchangerate.*;

import java.util.List;

public interface ExchangeRateService {

    ExchangeRateDTO getById(Long id);

    List<ExchangeRateDTO> getAll();

    ExchangeRateDTO getByCurrency(String currency);

    ExchangeRateResponse createSingleData(CreateExchangeRateRequest createExchangeRateRequest, BillingDataChangeDTO dataChangeDTO);

    ExchangeRateResponse createSingleApprove(ExchangeRateApproveRequest approveRequest);

    ExchangeRateResponse updateSingleData(UpdateExchangeRateRequest updateExchangeRateRequest, BillingDataChangeDTO dataChangeDTO);

    ExchangeRateResponse updateApprove(ExchangeRateApproveRequest approveRequest);

    String deleteAll();
}
