package com.services.billingservice.service.impl;

import com.opencsv.exceptions.CsvException;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.SkTransactionRepository;
import com.services.billingservice.service.SkTranService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.CsvDataMapper;
import com.services.billingservice.utils.CsvReaderUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.enums.SkTransactionType.TRANSACTION_BI_SSSS;
import static com.services.billingservice.enums.SkTransactionType.TRANSACTION_CBEST;

@Slf4j
@Service
@RequiredArgsConstructor
public class SkTranServiceImpl implements SkTranService {

    private static final String BASE_FILE_NAME = "Sktrans_";
    private final SkTransactionRepository skTransactionRepository;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String readFileAndInsertToDB(String filePath, String monthYear) {
        log.info("Start read and insert SK Transaction to the database : {}", monthYear);
        try {
            Map<String, String> stringMap = convertDateUtil.extractMonthYearInformation(monthYear);
            String monthName = stringMap.get("monthName");
            String monthValue = stringMap.get("monthValue");
            int year = Integer.parseInt(stringMap.get("year"));

            String fileName = BASE_FILE_NAME + year + monthValue + ".csv";
            String filePathNew = filePath + fileName;
            log.info("File Path New SKTRANS: {}", filePathNew);

            // Check if the file exists
            if (!Files.exists(Paths.get(filePath))) {
                log.error("File not found: {}", filePathNew);
                throw new DataNotFoundException("[SK Transaction] File not found: " + filePathNew);
            }

            skTransactionRepository.deleteByMonthAndYearNative(monthName, year);

            List<String[]> rows = CsvReaderUtil.readCsvFile(filePathNew);

            List<SkTransaction> skTransactionList = CsvDataMapper.mapCsvSkTransaction(rows);

            skTransactionRepository.saveAll(skTransactionList);

            return "[SK Transaction] CSV data processed and saved successfully";
        }  catch (IOException e) {
            log.error("Failed to read CSV file: {}", filePath, e);
            return "[SK Transaction] Failed to read CSV File: " + e.getMessage();
        } catch (CsvException e) {
            log.error("Failed to process CSV data from file: {}", filePath, e);
            return "[SK Transaction] Failed to process CSV data: " + e.getMessage();
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", filePath, e);
            return "[SK Transaction] Unexpected error: " + e.getMessage();
        }
    }

    @Override
    public List<SkTransaction> getAll() {
        return skTransactionRepository.findAll();
    }

    @Override
    public List<SkTransaction> getAllByPortfolioCode(String portfolioCode) {
        log.info("Start get all SK Transaction with portfolio code : {}", portfolioCode);
        return skTransactionRepository.findAllByPortfolioCode(portfolioCode);
    }

    @Override
    public List<SkTransaction> getAllByPortfolioCodeAndSystem(String portfolioCode, String system) {
        log.info("Start get all SK Transaction with portfolio code : {}, and system : {}", portfolioCode, system);
        return skTransactionRepository.findAllByPortfolioCodeAndSystem(portfolioCode, system);
    }

    @Override
    public List<SkTransaction> getAllByAidAndMonthAndYear(String aid, String month, Integer year) {
        log.info("Start get all SK Transaction by AID : {}, Month : {}, and Year : {}", aid, month, year);
        return skTransactionRepository.findAllByPortfolioCodeAndMonthAndYear(aid, month, year);
    }

    @Override
    public List<SkTransaction> getAllRetailByAidAndTypeAndCurrencyAndPeriod(String aid, String sellingAgent, String currency, LocalDate date) {
        log.info("Start get all SK Transaction by AID : {}, sellingAgent : {}, currency : {}, Date : {}", aid, sellingAgent, currency, date);
        return skTransactionRepository.getAllRetailByAidAndTypeAndCurrencyAndPeriod(aid, sellingAgent, currency, date);
    }

    @Override
    public String deleteAll() {
        try {
            skTransactionRepository.deleteAll();
            return "Successfully deleted all SkTran";
        } catch (Exception e) {
            log.error("Error when delete all SkTran : " + e.getMessage());
            throw new RuntimeException("Error when delete all SkTran");
        }
    }

    @Override
    public int[] filterTransactionsType(List<SkTransaction> transactionList) {
        int transactionCBESTTotal = 0;
        int transactionBIS4Total = 0;

        for (SkTransaction skTransaction : transactionList) {
            String settlementSystem = skTransaction.getSettlementSystem();
            if (settlementSystem != null) {
                if (TRANSACTION_CBEST.getValue().equalsIgnoreCase(settlementSystem)) {
                    transactionCBESTTotal++;
                } else if (TRANSACTION_BI_SSSS.getValue().equalsIgnoreCase(settlementSystem)) {
                    transactionBIS4Total++;
                }
            }
        }
        log.info("Total KSEI : {}", transactionCBESTTotal);
        log.info("Total BI-S4 : {}", transactionBIS4Total);

        return new int[] {transactionCBESTTotal, transactionBIS4Total};
    }

}
