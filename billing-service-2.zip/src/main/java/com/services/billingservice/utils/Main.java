package com.services.billingservice.utils;

import java.time.Month;

public class Main {

    public static void main(String[] args) {
        String monthName = "November";
        Month month = Month.valueOf(monthName.toUpperCase());
        int value = month.getValue();

        System.out.println(value);
    }

}
