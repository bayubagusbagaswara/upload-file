package com.services.billingservice.utils;

import com.services.billingservice.model.BillingScheduler;
import it.sauronsoftware.cron4j.SchedulingPattern;
import it.sauronsoftware.cron4j.Task;
import it.sauronsoftware.cron4j.TaskCollector;
import it.sauronsoftware.cron4j.TaskTable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MyTaskCollector implements TaskCollector {
	final static Logger logger = LogManager.getLogger(MyTaskCollector.class);

	TaskTable taskTable = null;
	Map<Integer, Task> taskList = new HashMap<>();

	public TaskTable getTasks() {
		taskTable = new TaskTable();
//
////		Session session = HibernateUtil.getSessionFactory().getCurrentSession();
//		try {
//			session.beginTransaction();
//
//			List<BillingScheduler> scheduler = CsaSchedulerDAO.get().listByCriterions(session,
//					Restrictions.eq(BillingScheduler.ENABLE, 1));
//
//			for (CsaScheduler csaScheduler : scheduler) {
//				Integer idx = csaScheduler.getId();
//				String cronPattern = csaScheduler.getCronPattern();
//				String className = csaScheduler.getClassName();
//				Integer enabled = csaScheduler.getEnable();
//
//				if (enabled == 1) {
//					Class clazz = Class.forName(className);
//					SchedulingPattern pattern = new SchedulingPattern(cronPattern);
//					taskList.put(idx - 1, (Task) clazz.newInstance());
//					taskTable.add(pattern, (Task) clazz.newInstance());
//				} else {
//					taskList.remove(idx - 1);
//				}
//			}
//
//			session.getTransaction().commit();
//
//		} catch (Exception e) {
//			session.getTransaction().rollback();
//			e.printStackTrace();
//		}
//
		return taskTable;
	}

	public TaskTable getTaskTable() {
		return taskTable;
	}

	public void setTaskTable(TaskTable taskTable) {
		this.taskTable = taskTable;
	}
}
