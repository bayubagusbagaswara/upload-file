package com.services.billingservice.utils;

import lombok.experimental.UtilityClass;

import java.time.Month;
import java.util.HashMap;
import java.util.Map;

@UtilityClass
public class MonthConverterUtil {

    private static final Map<String, Month> monthMap = new HashMap<>();

    static {
        monthMap.put("JAN", Month.JANUARY);
        monthMap.put("FEB", Month.FEBRUARY);
        monthMap.put("MAR", Month.MARCH);
        monthMap.put("APR", Month.APRIL);
        monthMap.put("MAY", Month.MAY);
        monthMap.put("JUN", Month.JUNE);
        monthMap.put("JUL", Month.JULY);
        monthMap.put("AUG", Month.AUGUST);
        monthMap.put("SEP", Month.SEPTEMBER);
        monthMap.put("OCT", Month.OCTOBER);
        monthMap.put("NOV", Month.NOVEMBER);
        monthMap.put("DEC", Month.DECEMBER);
    }

    public static Month getMonth(String monthString) {
        Month month = monthMap.get(monthString.toUpperCase());
        if (month == null) {
            throw new IllegalArgumentException("Invalid month string: " + monthString);
        }
        return month;
    }
}
