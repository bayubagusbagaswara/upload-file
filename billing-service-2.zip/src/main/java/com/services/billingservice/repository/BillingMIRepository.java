package com.services.billingservice.repository;

import com.services.billingservice.model.BillingMI;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BillingMIRepository extends JpaRepository<BillingMI, Long> {

    @Query(value = "SELECT * FROM billing_mi where code = :code", nativeQuery = true)
    Optional<BillingMI> findByCode(@Param("code") String code);

//    @Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN true ELSE false END "
//            + "FROM billing_mi "
//            + "WHERE code = :code", nativeQuery = true)
//    boolean existsByCode(@Param("code") String code);

    Boolean existsByCode(String code);
}
