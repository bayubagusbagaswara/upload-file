package com.services.billingservice.repository;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Repository
@Slf4j
public class CsaDataRepositoryImpl implements CsaDataRepository {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void executeQuerySpRekapAccountBalance() {
        String nativeQuery = "EXEC sp_rekap_account_balance";
        List<Object[]> resultList = entityManager.createNativeQuery(nativeQuery)
                .getResultList();

        for (int i = 0; i < resultList.size(); i++) {
            Object[] objects = resultList.get(i);
            log.info("Object - " + i + " is {}",  Arrays.stream(objects).collect(Collectors.toList()));
        }
    }

    @Override
    public void executeQuerySpRekapRekapDataTransaksi() {
        String nativeQuery = "EXEC sp_rekap_data_transaksi";
        List<Object[]> resultList = entityManager.createNativeQuery(nativeQuery)
                .getResultList();

        for (int i = 0; i < resultList.size(); i++) {
            Object[] objects = resultList.get(i);
            log.info("Object - " + i + " is {}",  Arrays.stream(objects).collect(Collectors.toList()));
        }
    }
}
