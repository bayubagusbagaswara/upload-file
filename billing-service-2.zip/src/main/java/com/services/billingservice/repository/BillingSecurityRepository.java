package com.services.billingservice.repository;

import com.services.billingservice.model.BillingSecurity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface BillingSecurityRepository extends JpaRepository<BillingSecurity, Long> {

    @Query(value = "SELECT * FROM billing_security where code = :code", nativeQuery = true)
    Optional<BillingSecurity> findByCode(@Param("code") String code);

    @Query(value = "SELECT * FROM billing_security", nativeQuery = true)
    List<BillingSecurity> findAll();

//    @Query(value = "SELECT * FROM billing_security where code = :code", nativeQuery = true)
//    List<BillingSecurity>findByCodeList(@Param("code") String code);

}
