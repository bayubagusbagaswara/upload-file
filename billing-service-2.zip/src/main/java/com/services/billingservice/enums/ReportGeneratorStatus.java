package com.services.billingservice.enums;

public enum ReportGeneratorStatus {

    SUCCESS("SUCCESS"),
    FAILED("FAILED");

    private final String status;

    ReportGeneratorStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
