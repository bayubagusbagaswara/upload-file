package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingDataChange;
import com.services.billingservice.service.BillingDataChangeService;
import lombok.RequiredArgsConstructor;
import org.hibernate.validator.constraints.EAN;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Array;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/api/dataChange")
@RequiredArgsConstructor
public class BillingDataChangeController {

    private final BillingDataChangeService billingDataChangeService;

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingDataChange>>> getAll() {
        List<BillingDataChange> billingDataChangeList = billingDataChangeService.getAll();
        ResponseDTO<List<BillingDataChange>> response = ResponseDTO.<List<BillingDataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(billingDataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all/menu")
    public ResponseEntity<ResponseDTO<List<String>>> getAllMenu() {
        List<String> menuList = billingDataChangeService.findAllMenu();
        ResponseDTO<List<String>> response = ResponseDTO.<List<String>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(menuList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/getByMenuAndStatus")
    public ResponseEntity<ResponseDTO<List<BillingDataChange>>> getByMenuAndStatus(@RequestParam("menu") String menu,
                                                                                   @RequestParam("status") String status) {
        ApprovalStatus approvalStatus = ApprovalStatus.valueOf(status);
        List<BillingDataChange> billingDataChangeList = billingDataChangeService.findByMenuAndApprovalStatus(menu, approvalStatus);
        ResponseDTO<List<BillingDataChange>> response = ResponseDTO.<List<BillingDataChange>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.toString())
                .payload(billingDataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/checkIdDataChanges")
    public ResponseEntity<ResponseDTO<String>> checkIdDataChanges(@RequestBody List<Long> ids) {
        Boolean isExits = billingDataChangeService.existByIdListAndStatus(ids, Long.valueOf(ids.size()), ApprovalStatus.Pending);

        if (!isExits)
            return ResponseEntity.status(HttpStatus.OK.value())
                    .body(ResponseDTO.<String>builder()
                            .code(HttpStatus.NOT_ACCEPTABLE.value())
                            .message(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase())
                            .payload("The ID data list does not match the data in the database.")
                            .build());

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }

//    @GetMapping
//    public ResponseEntity<ResponseDTO> getAll(){
//        return dataChangeService.getDataChangeAll();
//    }

//    @PutMapping("/approve/{id}")
//    public ResponseEntity<ResponseDTO> doApprove(@PathVariable Long id){
//        return dataChangeService.doApprove(id);
//    }

    @PutMapping("/reject/{id}")
    public ResponseEntity<ResponseDTO<String>> doReject(@PathVariable Long id){
        billingDataChangeService.reject(id);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }
}
