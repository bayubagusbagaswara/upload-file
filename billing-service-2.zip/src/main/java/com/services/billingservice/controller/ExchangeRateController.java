package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.exchangerate.*;
import com.services.billingservice.service.ExchangeRateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/exchange-rate")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class ExchangeRateController {

    private static final String MENU_EXCHANGE_RATE = "Exchange Rate";

    private final ExchangeRateService exchangeRateService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<ExchangeRateResponse>> create(@RequestBody CreateExchangeRateRequest createExchangeRateRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/exchange-rate/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_EXCHANGE_RATE)
                .build();

        ExchangeRateResponse exchangeRateResponse = exchangeRateService.createSingleData(createExchangeRateRequest, dataChangeDTO);

        ResponseDTO<ExchangeRateResponse> response = ResponseDTO.<ExchangeRateResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(exchangeRateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create-approve")
    public ResponseEntity<ResponseDTO<ExchangeRateResponse>> createApprove(@RequestBody ExchangeRateApproveRequest approveRequest) {
        ExchangeRateResponse singleApprove = exchangeRateService.createSingleApprove(approveRequest);
        ResponseDTO<ExchangeRateResponse> response = ResponseDTO.<ExchangeRateResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<ExchangeRateResponse>> updateSingleData(@RequestBody UpdateExchangeRateRequest updateRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/exchange-rate/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_EXCHANGE_RATE)
                .build();

        ExchangeRateResponse exchangeRateResponse = exchangeRateService.updateSingleData(updateRequest, dataChangeDTO);
        ResponseDTO<ExchangeRateResponse> response = ResponseDTO.<ExchangeRateResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(exchangeRateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<ExchangeRateResponse>> updateSingleApprove(@RequestBody ExchangeRateApproveRequest approveRequest) {
        ExchangeRateResponse exchangeRateResponse = exchangeRateService.updateApprove(approveRequest);
        ResponseDTO<ExchangeRateResponse> response = ResponseDTO.<ExchangeRateResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(exchangeRateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<ExchangeRateDTO>>> getAll() {
        List<ExchangeRateDTO> exchangeRateDTOS = exchangeRateService.getAll();

        ResponseDTO<List<ExchangeRateDTO>> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(exchangeRateDTOS);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @GetMapping(path = "/getById")
    public ResponseEntity<ResponseDTO<ExchangeRateDTO>> getById(@RequestParam(name = "id") String id) {
        ExchangeRateDTO exchangeRateDTO = exchangeRateService.getById(Long.valueOf(id));

        ResponseDTO<ExchangeRateDTO> response = new ResponseDTO<>();
        response.setCode(HttpStatus.OK.value());
        response.setMessage(HttpStatus.OK.toString());
        response.setPayload(exchangeRateDTO);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
