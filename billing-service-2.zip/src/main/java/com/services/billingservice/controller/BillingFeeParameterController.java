package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeparameter.*;
import com.services.billingservice.service.BillingFeeParameterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/fee-parameter")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingFeeParameterController {

    private final BillingFeeParameterService feeParameterService;
    private static final String MENU_FEE_PARAMETER = "Fee Parameter";

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<FeeParameterResponse>> createSingleData(@RequestBody CreateFeeParameterRequest createFeeParameterRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/fee-parameter/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_PARAMETER)
                .build();

        FeeParameterResponse feeParameterResponse = feeParameterService.createSingleData(createFeeParameterRequest, dataChangeDTO);
        ResponseDTO<FeeParameterResponse> response = ResponseDTO.<FeeParameterResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(feeParameterResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create-list")
    public ResponseEntity<ResponseDTO<FeeParameterResponse>> createList(@RequestBody FeeParameterListRequest createFeeParameterListRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/fee-parameter/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_PARAMETER)
                .build();

        FeeParameterResponse list = feeParameterService.createMultipleData(createFeeParameterListRequest, dataChangeDTO);
        ResponseDTO<FeeParameterResponse> response = ResponseDTO.<FeeParameterResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(list)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<FeeParameterResponse>> createSingleApprove(@RequestBody FeeParameterApproveRequest createFeeParameterListRequest) {
        FeeParameterResponse listApprove = feeParameterService.createSingleApprove(createFeeParameterListRequest);
        ResponseDTO<FeeParameterResponse> response = ResponseDTO.<FeeParameterResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update-list")
    public ResponseEntity<ResponseDTO<FeeParameterResponse>> updateMultipleData(@RequestBody FeeParameterListRequest updateFeeParameterListRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/fee-parameter/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_PARAMETER)
                .build();
        FeeParameterResponse list = feeParameterService.updateMultipleData(updateFeeParameterListRequest, dataChangeDTO);
        ResponseDTO<FeeParameterResponse> response = ResponseDTO.<FeeParameterResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(list)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<FeeParameterResponse>> updateSingleApprove(@RequestBody FeeParameterApproveRequest updateFeeParameterListRequest) {
        FeeParameterResponse listApprove = feeParameterService.updateSingleApprove(updateFeeParameterListRequest);
        ResponseDTO<FeeParameterResponse> response = ResponseDTO.<FeeParameterResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<FeeParameterDTO>>> getAll() {
        List<FeeParameterDTO> feeParameterDTOList = feeParameterService.getAll();
        ResponseDTO<List<FeeParameterDTO>> response = ResponseDTO.<List<FeeParameterDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(feeParameterDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> delete() {
        String status = feeParameterService.deleteAll();
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok(response);
    }

}
