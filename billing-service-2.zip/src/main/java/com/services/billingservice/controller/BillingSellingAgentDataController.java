package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.sellingagent.*;
import com.services.billingservice.service.BillingSellingAgentDataService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping(path = "/api/selling-agent")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingSellingAgentDataController {

    private static final String MENU_SELLING_AGENT = "Selling Agent";

    private final BillingSellingAgentDataService sellingAgentService;

    // Create Single Data
    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<SellingAgentResponse>> createSingleData(@RequestBody CreateSellingAgentRequest createSellingAgentRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/selling-agent/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_SELLING_AGENT)
                .build();
        SellingAgentResponse createResponse = sellingAgentService.createSingleData(createSellingAgentRequest, dataChangeDTO);
        ResponseDTO<SellingAgentResponse> response = ResponseDTO.<SellingAgentResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Create Multiple Approve
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<SellingAgentResponse>> createSingleApprove(@RequestBody SellingAgentApproveRequest approveRequest) {
        SellingAgentResponse listApprove = sellingAgentService.createSingleApprove(approveRequest);
        ResponseDTO<SellingAgentResponse> response = ResponseDTO.<SellingAgentResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    // Update Single Data by id
    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<SellingAgentResponse>> updateSingleData(@RequestBody UpdateSellingAgentRequest updateSellingAgentRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/selling-agent/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_SELLING_AGENT)
                .build();
        SellingAgentResponse updateResponse = sellingAgentService.updateSingleData(updateSellingAgentRequest, dataChangeDTO);
        ResponseDTO<SellingAgentResponse> response = ResponseDTO.<SellingAgentResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Update Multiple Data
    @PutMapping(path = "/update-list")
    public ResponseEntity<ResponseDTO<SellingAgentResponse>> updateMultipleData(@RequestBody SellingAgentListRequest listRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/selling-agent/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_SELLING_AGENT)
                .build();
        SellingAgentResponse updateListResponse = sellingAgentService.updateMultipleData(listRequest, dataChangeDTO);
        ResponseDTO<SellingAgentResponse> response = ResponseDTO.<SellingAgentResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateListResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Update Multiple Approve
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<SellingAgentResponse>> updateSingleApprove(@RequestBody SellingAgentApproveRequest approveRequest) {
        SellingAgentResponse listApprove = sellingAgentService.updateSingleApprove(approveRequest);
        ResponseDTO<SellingAgentResponse> response = ResponseDTO.<SellingAgentResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    // delete all hard
    @DeleteMapping(path = "/all")
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String deleteStatus = sellingAgentService.deleteAll();
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteStatus)
                .build();
        return ResponseEntity.ok(response);
    }

    // get all
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SellingAgentDTO>>> getAll() {
        List<SellingAgentDTO> sellingAgentDTOList = sellingAgentService.getAll();
        ResponseDTO<List<SellingAgentDTO>> response = ResponseDTO.<List<SellingAgentDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sellingAgentDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
