package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.request.CreateSfValCoreIIGRequest;
import com.services.billingservice.model.SfValCoreIIG;
import com.services.billingservice.service.SfValCoreIIGService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(path = "/api/sf-val/iig")
@RequiredArgsConstructor
public class SfValCoreIIGController {

    private final SfValCoreIIGService sfValCoreIIGService;

    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<String>> create(@RequestBody CreateSfValCoreIIGRequest request) {

        String status = sfValCoreIIGService.create(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<SfValCoreIIG>>> getAll() {

        List<SfValCoreIIG> sfValCoreIIGList = sfValCoreIIGService.getAll();

        ResponseDTO<List<SfValCoreIIG>> response = ResponseDTO.<List<SfValCoreIIG>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValCoreIIGList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping
    public ResponseEntity<ResponseDTO<List<SfValCoreIIG>>> getAllByCustomerCode(@RequestParam("customerCode") String customerCode) {

        List<SfValCoreIIG> sfValCoreIIGList = sfValCoreIIGService.getAllByCustomerCode(customerCode);

        ResponseDTO<List<SfValCoreIIG>> response = ResponseDTO.<List<SfValCoreIIG>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(sfValCoreIIGList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping(path = "/all")
    public ResponseEntity<ResponseDTO<String>> deleteAll() {

        String status = sfValCoreIIGService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

}
