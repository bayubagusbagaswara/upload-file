package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.dto.feeschedule.*;
import com.services.billingservice.service.BillingFeeScheduleService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/fee-schedule")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequiredArgsConstructor
public class BillingFeeScheduleController {

    private static final String MENU_FEE_SCHEDULE = "Fee Schedule";

    private final BillingFeeScheduleService feeScheduleService;

    // Create Single Data
    @PostMapping(path = "/create")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> createSingleData(@RequestBody CreateFeeScheduleRequest createFeeScheduleRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.POST.name())
                .endpoint("/api/fee-schedule/create/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_SCHEDULE)
                .build();
        FeeScheduleResponse createResponse = feeScheduleService.createSingleData(createFeeScheduleRequest, dataChangeDTO);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(createResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Create Multiple Approve
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> createSingleApprove(@RequestBody FeeScheduleApproveRequest approveRequest) {
        FeeScheduleResponse listApprove = feeScheduleService.createSingleApprove(approveRequest);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    // Update Single Data by Id
    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> updateSingleData(@RequestBody UpdateFeeScheduleRequest updateFeeScheduleRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/fee-schedule/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_SCHEDULE)
                .build();
        FeeScheduleResponse updateResponse = feeScheduleService.updateSingleData(updateFeeScheduleRequest, dataChangeDTO);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Update Multiple Data
    @PutMapping(path = "/update-list")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> updateMultipleData(@RequestBody FeeScheduleListRequest feeScheduleListRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.PUT.name())
                .endpoint("/api/fee-schedule/update/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_SCHEDULE)
                .build();
        FeeScheduleResponse updateResponse = feeScheduleService.updateMultipleData(feeScheduleListRequest, dataChangeDTO);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Update Multiple Approve
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> updateSingleApprove(@RequestBody FeeScheduleApproveRequest feeScheduleApproveRequest) {
        FeeScheduleResponse listApprove = feeScheduleService.updateSingleApprove(feeScheduleApproveRequest);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    // Delete Single Data
    @DeleteMapping(path = "/delete")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> deleteSingleData(@RequestBody DeleteFeeScheduleRequest deleteFeeScheduleRequest) {
        BillingDataChangeDTO dataChangeDTO = BillingDataChangeDTO.builder()
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint("/api/fee-schedule/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_FEE_SCHEDULE)
                .build();
        FeeScheduleResponse deleteResponse = feeScheduleService.deleteSingleData(deleteFeeScheduleRequest, dataChangeDTO);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // Delete Multiple Approve
    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDTO<FeeScheduleResponse>> deleteSingleApprove(@RequestBody FeeScheduleApproveRequest approveRequest) {
        FeeScheduleResponse listApprove = feeScheduleService.deleteSingleApprove(approveRequest);
        ResponseDTO<FeeScheduleResponse> response = ResponseDTO.<FeeScheduleResponse>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    // delete all hard delete
    @DeleteMapping(path = "/all")
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String deleteStatus = feeScheduleService.deleteAll();
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteStatus)
                .build();
        return ResponseEntity.ok(response);
    }

    // get all
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<FeeScheduleDTO>>> getAll() {
        List<FeeScheduleDTO> feeScheduleDTOList = feeScheduleService.getAll();
        ResponseDTO<List<FeeScheduleDTO>> response = ResponseDTO.<List<FeeScheduleDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(feeScheduleDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
