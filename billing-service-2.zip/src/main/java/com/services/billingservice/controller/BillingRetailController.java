package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.retail.BillingRetailListProcessDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.dto.retail.UpdateApprovalStatusBillingRetailRequest;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.services.billingservice.enums.BillingCategory.RETAIL;
import static com.services.billingservice.enums.BillingType.*;

@Slf4j
@RestController
@RequestMapping(path = "/api/billing/retail")
@RequiredArgsConstructor
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BillingRetailController {

    private final BillingRetailGeneralService billingRetailGeneralService;
    private final RetailGeneratePDFService retailGeneratePDFService;
    private final Retail1CalculateService retail1CalculateService;
    private final Retail2CalculateService retail2CalculateService;
    private final Retail3CalculateService retail3CalculateService;
    private final Retail4CalculateService retail4CalculateService;
    private static final String WORD_PATTERN = "[^\\w_]+";

    @PostMapping(path = "/calculate")
    public ResponseEntity<ResponseDTO<String>> calculate(@RequestBody RetailCalculateRequest request) {
        String category = request.getCategory().toUpperCase();
        String type = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
        String status;

        if (RETAIL.getValue().equalsIgnoreCase(category)) {
            if (TYPE_1.getValue().equalsIgnoreCase(type)) {
                status = retail1CalculateService.calculate(request);
            } else if (TYPE_2.getValue().equalsIgnoreCase(type)) {
                status = retail2CalculateService.calculate(request);
            } else if (TYPE_3.getValue().equalsIgnoreCase(type)) {
                status = retail3CalculateService.calculate(request);
            } else if (TYPE_4.getValue().equalsIgnoreCase(type)) {
                status = retail4CalculateService.calculate(request);
            } else {
                status = "It is Category Retail, but not type 1-4";
            }
        } else {
            status = "Not category Retail";
        }

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingRetail>>> getAll() {
        List<BillingRetail> billingRetailList = billingRetailGeneralService.getAll();

        ResponseDTO<List<BillingRetail>> response = ResponseDTO.<List<BillingRetail>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingRetailList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {
        String status = billingRetailGeneralService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping(path = "/category-type")
    public ResponseEntity<ResponseDTO<String>> deleteByCategoryAndType(@RequestBody RetailCalculateRequest request) {

        String status = billingRetailGeneralService.deleteByCategoryAndTypeAndMonthYear(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PostMapping(path = "/generate-pdf")
    public ResponseEntity<ResponseDTO<String>> generatePDF(@RequestBody RetailCalculateRequest request) {
        String status = retailGeneratePDFService.generatePDF(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list/process")
    public ResponseEntity<ResponseDTO<List<BillingRetailListProcessDTO>>> getAllListProcess() {
        List<BillingRetailListProcessDTO> billingRetailList = billingRetailGeneralService.getAllListProcess();

        ResponseDTO<List<BillingRetailListProcessDTO>> response = ResponseDTO.<List<BillingRetailListProcessDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingRetailList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list/pending-approve")
    public ResponseEntity<ResponseDTO<List<BillingRetailListProcessDTO>>> getAllListPendingApprove() {
        List<BillingRetailListProcessDTO> billingRetailList = billingRetailGeneralService.getAllListPendingApprove();

        ResponseDTO<List<BillingRetailListProcessDTO>> response = ResponseDTO.<List<BillingRetailListProcessDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingRetailList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period/type")
    public ResponseEntity<ResponseDTO<List<BillingRetail>>> getAllByPeriodType(@RequestParam("month") String month,
                                                                                @RequestParam("year") Integer year,
                                                                                @RequestParam("category") String category,
                                                                                @RequestParam("type") String type) {
        final String[] typeAndCcy = type.trim().split(WORD_PATTERN);
        final String typeRetail = typeAndCcy[0];
        final String currency = typeAndCcy[1];
        List<BillingRetail> billingRetails = billingRetailGeneralService.findByMonthAndYearAndBillingCategoryAndBillingTypeAndCurrency(month, year, category, typeRetail, currency);

        ResponseDTO<List<BillingRetail>> response = ResponseDTO.<List<BillingRetail>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingRetails)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PutMapping(path = "/approval-status")
    public ResponseEntity<ResponseDTO<String>> updateApprovalStatus(@RequestBody UpdateApprovalStatusBillingRetailRequest request) {
        String status = billingRetailGeneralService.updateApprovalStatus(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }
}
