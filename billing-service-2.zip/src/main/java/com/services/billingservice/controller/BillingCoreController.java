package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.core.*;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.services.billingservice.enums.BillingCategory.CORE;
import static com.services.billingservice.enums.BillingType.*;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(path = "/api/billing/core")
@RequiredArgsConstructor
public class BillingCoreController {

    private final BillingCoreGeneralService coreGeneralService;
    private final CoreGeneratePDFService coreGeneratePDFService;

    private final Core1CalculateService core1CalculateService;
    private final Core2CalculateService core2CalculateService;
    private final Core3CalculateService core3CalculateService;
    private final Core4CalculateService core4CalculateService;
    private final Core5And6CalculateService core5And6CalculateService;
    private final Core7CalculateService core7CalculateService;
    private final Core8CalculateService core8CalculateService;
    private final Core9CalculateService core9CalculateService;
    private final Core10CalculateService core10CalculateService;
    private final Core11CalculateService core11CalculateService;
    private final ConvertDateUtil convertDateUtil;

    @PostMapping(path = "/calculate")
    public ResponseEntity<ResponseDTO<String>> calculateCore1(@RequestBody CoreCalculateRequest request) {

        String category = request.getCategory().toUpperCase();
        String type = StringUtil.replaceBlanksWithUnderscores(request.getType()).toUpperCase();
        String status;

        if (CORE.getValue().equalsIgnoreCase(category)) {
            if (TYPE_1.getValue().equalsIgnoreCase(type)) {
                status = core1CalculateService.calculate(request);
            } else if (TYPE_2.getValue().equalsIgnoreCase(type)) {
                status = core2CalculateService.calculate(request);
            } else if (TYPE_3.getValue().equalsIgnoreCase(type)) {
                status = core3CalculateService.calculate(request);
            } else if (TYPE_4.getValue().equalsIgnoreCase(type)) {
                status = core4CalculateService.calculate(request);
            } else if (TYPE_5.getValue().equalsIgnoreCase(type) || TYPE_6.getValue().equalsIgnoreCase(type)) {
                status = core5And6CalculateService.calculate(request);
            } else if (TYPE_7.getValue().equalsIgnoreCase(type)) {
                status = core7CalculateService.calculate(request);
            } else if (TYPE_8.getValue().equalsIgnoreCase(type)) {
                status = core8CalculateService.calculate(request);
            } else if (TYPE_9.getValue().equalsIgnoreCase(type)) {
                status = core9CalculateService.calculate(request);
            } else if (TYPE_10.getValue().equalsIgnoreCase(type)) {
                status = core10CalculateService.calculate(request);
            } else if (TYPE_11.getValue().equalsIgnoreCase(type)) {
                status = core11CalculateService.calculate(request);
            } else {
                status = "It is Category Core, but not type 1-11";
            }
        } else {
            status = "Not category Core";
        }

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDTO<List<BillingCoreDTO>>> getBillingCore(@RequestParam("category") String category,
                                                                   @RequestParam("type") String type,
                                                                   @RequestParam("monthYear") String monthYear) {

        String categoryUpperCase = category.toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(type);
        String[] monthFormat = convertDateUtil.convertToYearMonthFormat(monthYear);
        String monthName = monthFormat[0];
        int year = Integer.parseInt(monthFormat[1]);

        List<BillingCoreDTO> billingCoreList = coreGeneralService.getAll(categoryUpperCase, typeUpperCase, monthName, year);

        ResponseDTO<List<BillingCoreDTO>> response = ResponseDTO.<List<BillingCoreDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingCoreList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PostMapping(path = "/generate-pdf")
    public ResponseEntity<ResponseDTO<String>> generatePDF(@RequestBody CoreCalculateRequest request) {
        String status = coreGeneratePDFService.generatePDF(request);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping
    public ResponseEntity<ResponseDTO<String>> deleteAll() {

        String status = coreGeneralService.deleteAll();

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping(path = "/category-type")
    public ResponseEntity<ResponseDTO<String>> deleteByCategoryAndType(@RequestBody CoreCalculateRequest request) {

        String status = coreGeneralService.deleteByCategoryAndTypeAndMonthYear(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PutMapping(path = "/update")
    public ResponseEntity<ResponseDTO<List<BillingCoreDTO>>> updateAll(@RequestBody List<UpdateBillingCoreRequest> requestList) {
        List<BillingCoreDTO> billingCoreDTOList = coreGeneralService.updateAll(requestList);

        ResponseDTO<List<BillingCoreDTO>> response = ResponseDTO.<List<BillingCoreDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingCoreDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PutMapping(path = "/approval-status")
    public ResponseEntity<ResponseDTO<String>> updateApprovalStatus(@RequestBody UpdateApprovalStatusBillingCoreRequest request) {
        String status = coreGeneralService.updateApprovalStatus(request);

        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list/process")
    public ResponseEntity<ResponseDTO<List<BillingCoreListProcessDTO>>> getAllListProcess() {
        List<BillingCoreListProcessDTO> billingCoreList = coreGeneralService.getAllListProcess();

        ResponseDTO<List<BillingCoreListProcessDTO>> response = ResponseDTO.<List<BillingCoreListProcessDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingCoreList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list/pending-approve")
    public ResponseEntity<ResponseDTO<List<BillingCoreListProcessDTO>>> getAllListPendingApprove() {
        List<BillingCoreListProcessDTO> billingCoreDTOList = coreGeneralService.getAllListPendingApprove();

        ResponseDTO<List<BillingCoreListProcessDTO>> response = ResponseDTO.<List<BillingCoreListProcessDTO>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingCoreDTOList)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDTO<List<BillingCore>>> getAllByPeriod(@RequestParam("month") String month,
                                                                         @RequestParam("year") Integer year) {
        List<BillingCore> billingCoreList = coreGeneralService.findByMonthAndYear(month, year);

        ResponseDTO<List<BillingCore>> response = ResponseDTO.<List<BillingCore>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(billingCoreList)
                .build();

        return ResponseEntity.ok().body(response);
    }
}
