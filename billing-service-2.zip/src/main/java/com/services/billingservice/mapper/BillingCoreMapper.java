package com.services.billingservice.mapper;

import com.services.billingservice.dto.core.BillingCoreDTO;
import com.services.billingservice.dto.datachange.BillingDataChangeDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.utils.ConvertDateUtil;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class BillingCoreMapper extends BaseMapper<BillingCore, BillingCoreDTO> {

    private final ConvertDateUtil convertDateUtil;

    public BillingCoreMapper(ModelMapper modelMapper, ConvertDateUtil convertDateUtil) {
        super(modelMapper);
        this.convertDateUtil = convertDateUtil;
    }

    @Override
    protected PropertyMap<BillingCore, BillingCoreDTO> getPropertyMap() {
        return new PropertyMap<BillingCore, BillingCoreDTO>() {
            @Override
            protected void configure() {
                skip(destination.getApprovalStatus());
                skip(destination.getInputerId());
                skip(destination.getInputerIPAddress());
                skip(destination.getInputDate());
                skip(destination.getApproverId());
                skip(destination.getApproverIPAddress());
                skip(destination.getApproveDate());
            }
        };
    }

    @Override
    public BillingCore mapToEntity(BillingCoreDTO dto) {
        return super.mapToEntity(dto);
    }

    @Override
    public BillingCoreDTO mapToDto(BillingCore entity) {
        return super.mapToDto(entity);
    }

    @Override
    public List<BillingCoreDTO> mapToDTOList(List<BillingCore> entityList) {
        return super.mapToDTOList(entityList);
    }

    @Override
    public BillingCoreDTO mapFromCreateRequestToDto(Object createRequest) {
        return super.mapFromCreateRequestToDto(createRequest);
    }

    @Override
    public BillingCoreDTO mapFromUpdateRequestToDto(Object updateRequest) {
        return super.mapFromUpdateRequestToDto(updateRequest);
    }

    @Override
    public BillingCore createEntity(BillingCoreDTO dto, BillingDataChangeDTO dataChangeDTO) {
        return super.createEntity(dto, dataChangeDTO);
    }

    @Override
    public BillingCore updateEntity(BillingCore updatedEntity, BillingDataChangeDTO dataChangeDTO) {
        return super.updateEntity(updatedEntity, dataChangeDTO);
    }

    @Override
    public void mapObjects(BillingCoreDTO sourceDto, BillingCore targetEntity) {
        super.mapObjects(sourceDto, targetEntity);
    }

    @Override
    protected Class<BillingCore> getEntityClass() {
        return BillingCore.class;
    }

    @Override
    protected Class<BillingCoreDTO> getDtoClass() {
        return BillingCoreDTO.class;
    }

    @Override
    protected void setCommonProperties(BillingCore entity, BillingDataChangeDTO dataChangeDTO) {
        entity.setApprovalStatus(ApprovalStatus.Approved);
        entity.setInputerId(dataChangeDTO.getInputerId());
        entity.setInputerIPAddress(dataChangeDTO.getInputerIPAddress());
        entity.setInputDate(dataChangeDTO.getInputDate());
        entity.setApproverId(dataChangeDTO.getApproverId());
        entity.setApproverIPAddress(dataChangeDTO.getApproverIPAddress());
        entity.setApproveDate(convertDateUtil.getDate());
    }
}
