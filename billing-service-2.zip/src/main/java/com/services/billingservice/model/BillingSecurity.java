package com.services.billingservice.model;


import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "billing_security")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingSecurity extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code")
    private String code;

    @Column(name = "bill_group")
    private String group;

    @Column(name = "currency")
    private String currency;

    @Column(name =  "issuer_name")
    private String issuerName;

    @Column(name = "name")
    private String name;
}
