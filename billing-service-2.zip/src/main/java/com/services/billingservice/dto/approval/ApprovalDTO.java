package com.services.billingservice.dto.approval;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
public abstract class ApprovalDTO {

    private String approvalStatus;
    private String inputerId;
    private String inputerIPAddress;
    private String inputDate;
    private String approverId;
    private String approverIPAddress;
    private String approveDate;
}
