package com.services.billingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingDTO {

    private LocalDate period;

    private String month;

    private String year;

    private BigDecimal accrualCustodialFee;

    private Integer valueFrequencyS4;

    private BigDecimal amountS4;

    private BigDecimal totalNominalBeforeTax;

    private Double taxFee;

    private BigDecimal amountTax;

    private Integer valueFrequencyKSEI;

    private BigDecimal amountKSEI;

    private BigDecimal totalNominalAfterTax;
}
