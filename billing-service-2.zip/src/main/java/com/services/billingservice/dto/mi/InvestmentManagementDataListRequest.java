package com.services.billingservice.dto.mi;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.billingservice.dto.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InvestmentManagementDataListRequest extends ApprovalDTO {

    private Long id;

    @NotBlank(message = "Code cannot be empty")
    @JsonProperty(value = "MI Code")
    private String code;

    @NotBlank(message = "Name cannot be empty")
    @JsonProperty(value = "MI Name")
    private String name;

    @NotBlank(message = "Email cannot be empty")
    @Email(message = "Email is not valid")
    @JsonProperty(value = "MI Email")
    private String email;

    @NotBlank(message = "Unique Key cannot be empty")
    private String uniqueKey;

    @NotBlank(message = "Address 1 cannot be empty")
    private String address1;

    private String address2;

    private String address3;

    private String address4;
}
