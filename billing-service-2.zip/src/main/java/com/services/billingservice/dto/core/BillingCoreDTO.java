package com.services.billingservice.dto.core;

import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingCoreDTO extends BillingCoreBaseDTO {

    private String transactionHandlingValueFrequency;
    private String transactionHandlingFee;
    private String transactionHandlingAmountDue;

    private String safekeepingValueFrequency;
    private String safekeepingFee;
    private String safekeepingAmountDue;

    private String subTotal;

    private String vatFee;
    private String vatAmountDue;

    private String totalAmountDue;

    // especially core type 3
    private String journalCreditTo;

    // especially for KSEI Safe Fee
    private String kseiSafekeepingAmountDue;

    private String kseiTransactionValueFrequency;
    private String kseiTransactionFee;
    private String kseiTransactionAmountDue;

    private String bis4TransactionValueFrequency;
    private String bis4TransactionFee;
    private String bis4TransactionAmountDue;

    // journal
    private String safekeepingFeeJournal;
    private String transactionHandlingJournal;

    // especially core type 8
    private String administrationSetUpItem;
    private String administrationSetUpFee;
    private String administrationSetUpAmountDue;

    private String signingRepresentationItem;
    private String signingRepresentationFee;
    private String signingRepresentationAmountDue;

    private String securityAgentItem;
    private String securityAgentFee;
    private String securityAgentAmountDue;

    private String transactionHandlingItem;

    private String safekeepingItem;

    private String otherItem;
    private String otherFee;
    private String otherAmountDue;

    private String accNumberCBEST;
}
