package com.services.billingservice.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.services.billingservice.dto.approval.ApprovalDTO;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerDataListRequest extends ApprovalDTO {

    private String customerCode;
    private String subCode;
    private String customerName;
    private String billingCategory;
    private String billingType;
    private String billingTemplate;
    private String currency;
    private String miCode;
    private String miName;
    private String account;
    private String accountName;
    private String costCenter;
    private String debitTransfer;
    private String glAccountHasil;
    private String customerMinimumFee;
    private String customerSafekeepingFee;
    private String customerTransactionHandling;
    private String npwpNumber;
    private String npwpName;
    private String npwpAddress;
    private String kseiSafeCode;
    private String sellingAgent;
    private boolean gl;

}
