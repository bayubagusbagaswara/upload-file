package com.services.billingservice.dto.customer;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.services.billingservice.dto.approval.ApprovalDTO;
import lombok.*;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerDTO extends ApprovalDTO {

    private Long id;

    // need a pattern (numeric & alphabet, not special character)
    @NotBlank(message = "Customer Code cannot be empty")
    private String customerCode;

    private String subCode;

    // need a pattern (numeric & alphabet, not special character)
    @NotEmpty(message = "Customer Name cannot be empty")
    private String customerName;

    @NotEmpty(message = "Billing Category cannot be empty")
    private String billingCategory;

    @NotEmpty(message = "Billing Type cannot be empty")
    private String billingType;

    @NotEmpty(message = "Billing Template cannot be empty")
    private String billingTemplate;

    @NotEmpty(message = "Currency cannot be empty")
    private String currency;

    @NotEmpty(message = "MI Code cannot be empty")
    private String miCode;

    private String miName;

    private String account;

    private String accountName;

    private String costCenter;

    private String debitTransfer;

    private String glAccountHasil;

    @NotBlank(message = "Customer Minimum Fee cannot be empty")
    private String customerMinimumFee;

    @NotBlank(message = "Customer Safekeeping Fee cannot be empty")
    private String customerSafekeepingFee;

    // need a pattern must be numeric because big decimal
    private String customerTransactionHandling;

    // need a pattern, must be numeric for string
    private String npwpNumber;

    // need a pattern (numeric & alphabet, not special character)
    private String npwpName;

    private String npwpAddress;

    // need a pattern (numeric & alphabet, not special character)
    private String kseiSafeCode;

    // need a pattern (numeric & alphabet, not special character)
    private String sellingAgent;

    private boolean gl;

}
