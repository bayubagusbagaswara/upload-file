package com.services.billingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ZipRequest {

    @NotBlank(message = "Category cannot be empty")
    private String category;

    @NotBlank(message = "Month Year cannot be empty")
    private String monthYear;

    private String investmentManagementName;
}
