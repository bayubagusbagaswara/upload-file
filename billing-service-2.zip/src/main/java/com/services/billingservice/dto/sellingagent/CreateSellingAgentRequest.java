package com.services.billingservice.dto.sellingagent;

import com.fasterxml.jackson.databind.ser.impl.MapEntrySerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateSellingAgentRequest {

    private String inputerId;
    private String inputerIPAddress;

    @NotBlank(message = "Code cannot be empty")
    private String code;

    @NotBlank(message = "Name cannot be empty")
    private String name;
}
