package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesisincode.*;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.mapper.SecuritiesISINCodeMapper;
import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.model.regulatory.SecuritiesISINCode;
import com.services.hiportservices.repository.regulatory.DataNotFoundRepository;
import com.services.hiportservices.repository.regulatory.SecuritiesISINCodeRepository;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.service.regulatory.SecuritiesISINCodeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.ISIN_CODE_TABLE;
import static com.services.hiportservices.enums.ApprovalStatus.Approved;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecuritiesISINCodeServiceImpl implements SecuritiesISINCodeService {

    private static final String CREATE_APPROVE_URL = "/api/regulatory/isin-code/create/approve";
    private static final String UPDATE_APPROVE_URL = "/api/regulatory/isin-code/update/approve";
    private static final String ID_NOT_FOUND = "Securities ISIN Code not found with id: ";
    private static final String UNKNOWN_EXTERNAL_CODE = "Unknown External Code";

    private final SecuritiesISINCodeRepository securitiesISINCodeRepository;
    private final ObjectMapper objectMapper;
    private final ValidationData validationData;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final SecuritiesISINCodeMapper securitiesISINCodeMapper;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public boolean isExternalCodeAlreadyExists(String externalCode) {
        log.info("Check the existing ISIN Code with the external code: {}", externalCode);
        return securitiesISINCodeRepository.existsByExternalCode2(externalCode);
    }

    @Transactional
    @Override
    public synchronized SecuritiesISINCodeResponse uploadData(UploadSecuritiesISINCodeListRequest uploadSecuritiesISINCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start upload data ISIN Code: {}, {}", uploadSecuritiesISINCodeListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadSecuritiesISINCodeDataRequest isinCodeDataRequest : uploadSecuritiesISINCodeListRequest.getUploadSecuritiesISINCodeDataRequestList()) {
            List<String> validationErrors = new ArrayList<>();
            SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

            try {
                Errors errors = validationData.validateObject(isinCodeDataRequest);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                securitiesISINCodeDTO = securitiesISINCodeMapper.fromUploadRequestToDTO(isinCodeDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                            !securitiesISINCodeDTO.getExternalCode().isEmpty() ? securitiesISINCodeDTO.getExternalCode() : UNKNOWN_EXTERNAL_CODE,
                            validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    Optional<SecuritiesISINCode> securitiesISINCode = securitiesISINCodeRepository.findByExternalCode(isinCodeDataRequest.getExternalCode2());

                    if (securitiesISINCode.isPresent()) {
                        // TODO: validation update
                        handleExistingISINCode(securitiesISINCode.get(), securitiesISINCodeDTO, regulatoryDataChangeDTO);
                    } else {
                        // TODO: validation create
                        handleNewISINCode(securitiesISINCodeDTO, regulatoryDataChangeDTO);
                    }
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }

        return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesISINCodeResponse createApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress) {
        log.info("Start create approve ISIN Code: {}, {}", approveSecuritiesISINCodeRequest, approveIPAddress);
        String approveId = approveSecuritiesISINCodeRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveSecuritiesISINCodeRequest.getDataChangeId());

            securitiesISINCodeDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), SecuritiesISINCodeDTO.class);

            /* validate whether the code already exists */
            validationExternalCodeAlreadyExists(securitiesISINCodeDTO.getExternalCode(), validationErrors);

            if (!validationErrors.isEmpty()) {
                regulatoryDataChangeService.setApprovalStatusIsRejected(dataChange, validationErrors);
                totalDataFailed++;
            } else {
                LocalDateTime approveDate = LocalDateTime.now();

                SecuritiesISINCode securitiesISINCode = SecuritiesISINCode.builder()
                        .approvalStatus(Approved)
                        .approverId(approveId)
                        .approveDate(approveDate)
                        .approveIPAddress(approveIPAddress)
                        .inputerId(dataChange.getInputerId())
                        .inputDate(dataChange.getInputDate())
                        .inputIPAddress(dataChange.getInputIPAddress())
                        .externalCode2(securitiesISINCodeDTO.getExternalCode().trim())
                        .currency(securitiesISINCodeDTO.getCurrency().trim())
                        .country(securitiesISINCodeDTO.getCountry().trim())
                        .isinLKPBU(securitiesISINCodeDTO.getIsinLKPBU().trim())
                        .isinLBABK(securitiesISINCodeDTO.getIsinLBABK().trim())
                        .build();

                SecuritiesISINCode save = securitiesISINCodeRepository.save(securitiesISINCode);

                dataChange.setApproverId(approveId);
                dataChange.setApproveDate(approveDate);
                dataChange.setApproveIPAddress(approveIPAddress);
                dataChange.setEntityId(save.getId().toString());
                dataChange.setJsonDataAfter(
                        JsonUtil.cleanedEntityDataFromApprovalData(
                                objectMapper.writeValueAsString(save)
                        )
                );
                dataChange.setDescription("Success create approve with id: " + save.getId());
                regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

                /* Get all data not found by FLAG_TABLE and code. The code can be filled with data 1 or data 2 (data source) */
                List<DataNotFound> dataNotFoundList = dataNotFoundRepository.findAllByFlagTableAndCode(
                        ISIN_CODE_TABLE, save.getExternalCode2()
                );

                if (!dataNotFoundList.isEmpty()) {
                    dataNotFoundList.forEach(dataNotFound -> dataNotFound.setStatus(Boolean.TRUE));
                    dataNotFoundRepository.saveAll(dataNotFoundList);
                }

                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesISINCodeResponse updateApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress) {
        log.info("Start update approve Securities ISIN Code: {}, {}", approveSecuritiesISINCodeRequest, approveIPAddress);
        String approveId = approveSecuritiesISINCodeRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveSecuritiesISINCodeRequest.getDataChangeId());

            securitiesISINCodeDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), SecuritiesISINCodeDTO.class);
            log.info("Update Approve: {}", securitiesISINCodeDTO);

            SecuritiesISINCode securitiesISINCode = securitiesISINCodeRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            if (!securitiesISINCodeDTO.getCurrency().isEmpty()) {
                securitiesISINCode.setCurrency(securitiesISINCodeDTO.getCurrency());
            }

            if (!securitiesISINCodeDTO.getIsinLKPBU().isEmpty()) {
                securitiesISINCode.setIsinLKPBU(securitiesISINCodeDTO.getIsinLKPBU());
            }

            if (!securitiesISINCodeDTO.getIsinLBABK().isEmpty()) {
                securitiesISINCode.setIsinLBABK(securitiesISINCodeDTO.getIsinLBABK());
            }

            LocalDateTime approveDate = LocalDateTime.now();

            securitiesISINCode.setApprovalStatus(Approved);
            securitiesISINCode.setApproverId(approveId);
            securitiesISINCode.setApproveIPAddress(approveIPAddress);
            securitiesISINCode.setApproveDate(approveDate);
            securitiesISINCode.setInputerId(dataChange.getInputerId());
            securitiesISINCode.setInputIPAddress(dataChange.getInputIPAddress());
            securitiesISINCode.setInputDate(dataChange.getInputDate());

            SecuritiesISINCode save = securitiesISINCodeRepository.save(securitiesISINCode);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setJsonDataAfter(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(save)
                    )
            );
            dataChange.setDescription("Success update approve with id: " + save.getId());
            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;

        }
        return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesISINCodeResponse deleteById(DeleteSecuritiesISINCodeRequest deleteSecuritiesISINCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start delete Securities ISIN Code by id: {}, {}", deleteSecuritiesISINCodeRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

        try {
            SecuritiesISINCode securitiesISINCode = securitiesISINCodeRepository.findById(deleteSecuritiesISINCodeRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + deleteSecuritiesISINCodeRequest.getId()));

            securitiesISINCodeDTO = securitiesISINCodeMapper.toDTO(securitiesISINCode);

            regulatoryDataChangeDTO.setEntityId(securitiesISINCode.getId().toString());
            regulatoryDataChangeDTO.setJsonDataBefore(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(securitiesISINCode)
                    )
            );
            regulatoryDataChangeDTO.setJsonDataAfter("");
            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
            regulatoryDataChangeService.createChangeActionDelete(regulatoryDataChange, SecuritiesISINCode.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesISINCodeResponse deleteApprove(ApproveSecuritiesISINCodeRequest approveSecuritiesISINCodeRequest, String approveIPAddress) {
        log.info("Delete approve Securities ISIN Code: {}, {}", approveSecuritiesISINCodeRequest, approveIPAddress);
        String approveId = approveSecuritiesISINCodeRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveSecuritiesISINCodeRequest.getDataChangeId());

            SecuritiesISINCode securitiesISINCode = securitiesISINCodeRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            securitiesISINCodeDTO = securitiesISINCodeMapper.toDTO(securitiesISINCode);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(LocalDateTime.now());
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setDescription("Success delete approve with id: " + securitiesISINCode.getId());

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            /* delete entity */
            securitiesISINCodeRepository.delete(securitiesISINCode);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SecuritiesISINCodeDTO getById(Long id) {
        log.info("Start get ISIN Code by id: {}", id);
        SecuritiesISINCode securitiesISINCode = securitiesISINCodeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));
        return securitiesISINCodeMapper.toDTO(securitiesISINCode);
    }

    @Override
    public SecuritiesISINCodeDTO getByExternalCode(String externalCode) {
        log.info("Start get ISIN Code by external code: {}", externalCode);
        SecuritiesISINCode securitiesISINCode = securitiesISINCodeRepository.findByExternalCode(externalCode)
                .orElseThrow(() -> new DataNotFoundHandleException("ISIN Code not found with external code: " + externalCode));
        return securitiesISINCodeMapper.toDTO(securitiesISINCode);
    }

    @Override
    public List<SecuritiesISINCodeDTO> getAll() {
        log.info("Start get all ISIN Code");
        List<SecuritiesISINCode> all = securitiesISINCodeRepository.findAll();
        return securitiesISINCodeMapper.toDTOList(all);
    }

    private void handleGeneralError(SecuritiesISINCodeDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        dto != null && !dto.getExternalCode().isEmpty() ? dto.getExternalCode() : UNKNOWN_EXTERNAL_CODE,
                        validationErrors)
        );
    }

    private void validationExternalCodeAlreadyExists(String externalCode, List<String> validationErrors) {
        if (isExternalCodeAlreadyExists(externalCode)) {
            validationErrors.add("Kode ISIN Efek is already taken with external code: " + externalCode);
        }
    }

    private void handleNewISINCode(SecuritiesISINCodeDTO securitiesISINCodeDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(POST.name());
        regulatoryDataChangeDTO.setEndpoint(CREATE_APPROVE_URL);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(securitiesISINCodeDTO)
                )
        );
        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory Data Change add: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionAdd(regulatoryDataChange, SecuritiesISINCode.class);
    }

    private void handleExistingISINCode(SecuritiesISINCode securitiesISINCodeEntity, SecuritiesISINCodeDTO securitiesISINCodeDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(PUT.name());
        regulatoryDataChangeDTO.setEndpoint(UPDATE_APPROVE_URL);

        regulatoryDataChangeDTO.setEntityId(securitiesISINCodeEntity.getId().toString());
        regulatoryDataChangeDTO.setJsonDataBefore(
                JsonUtil.cleanedEntityDataFromApprovalData(
                        objectMapper.writeValueAsString(securitiesISINCodeEntity)
        ));

        SecuritiesISINCodeDTO temp = SecuritiesISINCodeDTO.builder()
                .externalCode(securitiesISINCodeEntity.getExternalCode2())
                .currency(
                        !securitiesISINCodeDTO.getCurrency().isEmpty()
                                ? securitiesISINCodeDTO.getCurrency()
                                : securitiesISINCodeEntity.getCurrency()
                )
                .isinLKPBU(
                        !securitiesISINCodeDTO.getIsinLKPBU().isEmpty()
                                ? securitiesISINCodeDTO.getIsinLKPBU()
                                : securitiesISINCodeEntity.getIsinLKPBU()
                )
                .isinLBABK(
                        !securitiesISINCodeDTO.getIsinLBABK().isEmpty()
                                ? securitiesISINCodeDTO.getIsinLBABK() : securitiesISINCodeEntity.getIsinLBABK())
                .build();

        log.info("Temp: {}", temp);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(temp)
                )
        );

        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory data change edit: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, SecuritiesISINCode.class);
    }

}
