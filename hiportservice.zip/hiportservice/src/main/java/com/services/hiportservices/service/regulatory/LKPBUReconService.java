package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.recon.ApproveReconRequest;
import com.services.hiportservices.dto.regulatory.recon.ReconResponse;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.model.regulatory.LKPBUDataSource;
import com.services.hiportservices.model.regulatory.LKPBURecon;

import java.util.List;

public interface LKPBUReconService {

    List<LKPBURecon> getAll();

    List<LKPBURecon> getAllByMonthAndYear(String month, Integer year);

    ReconResponse update(UpdateReconRequest updateReconRequest, RegulatoryDataChangeDTO dataChangeDTO);

    ReconResponse updateApprove(ApproveReconRequest approveReconRequest, String approveIPAddress);

    List<LKPBUDataSource> getAllDistinctPortfolioCode(String month, Integer year);

    List<LKPBUDataSource> getAllDistinctSecurityCode(String month, Integer year);

    String reconPortfolioCode(String month, Integer year);

    String reconSecurityCode(String month, Integer year);
}
