package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.model.regulatory.DataNotFound;

import java.util.List;

public interface DataNotFoundService {

    List<DataNotFound> getAllByPeriod(String month, Integer year);

}
