package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.issuercodeplacementbank.*;
import com.services.hiportservices.service.regulatory.IssuerCodePlacementBankService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/issuer-placement-bank")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class IssuerCodePlacementBankController {

    private static final String MENU_ISSUER_CODE_PLACEMENT_BANK = "Kode Issuer dan Placement Bank";
    private static final String BASE_URL_ISSUER_CODE_PLACEMENT_BANK = "/api/regulatory/issuer-placement-bank";

    private final IssuerCodePlacementBankService issuerCodePlacementBankService;

    // upload file
    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankResponse>> uploadData(@RequestBody UploadIssuerCodePlacementBankListRequest uploadIssuerCodePlacementBankListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputerId(uploadIssuerCodePlacementBankListRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ISSUER_CODE_PLACEMENT_BANK)
                .build();
        IssuerCodePlacementBankResponse issuerCodePlacementBankResponse = issuerCodePlacementBankService.uploadData(uploadIssuerCodePlacementBankListRequest, regulatoryDataChangeDTO);
        ResponseDto<IssuerCodePlacementBankResponse> response = ResponseDto.<IssuerCodePlacementBankResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(issuerCodePlacementBankResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // create approve
    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankResponse>> createApprove(@RequestBody ApproveIssuerCodePlacementBankRequest approveRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        IssuerCodePlacementBankResponse issuerCodePlacementBankResponse = issuerCodePlacementBankService.createApprove(approveRequest, approveIPAddress);
        ResponseDto<IssuerCodePlacementBankResponse> response = ResponseDto.<IssuerCodePlacementBankResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(issuerCodePlacementBankResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // update approve
    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankResponse>> updateApprove(@RequestBody ApproveIssuerCodePlacementBankRequest approveRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        IssuerCodePlacementBankResponse updateSingleApprove = issuerCodePlacementBankService.updateApprove(approveRequest, approveIPAddress);
        ResponseDto<IssuerCodePlacementBankResponse> response = ResponseDto.<IssuerCodePlacementBankResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(updateSingleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    // delete by id
    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankResponse>> deleteById(@RequestBody DeleteIssuerCodePlacementBankRequest deleteIssuerCodePlacementBankRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputerId(deleteIssuerCodePlacementBankRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_ISSUER_CODE_PLACEMENT_BANK + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_ISSUER_CODE_PLACEMENT_BANK)
                .build();
        IssuerCodePlacementBankResponse deleteSingleData = issuerCodePlacementBankService.deleteById(deleteIssuerCodePlacementBankRequest, regulatoryDataChangeDTO);
        ResponseDto<IssuerCodePlacementBankResponse> response = ResponseDto.<IssuerCodePlacementBankResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteSingleData)
                .build();
        return ResponseEntity.ok(response);
    }

    // delete approve
    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankResponse>> deleteApprove(@RequestBody ApproveIssuerCodePlacementBankRequest approveRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        IssuerCodePlacementBankResponse issuerCodePlacementBankResponse = issuerCodePlacementBankService.deleteApprove(approveRequest, approveIPAddress);
        ResponseDto<IssuerCodePlacementBankResponse> response = ResponseDto.<IssuerCodePlacementBankResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(issuerCodePlacementBankResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    // get by id
    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankDTO>> getById(@PathVariable("id") Long id) {
        IssuerCodePlacementBankDTO issuerCodePlacementBank = issuerCodePlacementBankService.getById(id);
        ResponseDto<IssuerCodePlacementBankDTO> response = ResponseDto.<IssuerCodePlacementBankDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(issuerCodePlacementBank)
                .build();
        return ResponseEntity.ok(response);
    }

    // get by code
    @GetMapping(path = "/code")
    public ResponseEntity<ResponseDto<IssuerCodePlacementBankDTO>> getByCode(@RequestParam("code") String code) {
        IssuerCodePlacementBankDTO issuerCodePlacementBank = issuerCodePlacementBankService.getByCode(code);
        ResponseDto<IssuerCodePlacementBankDTO> response = ResponseDto.<IssuerCodePlacementBankDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(issuerCodePlacementBank)
                .build();
        return ResponseEntity.ok(response);
    }

    // get all
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<IssuerCodePlacementBankDTO>>> getAll() {
        List<IssuerCodePlacementBankDTO> all = issuerCodePlacementBankService.getAll();
        ResponseDto<List<IssuerCodePlacementBankDTO>> response = ResponseDto.<List<IssuerCodePlacementBankDTO>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(all)
                .build();
        return ResponseEntity.ok(response);
    }

}
