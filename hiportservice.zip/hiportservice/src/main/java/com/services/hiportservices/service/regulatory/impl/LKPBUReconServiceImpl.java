package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant;
import com.services.hiportservices.dto.regulatory.recon.LKPBUReconDTO;
import com.services.hiportservices.dto.regulatory.recon.ApproveReconRequest;
import com.services.hiportservices.dto.regulatory.recon.ReconResponse;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.exception.regulatory.UnknownValidationTypeException;
import com.services.hiportservices.mapper.LKPBUReconMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.*;
import com.services.hiportservices.repository.regulatory.*;
import com.services.hiportservices.service.regulatory.LKPBUReconService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class LKPBUReconServiceImpl implements LKPBUReconService {

    private static final String UNKNOWN = "Unknown External Code";

    private final LKPBUReconRepository lkpbuReconRepository;
    private final LKPBUReconMapper lkpbuReconMapper;
    private final ObjectMapper objectMapper;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final LKPBUDataSourceRepository dataSourceRepository;
    private final InsurancePensionFundRepository insurancePensionFundRepository;
    private final OwnerGroupRepository ownerGroupRepository;
    private final DataNotFoundRepository dataNotFoundRepository;
    private final SecuritiesISINCodeRepository securitiesISINCodeRepository;

    @Override
    public List<LKPBURecon> getAll() {
        return lkpbuReconRepository.findAll();
    }

    @Override
    public List<LKPBURecon> getAllByMonthAndYear(String month, Integer year) {
        return lkpbuReconRepository.findAllByMonthAndYearAndStatus(month, year, Boolean.FALSE);
    }

    @Override
    public ReconResponse update(UpdateReconRequest updateReconRequest, RegulatoryDataChangeDTO dataChangeDTO) {
        log.info("Start update LKPBU recon: {}, {}", updateReconRequest, dataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        String code = updateReconRequest.getCode().concat("_").concat(updateReconRequest.getReconType());

        try {
            LKPBUReconDTO lkpbuReconDTO = lkpbuReconMapper.fromUpdateRequestToDTO(updateReconRequest);

            LKPBURecon lkpbuRecon = lkpbuReconRepository.findById(updateReconRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ContentParameterConstant.LKPBU + " Recon not found with id: " + updateReconRequest.getId()));

            dataChangeDTO.setEntityId(lkpbuRecon.getId().toString());
            dataChangeDTO.setCode(updateReconRequest.getCode());
            dataChangeDTO.setReconType(updateReconRequest.getReconType());

            dataChangeDTO.setJsonDataBefore(
                    JsonUtil.getDataSource(
                            objectMapper.writeValueAsString(lkpbuReconDTO)
                    )
            );

            LKPBUReconDTO temp = LKPBUReconDTO.builder()
                    .csaValue(
                            !updateReconRequest.getCsaValue().isEmpty()
                            ? updateReconRequest.getCsaValue()
                                    : lkpbuRecon.getCsaValue()
                    )
                    .dataSourceValue(
                            !updateReconRequest.getDataSourceValue().isEmpty()
                            ? updateReconRequest.getDataSourceValue()
                                    : lkpbuRecon.getDataSourceValue()
                    )
                    .build();

            log.info("Temp: {}", temp);

            dataChangeDTO.setJsonDataAfter(
                    JsonUtil.getCsaValue(
                            objectMapper.writeValueAsString(temp)
                    )
            );

            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(dataChangeDTO);
            log.info("Regulatory data change edit: {}", regulatoryDataChange);
            regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, LKPBURecon.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(code, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new ReconResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public ReconResponse updateApprove(ApproveReconRequest approveReconRequest, String approveIPAddress) {
        log.info("Start update approve {} Recon: {}, {}", ContentParameterConstant.LKPBU, approveReconRequest, approveIPAddress);
        String approveId = approveReconRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        String errorCode = "";

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveReconRequest.getDataChangeId());
            log.info("Get data change by id: {}, {}", dataChange, approveReconRequest.getDataChangeId());

            errorCode = dataChange.getCode().concat("_").concat(dataChange.getReconType());

            LKPBUReconDTO lkpbuReconDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), LKPBUReconDTO.class);
            log.info("Mapper object LKPBU Recon DTO: {}", lkpbuReconDTO);

            LKPBURecon lkpbuRecon = lkpbuReconRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException("LKPBU Recon not found with id: " + dataChange.getEntityId()));
            
            lkpbuRecon.setStatus(Boolean.TRUE);

            LKPBURecon afterUpdateStatusRecon = lkpbuReconRepository.save(lkpbuRecon);
            log.info("After update status recon: {}", afterUpdateStatusRecon);

            String code = dataChange.getCode();
            String reconType = dataChange.getReconType();

            List<LKPBUDataSource> dataSourceList = new ArrayList<>();

            if (RECON_TYPE_PORTFOLIO_CODE.equalsIgnoreCase(reconType)) {
                dataSourceList = dataSourceRepository.findAllByData1(code);
            } else if (RECON_TYPE_SECURITY_CODE.equalsIgnoreCase(reconType)) {
                dataSourceList = dataSourceRepository.findAllByData2(code);
            }

            Instant now = Instant.now();
            List<LKPBUDataSource> dataUpdateList = new ArrayList<>();

            for (LKPBUDataSource dataSource : dataSourceList) {
                if (null != lkpbuReconDTO.getCsaValue() && !lkpbuReconDTO.getCsaValue().isEmpty()) {
                    if (ISIN_LKPBU.equalsIgnoreCase(lkpbuRecon.getFlagRecon())) {
                        dataSource.setIsinCode(lkpbuReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    } else if (DANA_JAMINAN.equalsIgnoreCase(lkpbuRecon.getFlagRecon())) {
                        dataSource.setDanaJaminan(lkpbuReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    } else if (REFERENSI_DAPEN_ASURANSI.equalsIgnoreCase(lkpbuRecon.getFlagRecon())) {
                        dataSource.setSandiPerusahaanAsuransi(lkpbuReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    } else if (REFERENSI_GOLONGAN_PIHAK_LAWAN.equalsIgnoreCase(lkpbuRecon.getFlagRecon())) {
                        dataSource.setGolonganPemilik(lkpbuReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    } else if (ISIN_COUNTRY.equalsIgnoreCase(lkpbuRecon.getFlagRecon())) {
                        dataSource.setNegara(lkpbuReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    } else if (ISIN_CURRENCY.equalsIgnoreCase(lkpbuRecon.getFlagRecon())) {
                        dataSource.setJenisValuta(lkpbuReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    }
                }
                dataUpdateList.add(dataSource);
            }

            List<LKPBUDataSource> saveAll = dataSourceRepository.saveAll(dataUpdateList);

            LocalDateTime approveDate = LocalDateTime.now();
            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setJsonDataAfter(objectMapper.writeValueAsString(saveAll.get(0))); // object yg diupdate paling atas
            dataChange.setDescription("Successfully update approve with code: " + code); // id data source

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(errorCode, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new ReconResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private void handleGeneralError(String value, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        value.isEmpty() ? UNKNOWN : value,
                        validationErrors
                )
        );
    }

    @Override
    public List<LKPBUDataSource> getAllDistinctPortfolioCode(String month, Integer year) {
        return dataSourceRepository.findAllDistinctPortfolioCode(month, year);
    }

    @Override
    public List<LKPBUDataSource> getAllDistinctSecurityCode(String month, Integer year) {
        return dataSourceRepository.findAllDistinctSecurityCode(month, year);
    }

    @Override
    public String reconPortfolioCode(String month, Integer year) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        int processData = 0;

        List<LKPBUDataSource> dataSourceList = dataSourceRepository.findAllDistinctPortfolioCode(month, year);
        log.info("Portfolio Code data source list size: {}", dataSourceList.size());

        lkpbuReconRepository.deleteByReconTypeAndMonthAndYear(RECON_TYPE_PORTFOLIO_CODE, month, year);

        for (LKPBUDataSource dataSource : dataSourceList) {
            try {
                if (!dataSource.getDanaJaminan().isEmpty()) {
                    processData++;
                    log.info("Recon portfolio code {} process data: {}", dataSource.getData1(), processData);

                    validateInvestmentGuaranteeFund(dataSource);

                    validateInsuranceCompanyCode(dataSource);

                    validateGroupOwner(dataSource);

                    totalDataSuccess++;
                }
            } catch (Exception e) {
                totalDataFailed++;
            }
        }

        return String.format("Total data success is %d and total data failed is %d", totalDataSuccess, totalDataFailed);
    }

    @Override
    public String reconSecurityCode(String month, Integer year) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        int processData = 0;

        List<LKPBUDataSource> dataSourceList = dataSourceRepository.findAllDistinctSecurityCode(month, year);
        log.info("Security Code data source list size: {}", dataSourceList.size());

        lkpbuReconRepository.deleteByReconTypeAndMonthAndYear(RECON_TYPE_SECURITY_CODE, month, year);

        for (LKPBUDataSource dataSource : dataSourceList) {
            try {
                processData++;
                log.info("Recon security code {} process data: {}", dataSource.getData2(), processData);

                validateLKPBUISINCode(dataSource);

                totalDataSuccess++;
            } catch (Exception e) {
                totalDataFailed++;
            }
        }

        return String.format("Total data success is %d and total data failed is %d", totalDataSuccess, totalDataFailed);
    }

    private void validateLKPBUISINCode(LKPBUDataSource dataSource) {
        validateSecuritiesISINCodeTable(dataSource);
    }

    private void validateSecuritiesISINCodeTable(LKPBUDataSource dataSource) {
        String data2 = dataSource.getData2();
        Optional<SecuritiesISINCode> securitiesISINCodeOptional = securitiesISINCodeRepository.findByExternalCode(data2);

        if (securitiesISINCodeOptional.isPresent()) {
            SecuritiesISINCode securitiesISINCode = securitiesISINCodeOptional.get();

            String dataSourceValue = dataSource.getIsinCode();
            String csaValue = securitiesISINCode.getIsinLKPBU();
            String description = createDescriptionRecon(ISIN_LKPBU, csaValue, dataSourceValue);

            if (!csaValue.equalsIgnoreCase(dataSourceValue)) {
                LKPBURecon lkpbuRecon = LKPBURecon.builder()
                        .createdDate(Instant.now())
                        .month(dataSource.getMonth())
                        .year(dataSource.getYear())
                        .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                        .dataSourceId(dataSource.getId().toString())
                        .code(data2)
                        .csaValue(csaValue)
                        .dataSourceValue(dataSourceValue)
                        .description(description)
                        .status(Boolean.FALSE)
                        .flagRecon(ISIN_LKPBU)
                        .reconType(RECON_TYPE_SECURITY_CODE)
                        .build();
                lkpbuReconRepository.save(lkpbuRecon);
            }
        } else {
            DataNotFound dataNotFound = DataNotFound.builder()
                    .createdDate(Instant.now())
                    .month(dataSource.getMonth())
                    .year(dataSource.getYear())
                    .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                    .code(data2)
                    .description(createDescriptionDataNotFound(ISIN_CODE_TABLE, "data 2", data2))
                    .status(Boolean.FALSE)
                    .reportType(LKPBU)
                    .flagTable(ISIN_CODE_TABLE)
                    .build();
            dataNotFoundRepository.save(dataNotFound);
        }
    }

    private void validateInsuranceCompanyCode(LKPBUDataSource dataSource) {
        validateInsurancePensionFundTable(dataSource, REFERENSI_DAPEN_ASURANSI);
    }

    private void validateInvestmentGuaranteeFund(LKPBUDataSource dataSource) {
        validateInsurancePensionFundTable(dataSource, DANA_JAMINAN);
    }

    private void validateInsurancePensionFundTable(LKPBUDataSource dataSource, String validationType) {
        String data1 = dataSource.getData1();

        Optional<InsurancePensionFund> insurancePensionFundOptional = insurancePensionFundRepository.findByPortfolioCode(data1);

        if (insurancePensionFundOptional.isPresent()) {
            InsurancePensionFund insurancePensionFund = insurancePensionFundOptional.get();

            String dataSourceValue;
            String csaValue;
            String description;
            String flagRecon;

            if (REFERENSI_DAPEN_ASURANSI.equalsIgnoreCase(validationType)) {
                dataSourceValue = dataSource.getSandiPerusahaanAsuransi();
                csaValue = insurancePensionFund.getInsurancePensionFundReference();
                description = createDescriptionRecon(REFERENSI_DAPEN_ASURANSI, csaValue, dataSourceValue);
                flagRecon = REFERENSI_DAPEN_ASURANSI;
            } else if (DANA_JAMINAN.equalsIgnoreCase(validationType)) {
                dataSourceValue = "0".concat(dataSource.getDanaJaminan());
                csaValue = insurancePensionFund.getGuaranteeFund();
                description = createDescriptionRecon(DANA_JAMINAN, csaValue, dataSourceValue);
                flagRecon = DANA_JAMINAN;
            } else {
                throw new UnknownValidationTypeException(HttpStatus.INTERNAL_SERVER_ERROR, "Unknown validation type: " + validationType);
            }

            if (!csaValue.equalsIgnoreCase(dataSourceValue)) {
                LKPBURecon lkpbuRecon = LKPBURecon.builder()
                        .createdDate(Instant.now())
                        .month(dataSource.getMonth())
                        .year(dataSource.getYear())
                        .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                        .dataSourceId(dataSource.getId().toString())
                        .code(data1)
                        .csaValue(csaValue)
                        .dataSourceValue(dataSourceValue)
                        .description(description)
                        .status(Boolean.FALSE)
                        .flagRecon(flagRecon)
                        .reconType(RECON_TYPE_PORTFOLIO_CODE)
                        .build();
                lkpbuReconRepository.save(lkpbuRecon);
            }
        } else {
            DataNotFound dataNotFound = DataNotFound.builder()
                    .createdDate(Instant.now())
                    .month(dataSource.getMonth())
                    .year(dataSource.getYear())
                    .dataSourcePeriod(dataSource.getMonth().concat(" ".concat(String.valueOf(dataSource.getYear()))))
                    .code(data1)
                    .description(createDescriptionDataNotFound(INSURANCE_PENSION_FUND_TABLE, "data 1", data1))
                    .status(Boolean.FALSE)
                    .reportType(LKPBU)
                    .flagTable(INSURANCE_PENSION_FUND_TABLE)
                    .build();
            dataNotFoundRepository.save(dataNotFound);
        }
    }

    private void validateGroupOwner(LKPBUDataSource dataSource) {
        String data1 = dataSource.getData1();
        Optional<OwnerGroup> ownerGroupOptional = ownerGroupRepository.findByPortfolioCode(data1);

        if (ownerGroupOptional.isPresent()) {
            OwnerGroup ownerGroup = ownerGroupOptional.get();

            String dataSourceValue = dataSource.getGolonganPemilik();
            String csaValue = ownerGroup.getOpposingGroupReference();
            String description = createDescriptionRecon(REFERENSI_GOLONGAN_PIHAK_LAWAN, ownerGroup.getOpposingGroupReference(), dataSource.getGolonganPemilik());

            if (!csaValue.equalsIgnoreCase(dataSourceValue)) {
                LKPBURecon lkpbuRecon = LKPBURecon.builder()
                        .createdDate(Instant.now())
                        .month(dataSource.getMonth())
                        .year(dataSource.getYear())
                        .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                        .code(data1)
                        .dataSourceId(dataSource.getId().toString())
                        .description(description)
                        .csaValue(csaValue)
                        .dataSourceValue(dataSourceValue)
                        .status(Boolean.FALSE)
                        .flagRecon(REFERENSI_GOLONGAN_PIHAK_LAWAN)
                        .reconType(RECON_TYPE_PORTFOLIO_CODE)
                        .build();
                lkpbuReconRepository.save(lkpbuRecon);
            }
        } else {
            DataNotFound dataNotFound = DataNotFound.builder()
                    .createdDate(Instant.now())
                    .month(dataSource.getMonth())
                    .year(dataSource.getYear())
                    .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                    .code(data1)
                    .description(createDescriptionDataNotFound(OWNER_GROUP_TABLE,"data 1", data1))
                    .status(Boolean.FALSE)
                    .reportType(LKPBU)
                    .flagTable(OWNER_GROUP_TABLE)
                    .build();
            dataNotFoundRepository.save(dataNotFound);
        }
    }

    private String createDescriptionRecon(String validationColumn, String csaValue, String dataSourceValue) {
        return String.format(
                "%s doest not match. Because the %s from CSA is %s, while from Data Source it is %s ",
                validationColumn, validationColumn, csaValue, dataSourceValue
        );
    }

    private String createDescriptionDataNotFound(String tableName, String key, String searchKey) {
        return String.format("%s data not found with code (%s): %s", tableName, key, searchKey);
    }

}
