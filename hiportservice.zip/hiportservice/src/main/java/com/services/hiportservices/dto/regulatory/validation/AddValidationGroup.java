package com.services.hiportservices.dto.regulatory.validation;

public interface AddValidationGroup {
}
