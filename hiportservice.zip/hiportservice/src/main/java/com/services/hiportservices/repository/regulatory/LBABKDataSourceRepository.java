package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LBABKDataSource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface LBABKDataSourceRepository extends JpaRepository<LBABKDataSource, Long> {

    @Query(value = "FROM LBABKDataSource l WHERE l.month = :month AND l.year = :year")
    List<LBABKDataSource> findAllByMonthAndYear(@Param("month") String month, @Param("year") Integer year);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM LBABKDataSource l WHERE l.month = :month AND l.year = :year")
    void deleteByMonthAndYear(@Param("month") String monthName, @Param("year") Integer year);

    @Query(value = "SELECT *\n" +
            "FROM (\n" +
            "    SELECT *, ROW_NUMBER() OVER (PARTITION BY kode_efek ORDER BY id) AS row_num\n" +
            "    FROM reg_lbabk_data_source\n" +
            "    WHERE month = :month\n" +
            "      AND year = :year\n" +
            ") AS subquery\n" +
            "WHERE row_num = 1;", nativeQuery = true)
    List<LBABKDataSource> findAllDistinctEffectCode(@Param("month") String monthName, @Param("year") Integer year);


    @Query(value = "FROM LBABKDataSource l WHERE l.kodeEfek = :effectCode")
    List<LBABKDataSource> findAllByEffectCode(@Param("effectCode") String effectCode);

}
