package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Data
@Table(name = "ORCHIDDATAMAPPINGISSUER")
public class OrchidIssuerMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "BankCode")
    private String BankCode;

    @Column(name = "IssuerCode")
    private String IssuerCode;

    @Column(name = "BankName")
    private String BankName = "";

    @Column(name = "Status")
    private String Status = "";

    @Column(name = "DisplayPortfolio")
    private String DisplayPortfolio = "";

    @Column(name = "LastModify")
    private Date LastModify;

    @Column(name = "ModifiedBy")
    private String ModifiedBy = "";


}
