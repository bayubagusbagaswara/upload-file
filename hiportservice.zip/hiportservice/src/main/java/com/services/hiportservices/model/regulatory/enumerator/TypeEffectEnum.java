package com.services.hiportservices.model.regulatory.enumerator;

import lombok.Getter;

@Getter
public enum TypeEffectEnum {

    EQUITY("1", "EQUITY"),
    CORPORATE("2", "CORPORATE BOND"),
    GOVERNMENT("3", "GOVERNMENT BOND"),
    WARRANT("4", "WARRANT"),
    INVESTMENT_FUND("6", "INVESTMENT FUND INSTRUMENT"),
    MEDIUM_TERM("7", "MEDIUM TERM NOTES"),
    TIME_DEPOSIT("11", "TIME DEPOSIT"),
    BI_CERTIFICATE("13", "SERTIFIKAT BANK INDONESIA"),
    SBSN("15", "SBSN"),
    SUKUK("17", "SUKUK"),
    EFEK_BERAGUN_ASSET("18", "EFEK BERAGUN ASSET"),
    DANA_INVESTASI_REAL_ESTATE("19", "DANA INVESTASI REAL ESTATE"),
    MUTUAL_FUND("50", "MUTUAL FUND"),
    ;

    private final String code;
    private final String description;

    TypeEffectEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getFullTypeEffect() {
        return code + " (" + description + ")";
    }

    // Static method to find TypeEffectEnum by code
    public static TypeEffectEnum fromCode(String code) {
        for (TypeEffectEnum typeEffect : values()) {
            if (typeEffect.getCode().equals(code)) {
                return typeEffect;
            }
        }
        return null; // or throw an exception if not found
    }

}
