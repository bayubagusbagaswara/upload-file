package com.services.hiportservices.dto.regulatory.insurancepensionfund;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateInsurancePensionFundRequest extends InputIdentifierRequest {

    private Long id;

    private String portfolioCode;

    private String portfolioName;

    private String regulatoryName;

    private String insurancePensionFundReference;

    private String guaranteeFund;

}
