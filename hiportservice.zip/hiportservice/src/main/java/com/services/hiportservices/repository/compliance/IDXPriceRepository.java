package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface IDXPriceRepository extends JpaRepository<IDXPrice,Long> {
    @Query("SELECT u FROM IDXPrice u WHERE u.stockCode = :stockCode and u.lastMarketDate = :lastMarketDate")
    IDXPrice searchByStockCodeAndDate(
            @Param("stockCode") String stockCode,
            @Param("lastMarketDate") Date lastMarketDate);

    @Query("SELECT u FROM IDXPrice u WHERE u.lastMarketDate = :lastMarketDate and u.approvalStatus = 'Approved'")
    List<IDXPrice> searchByDataDate(@Param("lastMarketDate") Date lastMarketDate);

    @Transactional
    @Modifying
    @Query(value="INSERT INTO comp_idx_price (approval_status, inputer_id, input_date, last_market_date, stock_code, company_name,"
            + " last_price, open_price, first_trade, highest_price, lowest_price, closing_price, difference, volume, the_value, frequency, index_individual, offer, offer_volume,"
            + " bid, bid_volume, listed_shares, tradeble_shares, index_weight, foreign_sell, foreign_buy, non_regular_volume, non_regular_value, non_regular_freq, remarks)"
            + " VALUES ('Pending', :inputerId, :inputDate, :lastMarketDate, :stockCode, :companyName, :lastPrice, :openPrice, :firstTrade, :highestPrice, :lowestPrice, :closingPrice,"
            + " :difference, :volume, :nilai, :frequency, :indexIndividual, :offer, :offerVolume, :bid, :bidVolume, :listedShares, :tradebleShares, :indexWeight, :foreignSell, :foreignBuy,"
            + " :nonRegularVolume, :nonRegularValue, :nonRegularFreq, :remarks)", nativeQuery = true)
    void insertIntoIdxPrice(@Param("inputerId") String inputerId, @Param("inputDate") Date inputDate, @Param("lastMarketDate") Date lastMarketDate,
                             @Param("stockCode") String stockCode, @Param("companyName") String companyName, @Param("lastPrice") double lastPrice,
                             @Param("openPrice") double openPrice, @Param("firstTrade") double firstTrade, @Param("highestPrice") double highestPrice,
                             @Param("lowestPrice") double lowestPrice, @Param("closingPrice") double closingPrice, @Param("difference") double difference,
                             @Param("volume") double volume, @Param("nilai") double value, @Param("frequency") double frequency,
                             @Param("indexIndividual") double indexIndividual, @Param("offer") double offer, @Param("offerVolume") double offerVolume,
                             @Param("bid") double bid, @Param("bidVolume") double bidVolume, @Param("listedShares") double listedShares,
                             @Param("tradebleShares") double tradebleShares, @Param("indexWeight") double indexWeight, @Param("foreignSell") double foreignSell,
                             @Param("foreignBuy") double foreignBuy, @Param("nonRegularVolume") double nonRegularVolume, @Param("nonRegularValue") double nonRegularValue,
                             @Param("nonRegularFreq") double nonRegularFreq, @Param("remarks") String remarks);

    @Query("SELECT u FROM IDXPrice u WHERE u.lastMarketDate = :date and u.approvalStatus = 'Pending'")
    List<IDXPrice> searchPendingData(@Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_idx_price SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverrId " +
            "WHERE last_market_date = :dataDate", nativeQuery = true)
    void approveOrRejectIDXPrice(@Param("approvalStatus") String approvalStatus,
                                  @Param("approveDate") Date approveDate,
                                  @Param("approverrId") String approverrId,
                                  @Param("dataDate") String dataDate);


//    @Transactional
//    @Modifying
//    @Query(value="UPDATE comp_idx_price SET approval_status = 'Pending', inputer_id = :inputerId,"
//            + " input_date = :inputDate, last_price = :lastPrice, open_price = :openPrice,"
//            + " first_trade = :firstTrade, highest_price = :highestPrice, lowest_price = :lowestPrice,"
//            + " closing_price = :closingPrice, difference = :difference, volume = :volume, the_value = :nilai,"
//            + " frequency = :frequency, index_individual = :indexIndividual, offer = :offer, offer_volume = :offerVolume,"
//            + " bid = :bid, bid_volume = :bidVolume, listed_shares = :listedShares, tradeble_shares = :tradebleShares,"
//            + " index_weight = :indexWeight, foreign_sell = :foreignSell, foreign_buy = :foreignBuy, non_regular_volume = :nonRegularVolume,"
//            + " non_regular_value = :nonRegularValue, non_regular_freq = :nonRegularFreq, remarks = :remarks)"
//            + " WHERE last_market_date = :lastMarketDate AND stock_code = :stockCode", nativeQuery = true)
//    void updateIdxPrice(@Param("inputerId") String inputerId, @Param("inputDate") Date inputDate, @Param("lastPrice") double lastPrice,
//                            @Param("openPrice") double openPrice, @Param("firstTrade") double firstTrade, @Param("highestPrice") double highestPrice,
//                            @Param("lowestPrice") double lowestPrice, @Param("closingPrice") double closingPrice, @Param("difference") double difference,
//                            @Param("volume") double volume, @Param("nilai") double nilai, @Param("frequency") double frequency,
//                            @Param("indexIndividual") double indexIndividual, @Param("offer") double offer, @Param("offerVolume") double offerVolume,
//                            @Param("bid") double bid, @Param("bidVolume") double bidVolume, @Param("listedShares") double listedShares,
//                            @Param("tradebleShares") double tradebleShares, @Param("indexWeight") double indexWeight, @Param("foreignSell") double foreignSell,
//                            @Param("foreignBuy") double foreignBuy, @Param("nonRegularVolume") double nonRegularVolume, @Param("nonRegularValue") double nonRegularValue,
//                            @Param("nonRegularFreq") double nonRegularFreq, @Param("remarks") String remarks, @Param("lastMarketDate") Date lastMarketDate,
//                            @Param("stockCode") String stockCode);
}
