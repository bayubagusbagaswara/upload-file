package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.response.ResponseBrokerMasterDto;
import com.services.hiportservices.dto.response.ResponseExpenseDto;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class ExpenseService {

    public ResponseEntity<ResponseDto> updateExpense() throws SQLException, ClassNotFoundException {
        return ResponseEntity.ok(
                new ResponseDto().builder().code(HttpStatus.OK.toString()).message("Berhasil update data Expense").payload(getExpense()).build()
        );
    }

    public List<ResponseExpenseDto> getExpense() throws ClassNotFoundException, SQLException {
        List<ResponseExpenseDto> responseExpenseDtoList = new ArrayList<>();

        Class.forName("com.dstglobalsolutions.dro.jdbc.openaccess.OpenAccessDriver");
        Connection con = DriverManager.getConnection("jdbc:DRO://10.197.31.137:29996;ServerDataSource=HIPORTDSN;USER=SSNC;PASSWORD=HIPORT04");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("select ID, ExpCode1, ExpVal1, ExpCode2, ExpVal2, ExpCode3, ExpVal3, ExpCode4, ExpVal4, ExpCode5, ExpVal5 from expenses where id = " + 1);
        while (rs.next()) {
            ResponseExpenseDto responseExpenseDto = new ResponseExpenseDto().builder()
                    .id(rs.getString("ID"))
                    .ExpCode1(rs.getString("ExpCode1"))
                    .ExpVal1(rs.getString("ExpVal1"))
                    .ExpCode2(rs.getString("ExpCode2"))
                    .ExpVal2(rs.getString("ExpVal2"))
                    .ExpCode3(rs.getString("ExpCode3"))
                    .ExpVal3( rs.getString("ExpVal3"))
                    .ExpCode4(rs.getString("ExpCode4"))
                    .ExpVal4(rs.getString("ExpVal4"))
                    .ExpCode5(rs.getString("ExpCode5"))
                    .ExpVal5(rs.getString("ExpVal5"))
                    .build();
            responseExpenseDtoList.add(responseExpenseDto);
        }
        con.close();
        return responseExpenseDtoList;
    }

}
