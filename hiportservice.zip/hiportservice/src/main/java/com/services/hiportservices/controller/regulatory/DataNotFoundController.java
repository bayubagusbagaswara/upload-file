package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.service.regulatory.DataNotFoundService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/data-not-found")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class DataNotFoundController {

    private final DataNotFoundService dataNotFoundService;

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDto<List<DataNotFound>>> getAllByPeriod(@RequestParam("month") String month,
                                                                          @RequestParam("year") Integer year) {
        List<DataNotFound> dataNotFoundList = dataNotFoundService.getAllByPeriod(month, year);
        ResponseDto<List<DataNotFound>> response = ResponseDto.<List<DataNotFound>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataNotFoundList)
                .build();
        return ResponseEntity.ok(response);
    }

}
