package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.exception.regulatory.UploadFileFailedException;
import com.services.hiportservices.utils.regulatory.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.Instant;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.*;

@RestController
@RequestMapping(path = "/api/regulatory/files")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class FileUploadController {

    @Value("${file.path.lbabk-data-source}")
    private String filePathUploadLBABK;

    @Value("${file.path.lkpbu-data-source.hiport}")
    private String filePathUploadLKPBUHiport;

    @Value("${file.path.lkpbu-data-source.income}")
    private String filePathUploadLKPBUIncome;

    private final DateUtil dateUtil;

    @PostMapping(path = "/upload")
    public ResponseEntity<ResponseDto<String>> uploadFile(@RequestParam("type") String type,
                                                          @RequestParam("file") MultipartFile file) {
        ResponseDto<String> responseDto = new ResponseDto<>();
        if (file.isEmpty()) {
            buildErrorResponse(HttpStatus.BAD_REQUEST, "File is empty!");
        }

        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());
            String fileName = generateFileName(type, contextDate, file.getOriginalFilename());
            String filePathNew = getFilePath(type) + fileName;

            Files.write(Paths.get(filePathNew), file.getBytes());

            responseDto.setCode(String.valueOf(HttpStatus.OK.value()));
            responseDto.setMessage(HttpStatus.OK.getReasonPhrase());
            responseDto.setPayload("File uploaded successfully: " + fileName);
        } catch (IOException e) {
            log.error("Failed to upload file", e);
            buildErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to upload file: " + e.getMessage());
        }
        return ResponseEntity.ok(responseDto);
    }

    private void buildErrorResponse(HttpStatus status, String message) {
        throw new UploadFileFailedException(message, status, String.valueOf(status.value()));
    }

    private String generateFileName(String type, ContextDate contextDate, String originalFilename) {
        StringBuilder fileNameBuilder = new StringBuilder();
        String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
        Integer yearMinus1 = contextDate.getYearMinus1();

        if (LKPBU.equalsIgnoreCase(type)) {
            fileNameBuilder.append("LkpbuHiport");
        } else if (LBABK.equalsIgnoreCase(type)) {
            fileNameBuilder.append("Lbabk");
        } else if (INCOME.equalsIgnoreCase(type)) {
            fileNameBuilder.append("LkpbuIncome");
        } else {
            fileNameBuilder.append(originalFilename);
        }

        return fileNameBuilder.append("_").append(yearMinus1).append(monthNameMinus1Value).append(".csv").toString();
    }

    private String getFilePath(String type) {
        if (LKPBU.equalsIgnoreCase(type)) {
            return filePathUploadLKPBUHiport;
        } else if (LBABK.equalsIgnoreCase(type)) {
            return filePathUploadLBABK;
        } else if (INCOME.equalsIgnoreCase(type)) {
            return filePathUploadLKPBUIncome;
        }
        return "";
    }

}
