package com.services.hiportservices.dto.regulatory.exchangerate;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveExchangeRateRequest extends ApprovalIdentifierRequest {

    private Long dataChangeId;

}
