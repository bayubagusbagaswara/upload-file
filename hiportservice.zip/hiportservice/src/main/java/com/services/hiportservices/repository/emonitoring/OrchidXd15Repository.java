package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.compliance.KinvDetails;
import com.services.hiportservices.model.emonitoring.OrchidXd15;
import com.services.hiportservices.model.emonitoring.OrchidXd16;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface OrchidXd15Repository extends JpaRepository<OrchidXd15, Long> {

    @Query(value = "SELECT * FROM ORCHIDXD15 WHERE tanggal = :date", nativeQuery = true)
    List<OrchidXd15> searchDataAt(
            @Param("date") String date);

    @Query(value = "SELECT * FROM ORCHIDXD15 WHERE tanggal = :date and ( Kode = :code or SInvestCode = :code)", nativeQuery = true)
    OrchidXd15 searchDataBy(
            @Param("date") String date,
            @Param("code") String code);
}
