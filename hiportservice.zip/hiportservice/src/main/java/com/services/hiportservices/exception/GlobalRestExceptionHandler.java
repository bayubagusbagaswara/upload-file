package com.services.hiportservices.exception;

import com.services.hiportservices.dto.ErrorResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.time.ZoneOffset;

@ControllerAdvice
public class GlobalRestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({BrokerNotfoundException.class})
    public ResponseEntity<ErrorResponseDto> handleCustomAPIException (HttpStatus status){
        ErrorResponseDto errorResponseDto =ErrorResponseDto.builder()
                .status(status)
                .errorCode(status.INTERNAL_SERVER_ERROR.name())
                .timeStamp(LocalDateTime.now(ZoneOffset.UTC))
                .build();
            return new ResponseEntity<>(errorResponseDto,errorResponseDto.getStatus());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity <?> globalExcpetionHandler(Exception ex) {
        ErrorResponseDto errorModel = new ErrorResponseDto().builder()
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .errorCode("500")
                .massage(ex.getMessage())
                .timeStamp(LocalDateTime.now(ZoneOffset.UTC))
                .build();;

        return new ResponseEntity <> (errorModel, HttpStatus.INTERNAL_SERVER_ERROR);

    }

    @ExceptionHandler(NullPointerException.class)
    public ResponseEntity <?> globalExcpetionHandlerNull(String ex) {
        ErrorResponseDto errorModel = new ErrorResponseDto().builder()
                .status(HttpStatus.BAD_REQUEST)
                .errorCode("500")
                .massage(ex)
                .timeStamp(LocalDateTime.now(ZoneOffset.UTC))
                .build();;

        return new ResponseEntity <> (errorModel, HttpStatus.BAD_REQUEST);

    }

}
