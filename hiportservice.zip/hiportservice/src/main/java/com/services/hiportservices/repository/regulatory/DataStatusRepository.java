package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.DataStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface DataStatusRepository extends JpaRepository<DataStatus, Long> {

    @Query(value = "FROM DataStatus d WHERE d.dataType = :dataType")
    Optional<DataStatus> findByDataType(@Param("dataType") String dataType);
}
