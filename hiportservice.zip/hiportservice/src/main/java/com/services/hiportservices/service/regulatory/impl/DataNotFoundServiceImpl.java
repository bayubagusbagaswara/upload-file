package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.repository.regulatory.DataNotFoundRepository;
import com.services.hiportservices.service.regulatory.DataNotFoundService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataNotFoundServiceImpl implements DataNotFoundService {

    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public List<DataNotFound> getAllByPeriod(String month, Integer year) {
        return dataNotFoundRepository.findAllByMonthAndYearAndStatus(month, year, Boolean.FALSE);
    }

}
