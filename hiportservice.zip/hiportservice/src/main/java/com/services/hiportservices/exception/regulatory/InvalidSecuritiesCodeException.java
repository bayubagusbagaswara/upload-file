package com.services.hiportservices.exception.regulatory;

public class InvalidSecuritiesCodeException extends RuntimeException {

    public InvalidSecuritiesCodeException() {
    }

    public InvalidSecuritiesCodeException(String message) {
        super(message);
    }

    public InvalidSecuritiesCodeException(String message, Throwable cause) {
        super(message, cause);
    }
}
