package com.services.hiportservices.exception.regulatory;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class GeneralHandleException extends RuntimeException {

    public GeneralHandleException() {
        super();
    }

    public GeneralHandleException(String message) {
        super(message);
    }

    public GeneralHandleException(String message, Throwable cause) {
        super(message, cause);
    }

}
