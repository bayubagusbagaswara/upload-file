package com.services.hiportservices.dto.regulatory.lkpbu;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUDTO {

    private Long id;

    private String flagDetail;

    private String kodeKomponen;

    private String golonganPemilik;

    private String sandiPerusahaanAsuransi;

    private String negaraAsal;

    private String golonganPenerbit;

    private String negara;

    private String isinCode;

    private String jenis;

    private String kodeEfek;

    private String lembarUnit; // format big decimal to string

    private String interestRate;

    private String keterangan;

    private String danaJaminan;

    private String jenisValuta;

    private String penerbitan;

    private String jatuhTempo;

    private String nilaiValutaAsal; // format big decimal to string

    private String pembayaranKupon; // format big decimal to string

}