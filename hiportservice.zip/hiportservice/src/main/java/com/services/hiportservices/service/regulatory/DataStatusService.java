package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.model.regulatory.DataStatus;

public interface DataStatusService {

    DataStatus getDataStatusByDataType(String dataType);

}
