package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.GenerateTextFileResponse;
import com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant;
import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUDTO;
import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUProcessResponse;
import com.services.hiportservices.exception.regulatory.GeneralHandleException;
import com.services.hiportservices.exception.regulatory.ReconAlreadyExistsException;
import com.services.hiportservices.mapper.LKPBUMapper;
import com.services.hiportservices.model.regulatory.LKPBU;
import com.services.hiportservices.model.regulatory.LKPBUDataSource;
import com.services.hiportservices.model.regulatory.LKPBURecon;
import com.services.hiportservices.repository.regulatory.LKPBUDataSourceRepository;
import com.services.hiportservices.repository.regulatory.LKPBUReconRepository;
import com.services.hiportservices.repository.regulatory.LKPBURepository;
import com.services.hiportservices.service.regulatory.LKPBUService;
import com.services.hiportservices.utils.regulatory.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.UNKNOWN_CODE;

@Service
@Slf4j
@RequiredArgsConstructor
public class LKPBUServiceImpl implements LKPBUService {

    @Value("${file.path.lkpbu-report}")
    private String filePathDataLKPBU;

    private final LKPBURepository lkpbuRepository;
    private final LKPBUDataSourceRepository lkpbuDataSourceRepository;
    private final DateUtil dateUtil;
    private final LKPBUReconRepository reconRepository;
    private final LKPBUMapper lkpbuMapper;

    @Override
    public LKPBUProcessResponse process(String month, Integer year) {
        Instant now = Instant.now();
        log.info("Start process {} with data: {}", ContentParameterConstant.LKPBU, now);

        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();

        /* get all data recon by month and year */
        List<LKPBURecon> reconList = reconRepository.findAllByMonthAndYearAndStatus(
                month, year, Boolean.FALSE
        );

        if (!reconList.isEmpty()) {
            String errorMsg = String.format("Recon data already exists for month: %s, year: %d. Process aborted.", month, year);
            throw new ReconAlreadyExistsException(errorMsg);
        }

        List<LKPBUDataSource> dataSourceList = lkpbuDataSourceRepository.findAllByMonthAndYear(month, year);

        for (LKPBUDataSource dataSource : dataSourceList) {
            try {
                LKPBU lkpbu = lkpbuMapper.mapFromDataSourceToLKPBU(dataSource);

                LKPBU save = lkpbuRepository.save(lkpbu);
                log.info("Successfully save {} with id: {}", ContentParameterConstant.LKPBU, save.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                handleGeneralError(dataSource.getData1(), e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new LKPBUProcessResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public List<LKPBU> getAllByMonthAndYear(String month, Integer year) {
        return lkpbuRepository.findAllByMonthAndYear(month, year);
    }

    @Override
    public String generateTxtAndSaveToServer(String month, Integer year) {
        log.info("Start generate txt file {} with month: {}, year, {}", ContentParameterConstant.LKPBU, month, year);
        try {
            Instant now = Instant.now();
            String monthName = month.toUpperCase();
            List<LKPBU> lkpbuList = lkpbuRepository.findAllByMonthAndYear(monthName, year);

            List<LKPBUDTO> lkpbuDTOList = lkpbuMapper.mapToDTOList(lkpbuList);

            GenerateTextFileResponse response = generateAndSaveTxtStatements(lkpbuDTOList, now);

            return "Successfully created a Text File for LKPBU with total data success: "
                    + response.getTotalDataSuccess()
                    + ", and total data failed: "
                    + response.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate text file {}: {}", ContentParameterConstant.LKPBU, e.getMessage(), e);
            throw new GeneralHandleException("Error when generate text file LKPBU: " + e.getMessage(), e);
        }
    }

    private GenerateTextFileResponse generateAndSaveTxtStatements(List<LKPBUDTO> dataList, Instant instant) {
        log.info("Start generate and save txt statements with size: {}", dataList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;

        try {
            ContextDate contextDate = dateUtil.buildContextDate(instant);

            StringBuilder content = new StringBuilder();
            // Notes: tanyakan apakah diakhir 0100 itu ada tanda | atau langsung enter
            content
                    .append("H01").append("|")
                    .append("010101").append("|")
                    .append("011").append("|")
                    .append(contextDate.getLastDayOfPreviousMonth()).append("|")
                    .append("KKMK").append("|")
                    .append("0100")
                    .append("\n");

            for (LKPBUDTO data : dataList) {
                content
                        .append(data.getFlagDetail()).append("|")
                        .append(data.getKodeKomponen()).append("|")
                        .append(data.getGolonganPemilik()).append("|")
                        .append(data.getSandiPerusahaanAsuransi()).append("|")
                        .append(data.getNegaraAsal()).append("|")
                        .append(data.getGolonganPenerbit()).append("|")
                        .append(data.getNegara()).append("|")
                        .append(data.getIsinCode()).append("|")
                        .append(data.getJenis()).append("|")
                        .append(data.getKodeEfek()).append("|")
                        .append(data.getLembarUnit()).append("|")
                        .append(data.getInterestRate()).append("|")
                        .append(data.getKeterangan()).append("|")
                        .append(data.getDanaJaminan()).append("|")
                        .append(data.getJenisValuta()).append("|")
                        .append(data.getPenerbitan()).append("|")
                        .append(data.getJatuhTempo()).append("|")
                        .append(data.getNilaiValutaAsal()).append("|")
                        .append(data.getPembayaranKupon()).append("|")
                        .append("\n")
                        ;
            }

            String fileName = "LKPBU_"
                    + contextDate.getLastDayOfPreviousMonth().replace("-", "")
                    + ".txt";

            String filePath = filePathDataLKPBU + fileName;

            deleteExistingFile(filePath);

            saveTextFile(filePath, content.toString());

            totalDataSuccess++;
        } catch (Exception e) {
            log.error("Error when generateAndSaveTxtStatements: {}", e.getMessage());
            totalDataFailed++;
        }
        return new GenerateTextFileResponse(totalDataSuccess, totalDataFailed);
    }

    private static void deleteExistingFile(String filePath) {
        Path path = Paths.get(filePath);
        if (Files.exists(path)) {
            try {
                Files.delete(path);
                log.info("File sebelumnya berhasil dihapus: {}", filePath);
            } catch (IOException e) {
                log.error("Gagal menghapus file: {}. Kesalahan: {}", filePath, e.getMessage(), e);
            }
        } else {
            log.info("File tidak ditemukan: {}", filePath);
        }
    }

    private static void saveTextFile(String filePath, String content) throws IOException {
        File file = new File(filePath);

        Path path = Paths.get(file.getParent());
        if (Files.notExists(path)) {
            Files.createDirectories(path);
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(content);
            log.info("File baru berhasil disimpan di: {}", filePath);
        } catch (IOException e) {
            log.info("Terjadi kesalahan saat menyimpan file: {}", e.getMessage());
        }
    }

    private void handleGeneralError(String data, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        data != null && !data.isEmpty() ? data : UNKNOWN_CODE,
                        validationErrors
                )
        );
    }

}
