package com.services.hiportservices.dto.regulatory.recon;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUReconDTO {

    private String code;

    private String reconType;

    private String csaValue;

    private String dataSourceValue;

}
