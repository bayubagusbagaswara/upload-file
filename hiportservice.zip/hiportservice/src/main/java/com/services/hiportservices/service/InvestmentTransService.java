package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class InvestmentTransService {
    public ResponseEntity<ResponseDto> updateInvestmentTrs(){
        return ResponseEntity.ok(new ResponseDto().builder().code(HttpStatus.OK.toString()).message("Berhasil update updateInvestmentTrs").payload("").build());
    }
}
