package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

/**
 * model sesuai file yang dikasih dari hiport
 */
@Entity
@Table(name = "reg_lkpbu_data_source")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUDataSource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private Instant createdDate;

    @Column(name = "updated_date")
    private Instant updatedDate;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "flag_detail")
    private String flagDetail;

    @Column(name = "kode_komponen")
    private String kodeKomponen;

    @Column(name = "golongan_pemilik")
    private String golonganPemilik;

    @Column(name = "sandi_perusahaan_asuransi")
    private String sandiPerusahaanAsuransi;

    @Column(name = "negara_asal")
    private String negaraAsal;

    @Column(name = "golongan_penerbit")
    private String golonganPenerbit; // golongan Barang

    @Column(name = "negara")
    private String negara;

    @Column(name = "isin_code")
    private String isinCode;

    @Column(name = "jenis")
    private String jenis;

    @Column(name = "kode_efek")
    private String kodeEfek;

    @Column(name = "lembar_unit")
    private BigDecimal lembarUnit;

    @Column(name = "interest_rate")
    private String interestRate;

    @Column(name = "keterangan")
    private String keterangan;

    @Column(name = "dana_jaminan")
    private String danaJaminan;

    @Column(name = "jenis_valuta")
    private String jenisValuta;

    @Column(name = "penerbitan")
    private String penerbitan;

    @Column(name = "jatuh_tempo")
    private String jatuhTempo;

    @Column(name = "nilai_valuta_asal")
    private BigDecimal nilaiValutaAsal;

    @Column(name = "pembayaran_kupon")
    private BigDecimal pembayaranKupon;

    @Column(name = "data_1")
    private String data1;

    @Column(name = "data_2")
    private String data2;

    @Column(name = "tipe_saham")
    private String tipeSaham;

    @Column(name = "concat_data")
    private String concatData; // combine data1 and data 2

}
