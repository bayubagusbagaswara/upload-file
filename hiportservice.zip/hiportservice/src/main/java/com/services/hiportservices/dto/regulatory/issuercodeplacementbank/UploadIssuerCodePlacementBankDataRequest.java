package com.services.hiportservices.dto.regulatory.issuercodeplacementbank;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * untuk menampung data JsonProperty
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadIssuerCodePlacementBankDataRequest {

    @JsonProperty(value = "kode")
    private String code;

    @JsonProperty(value = "Nama Bank")
    private String bankName;

    @JsonProperty(value = "Jenis Bank")
    private String bankType;

    @JsonProperty(value = "Gol Penerbit")
    private String issuerGroup;

    @JsonProperty(value = "Neg penerbit")
    private String issuerCountry;

    @JsonProperty(value = "Jenis SB")
    private String securityType;

    @JsonProperty(value = "Kode Tipe Efek")
    private String effectTypeCode;

    @JsonProperty(value = "Status")
    private String status;

    @JsonProperty(value = "Currency")
    private String currency;

}
