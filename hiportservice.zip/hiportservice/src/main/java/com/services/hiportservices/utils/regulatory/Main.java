package com.services.hiportservices.utils.regulatory;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
        String date = new SimpleDateFormat("yyyyMMdd").format(new Date());

        System.out.println(date);

        String scientificNotation = "9.40101E+11";

        // Menggunakan BigDecimal untuk konversi dari string ke angka
        BigDecimal number = new BigDecimal(scientificNotation);

        // Mengonversi kembali ke string
        String numberAsString = number.toPlainString();

        System.out.println("String: " + numberAsString);
    }
}
