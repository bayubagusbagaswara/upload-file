package com.services.hiportservices.utils.regulatory;

import lombok.experimental.UtilityClass;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
public class ExtractEffectTypeCodeUtil {

    public static String extractCode(String input) {
        // Regex untuk mengambil angka sebelum tanda kurung
        Pattern pattern = Pattern.compile("^\\d+");
        Matcher matcher = pattern.matcher(input);

        if (matcher.find()) {
            return matcher.group();  // Mengembalikan angka yang ditemukan
        } else {
            return "No code found";  // Jika tidak ditemukan angka
        }
    }

}
