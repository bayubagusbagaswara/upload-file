package com.services.hiportservices.model.regulatory.approval;

import com.services.hiportservices.enums.ApprovalStatus;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@MappedSuperclass
@SuperBuilder
@NoArgsConstructor
public abstract class RegulatoryApproval implements Serializable {

    private static final long serialVersionUID = 1482457565099017988L;

    @Enumerated(EnumType.STRING)
    @Column(name = "approval_status")
    private ApprovalStatus approvalStatus;

    @Column(name = "inputer_id")
    private String inputerId;

    @Column(name = "input_date")
    private LocalDateTime inputDate;

    @Column(name = "approver_id")
    private String approverId;

    @Column(name = "approve_date")
    private LocalDateTime  approveDate;

    @Column(name = "input_ip_address")
    private String inputIPAddress;

    @Column(name = "approve_ip_address")
    private String approveIPAddress;

}
