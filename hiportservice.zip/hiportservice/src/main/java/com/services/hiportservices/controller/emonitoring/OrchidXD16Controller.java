package com.services.hiportservices.controller.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.model.emonitoring.OrchidXd16;
import com.services.hiportservices.service.emonitoring.OrchidXd14Service;
import com.services.hiportservices.service.emonitoring.OrchidXd16Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/xd16")
public class OrchidXD16Controller {
    @Autowired
    OrchidXd16Service orchidXd16Service;

    @GetMapping("/updateAndInsert")
    public List<OrchidXd16> updateAndInsertXD14(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf,
            @RequestParam(name = "group", required = false) String group

    ) throws ClassNotFoundException, SQLException {

        return orchidXd16Service.insertOrUpdateAll(date, pf, group);
    }

    @GetMapping("/getDataXD16")
    public List<OrchidXd16> getDataXD16(

            @RequestParam(name = "date", required = false) String date,
            @RequestParam(name = "portofolio", required = false) String pf

    ) throws ClassNotFoundException, SQLException {
        System.out.println(date);
        System.out.println(pf);

        return orchidXd16Service.getDataXD11(date, pf);

    }

}
