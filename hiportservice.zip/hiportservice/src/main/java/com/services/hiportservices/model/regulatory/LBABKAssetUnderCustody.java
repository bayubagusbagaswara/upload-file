package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "reg_asset_under_custody")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABKAssetUnderCustody {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private Instant createdDate;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "flag_detail")
    private String flagDetail;

    @Column(name = "component_code")
    private String componentCode;

    @Column(name = "type_effect_code")
    private String typeEffectCode;

    @Column(name = "type_effect_information")
    private String typeEffectInformation;

    @Column(name = "total_value")
    private BigDecimal totalValue;

}
