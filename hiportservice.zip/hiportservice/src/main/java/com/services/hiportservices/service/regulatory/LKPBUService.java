package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUProcessResponse;
import com.services.hiportservices.model.regulatory.LKPBU;

import java.util.List;

public interface LKPBUService {

    LKPBUProcessResponse process(String month, Integer year);

    String generateTxtAndSaveToServer(String month, Integer year);

    List<LKPBU> getAllByMonthAndYear(String month, Integer year);

}
