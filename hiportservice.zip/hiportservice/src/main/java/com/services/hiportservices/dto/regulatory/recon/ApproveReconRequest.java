package com.services.hiportservices.dto.regulatory.recon;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveReconRequest extends ApprovalIdentifierRequest {

    private Long dataChangeId;

}
