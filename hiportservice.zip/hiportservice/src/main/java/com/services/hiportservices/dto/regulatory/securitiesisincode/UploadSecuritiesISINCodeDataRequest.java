package com.services.hiportservices.dto.regulatory.securitiesisincode;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.services.hiportservices.dto.regulatory.validation.AddValidationGroup;
import com.services.hiportservices.dto.regulatory.validation.UpdateValidationGroup;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadSecuritiesISINCodeDataRequest {

    @JsonProperty(value = "External Code 2")
    @NotBlank(message = "External Code is required", groups = AddValidationGroup.class)
    @Size(max = 50, message = "External Code cannot exceed 50 characters", groups = {AddValidationGroup.class, UpdateValidationGroup.class})
    private String externalCode2;

    @JsonProperty(value = "CURRENCY")
    private String currency;

    @JsonProperty(value = "NEGARA")
    private String country;

    @JsonProperty(value = "ISIN LKPBU")
    private String isinLKPBU;

    @JsonProperty(value = "ISIN LBABK")
    private String isinLBABK;

}
