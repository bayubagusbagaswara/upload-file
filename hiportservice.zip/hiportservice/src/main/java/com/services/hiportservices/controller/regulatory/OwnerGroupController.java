package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.*;
import com.services.hiportservices.service.regulatory.OwnerGroupService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/golongan-pemilik")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class OwnerGroupController {

    private static final String BASE_URL_OWNER_GROUP = "/api/regulatory/golongan-pemilik";
    private static final String MENU_OWNER_GROUP = "Golongan Pemilik";

    private final OwnerGroupService ownerGroupService;

    @PostMapping(path = "/upload-data")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> uploadData(@RequestBody UploadOwnerGroupListRequest uploadOwnerGroupListRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputerId(uploadOwnerGroupListRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_OWNER_GROUP)
                .build();

        OwnerGroupResponse listData = ownerGroupService.uploadData(uploadOwnerGroupListRequest, regulatoryDataChangeDTO);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(listData)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/create/approve")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> createApprove(@RequestBody ApproveOwnerGroupRequest approveOwnerGroupRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse singleApprove = ownerGroupService.createApprove(approveOwnerGroupRequest, approveIPAddress);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approve")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> updateApprove(@RequestBody ApproveOwnerGroupRequest approveOwnerGroupRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse singleApprove = ownerGroupService.updateApprove(approveOwnerGroupRequest, approveIPAddress);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/deleteById")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> deleteById(@RequestBody DeleteOwnerGroupRequest deleteOwnerGroupRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO regulatoryDataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputerId(deleteOwnerGroupRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.DELETE.name())
                .endpoint(BASE_URL_OWNER_GROUP + "/delete/approve")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_OWNER_GROUP)
                .build();
        OwnerGroupResponse deleteSingle = ownerGroupService.deleteById(deleteOwnerGroupRequest, regulatoryDataChangeDTO);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(deleteSingle)
                .build();
        return ResponseEntity.ok(response);
    }

    @DeleteMapping(path = "/delete/approve")
    public ResponseEntity<ResponseDto<OwnerGroupResponse>> deleteApprove(@RequestBody ApproveOwnerGroupRequest approveOwnerGroupRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        OwnerGroupResponse singleApprove = ownerGroupService.deleteApprove(approveOwnerGroupRequest, approveIPAddress);
        ResponseDto<OwnerGroupResponse> response = ResponseDto.<OwnerGroupResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(singleApprove)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/{id}")
    public ResponseEntity<ResponseDto<OwnerGroupDTO>> getById(@PathVariable("id") Long id) {
        OwnerGroupDTO ownerGroupDTO = ownerGroupService.getById(id);
        ResponseDto<OwnerGroupDTO> response = ResponseDto.<OwnerGroupDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ownerGroupDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/portfolio-code")
    public ResponseEntity<ResponseDto<OwnerGroupDTO>> getByPortfolioCode(@RequestParam("portfolioCode") String portfolioCode) {
        OwnerGroupDTO ownerGroupDTO = ownerGroupService.getByPortfolioCode(portfolioCode);
        ResponseDto<OwnerGroupDTO> response = ResponseDto.<OwnerGroupDTO>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ownerGroupDTO)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<OwnerGroupDTO>>> getAll() {
        List<OwnerGroupDTO> ownerGroupDTOList = ownerGroupService.getAll();
        ResponseDto<List<OwnerGroupDTO>> response = ResponseDto.<List<OwnerGroupDTO>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(ownerGroupDTOList)
                .build();
        return ResponseEntity.ok(response);
    }

}
