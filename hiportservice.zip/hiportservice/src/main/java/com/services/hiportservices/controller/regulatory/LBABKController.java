package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.lbabk.LBABKProcessResponse;
import com.services.hiportservices.model.regulatory.LBABK;
import com.services.hiportservices.model.regulatory.LBABKAssetUnderCustody;
import com.services.hiportservices.service.regulatory.LBABKAssetUnderCustodyService;
import com.services.hiportservices.service.regulatory.LBABKDataSourceService;
import com.services.hiportservices.service.regulatory.LBABKService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/lbabk")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class LBABKController {

    private final LBABKService lbabkService;
    private final LBABKDataSourceService dataSourceService;
    private final LBABKAssetUnderCustodyService assetUnderCustodyService;

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDto<String>> readAndInsertToDB() {
        String status = dataSourceService.readAndInsertToDB();
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/process")
    public ResponseEntity<ResponseDto<LBABKProcessResponse>> process(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        LBABKProcessResponse process = lbabkService.process(month, year);
        ResponseDto<LBABKProcessResponse> response = ResponseDto.<LBABKProcessResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(process)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/generate-txt")
    public ResponseEntity<ResponseDto<String>> generateTxtAndSaveToServer(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String status = lbabkService.generateTxtAndSaveToServer(month, year);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    /**
     * Apakah ini response nya diubah menjadi LBABK DTO ?
     */
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<LBABK>>> getAll(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        List<LBABK> lbabkList = lbabkService.getAllByMonthAndYear(month, year);
        ResponseDto<List<LBABK>> response = ResponseDto.<List<LBABK>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(lbabkList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/asset-under-custody/process")
    public ResponseEntity<ResponseDto<LBABKProcessResponse>> processAssetUnderCustody(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        LBABKProcessResponse processResponse = assetUnderCustodyService.process(month, year);
        ResponseDto<LBABKProcessResponse> response = ResponseDto.<LBABKProcessResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(processResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/asset-under-custody/generate-txt")
    public ResponseEntity<ResponseDto<String>> generateTxtAndSaveToServerAssetUnderCustody(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String status = assetUnderCustodyService.generateTxtAndSaveToServer(month, year);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/asset-under-custody/all")
    public ResponseEntity<ResponseDto<List<LBABKAssetUnderCustody>>> getAllAssetUnderCustodyByPeriod(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        List<LBABKAssetUnderCustody> assetUnderCustodyList = assetUnderCustodyService.getAllByMonthAndYear(month, year);
        ResponseDto<List<LBABKAssetUnderCustody>> response = ResponseDto.<List<LBABKAssetUnderCustody>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(assetUnderCustodyList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/asset-under-custody/updateByTypeEffectCode")
    public ResponseEntity<ResponseDto<String>> updateAssetUnderCustodyByTypeEffectCode(@RequestParam("typeEffectCode") String typeEffectCode,
                                                                                       @RequestParam("amount") String amount) {

        String status = assetUnderCustodyService.updateByTypeEffectCode(typeEffectCode, amount);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

}
