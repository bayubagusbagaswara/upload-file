package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.model.regulatory.DataStatus;
import com.services.hiportservices.service.regulatory.DataStatusService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/regulatory/data-status")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class DataStatusController {

    private final DataStatusService dataStatusService;

    @GetMapping
    public ResponseEntity<ResponseDto<DataStatus>> getByDataType(@RequestParam("dataType") String dataType) {

        DataStatus dataStatus = dataStatusService.getDataStatusByDataType(dataType);
        ResponseDto<DataStatus> response = ResponseDto.<DataStatus>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataStatus)
                .build();
        return ResponseEntity.ok(response);
    }

}
