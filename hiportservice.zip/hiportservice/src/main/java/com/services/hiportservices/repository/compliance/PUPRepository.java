package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface PUPRepository extends JpaRepository<PUP,Long> {
    @Query("SELECT u FROM PUP u WHERE u.reksadanaCode = :reksadanaCode and u.date = :date")
    PUP searchByReksadanaCodeAndDate(
            @Param("reksadanaCode") String reksadanaCode,
            @Param("date") Date date);

    @Query("SELECT u FROM PUP u WHERE u.date = :date and u.approvalStatus = 'Approved'")
    List<PUP> searchByDataDate(@Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value="INSERT INTO comp_pup (approval_status, inputer_id, input_date, data_date, reksadana_code, reksadana_name, pup_total)"
            + " VALUES ('Pending', :inputerId, :inputDate, :dataDate, :reksadanaCode, :reksadanaName, :daysTotal)", nativeQuery = true)
    void insertIntoPup(@Param("inputerId") String inputerId,
                       @Param("inputDate") Date inputDate,
                       @Param("dataDate") Date dataDate,
                       @Param("reksadanaCode") String reksadanaCode,
                       @Param("reksadanaName") String reksadanaName,
                       @Param("daysTotal") Date daysTotal);

    @Query("SELECT u FROM PUP u WHERE u.date = :date and u.approvalStatus = 'Pending'")
    List<PUP> searchPendingData(@Param("date") Date date);

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_pup SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverrId " +
            "WHERE data_date = :dataDate", nativeQuery = true)
    void approveOrRejectPUP(@Param("approvalStatus") String approvalStatus,
                                  @Param("approveDate") Date approveDate,
                                  @Param("approverrId") String approverrId,
                                  @Param("dataDate") String dataDate);
}
