package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.FairPrice;
import com.services.hiportservices.model.compliance.PUP;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class FairPriceService {

    @Autowired
    FairPriceRepository fairPriceRepository;

    @Autowired
    EntityManager entityManager;

    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat formatApprove = new SimpleDateFormat("yyyy-MM-dd");

    @Transactional
    public ResponseEntity<ResponseDto> insertDataFairPrice(List<Map<String, String>> fairPriceList) {
        ResponseDto responseDto =new ResponseDto();
        String message = "Input data success!";
        try {
            for (Map<String, String> fairPrice : fairPriceList){
                String date = fairPrice.get("DATE");
                Date dateOfData = format.parse(date);
//                System.out.println(dateOfData);
                String securityCode = fairPrice.get("CODE BASE SEC").trim();
                String securityDesc = fairPrice.get("SEC DSC");
                double lowerPrice = Double.valueOf(fairPrice.get("LOWER PRICE"));
                double todayPrice = Double.valueOf(fairPrice.get("TODAY PRICE"));
                double upperPrice = Double.valueOf(fairPrice.get("UPPER PRICE"));
                double stdev = Double.valueOf(fairPrice.get("STDEV"));
                FairPrice fp = fairPriceRepository.searchBySecCodeAndDate(securityCode, dateOfData);
                if (fp == null){
                    fairPriceRepository.insertIntoFairPrice(UserIdUtil.getUser(), new Date(),
                            dateOfData, securityCode, securityDesc, lowerPrice, todayPrice, upperPrice, stdev);
                }else {
                    fp.setApprovalStatus(ApprovalStatus.Pending);
                    fp.setApproveDate(null);
                    fp.setApproverId(null);
                    fp.setInputDate(new Date());
                    fp.setInputerId(UserIdUtil.getUser());
                    fp.setLowerPrice(lowerPrice);
                    fp.setTodayPrice(todayPrice);
                    fp.setUpperPrice(upperPrice);
                    fp.setStdev(stdev);
                    fairPriceRepository.save(fp);
                }
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(message);
            e.printStackTrace();
        }
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findDataAt(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatApprove.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(fairPriceRepository.searchApproveData(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataFairPrice() {
        List<Map<String, Object>> listPendingDataFairPrice = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                    "select data_date, count(*), inputer_id from comp_fair_price " +
                        "where approval_status = 'Pending' " +
                        "group by data_date, inputer_id");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("date", data[0]);
                eachColumn.put("totalData", data[1]);
                eachColumn.put("inputerId", data[2]);

                listPendingDataFairPrice.add(eachColumn);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(listPendingDataFairPrice);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataFairPrice(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        System.out.println(approverId);
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            fairPriceRepository.approveOrRejectFairPrice("Approved", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataFairPrice(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            fairPriceRepository.approveOrRejectFairPrice("Rejected", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> viewPendingData(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatApprove.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(fairPriceRepository.searchPendingData(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
