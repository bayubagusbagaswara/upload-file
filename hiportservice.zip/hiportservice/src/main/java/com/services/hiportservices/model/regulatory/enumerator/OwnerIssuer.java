package com.services.hiportservices.model.regulatory.enumerator;

public enum OwnerIssuer {

    S128011L, S128012L, S128013L, S12802, S12803, S129011L, S129012L, S129013L, S12902, S12903
}
