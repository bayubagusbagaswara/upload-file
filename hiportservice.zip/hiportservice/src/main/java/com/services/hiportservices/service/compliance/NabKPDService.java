package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.FairPrice;
import com.services.hiportservices.model.compliance.NabKPD;
import com.services.hiportservices.repository.compliance.FairPriceRepository;
import com.services.hiportservices.repository.compliance.NabKPDRepository;
import com.services.hiportservices.utils.UserIdUtil;
import lombok.Cleanup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class NabKPDService {

    @Autowired
    NabKPDRepository nabKPDRepository;

    @Autowired
    EntityManager entityManager;

    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat formatApprove = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat formatUpload = new SimpleDateFormat("dd/MM/yy");

    @Transactional
    public ResponseEntity<ResponseDto> insertDataNabKpd(MultipartFile file) {
        String message = "";
        ResponseDto responseDto = new ResponseDto();
        try {
            @Cleanup
            BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));
            String line;
            List<NabKPD> nabKPDList = new ArrayList<>();
            while ((line = br.readLine()) != null) {
                String[] dataList = line.split(",");
                Date date = formatUpload.parse(dataList[0]);
                String kpdCode = dataList[1].trim();
                double nab = Double.valueOf(dataList[2]);

                NabKPD nabKPD = nabKPDRepository.findByDateAndKpdCode(date, kpdCode);
                if (nabKPD == null){
                    nabKPD = new NabKPD();
                }
                nabKPD.setApprovalStatus(ApprovalStatus.Pending);
                nabKPD.setInputerId(UserIdUtil.getUser());
                nabKPD.setInputDate(new Date());
                nabKPD.setDate(date);
                nabKPD.setKpdCode(kpdCode);
                nabKPD.setNab(nab);

                nabKPDList.add(nabKPD);
            }
            nabKPDRepository.saveAll(nabKPDList);

            message = "Uploaded the file successfully: " + file.getOriginalFilename();
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);
        } catch (Exception e) {
            message = "Could not upload the file: " + file.getOriginalFilename() + ". Error: " + e.getMessage();
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(message);
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findDataAt(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatApprove.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(nabKPDRepository.searchApproveNabKpdDataByDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataNabKpd() {
        List<Map<String, Object>> listPendingDataFairPrice = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                    "select data_date, count(*), inputer_id from comp_nab_kpd " +
                        "where approval_status = 'Pending' " +
                        "group by data_date, inputer_id");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("date", data[0]);
                eachColumn.put("totalData", data[1]);
                eachColumn.put("inputerId", data[2]);

                listPendingDataFairPrice.add(eachColumn);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(listPendingDataFairPrice);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataNabKpd(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        System.out.println(approverId);
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            nabKPDRepository.approveOrRejectNabKpd("Approved", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataNabKpd(Map<String, List<String>> dates) {
        String approverId = UserIdUtil.getUser();
        List<String> dateList = dates.get("dateList");
        for (String date : dateList){
            nabKPDRepository.approveOrRejectNabKpd("Rejected", new Date(), approverId, date);
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> viewPendingData(String date) {
        Date dateOfData = null;
        try {
            dateOfData = formatApprove.parse(date);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(nabKPDRepository.searchPendingNabKpdDataByDate(dateOfData));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
