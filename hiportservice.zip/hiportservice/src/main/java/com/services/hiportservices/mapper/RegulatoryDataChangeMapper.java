package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RegulatoryDataChangeMapper {

    RegulatoryDataChangeDTO toDTO(RegulatoryDataChange regulatoryDataChange);

    @Mapping(source = "isRequestBody", target = "isRequestBody")
    @Mapping(source = "isRequestParam", target = "isRequestParam")
    @Mapping(source = "isPathVariable", target = "isPathVariable")
    @Mapping(source = "code", target = "code")
    @Mapping(source = "reconType", target = "reconType")
    RegulatoryDataChange toModel(RegulatoryDataChangeDTO regulatoryDataChangeDTO);

}
