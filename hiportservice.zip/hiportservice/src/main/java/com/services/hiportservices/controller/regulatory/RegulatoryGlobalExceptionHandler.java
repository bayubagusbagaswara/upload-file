package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryErrorResponseDTO;
import com.services.hiportservices.exception.regulatory.InvalidSecuritiesCodeException;
import com.services.hiportservices.exception.regulatory.ReconAlreadyExistsException;
import com.services.hiportservices.exception.regulatory.UnknownValidationTypeException;
import com.services.hiportservices.exception.regulatory.UploadFileFailedException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;

@RestControllerAdvice
public class RegulatoryGlobalExceptionHandler {

    @ExceptionHandler(ReconAlreadyExistsException.class)
    public ResponseEntity<RegulatoryErrorResponseDTO> reconAlreadyExistHandle(ReconAlreadyExistsException e) {
        RegulatoryErrorResponseDTO response = RegulatoryErrorResponseDTO.builder()
                .status(HttpStatus.BAD_REQUEST)
                .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .message(e.getMessage())
                .timestamp(Instant.now())
                .build();
        return ResponseEntity.ok(response);
    }

    @ExceptionHandler(InvalidSecuritiesCodeException.class)
    public ResponseEntity<RegulatoryErrorResponseDTO> invalidSecuritiesCodeHandle(InvalidSecuritiesCodeException e) {
        RegulatoryErrorResponseDTO response = RegulatoryErrorResponseDTO.builder()
                .status(HttpStatus.BAD_REQUEST)
                .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .message(e.getMessage())
                .timestamp(Instant.now())
                .build();
        return ResponseEntity.ok(response);
    }

    @ExceptionHandler(UploadFileFailedException.class)
    public ResponseEntity<RegulatoryErrorResponseDTO> uploadFileFailedHandle(UploadFileFailedException e) {
        RegulatoryErrorResponseDTO response = RegulatoryErrorResponseDTO.builder()
                .status(e.getHttpStatus())
                .errorCode(e.getErrorCode())
                .message(e.getMessage())
                .timestamp(Instant.now())
                .build();
        return ResponseEntity.ok(response);
    }

    @ExceptionHandler(UnknownValidationTypeException.class)
    public ResponseEntity<RegulatoryErrorResponseDTO> unknownValidationTypeHandle(UnknownValidationTypeException e) {
        RegulatoryErrorResponseDTO response = RegulatoryErrorResponseDTO.builder()
                .status(e.getHttpStatus())
                .errorCode(e.getErrorCode())
                .message(e.getMessage())
                .timestamp(Instant.now())
                .build();
        return ResponseEntity.ok(response);
    }

}
