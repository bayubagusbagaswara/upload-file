package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.securitiesisincode.SecuritiesISINCodeDTO;
import com.services.hiportservices.dto.regulatory.securitiesisincode.UploadSecuritiesISINCodeDataRequest;
import com.services.hiportservices.model.regulatory.SecuritiesISINCode;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SecuritiesISINCodeMapper {

    @Mapping(source = "id", target = "id")
    @Mapping(source = "externalCode2", target = "externalCode")
    SecuritiesISINCodeDTO toDTO(SecuritiesISINCode securitiesISINCode);

    @Mapping(target = "id", ignore = true) // Ignoring the ID field
    @Mapping(source = "externalCode2", target = "externalCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currency", target = "currency", qualifiedByName = "nullToEmpty")
    @Mapping(source = "country", target = "country", qualifiedByName = "nullToEmpty")
    @Mapping(source = "isinLKPBU", target = "isinLKPBU", qualifiedByName = "nullToEmpty")
    @Mapping(source = "isinLBABK", target = "isinLBABK", qualifiedByName = "nullToEmpty")
    SecuritiesISINCodeDTO fromUploadRequestToDTO(UploadSecuritiesISINCodeDataRequest dataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    List<SecuritiesISINCodeDTO> toDTOList(List<SecuritiesISINCode> all);
}
