package com.services.hiportservices.dto.regulatory.securitiesissuercode;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Ini adalah Isi data dari file upload Securities Issuer Code
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadSecuritiesIssuerCodeDataRequest {

    @JsonProperty(value = "EXTERNAL CODE 2")
    private String externalCode2;

    @JsonProperty(value = "CURRENCY")
    private String currency;

    @JsonProperty(value = "ISSUER LBABK")
    private String issuerLBABK;

    @JsonProperty(value = "ISSUER LKPBU")
    private String issuerLKPBU;

}
