package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.model.regulatory.DataStatus;
import com.services.hiportservices.repository.regulatory.DataStatusRepository;
import com.services.hiportservices.service.regulatory.DataStatusService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class DataStatusServiceImpl implements DataStatusService {

    private final DataStatusRepository dataStatusRepository;

    @Override
    public DataStatus getDataStatusByDataType(String dataType) {
        return dataStatusRepository.findByDataType(dataType).orElse(new DataStatus());
    }

}
