package com.services.hiportservices.service.regulatory.impl;

import com.opencsv.exceptions.CsvException;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.datasource.CalculateResponse;
import com.services.hiportservices.exception.regulatory.CsvHandleException;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.exception.regulatory.GeneralHandleException;
import com.services.hiportservices.model.regulatory.LKPBUIncome;
import com.services.hiportservices.repository.regulatory.LKPBUIncomeRepository;
import com.services.hiportservices.service.regulatory.LKPBUIncomeService;
import com.services.hiportservices.utils.regulatory.CsvDataMapper;
import com.services.hiportservices.utils.regulatory.CsvReaderUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.LKPBU;

@Service
@Slf4j
@RequiredArgsConstructor
public class LKPBUIncomeServiceImpl implements LKPBUIncomeService {

    @Value("${file.path.lkpbu-data-source.income}")
    private String filePath;

    private static final String BASE_FILE_NAME = "LkpbuIncome_";

    private final LKPBUIncomeRepository lkpbuIncomeRepository;
    private final DateUtil dateUtil;
    private final CsvDataMapper csvDataMapper;

    @Transactional
    @Override
    public synchronized String readAndInsertToDB() {
        log.info("Start read and insert {} Income data source to the database", LKPBU);
        String filePathNew = "";

        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());
            String monthNameMinus1 = contextDate.getMonthNameMinus1();
            String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
            Integer yearMinus1 = contextDate.getYearMinus1();

            String fileName = BASE_FILE_NAME + yearMinus1 + monthNameMinus1Value + ".csv";
            filePathNew = filePath + fileName;

            File file = new File(filePathNew);
            if (!file.exists()) {
                throw new DataNotFoundHandleException(LKPBU + " Income file not found with path: " + filePathNew);
            }

            lkpbuIncomeRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

             List<String[]> rows = CsvReaderUtil.readCsvFile(filePathNew);

            List<LKPBUIncome> lkpbuIncomeList = csvDataMapper.mapCsvLKPBUIncome(rows);

            CalculateResponse calculateResponse = process(lkpbuIncomeList);

            return String.format("Total data success: %d, total data failed: %d", calculateResponse.getTotalDataSuccess(), calculateResponse.getTotalDataFailed());
        } catch (DataNotFoundHandleException e) {
            log.error("{} Income file not found: {}", LKPBU, e.getMessage(), e);
            throw new DataNotFoundHandleException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error("{} Income failed to process CSV data from file: {}", LKPBU, filePathNew, e);
            throw new CsvHandleException(LKPBU + " failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", e.getMessage(), e);
            throw new GeneralHandleException(LKPBU + " Income unexpected error: " + e.getMessage());
        }
    }

    private CalculateResponse process(List<LKPBUIncome> incomeList) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        int processData = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (LKPBUIncome income : incomeList) {
            try {
                // set data concat
                income.setDataConcat(income.getPortfolioCode().concat(income.getSecurityCode()));

                processData++;
                log.info("{} Income {} process data- {}", LKPBU, income.getDataConcat(), processData);

                LKPBUIncome save = lkpbuIncomeRepository.save(income);
                log.info("Successfully save {} Income with id: {}", LKPBU, save.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error when process {} Income: {}", LKPBU, e.getMessage(), e);
                totalDataFailed++;
            }
        }

        return new CalculateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

}
