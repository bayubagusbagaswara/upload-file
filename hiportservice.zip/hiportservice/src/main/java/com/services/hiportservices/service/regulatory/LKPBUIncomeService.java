package com.services.hiportservices.service.regulatory;

public interface LKPBUIncomeService {

    String readAndInsertToDB();

}
