package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.DanaKelolahanRecord;
import com.services.hiportservices.model.compliance.FairPrice;
import com.services.hiportservices.model.compliance.PUP;
import com.services.hiportservices.model.compliance.PUPRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface PUPRecordRepository extends JpaRepository<PUPRecord,Long> {
    @Query("SELECT u FROM PUPRecord u WHERE u.reksadanaCode = :reksadanaCode")
    PUPRecord searchByReksadanaCode(
            @Param("reksadanaCode") String reksadanaCode);

    @Query("SELECT u FROM PUPRecord u")
    List<PUPRecord> searchAllPupRecord();

    @Query(value="SELECT * FROM comp_pup_record WHERE changes_date <> :changeDate", nativeQuery = true)
    List<PUPRecord> searchAllPupRecordNotInDate(@Param("changeDate") String changeDate);
}
