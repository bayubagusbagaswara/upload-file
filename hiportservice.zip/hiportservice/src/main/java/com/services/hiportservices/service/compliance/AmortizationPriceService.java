package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.AmortizationPrice;
import com.services.hiportservices.model.compliance.FairPrice;
import com.services.hiportservices.repository.compliance.AmortizationPriceRepository;
import com.services.hiportservices.repository.compliance.FairPriceRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class AmortizationPriceService {

    @Autowired
    AmortizationPriceRepository amortizationPriceRepository;
    @Autowired
    EntityManager entityManager;

    SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
    SimpleDateFormat formatFront = new SimpleDateFormat("yyyy-MM-dd");


    @Transactional
    public ResponseEntity<ResponseDto> insertDataAmortizationPrice(List<Map<String, String>> amortizationPriceList) {
        String message = "Input data success!";

        ResponseDto responseDto =new ResponseDto();
        try {
            List<AmortizationPrice>amortizationPrices = new ArrayList<>();
            for (Map<String, String> amortizationPrice : amortizationPriceList){
                String date = amortizationPrice.get("Date");
                Date dateOfData = format.parse(date);
                String reksadanaCode = amortizationPrice.get("ReksadanaCode").trim();
                String security = amortizationPrice.get("Security").trim();
                double price = Double.valueOf(amortizationPrice.get("Price"));
                AmortizationPrice aP = amortizationPriceRepository.findByDateAndReksadanaCodeAndSecurityCode(dateOfData, reksadanaCode, security);
                if (aP == null){
                    aP = new AmortizationPrice();
                    aP.setDate(dateOfData);
                    aP.setReksadanaCode(reksadanaCode);
                    aP.setSecurityCode(security);
                }
                aP.setApprovalStatus(ApprovalStatus.Pending);
                aP.setInputDate(new Date());
                aP.setInputerId(UserIdUtil.getUser());
                aP.setPrice(price);
                amortizationPrices.add(aP);
            }
            amortizationPriceRepository.saveAll(amortizationPrices);
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("Failed");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();

        }


        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(message);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> findDataAt(String startDate, String endDate) {
        Date start = null;
        Date end = null;
        try {
            start = formatFront.parse(startDate);
            end = formatFront.parse(endDate);
        }catch (Exception e){
            e.printStackTrace();
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(amortizationPriceRepository.searchByDataDate(start, end));
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> allPendingDataAmortization() {

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(amortizationPriceRepository.searchPendingData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataAmortization(Map<String, List<String>> idList) {
        String approverId = UserIdUtil.getUser();
        List<String> ids = idList.get("idList");
        for (String id : ids){
            amortizationPriceRepository.approveOrRejectAmortization("Approved", new Date(), approverId, Long.valueOf(id));
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have approved!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataAmortization(Map<String, List<String>> idList) {
        String approverId = UserIdUtil.getUser();
        List<String> ids = idList.get("idList");
        for (String id : ids){
            amortizationPriceRepository.approveOrRejectAmortization("Rejected", new Date(), approverId, Long.valueOf(id));
        }

        ResponseDto responseDto =new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload("Data have rejected!");
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

}
