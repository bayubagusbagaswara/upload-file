package com.services.hiportservices.dto.regulatory.recon;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateReconRequest extends InputIdentifierRequest {

    private Long id; // set status recon true

    private String code;

    private String reconType; // portfolio code or security code

    private String csaValue;

    private String dataSourceValue;

}
