package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.exchangerate.CreateExchangeRateRequest;
import com.services.hiportservices.dto.regulatory.exchangerate.ExchangeRateDTO;
import com.services.hiportservices.dto.regulatory.exchangerate.UpdateExchangeRateRequest;
import com.services.hiportservices.model.regulatory.ExchangeRate;
import com.services.hiportservices.utils.regulatory.ConversionUtil;
import org.mapstruct.*;

import java.math.BigDecimal;
import java.util.List;

@Mapper(componentModel = "spring")
public interface ExchangeRateMapper {

    @Mapping(target = "id", ignore = true)
    @Mapping(source = "currencyCode", target = "currencyCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currencyName", target = "currencyName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "rate", target = "rate", qualifiedByName = "nullToEmpty")
    ExchangeRateDTO fromCreateRequestToDTO(CreateExchangeRateRequest createExchangeRateRequest);

    @Mapping(target = "id", ignore = true)
    @Mapping(source = "currencyCode", target = "currencyCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currencyName", target = "currencyName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "rate", target = "rate", qualifiedByName = "nullToEmpty")
    ExchangeRateDTO fromUpdateRequestToDTO(UpdateExchangeRateRequest updateExchangeRateRequest);

    @BeanMapping(ignoreUnmappedSourceProperties = {
            "approvalStatus", "inputerId", "inputDate", "approverId",
            "approveDate", "inputIPAddress", "approveIPAddress"
    })
    @Mapping(source = "id", target = "id")
    @Mapping(source = "code", target = "currencyCode")
    @Mapping(source = "name", target = "currencyName")
    @Mapping(source = "rate", target = "rate", qualifiedByName = "bigDecimalToString")
    ExchangeRateDTO toDTO(ExchangeRate exchangeRate);

    @Mapping(target = "id", ignore = true)
    @Mapping(source = "currencyCode", target = "code")
    @Mapping(source = "currencyName", target = "name")
    @Mapping(source = "rate", target = "rate", qualifiedByName = "stringToBigDecimal")
    ExchangeRate toModel(ExchangeRateDTO exchangeRateDTO);

    List<ExchangeRateDTO> toDTOList(List<ExchangeRate> exchangeRateList);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    @Named("stringToBigDecimal")
    default BigDecimal stringToBigDecimal(String value) {
        return ConversionUtil.stringToBigDecimal(value);
    }

    @Named("bigDecimalToString")
    default String bigDecimalToString(BigDecimal value) {
        return ConversionUtil.bigDecimalToString(value);
    }

}
