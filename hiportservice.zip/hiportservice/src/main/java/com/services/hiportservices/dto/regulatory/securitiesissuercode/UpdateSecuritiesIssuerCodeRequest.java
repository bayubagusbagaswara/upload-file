package com.services.hiportservices.dto.regulatory.securitiesissuercode;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateSecuritiesIssuerCodeRequest extends InputIdentifierRequest {

    private Long id;

    private String externalCode2;

    private String currency;

    private String issuerLBABK;

    private String issuerLKPBU;

}
