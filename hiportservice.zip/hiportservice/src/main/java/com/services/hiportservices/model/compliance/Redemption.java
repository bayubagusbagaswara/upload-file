package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_redemption")
public class Redemption extends Approvable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "transaction_date")
    private Date transactionDate;

    @Column(name = "transaction_type")
    private String transactionType;

    @Column(name = "reference_no")
    private String referenceNo;

    @Column(name = "status")
    private String status;

    @Column(name = "im_fee_amendment")
    private String imFeeAmendment;

    @Column(name = "im_payment_date_amendment")
    private String imPaymentDateAmendment;

    @Column(name = "sa_code")
    private String saCode;

    @Column(name = "sa_name")
    private String saName;

    @Column(name = "investor_fund_unit_no")
    private String investorFundUnitNo;

    @Column(name = "investor_fund_unit_name")
    private String investorFundUnitName;

    @Column(name = "sid")
    private String sid;

    @Column(name = "fund_code")
    private String fundCode;

    @Column(name = "fund_name")
    private String fundName;

    @Column(name = "im_code")
    private String imCode;

    @Column(name = "im_name")
    private String imName;

    @Column(name = "cb_code")
    private String cbCode;

    @Column(name = "cb_name")
    private String cbName;

    @Column(name = "fund_ccy")
    private String fundCcy;

    @Column(name = "amount_nominal")
    private double amountNominal;

    @Column(name = "amount_unit")
    private double amountUnit;

    @Column(name = "amount_all_unit")
    private String amountAllUnits;

    @Column(name = "fee_nominal")
    private double feeNominal;

    @Column(name = "fee_unit")
    private double feeUnit;

    @Column(name = "fee_percent")
    private double feePercent;

    @Column(name = "transfer_path")
    private String transferPath;

    @Column(name = "redm_payment_sequential_code")
    private String redmPaymentSequentialCode;

    @Column(name = "redm_payment_bank_bic_code")
    private String redmPaymentBankBicCode;

    @Column(name = "redm_payment_bank_bi_member_code")
    private String redmPaymentBankBiMemberCode;

    @Column(name = "redm_payment_bank_name")
    private String redmPaymentBankName;

    @Column(name = "redm_payment_no")
    private String redmPaymentNo;

    @Column(name = "redm_payment_name")
    private String redmPaymentName;

    @Column(name = "payment_date")
    private Date paymentDate;

    @Column(name = "transfer_type")
    private String transferType;

    @Column(name = "input_date_redemp")
    private Date inputDateRedemp;

    @Column(name = "upload_reference_no")
    private String uploadReferenceNo;

    @Column(name = "sa_reference_no")
    private String saReferenceNo;

    @Column(name = "im_status")
    private String imStatus;

    @Column(name = "cb_status")
    private String cbStatus;

    @Column(name = "cb_completion_status")
    private String cbCompletionStatus;

}
