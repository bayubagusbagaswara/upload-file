package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.model.compliance.ComplianceDataChange;
import com.services.hiportservices.service.compliance.ComplianceDataChangeService;
import com.services.hiportservices.service.compliance.PUPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/dataChange")
public class ComplianceDataChangeController {

    @Autowired
    ComplianceDataChangeService complianceDataChangeService;

    @GetMapping("/allPendingData")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return complianceDataChangeService.getPendingData();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataChange(@RequestBody Map<String, List<String>> idList) {
        return complianceDataChangeService.approveDataChange(idList);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataChange(@RequestBody Map<String, List<String>> idList) {
        return complianceDataChangeService.rejectDataChange(idList);
    }

    @GetMapping("/view")
    public ResponseEntity<ResponseDto> getBreachReport(@RequestParam String id) {
        return complianceDataChangeService.getDataBeforAfter(id);
    }
}
