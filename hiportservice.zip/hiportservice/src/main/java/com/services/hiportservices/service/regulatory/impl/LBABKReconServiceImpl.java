package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant;
import com.services.hiportservices.dto.regulatory.recon.ApproveReconRequest;
import com.services.hiportservices.dto.regulatory.recon.LBABKReconDTO;
import com.services.hiportservices.dto.regulatory.recon.ReconResponse;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.mapper.LBABKReconMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.*;
import com.services.hiportservices.repository.regulatory.*;
import com.services.hiportservices.service.regulatory.LBABKReconService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.ExtractEffectTypeCodeUtil;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class LBABKReconServiceImpl implements LBABKReconService {

    private static final String UNKNOWN = "Unknown External Code";

    private final LBABKReconRepository reconRepository;
    private final LBABKReconMapper reconMapper;
    private final ObjectMapper objectMapper;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final LBABKDataSourceRepository dataSourceRepository;
    private final SecuritiesIssuerCodeRepository securitiesIssuerCodeRepository;
    private final SecuritiesISINCodeRepository securitiesISINCodeRepository;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public List<LBABKRecon> getAll() {
        return reconRepository.findAll();
    }

    @Override
    public List<LBABKRecon> getAllByMonthAndYear(String month, Integer year) {
        return reconRepository.findAllByMonthAndYearAndStatus(month, year, Boolean.FALSE);
    }

    @Override
    public ReconResponse update(UpdateReconRequest updateReconRequest, RegulatoryDataChangeDTO dataChangeDTO) {
        log.info("Start update LBABK recon: {}, {}", updateReconRequest, dataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        String code = updateReconRequest.getCode().concat("_").concat(updateReconRequest.getReconType());

        try {
            LBABKReconDTO lbabkReconDTO = reconMapper.fromUpdateRequestToDTO(updateReconRequest);

            LBABKRecon lbabkRecon = reconRepository.findById(updateReconRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ContentParameterConstant.LBABK + " Recon not found with id: " + updateReconRequest.getId()));

            dataChangeDTO.setEntityId(lbabkRecon.getId().toString());
            dataChangeDTO.setCode(updateReconRequest.getCode());
            dataChangeDTO.setReconType(updateReconRequest.getReconType());

            dataChangeDTO.setJsonDataBefore(
                    JsonUtil.getDataSource(
                            objectMapper.writeValueAsString(lbabkReconDTO)
                    )
            );

            LBABKReconDTO temp = LBABKReconDTO.builder()
                    .csaValue(
                            !updateReconRequest.getCsaValue().isEmpty()
                                    ? updateReconRequest.getCsaValue()
                                    : lbabkRecon.getCsaValue()
                    )
                    .dataSourceValue(
                            !updateReconRequest.getDataSourceValue().isEmpty()
                                    ? updateReconRequest.getDataSourceValue()
                                    : lbabkRecon.getDataSourceValue()
                    )
                    .build();

            log.info("Temp: {}", temp);

            dataChangeDTO.setJsonDataAfter(
                    JsonUtil.getCsaValue(
                            objectMapper.writeValueAsString(temp)
                    )
            );

            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(dataChangeDTO);
            log.info("Regulatory data change edit: {}", regulatoryDataChange);
            regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, LBABKRecon.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(code, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new ReconResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public synchronized ReconResponse updateApprove(ApproveReconRequest approveReconRequest, String approveIPAddress) {
        log.info("Start update approve {} Recon: {}, {}", ContentParameterConstant.LBABK, approveReconRequest, approveIPAddress);
        String approveId = approveReconRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        String errorCode = "";

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveReconRequest.getDataChangeId());
            log.info("Data Change: {}", dataChange);

            errorCode = dataChange.getCode().concat("_").concat(dataChange.getReconType());

            LBABKReconDTO lbabkReconDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), LBABKReconDTO.class);
            log.info("LBABK Recon DTO: {}", lbabkReconDTO);

            LBABKRecon lbabkRecon = reconRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException("LBABK Recon not found with id: " + dataChange.getEntityId()));
            log.info("LBABK Recon: {}", lbabkRecon);

            // Get Recon by Code, return 1 data
            lbabkRecon.setStatus(Boolean.TRUE);

            LBABKRecon afterUpdateStatusRecon = reconRepository.save(lbabkRecon);
            log.info("After update status recon: {}", afterUpdateStatusRecon);

            String code = dataChange.getCode();
            String reconType = dataChange.getReconType();

            List<LBABKDataSource> dataSourceList = new ArrayList<>();

            if (RECON_TYPE_SECURITY_CODE.equalsIgnoreCase(reconType)) {
                dataSourceList = dataSourceRepository.findAllByEffectCode(code);
            }

            Instant now = Instant.now();
            List<LBABKDataSource> dataUpdateList = new ArrayList<>();

            for (LBABKDataSource dataSource : dataSourceList) {
                if (null != lbabkReconDTO.getCsaValue() && !lbabkReconDTO.getCsaValue().isEmpty()) {
                    if (ISSUER_LBABK.equalsIgnoreCase(lbabkRecon.getFlagRecon())) {
                        dataSource.setIssuerCode(lbabkReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    } else if (ISIN_LBABK.equalsIgnoreCase(lbabkRecon.getFlagRecon())) {
                        dataSource.setIsinCode(lbabkReconDTO.getCsaValue());
                        dataSource.setUpdatedDate(now);
                    }
                }
                dataUpdateList.add(dataSource);
            }

            List<LBABKDataSource> saveAll = dataSourceRepository.saveAll(dataUpdateList);

            LocalDateTime approveDate = LocalDateTime.now();
            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setJsonDataAfter(objectMapper.writeValueAsString(saveAll.get(0)));
            dataChange.setDescription("Successfully update approve with code: " + code);

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(errorCode, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }

        return new ReconResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private void handleGeneralError(String value, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        value.isEmpty() ? UNKNOWN : value,
                        validationErrors
                )
        );
    }

    @Override
    public String reconSecurityCode(String month, Integer year) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        int processData = 0;

        List<LBABKDataSource> dataSourceList = dataSourceRepository.findAllDistinctEffectCode(month, year);
        log.info("Security Code data source list size: {}", dataSourceList.size());

        reconRepository.deleteByReconTypeAndMonthAndYear(RECON_TYPE_SECURITY_CODE, month, year);

        for (LBABKDataSource dataSource : dataSourceList) {
            try {
                processData++;
                log.info("Recon process data: {}", processData);

                validateLBABKIssuerCode(dataSource);

                validateLBABKISINCode(dataSource);

                totalDataSuccess++;
            } catch (Exception e) {
                totalDataFailed++;
            }
        }

        return String.format("Total data success is %d and total data failed is %d", totalDataSuccess, totalDataFailed);
    }

    private void validateLBABKIssuerCode(LBABKDataSource dataSource) {
        String extractCode = ExtractEffectTypeCodeUtil.extractCode(dataSource.getKodeTipeEfek());
        if (!TIME_DEPOSIT_CODE.equalsIgnoreCase(extractCode)) {
            String effectCode = dataSource.getKodeEfek();

            Optional<SecuritiesIssuerCode> securitiesIssuerCodeOptional = securitiesIssuerCodeRepository.findByExternalCode2(effectCode);

            if (securitiesIssuerCodeOptional.isPresent()) {
                SecuritiesIssuerCode securitiesIssuerCode = securitiesIssuerCodeOptional.get();

                String dataSourceValue = dataSource.getIssuerCode();
                String csaValue = securitiesIssuerCode.getIssuerLBABK();
                String description = createDescriptionRecon(ISSUER_LBABK, csaValue, dataSourceValue);

                if (!dataSource.getIssuerCode().equalsIgnoreCase(securitiesIssuerCode.getIssuerLBABK())) {
                    LBABKRecon recon = LBABKRecon.builder()
                            .createdDate(Instant.now())
                            .month(dataSource.getMonth())
                            .year(dataSource.getYear())
                            .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                            .dataSourceId(dataSource.getId().toString())
                            .code(effectCode)
                            .csaValue(csaValue)
                            .dataSourceValue(dataSourceValue)
                            .description(description)
                            .status(Boolean.FALSE)
                            .flagRecon(ISSUER_LBABK)
                            .reconType(RECON_TYPE_SECURITY_CODE)
                            .build();
                    reconRepository.save(recon);
                }
            } else {
                DataNotFound dataNotFound = DataNotFound.builder()
                        .createdDate(Instant.now())
                        .month(dataSource.getMonth())
                        .year(dataSource.getYear())
                        .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                        .code(effectCode)
                        .description(createDescriptionDataNotFound(ISSUER_CODE_TABLE, "kode efek", effectCode))
                        .status(Boolean.FALSE)
                        .reportType(LBABK)
                        .flagTable(ISSUER_CODE_TABLE)
                        .build();
                dataNotFoundRepository.save(dataNotFound);
            }
        }
    }

    private void validateLBABKISINCode(LBABKDataSource dataSource) {
        String effectCode = dataSource.getKodeEfek();
        String extractCode = ExtractEffectTypeCodeUtil.extractCode(dataSource.getKodeTipeEfek());

        if (!effectCode.isEmpty() || !TIME_DEPOSIT_CODE.equalsIgnoreCase(extractCode)) {
            Optional<SecuritiesIssuerCode> securitiesIssuerCodeOptional = securitiesIssuerCodeRepository.findByExternalCode2(effectCode);

            if (!securitiesIssuerCodeOptional.isPresent()) {
                Optional<SecuritiesISINCode> securitiesISINCodeOptional = securitiesISINCodeRepository.findByExternalCode(effectCode);

                if (securitiesISINCodeOptional.isPresent()) {
                    SecuritiesISINCode securitiesISINCode = securitiesISINCodeOptional.get();

                    String dataSourceValue = dataSource.getIsinCode();
                    String csaValue = securitiesISINCode.getIsinLBABK();
                    String description = createDescriptionRecon(ISIN_LBABK, csaValue, dataSourceValue);

                    if (!securitiesISINCode.getIsinLBABK().equalsIgnoreCase(dataSource.getIsinCode())) {
                        LBABKRecon recon = LBABKRecon.builder()
                                .createdDate(Instant.now())
                                .month(dataSource.getMonth())
                                .year(dataSource.getYear())
                                .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                                .dataSourceId(dataSource.getId().toString())
                                .code(effectCode)
                                .csaValue(csaValue)
                                .dataSourceValue(dataSourceValue)
                                .description(description)
                                .status(Boolean.FALSE)
                                .flagRecon(ISIN_LBABK)
                                .reconType(RECON_TYPE_SECURITY_CODE)
                                .build();
                        reconRepository.save(recon);
                    }
                } else {
                    DataNotFound dataNotFound = DataNotFound.builder()
                            .createdDate(Instant.now())
                            .month(dataSource.getMonth())
                            .year(dataSource.getYear())
                            .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                            .code(effectCode)
                            .description(createDescriptionDataNotFound(ISIN_CODE_TABLE, "kode efek", effectCode))
                            .status(Boolean.FALSE)
                            .reportType(LBABK)
                            .flagTable(ISIN_CODE_TABLE)
                            .build();
                    dataNotFoundRepository.save(dataNotFound);
                }
            }
        }
    }


    private String createDescriptionRecon(String validationColumn, String csaValue, String dataSourceValue) {
        return String.format(
                "%s doest not match. Because the %s from CSA is %s, while from Data Source it is %s ",
                validationColumn, validationColumn, csaValue, dataSourceValue
        );
    }

    private String createDescriptionDataNotFound(String tableName, String key, String searchKey) {
        return String.format("%s data not found with code (%s): %s", tableName, key, searchKey);
    }

}
