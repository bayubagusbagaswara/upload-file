package com.services.hiportservices.model.emonitoring;

import lombok.AccessLevel;
import lombok.Data;
import lombok.Getter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;

@Entity
@Data
@Table(name = "ORCHIDXD12")
public class OrchidXd12 {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_xd12")
    private Long id;

    @Column(name = "DATE_PROC")
    @Getter(AccessLevel.NONE)
    private Date dateProc;

    @Transient
    @Getter(AccessLevel.NONE)
    private String dateProcStr;

    @Column(name = "STAT_PROC")
    private String statProc;

    @Column(name = "Tanggal")
    @Getter(AccessLevel.NONE)
    private Date tanggal;

    @Transient
    @Getter(AccessLevel.NONE)
    private String tanggalStr;

    @Column(name = "Kode")
    private String kode;

    @Column(name = "Dividend")
    private BigDecimal dividen = BigDecimal.ZERO;

    @Column(name = "Bunga")
    private BigDecimal bunga = BigDecimal.ZERO;

    @Column(name = "TPINVEST")
    private BigDecimal tpInvest = BigDecimal.ZERO;

    @Column(name = "BKelola")
    private BigDecimal bKelola = BigDecimal.ZERO;

    @Column(name = "BKustodi")
    private BigDecimal bKustodi = BigDecimal.ZERO;

    @Column(name = "BLain")
    private BigDecimal bLain = BigDecimal.ZERO;

    @Column(name = "BPiutang")
    private BigDecimal bPiutang = BigDecimal.ZERO;

    @Column(name = "Provisi")
    private BigDecimal provisi = BigDecimal.ZERO;

    @Column(name = "TBIAYA")
    private BigDecimal tbiaya = BigDecimal.ZERO;

    @Column(name = "PINVEST")
    private BigDecimal pInvest = BigDecimal.ZERO;

    @Column(name = "LabaRugi")
    private BigDecimal labaRugi = BigDecimal.ZERO;

    @Column(name = "LabaRugiUR")
    private BigDecimal labaRugiUr = BigDecimal.ZERO;

    @Column(name = "LRINVEST")
    private BigDecimal lrInvest = BigDecimal.ZERO;

    @Column(name = "POPERASI")
    private BigDecimal pOperasi = BigDecimal.ZERO;

    @Column(name = "ReksadanaCode")
    private String reksadanaCode = "";

    public String getTanggalStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(tanggal);
    }

    public String getDateProcStr() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        return sdf.format(dateProc);
    }
}
