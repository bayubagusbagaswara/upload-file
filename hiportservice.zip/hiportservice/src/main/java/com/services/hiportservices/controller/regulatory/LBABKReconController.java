package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.recon.ApproveReconRequest;
import com.services.hiportservices.dto.regulatory.recon.ReconResponse;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.model.regulatory.LBABKRecon;
import com.services.hiportservices.service.regulatory.LBABKReconService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/lbabk-recon")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class LBABKReconController {

    private static final String URL_LBABK_RECON = "/api/regulatory/lbabk-recon";
    private static final String MENU_LBABK_RECON = "Regulatory LBABK Recon";

    private final LBABKReconService reconService;

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDto<List<LBABKRecon>>> getAllByPeriod(@RequestParam("month") String month,
                                                                        @RequestParam("year") Integer year) {

        List<LBABKRecon> reconList = reconService.getAllByMonthAndYear(month, year);
        ResponseDto<List<LBABKRecon>> response = ResponseDto.<List<LBABKRecon>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<LBABKRecon>>> getAll() {
        List<LBABKRecon> all = reconService.getAll();
        ResponseDto<List<LBABKRecon>> response = ResponseDto.<List<LBABKRecon>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(all)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update-recon")
    public ResponseEntity<ResponseDto<ReconResponse>> updateRecon(@RequestBody UpdateReconRequest updateReconRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO dataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputerId(updateReconRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_LBABK_RECON + "/update/approval")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_LBABK_RECON)
                .build();

        ReconResponse reconResponse = reconService.update(updateReconRequest, dataChangeDTO);

        ResponseDto<ReconResponse> response = ResponseDto.<ReconResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approval")
    public ResponseEntity<ResponseDto<ReconResponse>> updateApproval(@RequestBody ApproveReconRequest approveReconRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        ReconResponse reconResponse = reconService.updateApprove(approveReconRequest, approveIPAddress);
        ResponseDto<ReconResponse> response = ResponseDto.<ReconResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/kode-barang")
    public ResponseEntity<ResponseDto<String>> reconSecurityCode(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String status = reconService.reconSecurityCode(month, year);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

}
