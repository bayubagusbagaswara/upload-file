package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.issuercodeplacementbank.*;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.mapper.IssuerCodePlacementBankMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.model.regulatory.IssuerCodePlacementBank;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.repository.regulatory.DataNotFoundRepository;
import com.services.hiportservices.repository.regulatory.IssuerCodePlacementBankRepository;
import com.services.hiportservices.service.regulatory.IssuerCodePlacementBankService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.ISSUER_CODE_PLACEMENT_BANK_TABLE;
import static com.services.hiportservices.enums.ApprovalStatus.Approved;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

@Service
@Slf4j
@RequiredArgsConstructor
public class IssuerCodePlacementBankServiceImpl implements IssuerCodePlacementBankService {

    private static final String CREATE_APPROVE_URL = "/api/regulatory/issuer-placement-bank/create/approve";
    private static final String UPDATE_APPROVE_URL = "/api/regulatory/issuer-placement-bank/update/approve";
    private static final String ID_NOT_FOUND = "Kode Issuer dan Placement Bank not found with id: ";
    private static final String UNKNOWN_CODE = "Unknown Code";

    private final IssuerCodePlacementBankRepository issuerCodePlacementBankRepository;
    private final ObjectMapper objectMapper;
    private final ValidationData validationData;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final IssuerCodePlacementBankMapper issuerCodePlacementBankMapper;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public boolean isCodeAlreadyExists(String code) {
        log.info("Check the existing Issuer Code and Placement Bank with code: {}", code);
        return issuerCodePlacementBankRepository.existsByCode(code);
    }

    @Transactional
    @Override
    public synchronized IssuerCodePlacementBankResponse uploadData(UploadIssuerCodePlacementBankListRequest uploadIssuerCodePlacementBankListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start upload data Issuer Code Placement Bank: {}, {}", uploadIssuerCodePlacementBankListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadIssuerCodePlacementBankDataRequest issuerCodePlacementBankDataRequest : uploadIssuerCodePlacementBankListRequest.getUploadIssuerCodePlacementBankDataRequestList()) {
            List<String> validationErrors = new ArrayList<>();
            IssuerCodePlacementBankDTO issuerCodePlacementBankDTO = null;

            try {
                Errors errors = validationData.validateObject(issuerCodePlacementBankDataRequest);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                issuerCodePlacementBankDTO = issuerCodePlacementBankMapper.fromUploadRequestToDTO(issuerCodePlacementBankDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                            !issuerCodePlacementBankDTO.getCode().isEmpty() ? issuerCodePlacementBankDTO.getCode() : UNKNOWN_CODE,
                            validationErrors
                    );
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    Optional<IssuerCodePlacementBank> issuerCodePlacementBankOptional = issuerCodePlacementBankRepository.findByCode(issuerCodePlacementBankDataRequest.getCode());

                    if (issuerCodePlacementBankOptional.isPresent()) {
                        handleExistingIssuerCodePlacementBank(issuerCodePlacementBankOptional.get(), issuerCodePlacementBankDTO, regulatoryDataChangeDTO);
                    } else {
                        handleNewIssuerCodePlacementBank(issuerCodePlacementBankDTO, regulatoryDataChangeDTO);
                    }
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(issuerCodePlacementBankDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new IssuerCodePlacementBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized IssuerCodePlacementBankResponse createApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress) {
        log.info("Start create approve Issuer Code Placement Bank: {}, {}", approveRequest, approveIPAddress);
        String approveId = approveRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        IssuerCodePlacementBankDTO issuerCodePlacementBankDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveRequest.getDataChangeId());

            issuerCodePlacementBankDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), IssuerCodePlacementBankDTO.class);

            /* validate the code already exists */
            validationCodeAlreadyExists(issuerCodePlacementBankDTO.getCode(), validationErrors);

            if (!validationErrors.isEmpty()) {
                regulatoryDataChangeService.setApprovalStatusIsRejected(dataChange, validationErrors);
                totalDataFailed++;
            } else {
                LocalDateTime approveDate = LocalDateTime.now();

                IssuerCodePlacementBank issuerCodePlacementBank = IssuerCodePlacementBank.builder()
                        .approvalStatus(Approved)
                        .approverId(approveId)
                        .approveDate(approveDate)
                        .approveIPAddress(approveIPAddress)
                        .inputerId(dataChange.getInputerId())
                        .inputDate(dataChange.getInputDate())
                        .inputIPAddress(dataChange.getInputIPAddress())
                        .code(issuerCodePlacementBankDTO.getCode().trim())
                        .bankName(issuerCodePlacementBankDTO.getBankName().trim())
                        .bankType(issuerCodePlacementBankDTO.getBankType().trim())
                        .issuerGroup(issuerCodePlacementBankDTO.getIssuerGroup().trim())
                        .issuerCountry(issuerCodePlacementBankDTO.getIssuerCountry().trim())
                        .securityType(issuerCodePlacementBankDTO.getSecurityType().trim())
                        .effectTypeCode(issuerCodePlacementBankDTO.getEffectTypeCode().trim())
                        .status(issuerCodePlacementBankDTO.getStatus().trim())
                        .currency(issuerCodePlacementBankDTO.getCurrency().trim())
                        .build();

                IssuerCodePlacementBank save = issuerCodePlacementBankRepository.save(issuerCodePlacementBank);

                dataChange.setApproverId(approveId);
                dataChange.setApproveDate(approveDate);
                dataChange.setApproveIPAddress(approveIPAddress);
                dataChange.setJsonDataAfter(save.getId().toString());
                dataChange.setJsonDataAfter(
                        JsonUtil.cleanedEntityDataFromApprovalData(
                                objectMapper.writeValueAsString(save)
                        )
                );
                dataChange.setDescription("Success create approve with id: " + save.getId());
                regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

                /* Get all data not found by FLAG_TABLE and code. The code can be filled with data 1 or data 2 (data source) */
                String code7Digit = extractCode(save.getCode());
                List<DataNotFound> dataNotFoundList = dataNotFoundRepository.findAllByFlagTableAndCode(
                        ISSUER_CODE_PLACEMENT_BANK_TABLE, code7Digit
                );

                if (!dataNotFoundList.isEmpty()) {
                    dataNotFoundList.forEach(dataNotFound -> dataNotFound.setStatus(Boolean.TRUE));
                    dataNotFoundRepository.saveAll(dataNotFoundList);
                }

                totalDataSuccess++;
            }

        } catch (Exception e) {
            handleGeneralError(issuerCodePlacementBankDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new IssuerCodePlacementBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized IssuerCodePlacementBankResponse updateApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress) {
        log.info("Start update approve Issuer Code Placement Bank: {}, {}", approveRequest, approveIPAddress);
        String approveId = approveRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        IssuerCodePlacementBankDTO issuerCodePlacementBankDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveRequest.getDataChangeId());

            issuerCodePlacementBankDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), IssuerCodePlacementBankDTO.class);

            IssuerCodePlacementBank issuerCodePlacementBank = issuerCodePlacementBankRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            if (!issuerCodePlacementBankDTO.getBankName().isEmpty()) {
                issuerCodePlacementBank.setBankName(issuerCodePlacementBankDTO.getBankName().trim());
            }

            if (!issuerCodePlacementBankDTO.getBankType().isEmpty()) {
                issuerCodePlacementBank.setBankType(issuerCodePlacementBankDTO.getBankType().trim());
            }

            if (!issuerCodePlacementBankDTO.getIssuerGroup().isEmpty()) {
                issuerCodePlacementBank.setIssuerGroup(issuerCodePlacementBankDTO.getIssuerGroup().trim());
            }

            if (!issuerCodePlacementBankDTO.getIssuerCountry().isEmpty()) {
                issuerCodePlacementBank.setIssuerCountry(issuerCodePlacementBankDTO.getIssuerCountry().trim());
            }

            if (!issuerCodePlacementBankDTO.getSecurityType().isEmpty()) {
                issuerCodePlacementBank.setSecurityType(issuerCodePlacementBankDTO.getSecurityType().trim());
            }

            if (!issuerCodePlacementBankDTO.getEffectTypeCode().isEmpty()) {
                issuerCodePlacementBank.setEffectTypeCode(issuerCodePlacementBankDTO.getEffectTypeCode().trim());
            }

            if (!issuerCodePlacementBankDTO.getStatus().isEmpty()) {
                issuerCodePlacementBank.setStatus(issuerCodePlacementBankDTO.getStatus().trim());
            }

            if (!issuerCodePlacementBankDTO.getCurrency().isEmpty()) {
                issuerCodePlacementBank.setCurrency(issuerCodePlacementBankDTO.getCurrency().trim());
            }

            LocalDateTime approveDate = LocalDateTime.now();

            issuerCodePlacementBank.setApprovalStatus(Approved);
            issuerCodePlacementBank.setApproverId(approveId);
            issuerCodePlacementBank.setApproveIPAddress(approveIPAddress);
            issuerCodePlacementBank.setApproveDate(approveDate);
            issuerCodePlacementBank.setInputerId(dataChange.getInputerId());
            issuerCodePlacementBank.setInputIPAddress(dataChange.getInputIPAddress());
            issuerCodePlacementBank.setInputDate(dataChange.getInputDate());

            IssuerCodePlacementBank save = issuerCodePlacementBankRepository.save(issuerCodePlacementBank);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setJsonDataAfter(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(save)
                    )
            );
            dataChange.setDescription("Success update approve with id: " + save.getId());
            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(issuerCodePlacementBankDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new IssuerCodePlacementBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized IssuerCodePlacementBankResponse deleteById(DeleteIssuerCodePlacementBankRequest deleteIssuerCodePlacementBankRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start delete Issuer Code Placement Bank by id: {}, {}", deleteIssuerCodePlacementBankRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        IssuerCodePlacementBankDTO issuerCodePlacementBankDTO = null;

        try {
            IssuerCodePlacementBank issuerCodePlacementBank = issuerCodePlacementBankRepository.findById(deleteIssuerCodePlacementBankRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + deleteIssuerCodePlacementBankRequest.getId()));

            issuerCodePlacementBankDTO = issuerCodePlacementBankMapper.toDTO(issuerCodePlacementBank);

            regulatoryDataChangeDTO.setEntityId(issuerCodePlacementBank.getId().toString());
            regulatoryDataChangeDTO.setJsonDataBefore(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(issuerCodePlacementBank)
                    )
            );
            regulatoryDataChangeDTO.setJsonDataAfter("");
            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
            regulatoryDataChangeService.createChangeActionDelete(regulatoryDataChange, IssuerCodePlacementBank.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(issuerCodePlacementBankDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new IssuerCodePlacementBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized IssuerCodePlacementBankResponse deleteApprove(ApproveIssuerCodePlacementBankRequest approveRequest, String approveIPAddress) {
        log.info("Delete approve Issuer Code Placement Bank: {}, {}", approveRequest, approveIPAddress);
        String approveId = approveRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        IssuerCodePlacementBankDTO issuerCodePlacementBankDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveRequest.getDataChangeId());

            IssuerCodePlacementBank issuerCodePlacementBank = issuerCodePlacementBankRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            issuerCodePlacementBankDTO = issuerCodePlacementBankMapper.toDTO(issuerCodePlacementBank);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(LocalDateTime.now());
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setDescription("Success delete approve with id: " + issuerCodePlacementBank.getId());

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            /* delete entity */
            issuerCodePlacementBankRepository.delete(issuerCodePlacementBank);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(issuerCodePlacementBankDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new IssuerCodePlacementBankResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public IssuerCodePlacementBankDTO getById(Long id) {
        log.info("Start get Issuer Code Placement Bank by id: {}", id);
        IssuerCodePlacementBank issuerCodePlacementBank = issuerCodePlacementBankRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));
        return issuerCodePlacementBankMapper.toDTO(issuerCodePlacementBank);
    }

    @Override
    public IssuerCodePlacementBankDTO getByCode(String code) {
        log.info("Start get Issuer Code Placement Bank by code: {}", code);
        IssuerCodePlacementBank issuerCodePlacementBank = issuerCodePlacementBankRepository.findByCode(code)
                .orElseThrow(() -> new DataNotFoundHandleException("Issuer Code and Placement Bank not found with code: " + code));
        return issuerCodePlacementBankMapper.toDTO(issuerCodePlacementBank);
    }

    @Override
    public List<IssuerCodePlacementBankDTO> getAll() {
        log.info("Start get all Issuer Code Placement Bank");
        List<IssuerCodePlacementBank> all = issuerCodePlacementBankRepository.findAll();
        return issuerCodePlacementBankMapper.toDTOList(all);
    }

    private void handleGeneralError(IssuerCodePlacementBankDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        dto != null && !dto.getCode().isEmpty() ? dto.getCode() : UNKNOWN_CODE,
                        validationErrors
                )
        );
    }

    private void validationCodeAlreadyExists(String code, List<String> validationErrors) {
        if (isCodeAlreadyExists(code)) {
            validationErrors.add("Kode Issuer dan Placement Bank is already taken with code: " + code);
        }
    }

    private void handleNewIssuerCodePlacementBank(IssuerCodePlacementBankDTO issuerCodePlacementBankDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(POST.name());
        regulatoryDataChangeDTO.setEndpoint(CREATE_APPROVE_URL);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(issuerCodePlacementBankDTO)
                )
        );
        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory Data Change add: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionAdd(regulatoryDataChange, IssuerCodePlacementBank.class);
    }

    private void handleExistingIssuerCodePlacementBank(IssuerCodePlacementBank issuerCodePlacementBankEntity, IssuerCodePlacementBankDTO issuerCodePlacementBankDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(PUT.name());
        regulatoryDataChangeDTO.setEndpoint(UPDATE_APPROVE_URL);

        regulatoryDataChangeDTO.setEntityId(issuerCodePlacementBankEntity.getId().toString());
        regulatoryDataChangeDTO.setJsonDataBefore(
                JsonUtil.cleanedEntityDataFromApprovalData(
                        objectMapper.writeValueAsString(issuerCodePlacementBankEntity)
                )
        );

        IssuerCodePlacementBankDTO temp = IssuerCodePlacementBankDTO.builder()
                .code(issuerCodePlacementBankEntity.getCode())
                .bankName(
                        !issuerCodePlacementBankDTO.getBankName().isEmpty()
                                ? issuerCodePlacementBankDTO.getBankName()
                                : issuerCodePlacementBankEntity.getBankName()
                )
                .bankType(
                        !issuerCodePlacementBankDTO.getBankType().isEmpty()
                                ? issuerCodePlacementBankDTO.getBankType()
                                : issuerCodePlacementBankEntity.getBankType()
                )
                .issuerGroup(
                        !issuerCodePlacementBankDTO.getIssuerGroup().isEmpty()
                                ? issuerCodePlacementBankDTO.getIssuerGroup()
                                : issuerCodePlacementBankEntity.getIssuerGroup()
                )
                .issuerCountry(
                        !issuerCodePlacementBankDTO.getIssuerCountry().isEmpty()
                                ? issuerCodePlacementBankDTO.getIssuerCountry()
                                : issuerCodePlacementBankEntity.getIssuerCountry()
                )
                .securityType(
                        !issuerCodePlacementBankDTO.getSecurityType().isEmpty()
                                ? issuerCodePlacementBankDTO.getSecurityType()
                                : issuerCodePlacementBankEntity.getSecurityType()
                )
                .effectTypeCode(
                        !issuerCodePlacementBankDTO.getEffectTypeCode().isEmpty()
                                ? issuerCodePlacementBankDTO.getEffectTypeCode()
                                : issuerCodePlacementBankEntity.getEffectTypeCode()
                )
                .status(
                        !issuerCodePlacementBankDTO.getStatus().isEmpty()
                                ? issuerCodePlacementBankDTO.getStatus()
                                : issuerCodePlacementBankEntity.getStatus()
                )
                .currency(
                        !issuerCodePlacementBankDTO.getCurrency().isEmpty()
                                ? issuerCodePlacementBankDTO.getCurrency()
                                : issuerCodePlacementBankEntity.getCurrency()
                )
                .build();

        log.info("Temp: {}", temp);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(temp)
                )
        );

        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory data change edit: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, IssuerCodePlacementBank.class);
    }

    public static String extractCode(String input) {
        Pattern pattern = Pattern.compile("(TDC|TDS)\\d+");
        Matcher matcher = pattern.matcher(input);

        if (matcher.find()) {
            return matcher.group();
        }

        return "Code not found";
    }
}
