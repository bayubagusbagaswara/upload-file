package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.regulatory.approval.RegulatoryApproval;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "reg_asuransi_dana_pensiun")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class InsurancePensionFund extends RegulatoryApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "portfolio_name")
    private String portfolioName;

    @Column(name = "regulatory_name")
    private String regulatoryName;

    @Column(name = "insurance_pension_fund_ref")
    private String insurancePensionFundReference;

    @Column(name = "guarantee_fund")
    private String guaranteeFund;

}
