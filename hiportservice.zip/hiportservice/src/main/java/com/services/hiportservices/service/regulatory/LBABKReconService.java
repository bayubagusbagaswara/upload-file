package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.recon.ApproveReconRequest;
import com.services.hiportservices.dto.regulatory.recon.ReconResponse;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.model.regulatory.LBABKRecon;

import java.util.List;

public interface LBABKReconService {

    List<LBABKRecon> getAll();

    List<LBABKRecon> getAllByMonthAndYear(String month, Integer year);

    ReconResponse update(UpdateReconRequest updateReconRequest, RegulatoryDataChangeDTO dataChangeDTO);

    ReconResponse updateApprove(ApproveReconRequest approveReconRequest, String approveIPAddress);

    String reconSecurityCode(String month, Integer year);

}
