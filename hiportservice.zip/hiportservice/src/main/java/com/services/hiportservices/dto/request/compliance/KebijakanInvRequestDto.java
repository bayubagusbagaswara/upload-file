package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class KebijakanInvRequestDto {
    private String kinvCode;
    private String kebijakanName;
    private String types;
    private boolean isDelete;
}
