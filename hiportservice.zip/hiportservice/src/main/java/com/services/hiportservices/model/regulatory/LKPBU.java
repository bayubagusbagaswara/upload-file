package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "reg_lkpbu")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBU {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private Instant createdDate;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "flag_detail")
    private String flagDetail; // FlagDetail

    @Column(name = "kode_komponen")
    private String kodeKomponen; // KodeKomponen (tambahkan 0 diawal)

    @Column(name = "golongan_pemilik")
    private String golonganPemilik; // Golongan Pemilik

    @Column(name = "sandi_perusahaan_asuransi")
    private String sandiPerusahaanAsuransi; // Sandi Perusahaan Asuransi

    @Column(name = "negara_asal")
    private String negaraAsal; // Negara Asal

    @Column(name = "golongan_penerbit")
    private String golonganPenerbit; // Golongan Penerbit

    @Column(name = "negara")
    private String negara; // Negara

    @Column(name = "isin_code")
    private String isinCode; // Kode ISIN

    @Column(name = "jenis")
    private String jenis; // Jenis

    @Column(name = "kode_efek")
    private String kodeEfek; // Kode Efek/Nama bank

    @Column(name = "lembar_unit")
    private BigDecimal lembarUnit; // lembar/unit

    @Column(name = "interest_rate")
    private String interestRate; // interest rate/kupon

    @Column(name = "keterangan")
    private String keterangan; // keterangan

    @Column(name = "dana_jaminan")
    private String danaJaminan; // dana jaminan/investasi

    @Column(name = "jenis_valuta")
    private String jenisValuta; // jenis valuta

    @Column(name = "penerbitan")
    private String penerbitan; // penerbitan

    @Column(name = "jatuh_tempo")
    private String jatuhTempo; // jatuh tempo

    @Column(name = "nilai_valuta_asal")
    private BigDecimal nilaiValutaAsal; // nilai valuta asal (bigdecimal)

    @Column(name = "pembayaran_kupon")
    private BigDecimal pembayaranKupon; // pembayaran kupon (bigdecimal)

    @Column(name = "type_effect")
    private String typeEffect; // untuk keperluan grouping calculate LBABK Sheet 2 (AUC)

    @Column(name = "concat_data")
    private String concatData; // combine data1 and data 2

}
