package com.services.hiportservices.dto.regulatory.exchangerate;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DeleteExchangeRateRequest extends InputIdentifierRequest {

    private Long id;

}
