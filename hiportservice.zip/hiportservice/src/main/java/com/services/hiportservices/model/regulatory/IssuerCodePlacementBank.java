package com.services.hiportservices.model.regulatory;

import com.services.hiportservices.model.regulatory.approval.RegulatoryApproval;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;

@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "reg_issuer_code_placement_bank")
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class IssuerCodePlacementBank extends RegulatoryApproval {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "code")
    private String code;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "bank_type")
    private String bankType;

    @Column(name = "issuer_group")
    private String issuerGroup;

    @Column(name = "issuer_country")
    private String issuerCountry;

    @Column(name = "security_type")
    private String securityType;

    @Column(name = "effect_type_code")
    private String effectTypeCode;

    @Column(name = "status")
    private String status;

    @Column(name = "currency")
    private String currency;

}
