package com.services.hiportservices.utils.regulatory;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@UtilityClass
@Slf4j
public class StringUtil {

    public static String processString(String value) {
        String processedValue = !value.isEmpty() ? value : "";
        processedValue = processedValue.trim();
        return processedValue;
    }

    public static String removeWhitespaceBetweenCharacters(String input) {
        return input.replaceAll("\\s+", "").trim();
    }

    public static String replaceBlanksWithUnderscores(String input) {
        return input.replaceAll("\\s", "_");
    }

    public static String joinStrings(List<String> stringList) {
        return String.join(", ", stringList);
    }

    public static String capitalizeFirstLetter(String input) {
        if (input == null || input.isEmpty()) {
            return input;
        }

        return input.substring(0, 1).toUpperCase() + input.substring(1).toLowerCase();
    }

}
