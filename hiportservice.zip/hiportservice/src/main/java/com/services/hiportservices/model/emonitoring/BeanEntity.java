package com.services.hiportservices.model.emonitoring;

import javax.persistence.MappedSuperclass;
import java.io.Serializable;

@MappedSuperclass
public class BeanEntity implements Serializable {
    private static final long serialVersionUID = 1L;
}
