package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd16;
import com.services.hiportservices.model.emonitoring.OrchidXdAktif;
import com.services.hiportservices.repository.emonitoring.OrchidXd11Repository;
import com.services.hiportservices.repository.emonitoring.OrchidXd16Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;

@Service
public class OrchidXd16Service {
    @Autowired
    OrchidXd16Repository orchidXd16Repository;

    public List<OrchidXd16> insertOrUpdateAll(String date, String pf, String group) throws SQLException, ClassNotFoundException {

        List<OrchidXd16> listOrchid = new ArrayList<>();
        Class.forName("com.dstglobalsolutions.dro.jdbc.openaccess.OpenAccessDriver");
        Connection con = DriverManager.getConnection("jdbc:DRO://10.197.31.137:29996;ServerDataSource=HIPORTDSN;USER=ADMIN;PASSWORD=DANAMON01");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(queryInsert(date, pf, group));
        System.out.println(date);
        while (rs.next()) {
            OrchidXd16 orchidXd16 = orchidXd16Repository.findByReksadanaAndDate1(
                    rs.getString("PfCode"), date);

            if(orchidXd16 == null){
                System.out.println("baru?");
                orchidXd16 = new OrchidXd16();
            }

            orchidXd16.setDate1(date);
            orchidXd16.setDate2(date);
            orchidXd16.setDate3(date);
            orchidXd16.setPortfolioCode(rs.getString("Kode"));
            orchidXd16.setVal1("1");
            orchidXd16.setVal2("0");
            orchidXd16.setVal3("0");
            orchidXd16.setVal4("0");
            orchidXd16.setDESC1("INSTRUMEN HUTANG");
            orchidXd16.setReksadana(rs.getString("PfCode"));

            listOrchid.add(orchidXd16);
        }
        con.close();


        return orchidXd16Repository.saveAll(listOrchid);
    }

    private BigDecimal toDoubleValue(String data) {
        String doubleData = data.contains("-") ?
                "-" + data.replace("-", "").trim()
                : data.trim();
        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    private String queryInsert(String date, String pf, String group) {

        String param = " ";
        if (pf != null && !pf.isEmpty()) {
            param = " AND  pfG.PfCode in ('" + pf + "') ";
        }

        System.out.println(param);
//        String query = " SELECT pfG.PfCode, up.ExternalRef as Kode \n" +
//                " FROM PORTFOLIOGROUP pfG \n" +
//                " JOIN PORTFOLIO p on pfG.PfCode = p.CODE \n" +
//                "     and p.ActiveFlag = 1 and pfG.Code = '" + group + "' \n" +
//                " JOIN UNITISEDPORTFOLIO up \n" +
//                "     on pfg.PfCode = up.code " +
//                param;

        String query = "SELECT pfG.PfCode, up.ExternalRef, p.InceptionDate \n" +
                "    FROM PORTFOLIOGROUP pfG \n" +
                "    JOIN PORTFOLIO p on pfG.PfCode = p.CODE \n" +
                "         and p.ActiveFlag = 1 and pfG.Code = '" + group + "' \n" +
                "    JOIN UNITISEDPORTFOLIO up \n" +
                "    on pfg.PfCode = up.code \n" +
                "    where p.InceptionDate < '"+ date +"' " +
                param;

        System.out.println(query);

        return query;
    }

    public List<OrchidXd16> getDataXD11(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd16> listOrchid = new ArrayList<>();

        try {
            Date dateParm = sdf.parse(date);
            if (pfCode == null || pfCode.isEmpty()) {
                listOrchid.addAll(orchidXd16Repository.findAllByDate1(date));

            } else {
                listOrchid.addAll(orchidXd16Repository.searchDataAt(date, pfCode));
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
