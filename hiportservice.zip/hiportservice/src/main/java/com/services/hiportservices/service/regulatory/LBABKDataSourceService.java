package com.services.hiportservices.service.regulatory;

public interface LBABKDataSourceService {

    String readAndInsertToDB();

}
