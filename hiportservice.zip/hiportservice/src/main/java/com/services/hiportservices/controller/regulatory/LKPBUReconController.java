package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.recon.ApproveReconRequest;
import com.services.hiportservices.dto.regulatory.recon.ReconResponse;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.model.regulatory.LKPBUDataSource;
import com.services.hiportservices.model.regulatory.LKPBURecon;
import com.services.hiportservices.service.regulatory.LKPBUReconService;
import com.services.hiportservices.utils.regulatory.ClientIPUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/lkpbu-recon")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class LKPBUReconController {

    private static final String URL_LKPBU_RECON = "/api/regulatory/lkpbu-recon";
    private static final String MENU_LKPBU_RECON = "Regulatory LKPBU Recon";

    private final LKPBUReconService reconService;

    @GetMapping(path = "/period")
    public ResponseEntity<ResponseDto<List<LKPBURecon>>> getAllByPeriod(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        List<LKPBURecon> reconList = reconService.getAllByMonthAndYear(month, year);
        ResponseDto<List<LKPBURecon>> response = ResponseDto.<List<LKPBURecon>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<LKPBURecon>>> getAll() {
        List<LKPBURecon> all = reconService.getAll();
        ResponseDto<List<LKPBURecon>> response = ResponseDto.<List<LKPBURecon>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(all)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update-recon")
    public ResponseEntity<ResponseDto<ReconResponse>> updateRecon(@RequestBody UpdateReconRequest updateReconRequest, HttpServletRequest servletRequest) {
        String inputIPAddress = ClientIPUtil.getClientIP(servletRequest);
        RegulatoryDataChangeDTO dataChangeDTO = RegulatoryDataChangeDTO.builder()
                .inputerId(updateReconRequest.getInputerId())
                .inputIPAddress(inputIPAddress)
                .inputDate(LocalDateTime.now())
                .methodHttp(HttpMethod.PUT.name())
                .endpoint(URL_LKPBU_RECON + "/update/approval")
                .isRequestBody(true)
                .isRequestParam(false)
                .isPathVariable(false)
                .menu(MENU_LKPBU_RECON)
                .build();

        ReconResponse reconResponse = reconService.update(updateReconRequest, dataChangeDTO);
        ResponseDto<ReconResponse> response = ResponseDto.<ReconResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconResponse)
                .build();

        return ResponseEntity.ok(response);
    }

    @PutMapping(path = "/update/approval")
    public ResponseEntity<ResponseDto<ReconResponse>> updateApproval(@RequestBody ApproveReconRequest approveReconRequest, HttpServletRequest servletRequest) {
        String approveIPAddress = ClientIPUtil.getClientIP(servletRequest);
        ReconResponse reconResponse = reconService.updateApprove(approveReconRequest, approveIPAddress);
        ResponseDto<ReconResponse> response = ResponseDto.<ReconResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconResponse)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/test/kode-barang")
    public ResponseEntity<ResponseDto<List<LKPBUDataSource>>> getAllDistinctSecurityCode(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        List<LKPBUDataSource> dataSourceList = reconService.getAllDistinctSecurityCode(month, year);
        ResponseDto<List<LKPBUDataSource>> response = ResponseDto.<List<LKPBUDataSource>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataSourceList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/test/kode-nasabah")
    public ResponseEntity<ResponseDto<List<LKPBUDataSource>>> getAllDistinctPortfolioCode(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        List<LKPBUDataSource> dataSourceList = reconService.getAllDistinctPortfolioCode(month, year);
        ResponseDto<List<LKPBUDataSource>> response = ResponseDto.<List<LKPBUDataSource>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataSourceList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/kode-nasabah")
    public ResponseEntity<ResponseDto<String>> reconPortfolioCode(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String status = reconService.reconPortfolioCode(month, year);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/kode-barang")
    public ResponseEntity<ResponseDto<String>> reconSecurityCode(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String status = reconService.reconSecurityCode(month, year);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

}
