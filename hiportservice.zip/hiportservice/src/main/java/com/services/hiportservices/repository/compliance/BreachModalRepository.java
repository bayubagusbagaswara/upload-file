package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.model.compliance.BreachModal;
import com.services.hiportservices.model.compliance.BreachReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BreachModalRepository extends JpaRepository<BreachModal,Long> {

    @Query(value="SELECT * FROM comp_breach_modal_disetor WHERE data_date = :dataDate", nativeQuery = true)
    List<BreachModal> searchDataAt(@Param("dataDate") String dataDate);
}
