package com.services.hiportservices.dto.regulatory.lbabk;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABKDTO {

    private Long id;

    private String flagDetail;

    private String kodeKomponen;

    private String tanggalTransaksi; // yyyyMMdd

    private String kodeTipeEfek;

    private String keteranganTipeEfek;

    private String isinCode;

    private String securityName;

    private String issuerCode;

    private String issuerName;

    private String kodeMataUang;

    private String buyFrequency; // from Integer

    private String buyVolume; // from BigDecimal to String

    private String buyValue; // from BigDecimal to String

    private String buyInvestorIndonesia; // from BigDecimal to String

    private String buyInvestorForeign; // from BigDecimal to String

    private String buyInvestorConfirmation; // from BigDecimal to String

    private String sellFrequency; // from BigDecimal to String

    private String sellVolume; // from BigDecimal to String

    private String sellValue; // from BigDecimal to String

    private String sellInvestorIndonesia; // from BigDecimal to String

    private String sellInvestorForeign; // from BigDecimal to String

    private String sellInvestorConfirmation; // from BigDecimal to String

}
