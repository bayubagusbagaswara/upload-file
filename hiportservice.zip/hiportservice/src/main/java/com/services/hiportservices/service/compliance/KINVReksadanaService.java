package com.services.hiportservices.service.compliance;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.request.compliance.KINVReksadanaRequestDTO;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.enums.ChangeAction;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.utils.UserIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.*;


@Service
public class KINVReksadanaService {

    @Autowired
    KINVReksadanaRepository kinvReksadanaRepository;
    @Autowired
    ReksadanaRepository reksadanaRepository;
    @Autowired
    MasterKebijakanInvestasiRepository masterKebijakanInvestasiRepository;
    @Autowired
    ComplianceDataChangeRepository complianceDataChangeRepository;

//    public ResponseEntity<ResponseDto> insertListKinvReksadana(List<KINVReksadanaRequestDTO> kinvReksadanaRequestDTOLit) {
//        String message = "Success insert new mapping KINV Reksadana";
//        ResponseDto responseDto = new ResponseDto();
//        try{
//            for (KINVReksadanaRequestDTO kinvReksadanaRequestDTO : kinvReksadanaRequestDTOLit){
//                Reksadana reksadana = reksadanaRepository.findByCode(kinvReksadanaRequestDTO.getReksadanaCode());
//                MasterKebijakanInvestasi masterKebijakanInvestasi = masterKebijakanInvestasiRepository.findByKinvCode(kinvReksadanaRequestDTO.getKinvCode());
//                KINVReksadana kinvReksadana = kinvReksadanaRepository.checkDataExistOrNot(ApprovalStatus.Approved,
//                        reksadana, masterKebijakanInvestasi);
//
//                if(kinvReksadana == null){
//                    kinvReksadana = new KINVReksadana();
//                    kinvReksadana.setApprovalStatus(ApprovalStatus.Pending);
//                    kinvReksadana.setInputDate(new Date());
//                    kinvReksadana.setInputerId(UserIdUtil.getUser());
//                    kinvReksadana.setKinvCode(masterKebijakanInvestasi);
//                    kinvReksadana.setKinvMax(kinvReksadanaRequestDTO.getKinvMax());
//                    kinvReksadana.setKinvMin(kinvReksadanaRequestDTO.getKinvMin());
//                    kinvReksadana.setRdExternalCode(reksadana.getExternalCode());
//                    kinvReksadana.setReksadanaCode(reksadana);
//                    kinvReksadanaRepository.save(kinvReksadana);
//
//                } else {
//                    kinvReksadana.setApprovalStatus(ApprovalStatus.Pending);
//                    kinvReksadana.setInputDate(new Date());
//                    kinvReksadana.setInputerId(UserIdUtil.getUser());
//                    kinvReksadana.setKinvCode(masterKebijakanInvestasi);
//                    kinvReksadana.setKinvMax(kinvReksadanaRequestDTO.getKinvMax());
//                    kinvReksadana.setKinvMin(kinvReksadanaRequestDTO.getKinvMin());
//                    kinvReksadana.setRdExternalCode(reksadana.getExternalCode());
//                    kinvReksadanaRepository.save(kinvReksadana);
//
//                    message = "Success update mapping KINV Reksadana";
//                }
//
//            }
//
//            responseDto.setCode(HttpStatus.OK.toString());
//            responseDto.setMessage("OK");
//            responseDto.setPayload(message);
//        }catch (Exception e){
//            e.printStackTrace();
//        }
//
//
//        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
//    }

    public ResponseEntity<ResponseDto> getByReksadanaCode(String code) {
        Reksadana reksadana = reksadanaRepository.findByCode(code);
        ResponseDto responseDto =new com.services.hiportservices.dto.ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(kinvReksadanaRepository.findAllByApprovalStatusAndReksadanaCode(ApprovalStatus.Approved, reksadana));

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);

    }

    public ResponseEntity<ResponseDto> allPendingDataKinvReksadana() {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(kinvReksadanaRepository.searchPendingData());
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> approveDataKinvReksadana(Map<String, List<String>> idList) {
        ResponseDto responseDto =new ResponseDto();
        String approverId = UserIdUtil.getUser();
        List<String> ids = idList.get("idList");
        try {
            for (String id : ids){
                kinvReksadanaRepository.approveOrRejectKinvReksadana("Approved", new Date(), approverId, Long.valueOf(id));
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have approved!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> rejectDataKinvReksadana(Map<String, List<String>> idList) {
        ResponseDto responseDto =new ResponseDto();
        String approverId = UserIdUtil.getUser();
        List<String> ids = idList.get("idList");
        try {
            for (String id : ids){
                KINVReksadana kinvReksadana = kinvReksadanaRepository.findById(Long.valueOf(id)).orElseThrow(()-> new RuntimeException("Data Not Found!"));
                if (kinvReksadana != null){
                    kinvReksadanaRepository.delete(kinvReksadana);
                }
            }
            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload("Data have approved!");
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> insertKinvReksadanaUpload(String param, List<Map<String, String>> kinvRekasaDanaList) {
        String message = "Input data success!";
        ResponseDto responseDto = new ResponseDto();
        List<KINVReksadana> newKinvReksadanaList =  new ArrayList<>();
        List<ComplianceDataChange> newComplianceDataChangeList = new ArrayList<>();
        try {
            if (param.equalsIgnoreCase("new")) {
                int row = 1;
                for (Map<String, String> kinvRekasaDana : kinvRekasaDanaList) {
                    row += 1;
                    String reksadanaCode = kinvRekasaDana.get("reksadanaCode").trim();
                    String kinvCode = kinvRekasaDana.get("kinvCode").trim();
                    String kinvMin = kinvRekasaDana.get("kinvMin");
                    String kinvMax = kinvRekasaDana.get("kinvMax");

                    if (reksadanaCode == "" || reksadanaCode == null || reksadanaCode.isEmpty() ||
                            kinvCode == "" || kinvCode == null || kinvCode.isEmpty()) {
                        throw new Exception("Reksadana Code or KINV Code in Row: " + row + " cannot be empty!");
                    }

                    Reksadana reksadana = reksadanaRepository.findByCodeAndDelete(reksadanaCode, false);
                    if (reksadana == null) {
                        throw new Exception("Row: " + row + " Reksadana " + reksadanaCode + " not exist!");
                    }

                    MasterKebijakanInvestasi masterKebijakanInvestasi = masterKebijakanInvestasiRepository.findByKinvCode(kinvCode);
                    if (masterKebijakanInvestasi == null) {
                        throw new Exception("Row: " + row + " Kebijakan " + masterKebijakanInvestasi + " not exist!");
                    }

                    KINVReksadana kinvReksadana = kinvReksadanaRepository.checkDataExistOrNot(ApprovalStatus.Approved, reksadana, masterKebijakanInvestasi);
                    if (kinvReksadana == null){
                        kinvReksadana = new KINVReksadana();
                        kinvReksadana.setApprovalStatus(ApprovalStatus.Pending);
                        kinvReksadana.setInputerId(UserIdUtil.getUser());
                        kinvReksadana.setInputDate(new Date());
                        kinvReksadana.setReksadanaCode(reksadana);
                        kinvReksadana.setKinvCode(masterKebijakanInvestasi);
                        kinvReksadana.setRdExternalCode(reksadana.getExternalCode());
                        if (kinvMin == "" || kinvMin == null || kinvMin.isEmpty()){
                            throw new Exception("KINV Minimum for New KINV Reksadana cannot be Empty in row: " + row + "!");
                        } else {
                            kinvReksadana.setKinvMin(Double.valueOf(kinvMin));
                        }

                        if (kinvMax == "" || kinvMax == null || kinvMax.isEmpty()){
                            throw new Exception("KINV Maximum for New KINV Reksadana cannot be Empty in row: " + row + "!");
                        } else {
                            kinvReksadana.setKinvMax(Double.valueOf(kinvMax));
                        }

                        newKinvReksadanaList.add(kinvReksadana);
                    } else {
                        KINVReksadana kinvReksadanaAfter = new KINVReksadana();
                        kinvReksadanaAfter.setInputerId(UserIdUtil.getUser());
                        kinvReksadanaAfter.setInputDate(new Date());
                        kinvReksadanaAfter.setReksadanaCode(reksadana);
                        kinvReksadanaAfter.setKinvCode(masterKebijakanInvestasi);
                        kinvReksadanaAfter.setRdExternalCode(reksadana.getExternalCode());
                        if (kinvMin == "" || kinvMin == null || kinvMin.isEmpty()){
                            kinvReksadanaAfter.setKinvMin(kinvReksadana.getKinvMin());
                        } else {
                            kinvReksadanaAfter.setKinvMin(Double.valueOf(kinvMin));
                        }

                        if (kinvMax == "" || kinvMax == null || kinvMax.isEmpty()){
                            kinvReksadanaAfter.setKinvMax(kinvReksadana.getKinvMax());
                        } else {
                            kinvReksadanaAfter.setKinvMax(Double.valueOf(kinvMax));
                        }

                        ObjectMapper Obj = new ObjectMapper();
                        String jsonbefore = Obj.writeValueAsString(kinvReksadana);
                        ObjectMapper ObjAfter = new ObjectMapper();
                        String jsonAfter = ObjAfter.writeValueAsString(kinvReksadanaAfter);

                        ComplianceDataChange dataChange = new ComplianceDataChange();
                        dataChange.setApprovalStatus(ApprovalStatus.Pending);
                        dataChange.setInputerId(UserIdUtil.getUser());
                        dataChange.setInputDate(new Date());
                        dataChange.setAction(ChangeAction.Edit);
                        dataChange.setEntityId(String.valueOf(kinvReksadana.getId()));
                        dataChange.setTableName("comp_kinv_reksadana");
                        dataChange.setEntityClassName(KINVReksadana.class.getName());
                        dataChange.setDataBefore(jsonbefore);
                        dataChange.setDataChange(jsonAfter);

                        newComplianceDataChangeList.add(dataChange);
                    }
                }
                complianceDataChangeRepository.saveAll(newComplianceDataChangeList);
                kinvReksadanaRepository.saveAll(newKinvReksadanaList);
            } else if (param.equalsIgnoreCase("delete")) {
                int row = 1;
                for (Map<String, String> kinvRekasaDana : kinvRekasaDanaList) {
                    row += 1;
                    String reksadanaCode = kinvRekasaDana.get("reksadanaCode").trim();
                    String kinvCode = kinvRekasaDana.get("kinvCode").trim();
                    String kinvMin = kinvRekasaDana.get("kinvMin");
                    String kinvMax = kinvRekasaDana.get("kinvMax");

                    if (reksadanaCode == "" || reksadanaCode == null || kinvCode == "" || kinvCode == null || kinvMin == "" || kinvMin == null || kinvMax == "" || kinvMax == null) {
                        throw new Exception("Required properties are missing in Row: " + row);
                    }

                    Reksadana reksadana = reksadanaRepository.findByCodeAndDelete(reksadanaCode, false);
                    if (reksadana == null) {
                        throw new Exception("Row: " + row + " Reksadana " + reksadanaCode + " not exist!");
                    }

                    MasterKebijakanInvestasi masterKebijakanInvestasi = masterKebijakanInvestasiRepository.findByKinvCode(kinvCode);
                    if (masterKebijakanInvestasi == null) {
                        throw new Exception("Row: " + row + " Kebijakan " + masterKebijakanInvestasi + " not exist!");
                    }

                    KINVReksadana kinvReksadana = kinvReksadanaRepository.checkDataExistOrNot(ApprovalStatus.Approved, reksadana, masterKebijakanInvestasi);
                    if(kinvReksadana == null){
                        throw new Exception("Row: " + row + " this kinv are not registered for reksadana " + reksadanaCode );
                    } else {
                        KINVReksadana kinvReksadanaAfter = new KINVReksadana();
                        ObjectMapper Obj = new ObjectMapper();
                        String jsonbefore = Obj.writeValueAsString(kinvReksadana);
                        ObjectMapper ObjAfter = new ObjectMapper();
                        String jsonAfter = ObjAfter.writeValueAsString(kinvReksadanaAfter);

                        ComplianceDataChange dataChange = new ComplianceDataChange();
                        dataChange.setApprovalStatus(ApprovalStatus.Pending);
                        dataChange.setInputerId(UserIdUtil.getUser());
                        dataChange.setInputDate(new Date());
                        dataChange.setAction(ChangeAction.Delete);
                        dataChange.setEntityId(String.valueOf(kinvReksadana.getId()));
                        dataChange.setTableName("comp_kinv_reksadana");
                        dataChange.setEntityClassName(KINVReksadana.class.getName());
                        dataChange.setDataBefore(jsonbefore);
                        dataChange.setDataChange(jsonAfter);

                        newComplianceDataChangeList.add(dataChange);
                    }
                }
                complianceDataChangeRepository.saveAll(newComplianceDataChangeList);
                message = "Delete data success! Need Approval for This Action!";
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(message);

        } catch (Exception e) {
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }
}
