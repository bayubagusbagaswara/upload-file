package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.*;

@Service
public class AccountService {
//    DroConnectionUtil droConnectionUtil;

    public ResponseEntity<ResponseDto> update() throws ClassNotFoundException, SQLException {

//        ResultSet rs = stmt.executeQuery("SELECT userDefinedField03 FROM PORTFOLIOUSERDEFINED");
//            ResultSet rs = droConnectionUtil.getData("SELECT userDefinedField03 FROM PORTFOLIOUSERDEFINED");
//            while (rs.next()){
//                System.out.println(rs);
//            }
//            con.close();
        return ResponseEntity.ok(new ResponseDto().builder()
                .code(HttpStatus.OK.toString())
                .message("Berhasil update data Expense")
                .payload("").build());
    }




}
