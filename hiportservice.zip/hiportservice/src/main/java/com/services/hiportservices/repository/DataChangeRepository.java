package com.services.hiportservices.repository;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.DataChange;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.xml.crypto.Data;
import java.util.List;
@Repository
public interface DataChangeRepository extends JpaRepository<DataChange, Long> {

    List<DataChange> findByApprovalStatus(ApprovalStatus ApprovalStatus);
    List<DataChange> findByEntityClassName(String entityClassName);
}
