package com.services.hiportservices.utils.regulatory;

import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.exception.regulatory.CsvHandleException;
import com.services.hiportservices.model.regulatory.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Component
@Slf4j
public class CsvDataMapper {

    private static final String DATE_FORMAT_1 = "dd/MM/yyyy";
    private static final String DATE_FORMAT_2 = "MM/dd/yyyy";
    private static final String DATE_FORMAT_3 = "yyyyMMdd";

    private final DateUtil dateUtil;

    public CsvDataMapper(DateUtil dateUtil) {
        this.dateUtil = dateUtil;
    }

    private LocalDate parseToLocalDate(String value, String dateFormat) {
        try {
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(dateFormat);
            return LocalDate.parse(value, dateTimeFormatter);
        } catch (Exception e) {
            log.error("Parse Date is failed: {}", e.getMessage(), e);
            throw new CsvHandleException("Parse Date is failed: " + e.getMessage());
        }
    }

    private BigDecimal cleanedAndParseToBigDecimal(String value) {
        try {
            String replace = value.replace(".", "");
            return new BigDecimal(replace);
        } catch (Exception e) {
            log.error("Parse Big Decimal is failed: {}", e.getMessage(), e);
            throw new CsvHandleException("Parse Big Decimal is failed: " + e.getMessage());
        }
    }

    private BigDecimal parseToBigDecimal(String value) {
        try {
            if (value == null || value.trim().isEmpty()) {
                return BigDecimal.ZERO;
            }

            NumberFormat format = NumberFormat.getNumberInstance(Locale.US);
            Number number = format.parse(value.trim());

            return BigDecimal.valueOf(number.doubleValue());
        } catch (Exception e) {
            log.error("Parse Big Decimal is failed: {}", e.getMessage(), e);
            throw new CsvHandleException("Parse Big Decimal is failed: " + e.getMessage());
        }
    }

    public List<LBABKDataSource> mapCsvLBABKDataSource(List<String[]> rows) {
        log.info("Start map csv file LBABK Data Source rows: {}", rows.size());
        int totalData = 0;
        List<LBABKDataSource> lbabkDataSourceList = new ArrayList<>();
        Instant now = Instant.now();

        for (String[] row : rows) {
            try {
                log.info("Process Data ke- {}", totalData++);
                log.info("Row 1: {}", row[1]);
                log.info("Row 11: {}", row[11]);
                log.info("Row 12: {}", row[12]);
                log.info("Row 13: {}", row[13]);
                log.info("Row 14: {}", row[14]);
                log.info("Row 15: {}", row[15]);
                log.info("Row 16: {}", row[16]);
                log.info("Row 17: {}", row[17]);
                log.info("Row 18: {}", row[18]);
                log.info("Row 19: {}", row[19]);
                log.info("Row 20: {}", row[20]);
                log.info("Row 21: {}", row[21]);


                LocalDate localDate = parseToLocalDate(row[2], DATE_FORMAT_3);
                String monthName = localDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
                Integer year = localDate.getYear();

                LBABKDataSource lbabkDataSource = LBABKDataSource.builder()
                        .createdDate(now)
                        .updatedDate(now)
                        .flagDetail(StringUtil.processString(row[0]))
//                        .kodeKomponen(parseCodeComponent(row[1]))
                        .kodeKomponen(StringUtil.processString(row[1]))
                        .tanggalTransaksi(localDate)
                        .month(monthName)
                        .year(year)
                        .kodeTipeEfek(StringUtil.processString(row[3]))
                        .keteranganTipeEfek(StringUtil.processString(row[4]))
                        .isinCode(StringUtil.processString(row[5]))
                        .securityName(StringUtil.processString(row[6]))
                        .issuerCode(StringUtil.processString(row[7]))
                        .issuerName(StringUtil.processString(row[8]))
                        .kodeMataUang(StringUtil.processString(row[9]))

                        .buyFrequency(parseInt(row[10].trim()))
                        .buyVolume(parseToBigDecimal(row[11]))
                        .buyValue(parseToBigDecimal(row[12]))
                        .buyInvestorIndonesia(parseToBigDecimal(row[13]))
                        .buyInvestorForeign(parseToBigDecimal(row[14]))
                        .buyInvestorConfirmation(parseToBigDecimal(row[15]))

                        .sellFrequency(parseInt(row[16].trim()))
                        .sellVolume(parseToBigDecimal(row[17]))
                        .sellValue(parseToBigDecimal(row[18]))
                        .sellInvestorIndonesia(parseToBigDecimal(row[19]))
                        .sellInvestorForeign(parseToBigDecimal(row[20]))
                        .sellInvestorConfirmation(parseToBigDecimal(row[21]))

                        .kodeEfek(StringUtil.processString(row[22]))

                        .data1(StringUtil.processString(row[23]))
                        .data2(StringUtil.processString(row[24]))

                        .build();

                lbabkDataSourceList.add(lbabkDataSource);

            } catch (Exception e) {
                log.error("Failed to map row to LBABK Data Source: {}", (Object) row, e);
            }
        }
        return lbabkDataSourceList;
    }

    private Integer parseInt(String value) {
        try {
            return (value == null || value.isEmpty()) ? 0 : Integer.parseInt(value);
        } catch (NumberFormatException e) {
            log.error("Parse Integer is Failed : {}", e.getMessage(), e);
            throw new CsvHandleException("Parse Integer is failed: " + e.getMessage());
        }
    }

    public List<LKPBUDataSource> mapCsvLKPBUDataSource(List<String[]> rows) {
        log.info("Start map csv file LKPBU Data Source rows: {}", rows.size());
        List<LKPBUDataSource> lkpbuDataSourceList = new ArrayList<>();

        // Create month and year
        Instant now = Instant.now();
        ContextDate contextDate = dateUtil.buildContextDate(now);

        for (String[] row : rows) {
            try {
                LKPBUDataSource lkpbuDataSource = LKPBUDataSource.builder()
                        .createdDate(now)
                        .month(contextDate.getMonthNameMinus1())
                        .year(contextDate.getYearMinus1())
                        .flagDetail(StringUtil.processString(row[0]))
                        .kodeKomponen("0".concat(StringUtil.processString(row[1]))) // ini tambahkan 0 diawal
                        .golonganPemilik(StringUtil.processString(row[2]))
                        .sandiPerusahaanAsuransi(parseCodeComponent(row[3]))
                        .negaraAsal(StringUtil.processString(row[4]))
                        .golonganPenerbit(StringUtil.processString(row[5]))
                        .negara(StringUtil.processString(row[6]))
                        .isinCode(StringUtil.processString(row[7]))
                        .jenis(StringUtil.processString(row[8]))
                        .kodeEfek(StringUtil.processString(row[9]))
                        .lembarUnit(parseToBigDecimal(row[10]))
                        .interestRate(StringUtil.processString(row[11]))
                        .keterangan(StringUtil.processString(row[12]))
                        .danaJaminan(StringUtil.processString(row[13]))
                        .jenisValuta(StringUtil.processString(row[14]))
                        .penerbitan(StringUtil.processString(row[15]))
                        .jatuhTempo(StringUtil.processString(row[16]))
                        .nilaiValutaAsal(parseToBigDecimal(row[17]))
                        .pembayaranKupon(parseToBigDecimal(row[18]))
                        .data1(StringUtil.processString(row[19]))
                        .data2(StringUtil.processString(row[20]))
                        .tipeSaham(StringUtil.processString(row[21]))
                        .build();
                lkpbuDataSource.setConcatData(lkpbuDataSource.getData1().concat(lkpbuDataSource.getData2()));
                lkpbuDataSourceList.add(lkpbuDataSource);
            } catch (Exception e) {
                log.error("Failed to map row to LKPBU Data Source: {}", (Object) row, e);
            }
        }
        return lkpbuDataSourceList;
    }

    public List<LKPBUIncome> mapCsvLKPBUIncome(List<String[]> rows) {
        log.info("Start map csv LKPBU Income rows: {}", rows.size());
        List<LKPBUIncome> lkpbuIncomeList = new ArrayList<>();

        int totalDataSuccess = 0;
        int totalDataFailed = 0;

        Instant now = Instant.now();

        for (String[] row : rows) {
            try {
                LocalDate localDate = parseToLocalDate(StringUtil.processString(row[0]), DATE_FORMAT_2);
                String monthName = localDate.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);
                Integer year = localDate.getYear();

                LKPBUIncome lkpbuIncome = LKPBUIncome.builder()
                        .createdDate(now)
                        .updatedDate(now)
                        .transactionDate(localDate)
                        .month(monthName)
                        .year(year)
                        .portfolioCode(StringUtil.processString(row[1]))
                        .jenis(StringUtil.processString(row[2]))
                        .securityCode(StringUtil.processString(row[3]))
                        .nominal(parseToBigDecimal(row[4]))
                        .type(StringUtil.processString(row[5]))
                        .system(StringUtil.processString(row[6]))
                        .customerType(StringUtil.processString(row[7]))
                        .statusClient(StringUtil.processString(row[8]))
                        .data1(StringUtil.processString(row[9]))
                        .build();

                lkpbuIncomeList.add(lkpbuIncome);
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Failed to map row to LKPBU Income: {}", (Object) row);
                totalDataFailed++;
            }
        }
        log.info("Total data success: {}, total data failed: {}", totalDataSuccess, totalDataFailed);

        log.info("Finish map csv file LKPBU Income size: {}", lkpbuIncomeList.size());
        return lkpbuIncomeList;
    }

    private static String parseCodeComponent(String value) {
        String newValue;
        if (value == null || value.trim().isEmpty()) {
            newValue = "";
        } else {
            BigDecimal bigDecimal = new BigDecimal(value);
            newValue = bigDecimal.toPlainString();
        }
        log.info("New Value: {}", newValue);
        return newValue;
    }

}
