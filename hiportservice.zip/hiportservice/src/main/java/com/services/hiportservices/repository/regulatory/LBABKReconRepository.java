package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LBABKRecon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface LBABKReconRepository extends JpaRepository<LBABKRecon, Long> {

    @Query(value = "FROM LBABKRecon l WHERE l.month = :month AND l.year = :year AND l.status = :status")
    List<LBABKRecon> findAllByMonthAndYearAndStatus(@Param("month") String month, @Param("year") Integer year, @Param("status") Boolean status);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM LBABKRecon l WHERE l.month = :month AND l.year = :year")
    void deleteByMonthAndYear(@Param("month") String month, @Param("year") Integer year);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM LBABKRecon l WHERE l.reconType = :reconType AND l.month = :month AND l.year = :year")
    void deleteByReconTypeAndMonthAndYear(@Param("reconType") String reconType, @Param("month") String month, @Param("year") Integer year);
}
