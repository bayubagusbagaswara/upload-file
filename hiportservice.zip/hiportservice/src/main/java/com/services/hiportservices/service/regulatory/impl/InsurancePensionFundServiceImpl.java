package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.insurancepensionfund.*;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.mapper.InsurancePensionFundMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.model.regulatory.InsurancePensionFund;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.repository.regulatory.DataNotFoundRepository;
import com.services.hiportservices.repository.regulatory.InsurancePensionFundRepository;
import com.services.hiportservices.service.regulatory.InsurancePensionFundService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.INSURANCE_PENSION_FUND_TABLE;
import static com.services.hiportservices.enums.ApprovalStatus.Approved;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

@Service
@Slf4j
@RequiredArgsConstructor
public class InsurancePensionFundServiceImpl implements InsurancePensionFundService {

    private static final String CREATE_APPROVE_URL = "/api/regulatory/asuransi-dana-pensiun/create/approve";
    private static final String UPDATE_APPROVE_URL = "/api/regulatory/asuransi-dana-pensiun/update/approve";
    private static final String ID_NOT_FOUND = "Asuransi dan Dana Pensiun not found with id: ";
    private static final String UNKNOWN_PORTFOLIO_CODE = "Unknown Portfolio Code";

    private final InsurancePensionFundRepository insurancePensionFundRepository;
    private final ObjectMapper objectMapper;
    private final ValidationData validationData;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final InsurancePensionFundMapper insurancePensionFundMapper;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public boolean isPortfolioCodeAlreadyExists(String portfolioCode) {
        log.info("Check the existing Asuransi dan Dana Pensiun with the portfolio code: {}", portfolioCode);
        return insurancePensionFundRepository.existsByPortfolioCode(portfolioCode);
    }

    @Transactional
    @Override
    public synchronized InsurancePensionFundResponse uploadData(UploadInsurancePensionFundListRequest uploadInsurancePensionFundListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start upload data Asuransi dan Dana Pensiun: {}, {}", uploadInsurancePensionFundListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadInsurancePensionFundDataRequest insurancePensionFundDataRequest : uploadInsurancePensionFundListRequest.getUploadInsurancePensionFundDataRequests()) {
            List<String> validationErrors = new ArrayList<>();
            InsurancePensionFundDTO insurancePensionFundDTO = null;

            try {
                Errors errors = validationData.validateObject(insurancePensionFundDataRequest);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                insurancePensionFundDTO = insurancePensionFundMapper.fromUploadRequestToDTO(insurancePensionFundDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                            !insurancePensionFundDTO.getPortfolioCode().isEmpty() ? insurancePensionFundDTO.getPortfolioCode() : UNKNOWN_PORTFOLIO_CODE,
                            validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    Optional<InsurancePensionFund> insurancePensionFund = insurancePensionFundRepository.findByPortfolioCode(insurancePensionFundDataRequest.getPortfolioCode());

                    if (insurancePensionFund.isPresent()) {
                        handleExistingInsurancePensionFund(insurancePensionFund.get(), insurancePensionFundDTO, regulatoryDataChangeDTO);
                    } else {
                        handleNewInsurancePensionFund(insurancePensionFundDTO, regulatoryDataChangeDTO);
                    }
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(insurancePensionFundDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new InsurancePensionFundResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized InsurancePensionFundResponse createApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress) {
        log.info("Start create approve Asuransi dan Dana Pensiun: {}, {}", approveInsurancePensionFundRequest, approveIPAddress);
        String approveId = approveInsurancePensionFundRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        InsurancePensionFundDTO insurancePensionFundDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveInsurancePensionFundRequest.getDataChangeId());

            insurancePensionFundDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), InsurancePensionFundDTO.class);

            /* validate whether the code already exists */
            validationPortfolioCodeAlreadyExists(insurancePensionFundDTO.getPortfolioCode(), validationErrors);

            if (!validationErrors.isEmpty()) {
                regulatoryDataChangeService.setApprovalStatusIsRejected(dataChange, validationErrors);
                totalDataFailed++;
            } else {
                LocalDateTime approveDate = LocalDateTime.now();
                InsurancePensionFund insurancePensionFund = InsurancePensionFund.builder()
                        .approvalStatus(Approved)
                        .approverId(approveId)
                        .approveDate(approveDate)
                        .approveIPAddress(approveIPAddress)
                        .inputerId(dataChange.getInputerId())
                        .inputDate(dataChange.getInputDate())
                        .inputIPAddress(dataChange.getInputIPAddress())
                        .portfolioCode(insurancePensionFundDTO.getPortfolioCode().trim())
                        .portfolioName(insurancePensionFundDTO.getPortfolioName().trim())
                        .regulatoryName(insurancePensionFundDTO.getRegulatoryName().trim())
                        .insurancePensionFundReference(insurancePensionFundDTO.getInsurancePensionFundReference().trim())
                        .guaranteeFund(insurancePensionFundDTO.getGuaranteeFund().trim())
                        .build();

                InsurancePensionFund save = insurancePensionFundRepository.save(insurancePensionFund);

                dataChange.setApproverId(approveId);
                dataChange.setApproveDate(approveDate);
                dataChange.setApproveIPAddress(approveIPAddress);
                dataChange.setEntityId(save.getId().toString());
                dataChange.setJsonDataAfter(
                        JsonUtil.cleanedEntityDataFromApprovalData(
                                objectMapper.writeValueAsString(save)
                        )
                );

                dataChange.setDescription("Success create approve with id: " + save.getId());

                /* Get all data not found by FLAG_TABLE and code */
                List<DataNotFound> dataNotFoundList = dataNotFoundRepository.findAllByFlagTableAndCode(
                        INSURANCE_PENSION_FUND_TABLE, save.getPortfolioCode()
                );

                if (!dataNotFoundList.isEmpty()) {
                    dataNotFoundList.forEach(dataNotFound -> dataNotFound.setStatus(Boolean.TRUE));
                    dataNotFoundRepository.saveAll(dataNotFoundList);
                }

                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(insurancePensionFundDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new InsurancePensionFundResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized InsurancePensionFundResponse updateApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress) {
        log.info("Start update approve Asuransi dan Dana Pensiun: {}, {}", approveInsurancePensionFundRequest, approveIPAddress);
        String approveId = approveInsurancePensionFundRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        InsurancePensionFundDTO insurancePensionFundDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveInsurancePensionFundRequest.getDataChangeId());

            insurancePensionFundDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), InsurancePensionFundDTO.class);

            InsurancePensionFund insurancePensionFund = insurancePensionFundRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            if (!insurancePensionFundDTO.getPortfolioName().isEmpty()) {
                insurancePensionFund.setPortfolioName(insurancePensionFundDTO.getPortfolioName().trim());
            }

            if (!insurancePensionFundDTO.getRegulatoryName().isEmpty()) {
                insurancePensionFund.setRegulatoryName(insurancePensionFundDTO.getRegulatoryName().trim());
            }

            if (!insurancePensionFundDTO.getInsurancePensionFundReference().isEmpty()) {
                insurancePensionFund.setInsurancePensionFundReference(insurancePensionFundDTO.getInsurancePensionFundReference().trim());
            }

            if (!insurancePensionFundDTO.getGuaranteeFund().isEmpty()) {
                insurancePensionFund.setGuaranteeFund(insurancePensionFundDTO.getGuaranteeFund().trim());
            }

            LocalDateTime approveDate = LocalDateTime.now();

            insurancePensionFund.setApprovalStatus(Approved);
            insurancePensionFund.setApproverId(approveId);
            insurancePensionFund.setApproveIPAddress(approveIPAddress);
            insurancePensionFund.setApproveDate(approveDate);
            insurancePensionFund.setInputerId(dataChange.getInputerId());
            insurancePensionFund.setInputIPAddress(dataChange.getInputIPAddress());
            insurancePensionFund.setInputDate(dataChange.getInputDate());

            InsurancePensionFund save = insurancePensionFundRepository.save(insurancePensionFund);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setJsonDataAfter(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(save)
                    )
            );
            dataChange.setDescription("Success update approve with id: " + save.getId());
            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(insurancePensionFundDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new InsurancePensionFundResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized InsurancePensionFundResponse deleteById(DeleteInsurancePensionFundRequest deleteInsurancePensionFundRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start delete Asuransi dan Dana Pensiun by id: {}, {}", deleteInsurancePensionFundRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        InsurancePensionFundDTO insurancePensionFundDTO = null;

        try {
            InsurancePensionFund insurancePensionFund = insurancePensionFundRepository.findById(deleteInsurancePensionFundRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + deleteInsurancePensionFundRequest.getId()));

            insurancePensionFundDTO = insurancePensionFundMapper.toDTO(insurancePensionFund);

            regulatoryDataChangeDTO.setEntityId(insurancePensionFund.getId().toString());
            regulatoryDataChangeDTO.setJsonDataBefore(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(insurancePensionFund)
                    )
            );
            regulatoryDataChangeDTO.setJsonDataAfter("");
            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
            regulatoryDataChangeService.createChangeActionDelete(regulatoryDataChange, InsurancePensionFund.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(insurancePensionFundDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new InsurancePensionFundResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized InsurancePensionFundResponse deleteApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress) {
        log.info("Delete approve Asuransi dan Dana Pensiun: {}, {}", approveInsurancePensionFundRequest, approveIPAddress);
        String approveId = approveInsurancePensionFundRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        InsurancePensionFundDTO insurancePensionFundDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveInsurancePensionFundRequest.getDataChangeId());

            InsurancePensionFund insurancePensionFund = insurancePensionFundRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            insurancePensionFundDTO = insurancePensionFundMapper.toDTO(insurancePensionFund);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(LocalDateTime.now());
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setDescription("Success delete approve with id; " + insurancePensionFund.getId());

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            /* delete entity */
            insurancePensionFundRepository.delete(insurancePensionFund);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(insurancePensionFundDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new InsurancePensionFundResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public InsurancePensionFundDTO getById(Long id) {
        log.info("Start get Asuransi dan Dana Pensiun by id: {}", id);
        InsurancePensionFund insurancePensionFund = insurancePensionFundRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));
        return insurancePensionFundMapper.toDTO(insurancePensionFund);
    }

    @Override
    public InsurancePensionFundDTO getByPortfolioCode(String portfolioCode) {
        log.info("Start get Asuransi dan Dana Pensiun by portfolio code: {}", portfolioCode);
        InsurancePensionFund insurancePensionFund = insurancePensionFundRepository.findByPortfolioCode(portfolioCode)
                .orElseThrow(() -> new DataNotFoundHandleException("Asuransi dan Dana Pensiun not found with portfolio code: " + portfolioCode));
        return insurancePensionFundMapper.toDTO(insurancePensionFund);
    }

    @Override
    public List<InsurancePensionFundDTO> getAll() {
        log.info("Start get all Asuransi dan Dana Pensiun");
        List<InsurancePensionFund> all = insurancePensionFundRepository.findAll();
        return insurancePensionFundMapper.toDTOList(all);
    }

    private void handleGeneralError(InsurancePensionFundDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        dto != null && !dto.getPortfolioCode().isEmpty() ? dto.getPortfolioCode() : UNKNOWN_PORTFOLIO_CODE,
                        validationErrors)
        );
    }

    private void validationPortfolioCodeAlreadyExists(String portfolioCode, List<String> validationErrors) {
        if (isPortfolioCodeAlreadyExists(portfolioCode)) {
            validationErrors.add("Asuransi dan Dana Pensiun is already taken with portfolio code: " + portfolioCode);
        }
    }

    private void handleExistingInsurancePensionFund(InsurancePensionFund insurancePensionFundEntity, InsurancePensionFundDTO insurancePensionFundDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(PUT.name());
        regulatoryDataChangeDTO.setEndpoint(UPDATE_APPROVE_URL);

        regulatoryDataChangeDTO.setEntityId(insurancePensionFundEntity.getId().toString());
        regulatoryDataChangeDTO.setJsonDataBefore(
                JsonUtil.cleanedEntityDataFromApprovalData(
                        objectMapper.writeValueAsString(insurancePensionFundEntity)
                )
        );

        InsurancePensionFundDTO temp = InsurancePensionFundDTO.builder()
                .portfolioCode(insurancePensionFundEntity.getPortfolioCode())
                .portfolioName(
                        !insurancePensionFundDTO.getPortfolioName().isEmpty()
                                ? insurancePensionFundDTO.getPortfolioName()
                                : insurancePensionFundEntity.getPortfolioName()
                )
                .regulatoryName(
                        !insurancePensionFundDTO.getRegulatoryName().isEmpty()
                                ? insurancePensionFundDTO.getRegulatoryName()
                                : insurancePensionFundEntity.getRegulatoryName()
                )
                .insurancePensionFundReference(
                        !insurancePensionFundDTO.getInsurancePensionFundReference().isEmpty()
                                ? insurancePensionFundDTO.getInsurancePensionFundReference()
                                : insurancePensionFundEntity.getInsurancePensionFundReference()
                )
                .guaranteeFund(
                        !insurancePensionFundDTO.getGuaranteeFund().isEmpty()
                                ? insurancePensionFundDTO.getGuaranteeFund()
                                : insurancePensionFundEntity.getGuaranteeFund()
                )
                .build();

        log.info("Temp: {}", temp);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(temp)
                )
        );

        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory data change edit: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, InsurancePensionFund.class);
    }

    private void handleNewInsurancePensionFund(InsurancePensionFundDTO insurancePensionFundDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(POST.name());
        regulatoryDataChangeDTO.setEndpoint(CREATE_APPROVE_URL);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(insurancePensionFundDTO)
                )
        );
        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory data change add: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionAdd(regulatoryDataChange, InsurancePensionFund.class);
    }

}
