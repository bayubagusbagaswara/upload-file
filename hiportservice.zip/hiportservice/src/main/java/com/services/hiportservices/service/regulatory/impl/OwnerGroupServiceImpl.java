package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.*;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.mapper.OwnerGroupMapper;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.model.regulatory.OwnerGroup;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.repository.regulatory.DataNotFoundRepository;
import com.services.hiportservices.repository.regulatory.OwnerGroupRepository;
import com.services.hiportservices.service.regulatory.OwnerGroupService;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.OWNER_GROUP_TABLE;
import static com.services.hiportservices.enums.ApprovalStatus.Approved;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

@Service
@Slf4j
@RequiredArgsConstructor
public class OwnerGroupServiceImpl implements OwnerGroupService {

    private static final String CREATE_APPROVE_URL = "/api/regulatory/golongan-pemilik/create/approve";
    private static final String UPDATE_APPROVE_URL = "/api/regulatory/golongan-pemilik/update/approve";

    private static final String ID_NOT_FOUND = "Owner Group not found with id: ";
    private static final String UNKNOWN_PORTFOLIO_CODE = "Unknown Portfolio Code";

    private final OwnerGroupRepository ownerGroupRepository;
    private final ObjectMapper objectMapper;
    private final ValidationData validationData;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final OwnerGroupMapper ownerGroupMapper;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public boolean isPortfolioCodeAlreadyExists(String portfolioCode) {
        return ownerGroupRepository.existsByPortfolioCode(portfolioCode);
    }

    @Transactional
    @Override
    public synchronized OwnerGroupResponse uploadData(UploadOwnerGroupListRequest uploadOwnerGroupListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start upload data Golongan Pemilik: {}, {}", uploadOwnerGroupListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadOwnerGroupDataRequest  ownerGroupDataRequest : uploadOwnerGroupListRequest.getUploadOwnerGroupDataRequests()) {
            List<String> validationErrors = new ArrayList<>();
            OwnerGroupDTO ownerGroupDTO = null;
            try {
                Errors errors = validationData.validateObject(ownerGroupDataRequest);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                ownerGroupDTO = ownerGroupMapper.fromUploadRequestToDTO(ownerGroupDataRequest);
                
                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                            !ownerGroupDTO.getPortfolioCode().isEmpty() ? ownerGroupDTO.getPortfolioCode() : UNKNOWN_PORTFOLIO_CODE,
                            validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    Optional<OwnerGroup> ownerGroup = ownerGroupRepository.findByPortfolioCode(ownerGroupDataRequest.getPortfolioCode());
                    
                    if (ownerGroup.isPresent()) {
                        handleExistingOwnerGroup(ownerGroup.get(), ownerGroupDTO, regulatoryDataChangeDTO);
                    } else {
                        handleNewOwnerGroup(ownerGroupDTO, regulatoryDataChangeDTO);
                    }
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized OwnerGroupResponse createApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress) {
        log.info("Start create approve Golongan Pemilik: {}, {}", approveOwnerGroupRequest, approveIPAddress);
        String approveId = approveOwnerGroupRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        OwnerGroupDTO ownerGroupDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveOwnerGroupRequest.getDataChangeId());

            ownerGroupDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), OwnerGroupDTO.class);

            validationPortfolioCodeAlreadyExists(ownerGroupDTO.getPortfolioCode(), validationErrors);

            if (!validationErrors.isEmpty()) {
                regulatoryDataChangeService.setApprovalStatusIsRejected(dataChange, validationErrors);
                totalDataFailed++;
            } else {
                LocalDateTime approveDate = LocalDateTime.now();

                OwnerGroup ownerGroup = OwnerGroup.builder()
                        .approvalStatus(Approved)
                        .approverId(approveId)
                        .approveDate(approveDate)
                        .approveIPAddress(approveIPAddress)
                        .inputerId(dataChange.getInputerId())
                        .inputDate(dataChange.getInputDate())
                        .inputIPAddress(dataChange.getInputIPAddress())
                        .portfolioCode(ownerGroupDTO.getPortfolioCode().trim())
                        .portfolioName(ownerGroupDTO.getPortfolioName().trim())
                        .sInvestCode(ownerGroupDTO.getSInvestCode().trim())
                        .opposingGroupReference(ownerGroupDTO.getOpposingGroupReference().trim())
                        .countryReference(ownerGroupDTO.getCountryReference().trim())
                        .build();

                OwnerGroup save = ownerGroupRepository.save(ownerGroup);

                dataChange.setApproverId(approveId);
                dataChange.setApproveDate(approveDate);
                dataChange.setApproveIPAddress(approveIPAddress);
                dataChange.setEntityId(save.getId().toString());
                dataChange.setJsonDataAfter(
                        JsonUtil.cleanedEntityDataFromApprovalData(
                                objectMapper.writeValueAsString(save)
                        )
                );
                dataChange.setDescription("Success create approve with id: " + save.getId());
                regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

                /* Get all data not found by FLAG_TABLE and code. The code can be filled with data 1 or data 2 (data source) */
                List<DataNotFound> dataNotFoundList = dataNotFoundRepository.findAllByFlagTableAndCode(
                        OWNER_GROUP_TABLE, save.getPortfolioCode()
                );

                if (!dataNotFoundList.isEmpty()) {
                    dataNotFoundList.forEach(dataNotFound -> dataNotFound.setStatus(Boolean.TRUE));
                    dataNotFoundRepository.saveAll(dataNotFoundList);
                }

                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized OwnerGroupResponse updateApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress) {
        log.info("Start update approve Golongan Pemilik: {}, {}", approveOwnerGroupRequest, approveIPAddress);
        String approveId = approveOwnerGroupRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        OwnerGroupDTO ownerGroupDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveOwnerGroupRequest.getDataChangeId());

            ownerGroupDTO = objectMapper.readValue(dataChange.getJsonDataAfter(), OwnerGroupDTO.class);
            log.info("Update Approve: {}", ownerGroupDTO);

            OwnerGroup ownerGroup = ownerGroupRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            // portfolioName
            if (!ownerGroupDTO.getPortfolioName().isEmpty()) {
                ownerGroup.setPortfolioName(ownerGroupDTO.getPortfolioName().trim());
            }

            // sInvestCode
            if (!ownerGroupDTO.getSInvestCode().isEmpty()) {
                ownerGroup.setSInvestCode(ownerGroupDTO.getSInvestCode().trim());
            }

            // opposingGroupReference
            if (!ownerGroupDTO.getOpposingGroupReference().isEmpty()) {
                ownerGroup.setOpposingGroupReference(ownerGroupDTO.getOpposingGroupReference().trim());
            }

            // countryReference
            if (!ownerGroupDTO.getCountryReference().isEmpty()) {
                ownerGroup.setCountryReference(ownerGroupDTO.getCountryReference().trim());
            }

            LocalDateTime approveDate = LocalDateTime.now();

            ownerGroup.setApprovalStatus(Approved);
            ownerGroup.setApproverId(approveId);
            ownerGroup.setApproveIPAddress(approveIPAddress);
            ownerGroup.setApproveDate(approveDate);
            ownerGroup.setInputerId(dataChange.getInputerId());
            ownerGroup.setInputIPAddress(dataChange.getInputIPAddress());
            ownerGroup.setInputDate(dataChange.getInputDate());

            OwnerGroup save = ownerGroupRepository.save(ownerGroup);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setJsonDataAfter(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(save)
                    )
            );
            dataChange.setDescription("Success update approve with id: " + save.getId());
            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized OwnerGroupResponse deleteById(DeleteOwnerGroupRequest deleteOwnerGroupRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start delete Golongan Pemilik by id: {}, {}", deleteOwnerGroupRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        OwnerGroupDTO ownerGroupDTO = null;

        try {

            OwnerGroup ownerGroup = ownerGroupRepository.findById(deleteOwnerGroupRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + deleteOwnerGroupRequest.getId()));

            ownerGroupDTO = ownerGroupMapper.toDTO(ownerGroup);

            regulatoryDataChangeDTO.setEntityId(ownerGroup.getId().toString());
            regulatoryDataChangeDTO.setJsonDataBefore(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(ownerGroup)
                    )
            );
            regulatoryDataChangeDTO.setJsonDataAfter("");
            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
            regulatoryDataChangeService.createChangeActionDelete(regulatoryDataChange, OwnerGroup.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized OwnerGroupResponse deleteApprove(ApproveOwnerGroupRequest approveOwnerGroupRequest, String approveIPAddress) {
        log.info("Delete approve Golongan Pemilik: {}, {}", approveOwnerGroupRequest, approveIPAddress);
        String approveId = approveOwnerGroupRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        OwnerGroupDTO ownerGroupDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveOwnerGroupRequest.getDataChangeId());

            OwnerGroup ownerGroup = ownerGroupRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            ownerGroupDTO = ownerGroupMapper.toDTO(ownerGroup);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(LocalDateTime.now());
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setDescription("Success delete approve with id: " + ownerGroup.getId());

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            /* delete entity */
            ownerGroupRepository.delete(ownerGroup);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(ownerGroupDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new OwnerGroupResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public OwnerGroupDTO getById(Long id) {
        log.info("Start get Owner Group by id: {}", id);
        OwnerGroup ownerGroup = ownerGroupRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));
        return ownerGroupMapper.toDTO(ownerGroup);
    }

    @Override
    public OwnerGroupDTO getByPortfolioCode(String portfolioCode) {
        log.info("Start get Owner Group by portfolio code: {}", portfolioCode);
        OwnerGroup ownerGroup = ownerGroupRepository.findByPortfolioCode(portfolioCode)
                .orElseThrow(() -> new DataNotFoundHandleException("Owner Group not found with portfolio code: " + portfolioCode));
        return ownerGroupMapper.toDTO(ownerGroup);
    }

    @Override
    public List<OwnerGroupDTO> getAll() {
        log.info("Start get all owner group");
        List<OwnerGroup> all = ownerGroupRepository.findAll();
        return ownerGroupMapper.toDTOList(all);
    }

    private void handleGeneralError(OwnerGroupDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        dto != null && !dto.getPortfolioCode().isEmpty() ? dto.getPortfolioCode() : UNKNOWN_PORTFOLIO_CODE, 
                        validationErrors
                )
        );
    }
    
    private void validationPortfolioCodeAlreadyExists(String portfolioCode, List<String> validationErrors) {
        if (isPortfolioCodeAlreadyExists(portfolioCode)) {
            validationErrors.add("Golongan Pemilik is already taken with portfolio code: " + portfolioCode);
        }
    }

    private void handleNewOwnerGroup(OwnerGroupDTO ownerGroupDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(POST.name());
        regulatoryDataChangeDTO.setEndpoint(CREATE_APPROVE_URL);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(ownerGroupDTO)
                )
        );
        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory Data Change add: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionAdd(regulatoryDataChange, OwnerGroup.class);
    }

    private void handleExistingOwnerGroup(OwnerGroup ownerGroupEntity, OwnerGroupDTO ownerGroupDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(PUT.name());
        regulatoryDataChangeDTO.setEndpoint(UPDATE_APPROVE_URL);

        regulatoryDataChangeDTO.setEntityId(ownerGroupEntity.getId().toString());
        regulatoryDataChangeDTO.setJsonDataBefore(
                JsonUtil.cleanedEntityDataFromApprovalData(
                        objectMapper.writeValueAsString(ownerGroupEntity)
                )
        );

        OwnerGroupDTO temp = OwnerGroupDTO.builder()
                .portfolioCode(ownerGroupEntity.getPortfolioCode())
                .portfolioName(
                        !ownerGroupDTO.getPortfolioName().isEmpty()
                                ? ownerGroupDTO.getPortfolioName()
                                : ownerGroupEntity.getPortfolioName()
                )
                .sInvestCode(
                        !ownerGroupDTO.getSInvestCode().isEmpty()
                                ? ownerGroupDTO.getSInvestCode()
                                : ownerGroupEntity.getSInvestCode()
                )
                .opposingGroupReference(
                        !ownerGroupDTO.getOpposingGroupReference().isEmpty()
                                ? ownerGroupDTO.getOpposingGroupReference()
                                : ownerGroupEntity.getOpposingGroupReference()
                )
                .countryReference(
                        !ownerGroupDTO.getCountryReference().isEmpty()
                                ? ownerGroupDTO.getCountryReference()
                                : ownerGroupEntity.getCountryReference()
                )
                .build();

        log.info("Temp: {}", temp);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(temp)
                )
        );

        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory data change edit: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, OwnerGroup.class);
    }

}
