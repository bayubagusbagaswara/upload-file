package com.services.hiportservices.dto.regulatory.issuercodeplacementbank;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

/**
 * untuk update satuan
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateIssuerCodePlacementBankRequest extends InputIdentifierRequest {

    private Long id; // as a parameter

    private String code; // kode

    private String bankName; // nama bank

    private String bankType; // jenis bank

    private String issuerGroup; // golongan penerbit

    private String issuerCountry; // negara penerbit

    private String securityType; // jenis surat beharga

    private String effectTypeCode; // kode tipe efek

    private String status;

    private String currency;

}
