package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class KINVReksadanaRequestDTO {
    private Long id;
    private String reksadanaCode;
    private String rdExternalCode;
    private String kinvCode;
    private double kinvMin;
    private double kinvMax;
    private String note;
}
