package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidFundProductCode;
import com.services.hiportservices.model.emonitoring.OrchidXd15;
import com.services.hiportservices.model.emonitoring.OrchidXd16;
import com.services.hiportservices.repository.emonitoring.OrchidFundProductCodeRepository;
import com.services.hiportservices.repository.emonitoring.OrchidXd15Repository;
import com.services.hiportservices.repository.emonitoring.OrchidXd16Repository;
import com.services.hiportservices.utils.ConfigPropertiesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.Column;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OrchidXd15Service {
    @Autowired
    OrchidXd15Repository orchidXd15Repository;

    @Autowired
    OrchidFundProductCodeRepository orchidFundproductCodeRepository;

    public List<OrchidXd15> insertOrUpdateAll(String date, String pf)
            throws SQLException, ClassNotFoundException, IOException {

        List<OrchidXd15> listOrchid = new ArrayList<>();
        List<OrchidFundProductCode> orchidFund = new ArrayList<>();

        String className = ConfigPropertiesUtil.getProperty("urs.className", "connection.properties");
        String ip = ConfigPropertiesUtil.getProperty("urs.ip", "connection.properties");
        String port = ConfigPropertiesUtil.getProperty("urs.port", "connection.properties");
        String dataSource = ConfigPropertiesUtil.getProperty("urs.ServerDataSource", "connection.properties");
        String user = ConfigPropertiesUtil.getProperty("urs.user", "connection.properties");
        String pass = ConfigPropertiesUtil.getProperty("urs.password", "connection.properties");

        Class.forName(className);
        String connectionUrl = "jdbc:sqlserver://" + ip + ":" + port + ";databaseName=" +
                dataSource + ";user=" + user + ";password=" + pass + ";integratedSecurity=false;trustServerCertificate=true";

        orchidFundproductCodeRepository.deleteAllFundProductCode();

        Connection con = DriverManager.getConnection(connectionUrl);
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(queryInsert(date));

        while (rs.next()) {

            if (!rs.getString("FundCode").isEmpty() &&
                    rs.getString("FundCode") != null) {


                System.out.println(rs.getString("FundCode") + " - " + date);
                OrchidXd15 orchidXd15 = orchidXd15Repository.searchDataBy(
                        date, rs.getString("FundCode"));

                if (orchidXd15 == null) {
                    orchidXd15 = new OrchidXd15();
                }

                orchidXd15.setPemegang(rs.getBigDecimal("SumAllInvestor"));
                orchidXd15.setPAsing100(rs.getBigDecimal("PercentageForeignUnit"));
                orchidXd15.setPAsing(rs.getBigDecimal("SumAllInvestorForeign"));
                orchidXd15.setPLokal100(rs.getBigDecimal("PercentageLocalUnit"));
                orchidXd15.setPLokal(rs.getBigDecimal("SumAllInvestorLocal"));
                orchidXd15.setUnit10(rs.getBigDecimal("PercentageTopTenUnit"));
                orchidXd15.setUnit(rs.getBigDecimal("PercentageInsideFHUnit"));
                orchidXd15.setUnitBaru(rs.getBigDecimal("NewInvestor"));
                orchidXd15.setLunas(rs.getBigDecimal("PercentageSalesAgainstNAB"));
                orchidXd15.setJual(rs.getBigDecimal("PercentageAcquittalAgainstNAB"));
                orchidXd15.setTLunas(rs.getBigDecimal("HighestSalesDaily"));
                orchidXd15.setTinggi(rs.getBigDecimal("PercentageHighestFHFromSumOutstanding"));
                orchidXd15.setTanggal(rs.getDate("GeneratedDate"));
                orchidXd15.setKode(rs.getString("FundCode"));
                orchidXd15.setPROCESS_DATE(new Date());

                listOrchid.add(orchidXd15);

                orchidFundproductCodeRepository.
                        insertIntoFund(rs.getString("FundCode"));
            }

        }

        rs.close();
        stmt.close();
        con.close();


        return orchidXd15Repository.saveAll(listOrchid);
    }

    private BigDecimal toDoubleValue(String data) {
        String doubleData = data.contains("-") ?
                "-" + data.replace("-", "").trim()
                : data.trim();
        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    private String queryInsert(String date) {

        String query = "EXEC SP_CSA_GetXD15Report '" + date + "'";
//        String query = "EXEC GET_FOR_XD13 '" + date + "'";

        System.out.println(query);

        return query;
    }

    public List<OrchidXd15> getDataXD15(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd15> listOrchid = new ArrayList<>();

        try {

            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {
                listOrchid.addAll(orchidXd15Repository.searchDataAt(date));

            } else {
                System.out.println("here");
                listOrchid.add(orchidXd15Repository.searchDataBy(date, pfCode));
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

}
