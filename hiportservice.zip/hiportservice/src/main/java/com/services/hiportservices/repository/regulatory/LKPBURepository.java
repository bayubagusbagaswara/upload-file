package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LKPBU;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface LKPBURepository extends JpaRepository<LKPBU, Long> {

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM LKPBU l WHERE l.month = :month AND l.year = :year")
    void deleteByMonthAndYear(@Param("month") String monthName, @Param("year") Integer year);

    @Query(value = "FROM LKPBU l WHERE l.month = :month AND l.year = :year")
    List<LKPBU> findAllByMonthAndYear(@Param("month") String month, @Param("year") Integer year);

}
