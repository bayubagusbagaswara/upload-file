package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/data-change")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class RegulatoryDataChangeController {

    private final RegulatoryDataChangeService dataChangeService;

    @GetMapping(path = "/getByMenuAndStatus")
    public ResponseEntity<ResponseDto<List<RegulatoryDataChange>>> getByMenuAndStatus(@RequestParam("menu") String menu,
                                                                                      @RequestParam("status") String status) {
        ApprovalStatus approvalStatus = ApprovalStatus.valueOf(status);
        List<RegulatoryDataChange> regulatoryDataChangeList = dataChangeService.findByMenuAndApprovalStatus(menu, approvalStatus);
        ResponseDto<List<RegulatoryDataChange>> response = ResponseDto.<List<RegulatoryDataChange>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(regulatoryDataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all/menu")
    public ResponseEntity<ResponseDto<List<String>>> getAllMenu() {
        List<String> menuList = dataChangeService.findAllMenuNotLike("Recon");
        ResponseDto<List<String>> response = ResponseDto.<List<String>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.toString())
                .payload(menuList)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/all/menu-recon")
    public ResponseEntity<ResponseDto<List<String>>> getAllMenuRecon() {
        List<String> reconMenuList = dataChangeService.findAllMenuLike("Recon");
        ResponseDto<List<String>> response = ResponseDto.<List<String>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(reconMenuList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "/checkIdDataChanges")
    public ResponseEntity<ResponseDto<String>> checkIdDataChanges(@RequestBody List<Long> ids) {
        Boolean isExits = dataChangeService.existByIdListAndStatus(ids, (long) ids.size(), ApprovalStatus.Pending);

        if (Boolean.FALSE.equals(isExits))
            return ResponseEntity.status(HttpStatus.OK.value())
                    .body(ResponseDto.<String>builder()
                            .code(String.valueOf(HttpStatus.NOT_ACCEPTABLE.value()))
                            .message(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase())
                            .payload("The ID data list does not match the data in the database.")
                            .build());

        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/approval-status")
    public ResponseEntity<ResponseDto<List<RegulatoryDataChange>>> getAllByApprovalStatus(@RequestParam("approvalStatus") String approvalStatus) {
        List<RegulatoryDataChange> dataChangeList = dataChangeService.getAllByApprovalStatus(approvalStatus);
        ResponseDto<List<RegulatoryDataChange>> response = ResponseDto.<List<RegulatoryDataChange>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(dataChangeList)
                .build();
        return ResponseEntity.ok(response);
    }

    @PutMapping("/reject/{id}")
    public ResponseEntity<ResponseDto<String>> doReject(@PathVariable("id") Long id) {
        dataChangeService.reject(id);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success reject id: " + id)
                .build();
        return ResponseEntity.ok(response);
    }

}
