package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.securitiesissuercode.SecuritiesIssuerCodeDTO;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.UploadSecuritiesIssuerCodeDataRequest;
import com.services.hiportservices.model.regulatory.SecuritiesIssuerCode;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SecuritiesIssuerCodeMapper {

    @Mapping(source = "id", target = "id")
    @Mapping(source = "externalCode2", target = "externalCode")
    SecuritiesIssuerCodeDTO toDTO(SecuritiesIssuerCode securitiesIssuerCode);

    @Mapping(target = "id", ignore = true)
    @Mapping(source = "externalCode2", target = "externalCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currency", target = "currency", qualifiedByName = "nullToEmpty")
    @Mapping(source = "issuerLBABK", target = "issuerLBABK", qualifiedByName = "nullToEmpty")
    @Mapping(source = "issuerLKPBU", target = "issuerLKPBU", qualifiedByName = "nullToEmpty")
    SecuritiesIssuerCodeDTO fromUploadRequestToDTO(UploadSecuritiesIssuerCodeDataRequest uploadSecuritiesIssuerCodeDataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    List<SecuritiesIssuerCodeDTO> toDTOList(List<SecuritiesIssuerCode> all);

}
