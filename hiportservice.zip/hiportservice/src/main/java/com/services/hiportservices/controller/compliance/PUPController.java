package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.PUPService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/pup")
public class PUPController {

    @Autowired
    PUPService pupService;

    @PutMapping("/upload/{date}")
    public ResponseEntity<ResponseDto> uploadFilePUP(@PathVariable String date, @RequestBody List<Map<String, String>> pupList) {
        return pupService.insertDataPUP(date, pupList);
    }

    @GetMapping("/{date}")
    public ResponseEntity<ResponseDto> getAllDataAt(@PathVariable String date) {
        return pupService.findDataAt(date);
    }

    @GetMapping("/viewPending/{date}")
    public ResponseEntity<ResponseDto> viewPendingData(@PathVariable String date) {
        return pupService.viewPendingData(date);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return pupService.allPendingDataPUP();
    }

    @PutMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataAt(@RequestParam String date) {
        return pupService.approveDataPUP(date);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataAt(@RequestBody Map<String, List<String>> dates) {
        return pupService.rejectDataPUP(dates);
    }
}
