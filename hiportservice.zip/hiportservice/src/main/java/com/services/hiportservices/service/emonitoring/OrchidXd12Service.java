package com.services.hiportservices.service.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd12;
import com.services.hiportservices.repository.emonitoring.OrchidXd12Repository;
import com.services.hiportservices.utils.ConfigPropertiesUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class OrchidXd12Service {
    @Autowired
    OrchidXd12Repository orchidXd12Repository;

    public List<OrchidXd12> insertOrUpdateAll(String date, String pf, String group)
            throws SQLException, ClassNotFoundException, IOException {
        List<OrchidXd12> listOrchid = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        String className = ConfigPropertiesUtil.getProperty("hiport.className", "connection.properties");
        String ip = ConfigPropertiesUtil.getProperty("hiport.ip", "connection.properties");
        String port = ConfigPropertiesUtil.getProperty("hiport.port", "connection.properties");
        String dataSource = ConfigPropertiesUtil.getProperty("hiport.ServerDataSource", "connection.properties");
        String user = ConfigPropertiesUtil.getProperty("hiport.user", "connection.properties");
        String pass = ConfigPropertiesUtil.getProperty("hiport.password", "connection.properties");

        try {
            Date dateParm = sdf.parse(date);

            if (pf == null || pf.isEmpty()) {
                orchidXd12Repository.deleteAllOrchidXd12(dateParm);
            } else {
                System.out.println("pf " + pf);
                orchidXd12Repository.deleteOrchidXd12(dateParm, pf);

            }

            Class.forName(className);

            String urlConn = "jdbc:DRO://" + ip + ":" + port +
                    ";ServerDataSource=" + dataSource + ";USER=" + user + ";PASSWORD=" + pass;
            System.out.println(urlConn);

            Connection con = DriverManager.getConnection(urlConn);

            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(queryInsert(date, pf, group));
            while (rs.next()) {

                if (rs.getString("Kode") != null) {
                    OrchidXd12 orchidXd12 = orchidXd12Repository.findByTanggalAndKode(rs.getDate("Tanggal"),
                            rs.getString("Kode"));
                    if (orchidXd12 == null) {
                        orchidXd12 = new OrchidXd12();
                    }
                    orchidXd12.setDateProc(rs.getDate("DATE_PROC"));
                    orchidXd12.setStatProc(rs.getString("STAT_PROC"));
                    orchidXd12.setTanggal(rs.getDate("Tanggal"));
                    orchidXd12.setKode(rs.getString("Kode"));
                    orchidXd12.setDividen(toDoubleValue(rs.getString("Dividend")));
                    orchidXd12.setBunga(toDoubleValue(rs.getString("Bunga")));
                    orchidXd12.setTpInvest(toDoubleValue(rs.getString("TPINVEST")));
                    orchidXd12.setBKelola(toDoubleValue(rs.getString("BKelola")));
                    orchidXd12.setBKustodi(toDoubleValue(rs.getString("BKustodi")));
                    orchidXd12.setBLain(toDoubleValue(rs.getString("BLain")));
                    orchidXd12.setBPiutang(toDoubleValue(rs.getString("BPiutang")));
                    orchidXd12.setProvisi(toDoubleValue(rs.getString("Provisi")));
                    orchidXd12.setTbiaya(toDoubleValue(rs.getString("TBIAYA")));
                    orchidXd12.setPInvest(toDoubleValue(rs.getString("PINVEST")));
                    orchidXd12.setLabaRugi(toDoubleValue(rs.getString("LabaRugi")));
                    orchidXd12.setLabaRugiUr(toDoubleValue(rs.getString("LabaRugiUR")));
                    orchidXd12.setLrInvest(toDoubleValue(rs.getString("LRINVEST")));
                    orchidXd12.setPOperasi(toDoubleValue(rs.getString("POPERASI")));
                    orchidXd12.setReksadanaCode(rs.getString("reksadanaCode"));

                    listOrchid.add(orchidXd12);
                }

            }
            rs.close();
            stmt.close();
            con.close();

            return orchidXd12Repository.saveAll(listOrchid);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }

    private BigDecimal toDoubleValue(String data) {
        String doubleData = "0.00";
        if (data != null) {
            if (data.isEmpty())
                data = "0.00";
            else
                doubleData = data.contains("-") ?
                        "-" + data.replace("-", "").trim()
                        : data.trim();
        } else {
            data = "0.00";
        }

        return BigDecimal.valueOf(Double.valueOf(doubleData));
    }

    private String queryInsert(String date, String pf, String group) throws Exception {
        String param = " ";
        if (pf != null && !pf.isEmpty()) {
            param = "   PortfolioCode in ('" + pf + "')\n" +
                    "   AND \n";
        }

        String query = ConfigPropertiesUtil.getAllValue("xd12.properties");
        query = query.replace("PORTFOLIOPARAM", param);
        query = query.replace("DATEPARAM", date);
        query = query.replace("GROUPPARAM", group);

        return query;
    }

    public List<OrchidXd12> getDataXD12(String date, String pfCode) {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        List<OrchidXd12> listOrchid = new ArrayList<>();

        try {
            Date dateParm = sdf.parse(date);

            if (pfCode == null || pfCode.isEmpty()) {
                listOrchid.addAll(orchidXd12Repository.findAllByTanggal(dateParm));

                System.out.println(listOrchid.size());
            } else {
                listOrchid.add(orchidXd12Repository.searchDataBy(date,
                        pfCode));
            }

            return listOrchid;


        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
}
