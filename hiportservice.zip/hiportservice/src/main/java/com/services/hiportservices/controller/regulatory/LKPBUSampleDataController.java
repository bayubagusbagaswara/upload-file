package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.model.regulatory.LKPBUSampleData;
import com.services.hiportservices.repository.regulatory.LKPBUSampleDataRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/lkpbu-sample")
@RequiredArgsConstructor
@Slf4j
public class LKPBUSampleDataController {

    private final LKPBUSampleDataRepository sampleDataRepository;

    @GetMapping
    public ResponseEntity<ResponseDto<String>> createData() {
        sampleDataRepository.saveAll(dataList());
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload("Success")
                .build();
        return ResponseEntity.ok(response);
    }

    private List<LKPBUSampleData> dataList() {
        return Arrays.asList(
                new LKPBUSampleData("11(TIME DEPOSIT)", "IDR", new BigDecimal("12000")),
                new LKPBUSampleData("1 (EQUITY)", "IDR", new BigDecimal("12000")),
                new LKPBUSampleData( "2 (GOVERNMENT BANK)", "IDR", new BigDecimal("12000")),
                new LKPBUSampleData( "11(TIME DEPOSIT)", "USD", new BigDecimal("123.8")),
                new LKPBUSampleData( "2 (GOVERNMENT BANK)", "USD", new BigDecimal("552.5")),
                new LKPBUSampleData( "2 (GOVERNMENT BANK)", "IDR", new BigDecimal("12000")),
                new LKPBUSampleData( "11(TIME DEPOSIT)", "IDR", new BigDecimal("12000")),
                new LKPBUSampleData( "11(TIME DEPOSIT)", "USD", new BigDecimal("155.3"))
        );
    }

}
