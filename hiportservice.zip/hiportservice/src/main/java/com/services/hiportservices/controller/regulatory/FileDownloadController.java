package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.model.regulatory.enumerator.Month;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.nio.file.Files;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.*;

@RestController
@RequestMapping(path = "/api/regulatory/download")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class FileDownloadController {

    @Value("${file.path.lbabk-report}")
    private String basePathLBABKTextFile;

    @Value("${file.path.lbabk-auc-report}")
    private String basePathAUCTextFile;

    @Value("${file.path.lkpbu-report}")
    private String basePathLKPBUTextFile;

    @GetMapping
    public ResponseEntity<byte[]> downloadTextFile(@RequestParam("reportType") String reportType,
                                                   @RequestParam("month") String month,
                                                   @RequestParam("year") Integer year) throws IOException {

        Month monthEnum;
        try {
            monthEnum = Month.fromString(month.toUpperCase());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }

        String yearMonthStr = String.format("%04d%02d", year, monthEnum.getMonthNumber());
        YearMonth yearMonth = YearMonth.parse(yearMonthStr, DateTimeFormatter.ofPattern("yyyyMM"));
        String lastDayOfMonth = yearMonth.atEndOfMonth().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        log.info("Last Day of Month: {}", lastDayOfMonth);

        String fileName;
        String filePath;

        String reportTypeUpperCase = reportType.toUpperCase();

        if (LBABK.equalsIgnoreCase(reportTypeUpperCase)) {
            fileName = LBABK.concat("_").concat(lastDayOfMonth).concat(".txt");
            filePath = basePathLBABKTextFile + fileName;
        } else if (LKPBU.equalsIgnoreCase(reportTypeUpperCase)) {
            fileName = LKPBU.concat("_").concat(lastDayOfMonth).concat(".txt");
            filePath = basePathLKPBUTextFile + fileName;
        } else if (AUC.equalsIgnoreCase(reportTypeUpperCase)) {
            fileName = AUC.concat("_").concat(lastDayOfMonth).concat(".txt");
            filePath = basePathAUCTextFile + fileName;
        } else {
            fileName = "";
            filePath = "";
        }

        File file = new File(filePath);

        if (!file.exists()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }

        byte[] contentBytes;
        try (BufferedInputStream bis = new BufferedInputStream(Files.newInputStream(file.toPath()));
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = bis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            contentBytes = bos.toByteArray();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=" + fileName);

        return new ResponseEntity<>(contentBytes, headers, HttpStatus.OK);
    }

}
