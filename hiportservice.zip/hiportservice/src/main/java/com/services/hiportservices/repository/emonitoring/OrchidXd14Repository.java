package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd14;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

public interface OrchidXd14Repository extends JpaRepository<OrchidXd14, Long> {
    List<OrchidXd14> findAllByPortofolio(String portofolio);

    List<OrchidXd14> findAllByTanggal(Date tanggal);

    OrchidXd14 findByTanggalAndKode(Date tanggal, String code);

    List<OrchidXd14> findByTanggalAndReksadanaCode(Date tanggal, String code);

    @Query(value = "SELECT * FROM ORCHIDXD14 WHERE Tanggal = :date and ( Kode = :reksadanaCode or ReksadanaCode = :reksadanaCode)", nativeQuery = true)
    List<OrchidXd14> searchDataAt(
            @Param("date") Date date,
            @Param("reksadanaCode") String reksadanaCode);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDXD14 WHERE Tanggal = :tgl and ReksadanaCode = :rekCode", nativeQuery = true)
    void deleteOrchidXd14(@Param("tgl") Date tgl,
                          @Param("rekCode") String rekCode);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDXD14 WHERE Tanggal = :tgl", nativeQuery = true)
    void deleteAllOrchidXd14(@Param("tgl") Date tgl);


    @Query(value = "select count(*) AS counter from" +
            " ORCHIDXD14  where Tanggal = :tgl and Kode = :code and Portofolio = :pf and SECTYPE = :sectype and REPORTGROUP =:reportGroup ", nativeQuery = true)
    int count(
            @Param("tgl") Date tgl,
            @Param("code") String code,
            @Param("pf") String pf,
            @Param("sectype") String sectype,
            @Param("reportGroup") String reportGroup);


}
