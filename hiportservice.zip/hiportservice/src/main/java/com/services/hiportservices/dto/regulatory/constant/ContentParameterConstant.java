package com.services.hiportservices.dto.regulatory.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ContentParameterConstant {

    public static final String LKPBU = "LKPBU";
    public static final String LBABK = "LBABK";
    public static final String AUC = "AUC";
    public static final String INCOME = "INCOME";

    public static final String ISIN_CODE_TABLE = "Kode ISIN Efek";
    public static final String ISSUER_CODE_TABLE = "Kode Issuer Efek";
    public static final String ISSUER_CODE_PLACEMENT_BANK_TABLE = "Kode Issuer dan Placement Bank";
    public static final String OWNER_GROUP_TABLE = "Golongan Pemilik";
    public static final String INSURANCE_PENSION_FUND_TABLE = "Asuransi dan Dapen";
    public static final String EXCHANGE_RATE_TABLE = "Closing Rate";

    // Columns in the ISIN Code table
    public static final String ISIN_LKPBU = "ISIN LKPBU";
    public static final String ISIN_LBABK = "ISIN LBABK";
    public static final String ISIN_CURRENCY = "ISIN Currency";
    public static final String ISIN_COUNTRY = "ISIN Negara";

    // Columns in the Issuer Code table
    public static final String ISSUER_LBABK = "Issuer LBABK";
    public static final String ISSUER_LKPBU = "Issuer LKPBU";

    // Columns in the Golongan Pemilik table
    public static final String REFERENSI_GOLONGAN_PIHAK_LAWAN = "Referensi Golongan Pihak Lawan";

    // Columns in the Asuransi dan Dana Pensiun table
    public static final String REFERENSI_DAPEN_ASURANSI = "Referensi Dapen dan Asuransi";
    public static final String DANA_JAMINAN = "Dana Jaminan/Investasi";


    // DEPOSIT CODE
    public static final String DEPOSIT_CODE_F110201 = "F110201";
    public static final String DEPOSIT_CODE_F110202 = "F110202";

    // Additional
    public static final String UNKNOWN_CODE = "Unknown Code";
    public static final String TIME_DEPOSIT_CODE = "11";

    // Recon Type
    public static final String RECON_TYPE_PORTFOLIO_CODE = "PORTFOLIO";
    public static final String RECON_TYPE_SECURITY_CODE = "SECURITY";

    // Currency
    public static final String CURRENCY_USD = "USD";

}
