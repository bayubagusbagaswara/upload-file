package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "reg_lbabk_data_source")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABKDataSource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private Instant createdDate;

    @Column(name = "updated_date")
    private Instant updatedDate;

    @Column(name = "flag_detail")
    private String flagDetail;

    @Column(name = "kode_komponen")
    private String kodeKomponen;

    @Column(name = "tanggal_transaksi")
    private LocalDate tanggalTransaksi;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "kode_tipe_efek")
    private String kodeTipeEfek;

    @Column(name = "keterangan_tipe_efek")
    private String keteranganTipeEfek;

    @Column(name = "isin_code")
    private String isinCode;

    @Column(name = "security_name")
    private String securityName;

    @Column(name = "issuer_code")
    private String issuerCode;

    @Column(name = "issuer_name")
    private String issuerName;

    @Column(name = "kode_mata_uang")
    private String kodeMataUang;

    @Column(name = "buy_frequency")
    private Integer buyFrequency;

    @Column(name = "buy_volume")
    private BigDecimal buyVolume;

    @Column(name = "buy_value")
    private BigDecimal buyValue;

    @Column(name = "buy_investor_indonesia")
    private BigDecimal buyInvestorIndonesia;

    @Column(name = "buy_investor_foreign")
    private BigDecimal buyInvestorForeign;

    @Column(name = "buy_investor_confirmation")
    private BigDecimal buyInvestorConfirmation;

    @Column(name = "sell_frequency")
    private Integer sellFrequency;

    @Column(name = "sell_volume")
    private BigDecimal sellVolume;

    @Column(name = "sell_value")
    private BigDecimal sellValue;

    @Column(name = "sell_investor_indonesia")
    private BigDecimal sellInvestorIndonesia;

    @Column(name = "sell_investor_foreign")
    private BigDecimal sellInvestorForeign;

    @Column(name = "sell_investor_confirmation")
    private BigDecimal sellInvestorConfirmation;

    @Column(name = "kode_efek")
    private String kodeEfek;

    @Column(name = "data_1")
    private String data1; // data 1

    @Column(name = "data_2")
    private String data2; // data 2

//    @Column(name = "buy_result")
//    private String settlementResultBuy; // buyVolume - buyValue
//
//    @Column(name = "sell_result")
//    private String settlementResultSell; // sellVolume - sellValue

//    @Column(name = "flag_recon_isin")
//    private String flagReconISIN; // ISIN
//
//    @Column(name = "flag_recon_issuer")
//    private String flagReconIssuer; // ISSUER

}
