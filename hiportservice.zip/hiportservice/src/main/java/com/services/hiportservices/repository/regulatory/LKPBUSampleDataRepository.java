package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LKPBUSampleData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LKPBUSampleDataRepository extends JpaRepository<LKPBUSampleData, Long> {

//    List<LKPBUSampleData> findAllByMonthAndYear(String month, Integer year);

}
