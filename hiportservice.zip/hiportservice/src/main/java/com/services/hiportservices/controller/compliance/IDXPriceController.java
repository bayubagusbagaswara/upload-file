package com.services.hiportservices.controller.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.service.compliance.AmortizationPriceService;
import com.services.hiportservices.service.compliance.IDXPriceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping("/compliance/idxPrice")
public class IDXPriceController {

    @Autowired
    IDXPriceService idxPriceService;

    @PostMapping("/upload")
    public ResponseEntity<ResponseDto> uploadFileIdx(@RequestBody List<Map<String, String>> idxPriceList) {
        return idxPriceService.insertDataIdxPrice(idxPriceList);
    }

    @GetMapping("/{date}")
    public ResponseEntity<ResponseDto> getAllDataAt(@PathVariable String date) {
        return idxPriceService.findDataAt(date);
    }

    @GetMapping("/viewPending/{date}")
    public ResponseEntity<ResponseDto> viewPendingData(@PathVariable String date) {
        return idxPriceService.viewPendingData(date);
    }

    @GetMapping("/approval")
    public ResponseEntity<ResponseDto> getAllPendingData() {
        return idxPriceService.allPendingDataIDXPrice();
    }

    @PostMapping("/approve")
    public ResponseEntity<ResponseDto> approveDataAt(@RequestBody Map<String, List<String>> dates) {
        return idxPriceService.approveDataIDXPrice(dates);
    }

    @PostMapping("/reject")
    public ResponseEntity<ResponseDto> rejectDataIDXPrice(@RequestBody Map<String, List<String>> dates) {
        return idxPriceService.approveDataIDXPrice(dates);
    }
}
