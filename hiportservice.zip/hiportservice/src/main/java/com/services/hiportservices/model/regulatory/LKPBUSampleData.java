package com.services.hiportservices.model.regulatory;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "reg_lkpbu_sample_data")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUSampleData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
//
//    @Column(name = "month")
//    private String month;
//
//    @Column(name = "year")
//    private Integer year;

    @Column(name = "type_effect")
    private String typeEffect;

    @Column(name = "currency")
    private String currency;

    @Column(name = "value")
    private BigDecimal value;

    public LKPBUSampleData(String typeEffect, String currency, BigDecimal value) {
        this.typeEffect = typeEffect;
        this.currency = currency;
        this.value = value;
    }
}
