package com.services.hiportservices.service.regulatory.impl;

import com.opencsv.exceptions.CsvException;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant;
import com.services.hiportservices.dto.regulatory.datasource.CalculateResponse;
import com.services.hiportservices.exception.regulatory.CsvHandleException;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.exception.regulatory.GeneralHandleException;
import com.services.hiportservices.model.regulatory.*;
import com.services.hiportservices.repository.regulatory.*;
import com.services.hiportservices.service.regulatory.LKPBUDataSourceService;
import com.services.hiportservices.utils.regulatory.CsvDataMapper;
import com.services.hiportservices.utils.regulatory.CsvReaderUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import com.services.hiportservices.utils.regulatory.EnumValidator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class LKPBUDataSourceServiceImpl implements LKPBUDataSourceService {

    @Value("${file.path.lkpbu-data-source.hiport}")
    private String filePath;

    private static final String BASE_FILE_NAME = "LkpbuHiport_";

    private final LKPBUDataSourceRepository dataSourceRepository;
    private final DateUtil dateUtil;
    private final CsvDataMapper csvDataMapper;
    private final LKPBUReconRepository lkpbuReconRepository;
    private final LKPBUIncomeRepository incomeRepository;
    private final IssuerCodePlacementBankRepository placementBankRepository;
    private final DataStatusRepository dataStatusRepository;

    @Override
    public String readAndInsertToDB() {
        log.info("Start read and insert {} data source to the database", ContentParameterConstant.LKPBU);
        String filePathNew = "";

        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());

            String monthNameMinus1 = contextDate.getMonthNameMinus1();
            String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
            Integer yearMinus1 = contextDate.getYearMinus1();

            String fileName = BASE_FILE_NAME + yearMinus1 + monthNameMinus1Value + ".csv";
            filePathNew = filePath + fileName;

            File file = new File(filePathNew);
            if (!file.exists()) {
                throw new DataNotFoundHandleException(ContentParameterConstant.LKPBU + " data source file not found with path: " + filePathNew);
            }

            dataSourceRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

            lkpbuReconRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

            List<String[]> rows = CsvReaderUtil.readCsvFile(filePathNew);

            List<LKPBUDataSource> lkpbuDataSourceList = csvDataMapper.mapCsvLKPBUDataSource(rows);

            CalculateResponse calculateResponse = process(lkpbuDataSourceList);

            return String.format("Total data success: %d, total data failed: %d", calculateResponse.getTotalDataSuccess(), calculateResponse.getTotalDataFailed());
        } catch (DataNotFoundHandleException e) {
            log.error(String.format("%s Data Source file not found: {}", ContentParameterConstant.LKPBU), e.getMessage(), e);
            throw new DataNotFoundHandleException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error(String.format("%s Data Source failed to process CSV data from file: {}", ContentParameterConstant.LKPBU), filePathNew, e);
            throw new CsvHandleException(ContentParameterConstant.LKPBU + " failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", e.getMessage(), e);
            throw new GeneralHandleException(ContentParameterConstant.LKPBU + " Data Source unexpected error: " + e.getMessage());
        }
    }

    private CalculateResponse process(List<LKPBUDataSource> dataList) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        int processData = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (LKPBUDataSource dataSource : dataList) {
            List<String> validationErrors = new ArrayList<>();

            try {
                processData++;
                log.info("{} data source {}-{} process data- : {}", LKPBU, dataSource.getData1(), dataSource.getData2(), processData);

                validateIssuerPlacementBank(dataSource);

                validateIncome(dataSource);

                LKPBUDataSource save = dataSourceRepository.save(dataSource);

                log.info(String.format("Successfully save %s data source with id: {}", ContentParameterConstant.LKPBU), save.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                handleGeneralError(dataSource, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }

            int remainingData = dataList.size() - totalDataSuccess - totalDataFailed;
            updateDataStatus(LKPBU, totalDataSuccess, totalDataFailed, remainingData);
        }
        return new CalculateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private void validateIncome(LKPBUDataSource dataSave) {
        if (!DEPOSIT_CODE_F110201.equalsIgnoreCase(dataSave.getJenis()) || !DEPOSIT_CODE_F110202.equalsIgnoreCase(dataSave.getJenis())) {
            String concatData1And2 = dataSave.getData1().concat(dataSave.getData2());
            Optional<LKPBUIncome> incomeOptional = incomeRepository.findByDataConcatAndMonthAndYear(concatData1And2, dataSave.getMonth(), dataSave.getYear());
            if (incomeOptional.isPresent()) {
                LKPBUIncome lkpbuIncome = incomeOptional.get();
                dataSave.setPembayaranKupon(lkpbuIncome.getNominal());
            } else {
                dataSave.setPembayaranKupon(BigDecimal.ZERO);
            }
        }
    }

    private void validateIssuerPlacementBank(LKPBUDataSource dataSave) {
        String data2 = dataSave.getData2();
        boolean b = EnumValidator.validateEnumOwnerIssuer(dataSave.getGolonganPenerbit());
        if (!b) {
            if (DEPOSIT_CODE_F110201.equalsIgnoreCase(dataSave.getJenis()) || DEPOSIT_CODE_F110202.equalsIgnoreCase(dataSave.getJenis())) {
                Optional<IssuerCodePlacementBank> placementBankOptional = placementBankRepository.findByCodeContaining(data2);
                if (placementBankOptional.isPresent()) {
                    IssuerCodePlacementBank issuerCodePlacementBank = placementBankOptional.get();
                    dataSave.setKodeEfek(issuerCodePlacementBank.getBankName());
                }
            } else {
                dataSave.setKodeEfek(data2);
            }
        }
    }

    private void handleGeneralError(LKPBUDataSource data, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        data != null && !data.getData1().isEmpty()
                                ? data.getData2() : UNKNOWN_CODE,
                        validationErrors
                )
        );
    }

    public void updateDataStatus(String dataType, int totalDataSuccess, int totalDataFailed, int remainingData) {
        // ini artinya sekali proses
        // jika proses 1 (tanggal 1) itu terjadi error atau hasilnya tidak sesuai, maka jika melakukan read-insert lagi, akan set menjadi 0 lagi
        DataStatus dataStatus = dataStatusRepository.findByDataType(dataType)
                .orElse(new DataStatus(dataType, 0, 0, remainingData));

        dataStatus.setTotalDataSuccess(totalDataSuccess);
        dataStatus.setTotalDataFailed(totalDataFailed);
        dataStatus.setRemainingData(remainingData);
        dataStatus.setLastUpdated(LocalDateTime.now());

        dataStatusRepository.save(dataStatus);
    }

}
