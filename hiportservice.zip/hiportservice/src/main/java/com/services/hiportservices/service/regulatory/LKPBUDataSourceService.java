package com.services.hiportservices.service.regulatory;

public interface LKPBUDataSourceService {

    String readAndInsertToDB();
}
