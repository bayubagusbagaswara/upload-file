
package com.services.hiportservices.model.compliance;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@Table(name = "comp_breach_kinv")
public class BreachKebijakanInvestasi {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "data_date")
    private Date date;

    @Column(name = "reksadana_code")
    private String reksadanaCode;

    @Column(name = "rd_external_code")
    private String rdExternalCode;

    @Column(name = "reksadana_name")
    private String reksadanaName;

    @Column(name = "jumlah_XD14")
    private double jumlahXD14;

    @Column(name = "kinv_code")
    private String kinvCode;

    @Column(name = "kinv_min")
    private double kinvMin;

    @Column(name = "kinv_max")
    private double kinvMax;

    @Column(name = "total_percentage_asset")
    private double totalPercentageAsset;

    @Column(name = "breach")
    private String breach;
}
