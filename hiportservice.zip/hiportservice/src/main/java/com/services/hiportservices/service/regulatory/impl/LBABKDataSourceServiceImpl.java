package com.services.hiportservices.service.regulatory.impl;

import com.opencsv.exceptions.CsvException;
import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant;
import com.services.hiportservices.dto.regulatory.datasource.CalculateResponse;
import com.services.hiportservices.exception.regulatory.CsvHandleException;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.exception.regulatory.GeneralHandleException;
import com.services.hiportservices.exception.regulatory.InvalidSecuritiesCodeException;
import com.services.hiportservices.model.regulatory.*;
import com.services.hiportservices.repository.regulatory.*;
import com.services.hiportservices.service.regulatory.LBABKDataSourceService;
import com.services.hiportservices.utils.regulatory.CsvDataMapper;
import com.services.hiportservices.utils.regulatory.CsvReaderUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import com.services.hiportservices.utils.regulatory.ExtractEffectTypeCodeUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class LBABKDataSourceServiceImpl implements LBABKDataSourceService {

    @Value("${file.path.lbabk-data-source}")
    private String filePath;

    private static final String BASE_FILE_NAME = "Lbabk_";

    private final LBABKDataSourceRepository dataSourceRepository;
    private final DateUtil dateUtil;
    private final CsvDataMapper csvDataMapper;
    private final LBABKReconRepository reconRepository;
    private final IssuerCodePlacementBankRepository issuerCodePlacementBankRepository;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public String readAndInsertToDB() {
        log.info("Start read and insert LBABK data source to the database");
        String filePathNew = "";

        try {
            ContextDate contextDate = dateUtil.buildContextDate(Instant.now());
            String monthNameMinus1 = contextDate.getMonthNameMinus1();
            String monthNameMinus1Value = contextDate.getMonthNameMinus1Value();
            Integer yearMinus1 = contextDate.getYearMinus1();

            String fileName = BASE_FILE_NAME + yearMinus1 + monthNameMinus1Value + ".csv";
            filePathNew = filePath + fileName;

            File file = new File(filePathNew);
            if (!file.exists()) {
                throw new DataNotFoundHandleException("LBABK data source file not found with path: " + filePathNew);
            }

            dataSourceRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);
            reconRepository.deleteByMonthAndYear(monthNameMinus1, yearMinus1);

            List<String[]> rows = CsvReaderUtil.readCsvFile(filePathNew);

            List<LBABKDataSource> lbabkDataSourceList = csvDataMapper.mapCsvLBABKDataSource(rows);

            CalculateResponse calculateResponse = process(lbabkDataSourceList);

            return String.format("Total data success: %d, total data failed: %d", calculateResponse.getTotalDataSuccess(), calculateResponse.getTotalDataFailed());
        } catch (DataNotFoundHandleException e) {
            log.error("{} Data Source file not found: {}", ContentParameterConstant.LBABK, e.getMessage(), e);
            throw new DataNotFoundHandleException(e.getMessage());
        } catch (IOException | CsvException e) {
            log.error("{} Data Source failed to process CSV data from file: {}", ContentParameterConstant.LBABK, filePathNew, e);
            throw new CsvHandleException(ContentParameterConstant.LBABK + " failed to process CSV data: " + e.getMessage());
        } catch (Exception e) {
            log.error("Unexpected error occurred while processing file: {}", e.getMessage(), e);
            throw new GeneralHandleException(ContentParameterConstant.LBABK + " data source unexpected error: " + e.getMessage());
        }
    }

    private CalculateResponse process(List<LBABKDataSource> dataList) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (LBABKDataSource lbabkDataSource : dataList) {
            List<String> validationErrors = new ArrayList<>();

            try {
                validateSecuritiesCode(lbabkDataSource);

                validateIssuerPlacementBank(lbabkDataSource);

                LBABKDataSource save = dataSourceRepository.save(lbabkDataSource);

                log.info("Successfully save {} data source with id: {}", ContentParameterConstant.LBABK, save.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error when process LBABK Data Source with kode efek: {}, security code: {}", lbabkDataSource.getKodeEfek(), lbabkDataSource.getData2());
                handleGeneralError(lbabkDataSource, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }

        return new CalculateResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    private void validateIssuerPlacementBank(LBABKDataSource dataSource) {
        String data2 = dataSource.getData2();
        String effectTypeCode = ExtractEffectTypeCodeUtil.extractCode(dataSource.getKodeTipeEfek());

        if (TIME_DEPOSIT_CODE.equalsIgnoreCase(effectTypeCode)) {
            Optional<IssuerCodePlacementBank> issuerCodePlacementBankOptional = issuerCodePlacementBankRepository.findByCodeContaining(data2);
            if (issuerCodePlacementBankOptional.isPresent()) {
                IssuerCodePlacementBank issuerCodePlacementBank = issuerCodePlacementBankOptional.get();
                dataSource.setIssuerCode(issuerCodePlacementBank.getCode().substring(0, 5));
                dataSource.setKodeEfek(issuerCodePlacementBank.getCode());
            } else {
                DataNotFound dataNotFound = DataNotFound.builder()
                        .createdDate(Instant.now())
                        .month(dataSource.getMonth())
                        .year(dataSource.getYear())
                        .dataSourcePeriod(dataSource.getMonth().concat(" ").concat(String.valueOf(dataSource.getYear())))
                        .code(data2)
                        .description(String.format("Issuer Code Placement Bank not found with containing data 2 (security code): %s", data2))
                        .status(Boolean.FALSE)
                        .reportType(LBABK)
                        .flagTable(ISSUER_CODE_PLACEMENT_BANK_TABLE)
                        .build();
                dataNotFoundRepository.save(dataNotFound);
            }
        }
    }

    private void validateSecuritiesCode(LBABKDataSource dataSource) {
        String effectTypeCode = ExtractEffectTypeCodeUtil.extractCode(dataSource.getKodeTipeEfek());
        if (!TIME_DEPOSIT_CODE.equalsIgnoreCase(effectTypeCode)
                && (dataSource.getKodeEfek() == null
                || dataSource.getKodeEfek().isEmpty())) {
                throw new InvalidSecuritiesCodeException("Kode Efek harus ada untuk Kode Tipe Efek selain " + TIME_DEPOSIT_CODE);
        }
    }

    private void handleGeneralError(LBABKDataSource data, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        data != null && !data.getFlagDetail().isEmpty()
                                ? data.getFlagDetail() : UNKNOWN_CODE,
                        validationErrors)
        );
    }

}
