package com.services.hiportservices.dto.regulatory.insurancepensionfund;

import com.services.hiportservices.dto.regulatory.approval.ApprovalIdentifierRequest;
import lombok.*;

@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ApproveInsurancePensionFundRequest extends ApprovalIdentifierRequest {

    private Long dataChangeId;

}
