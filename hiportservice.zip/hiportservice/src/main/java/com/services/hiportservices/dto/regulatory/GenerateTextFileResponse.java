package com.services.hiportservices.dto.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GenerateTextFileResponse {

    private Integer totalDataSuccess;

    private Integer totalDataFailed;

}
