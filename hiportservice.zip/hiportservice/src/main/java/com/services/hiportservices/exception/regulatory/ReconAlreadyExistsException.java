package com.services.hiportservices.exception.regulatory;

public class ReconAlreadyExistsException extends RuntimeException {

    public ReconAlreadyExistsException() {
        super();
    }

    public ReconAlreadyExistsException(String message) {
        super(message);
    }

    public ReconAlreadyExistsException(String message, Throwable cause) {
        super(message, cause);
    }


}
