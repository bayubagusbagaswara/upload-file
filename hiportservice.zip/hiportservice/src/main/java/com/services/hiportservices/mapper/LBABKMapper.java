package com.services.hiportservices.mapper;

import com.services.hiportservices.model.regulatory.LBABK;
import com.services.hiportservices.model.regulatory.LBABKDataSource;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface LBABKMapper {

    LBABK mapFromDataSourceToLBABK(LBABKDataSource dataSource);

}
