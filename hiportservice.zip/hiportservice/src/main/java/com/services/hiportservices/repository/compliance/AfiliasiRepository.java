package com.services.hiportservices.repository.compliance;

import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.Afiliasi;
import com.services.hiportservices.model.compliance.Portfolio;
import com.services.hiportservices.model.compliance.PortfolioKINVGrouping;
import com.services.hiportservices.model.compliance.Reksadana;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Repository
public interface AfiliasiRepository extends JpaRepository<Afiliasi,Long> {
    Afiliasi findByReksadanaCode(String code);

    @Query("SELECT u FROM Afiliasi u WHERE u.approvalStatus = :approvalStatus and u.reksadanaCode like %:reksadanaCode%")
    List<Afiliasi> searchByReksadanaCodeLike(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("reksadanaCode") Reksadana reksadanaCode);

    @Query("SELECT u FROM Afiliasi u WHERE u.approvalStatus = :approvalStatus and u.reksadanaName like %:reksadanaName%")
    List<Afiliasi> searchByReksadanaNameLike(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("reksadanaName") String reksadanaName);

    @Query("SELECT u FROM Afiliasi u WHERE u.approvalStatus = :approvalStatus and u.reksadanaCode = :reksadanaCode")
    List<Afiliasi> searchByReksadanaCode(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("reksadanaCode") Reksadana reksadanaCode);

    List<Afiliasi> findByIdAndApprovalStatus(Long id, ApprovalStatus approvalStatus);

    @Query("SELECT u FROM Afiliasi u WHERE u.approvalStatus = :approvalStatus and u.reksadanaCode = :reksadanaCode and u.kodeEfek = :kodeEfek")
    Afiliasi searchByReksadanaCodeAndKodeEfek(
            @Param("approvalStatus") ApprovalStatus approvalStatus,
            @Param("reksadanaCode") Reksadana reksadanaCode,
            @Param("kodeEfek") String kodeEfek);

    @Transactional
    @Modifying
    @Query("DELETE FROM Afiliasi f where f.reksadanaCode= :reksadanaCode and f.kodeEfek = :kodeEfek")
    void deletePihakTerafiliasi(@Param("reksadanaCode") Reksadana reksadanaCode,
                                @Param("kodeEfek") String kodeEfek);

    @Query("SELECT u FROM Afiliasi u WHERE  u.approvalStatus = 'Pending'")
    List<Afiliasi> searchPendingAfiliasiData();

    @Transactional
    @Modifying
    @Query(value="UPDATE comp_afiliasi SET approval_status = :approvalStatus, approve_date = :approveDate, approver_id = :approverId " +
            "WHERE id = :id", nativeQuery = true)
    void approveOrRejectAfiliasi(@Param("approvalStatus") String approvalStatus,
                                         @Param("approveDate") Date approveDate,
                                         @Param("approverId") String approverId,
                                         @Param("id") Long id);
}
