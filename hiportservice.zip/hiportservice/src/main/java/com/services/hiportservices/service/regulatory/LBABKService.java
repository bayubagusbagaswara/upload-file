package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.lbabk.LBABKProcessResponse;
import com.services.hiportservices.model.regulatory.LBABK;

import java.util.List;

public interface LBABKService {

    LBABKProcessResponse process(String month, Integer year);

    String generateTxtAndSaveToServer(String month, Integer year);

    List<LBABK> getAllByMonthAndYear(String month, Integer year);

}
