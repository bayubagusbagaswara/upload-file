package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.GenerateTextFileResponse;
import com.services.hiportservices.dto.regulatory.lbabk.LBABKProcessResponse;
import com.services.hiportservices.exception.regulatory.GeneralHandleException;
import com.services.hiportservices.exception.regulatory.ReconAlreadyExistsException;
import com.services.hiportservices.mapper.LBABKMapper;
import com.services.hiportservices.model.regulatory.LBABK;
import com.services.hiportservices.model.regulatory.LBABKDataSource;
import com.services.hiportservices.model.regulatory.LBABKRecon;
import com.services.hiportservices.repository.regulatory.LBABKDataSourceRepository;
import com.services.hiportservices.repository.regulatory.LBABKReconRepository;
import com.services.hiportservices.repository.regulatory.LBABKRepository;
import com.services.hiportservices.service.regulatory.LBABKService;
import com.services.hiportservices.utils.regulatory.DateUtil;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.UNKNOWN_CODE;

@Service
@Slf4j
@RequiredArgsConstructor
public class LBABKServiceImpl implements LBABKService {

    @Value("${file.path.lbabk-report}")
    private String filePathDataLBABK;

    private final LBABKRepository lbabkRepository;
    private final LBABKDataSourceRepository lbabkDataSourceRepository;
    private final DateUtil dateUtil;
    private final LBABKReconRepository reconRepository;
    private final LBABKMapper lbabkMapper;

    @Override
    public LBABKProcessResponse process(String month, Integer year) {
        Instant now = Instant.now();
        log.info("Start process LBABK with date: {}", now);

        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();

        /* Get all data recon by month and year */
        List<LBABKRecon> reconList = reconRepository.findAllByMonthAndYearAndStatus(
                month, year, Boolean.FALSE
        );

        if (!reconList.isEmpty()) {
            String errorMsg = String.format("Recon data already exists for month: %s, year: %d. Process aborted.", month, year);
            throw new ReconAlreadyExistsException(errorMsg);
        }

        List<LBABKDataSource> dataSourceList = lbabkDataSourceRepository.findAllByMonthAndYear(month, year);

        for (LBABKDataSource dataSource : dataSourceList) {
            try {
                LBABK lbabk = lbabkMapper.mapFromDataSourceToLBABK(dataSource);

                LBABK save = lbabkRepository.save(lbabk);
                log.info("Success save LBABK with id: {}", save.getId());
                totalDataSuccess++;
            } catch (Exception e) {
                log.error("Error when process LBABK: {}", e.getMessage(), e);
                handleGeneralError(dataSource.getData1(), e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }

        return new LBABKProcessResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public List<LBABK> getAllByMonthAndYear(String month, Integer year) {
        return lbabkRepository.findAllByMonthAndYear(month, year);
    }

    @Override
    public String generateTxtAndSaveToServer(String month, Integer year) {
        log.info("Start generate txt file LBABK with month: {}, year: {}", month, year);
        try {
            Instant now = Instant.now();

            List<LBABK> lbabkList = lbabkRepository.findAllByMonthAndYear(month, year);

            GenerateTextFileResponse response = generateAndSaveTxtStatements(lbabkList, now);

            return "Successfully created a Text File for LBABK with total data success: "
                    + response.getTotalDataSuccess()
                    + ", and total data failed: "
                    + response.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate Text File LBABK: {}", e.getMessage(), e);
            throw new GeneralHandleException("Error when generate Text File LBABK: " + e.getMessage());
        }
    }

    private GenerateTextFileResponse generateAndSaveTxtStatements(List<LBABK> dataList, Instant instant) {
        log.info("Start generate and save txt statements with size: {}", dataList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;

        try {
            ContextDate contextDate = dateUtil.buildContextDate(instant);

            StringBuilder content = new StringBuilder();
            content
                    .append("H01").append("|")
                    .append("021001").append("|")
                    .append("BDMN2").append("|")
                    .append(contextDate.getLastDayOfPreviousMonth()).append("|")
                    .append("BKMAB").append("|")
                    .append("94M101").append("|")
                    .append("\n");

            for (LBABK data : dataList) {
                content
                        .append(data.getFlagDetail()).append("|")
                        .append(data.getKodeKomponen()).append("|")
                        .append(data.getTanggalTransaksi().toString().replace("-","")).append("|")
                        .append(extractCode(data.getKodeTipeEfek())).append("|")
                        .append(data.getKeteranganTipeEfek()).append("|")
                        .append(data.getIsinCode()).append("|")
                        .append(data.getSecurityName()).append("|")
                        .append(data.getIssuerCode()).append("|")
                        .append(data.getIssuerName()).append("|")
                        .append(data.getKodeMataUang()).append("|")
                        .append(data.getBuyFrequency()).append("|")
                        .append(data.getBuyVolume()).append("|")
                        .append(data.getBuyValue()).append("|")
                        .append(data.getBuyInvestorIndonesia()).append("|")
                        .append(data.getBuyInvestorForeign()).append("|")
                        .append(data.getBuyInvestorConfirmation()).append("|")
                        .append(data.getSellFrequency()).append("|")
                        .append(data.getSellVolume()).append("|")
                        .append(data.getSellValue()).append("|")
                        .append(data.getSellInvestorIndonesia()).append("|")
                        .append(data.getSellInvestorForeign()).append("|")
                        .append(data.getSellInvestorConfirmation()).append("|")
                        .append(data.getKodeEfek())
                        .append("\n");
            }

            /* create filename */
            String fileName = "LBABK_"
                    + contextDate.getLastDayOfPreviousMonth().replace("-", "")
                    + ".txt";

            String filePath = filePathDataLBABK + fileName;

            deleteExistingFile(filePath);

            saveTextFile(filePath, content.toString());

            totalDataSuccess++;
        } catch (Exception e) {
            log.error("Error when generateAndSaveTxtStatements: {}", e.getMessage(), e);
            totalDataFailed++;
        }
        return new GenerateTextFileResponse(totalDataSuccess, totalDataFailed);
    }

    private static void deleteExistingFile(String filePath) {
        Path path = Paths.get(filePath);
        if (Files.exists(path)) {
            try {
                Files.delete(path);
                log.info("File sebelumnya berhasil dihapus: {}", filePath);
            } catch (IOException e) {
                log.error("Gagal menghapus file: {}. Kesalahan: {}", filePath, e.getMessage(), e);
            }
        } else {
            log.info("File tidak ditemukan: {}", filePath);
        }
    }

    private static void saveTextFile(String filePath, String content) throws IOException {
        File file = new File(filePath);

        Path path = Paths.get(file.getParent());
        if (Files.notExists(path)) {
            Files.createDirectories(path);
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(content);
            log.info("File baru berhasil disimpan di: {}", filePath);
        } catch (IOException e) {
            log.info("Terjadi kesalahan saat menyimpan file: {}", e.getMessage());
        }
    }

    private void handleGeneralError(String data, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        data != null && !data.isEmpty() ? data : UNKNOWN_CODE,
                        validationErrors
                )
        );
    }

    public static String extractCode(String input) {
        Pattern pattern = Pattern.compile("^\\d+");
        Matcher matcher = pattern.matcher(input);

        if (matcher.find()) {
            return matcher.group();
        } else {
            return "No code found";
        }
    }

}
