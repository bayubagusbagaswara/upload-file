package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUDTO;
import com.services.hiportservices.model.regulatory.LKPBU;
import com.services.hiportservices.model.regulatory.LKPBUDataSource;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Mapper(componentModel = "spring")
public interface LKPBUMapper {

    @Mapping(source = "tipeSaham", target = "typeEffect")
    LKPBU mapFromDataSourceToLKPBU(LKPBUDataSource dataSource);

    @Mapping(source = "lembarUnit", target = "lembarUnit", qualifiedByName = "bigDecimalToString")
    @Mapping(source = "nilaiValutaAsal", target = "nilaiValutaAsal", qualifiedByName = "bigDecimalToString")
    @Mapping(source = "pembayaranKupon", target = "pembayaranKupon", qualifiedByName = "bigDecimalToString")
    LKPBUDTO mapToDTO(LKPBU lkpbu);

    List<LKPBUDTO> mapToDTOList(List<LKPBU> lkpbuList);

    @Named("bigDecimalToString")
    default String formatBigDecimal(BigDecimal value) {
        if (value == null || value.compareTo(BigDecimal.ZERO) == 0) {
            return "";
        }

        BigDecimal formattedValue = value.setScale(0, RoundingMode.HALF_UP);
        return formattedValue.toPlainString();
    }

}
