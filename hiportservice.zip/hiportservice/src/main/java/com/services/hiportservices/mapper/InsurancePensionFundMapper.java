package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.insurancepensionfund.InsurancePensionFundDTO;
import com.services.hiportservices.dto.regulatory.insurancepensionfund.UploadInsurancePensionFundDataRequest;
import com.services.hiportservices.model.regulatory.InsurancePensionFund;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface InsurancePensionFundMapper {

    @Mapping(source = "id", target = "id")
    InsurancePensionFundDTO toDTO(InsurancePensionFund insurancePensionFund);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "portfolioCode", source = "portfolioCode", qualifiedByName = "nullToEmpty")
    @Mapping(target = "portfolioName", source = "portfolioName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "regulatoryName", source = "regulatoryName", qualifiedByName = "nullToEmpty")
    @Mapping(target = "insurancePensionFundReference", source = "insurancePensionFundReference", qualifiedByName = "nullToEmpty")
    @Mapping(target = "guaranteeFund", source = "guaranteeFund", qualifiedByName = "nullToEmpty")
    InsurancePensionFundDTO fromUploadRequestToDTO(UploadInsurancePensionFundDataRequest dataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    List<InsurancePensionFundDTO> toDTOList(List<InsurancePensionFund> all);

}