package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

@Data
public class AddDeletePortfolioKINVRequestDTO {
    private String reksadanaCode;
    private String addPortfolio;
    private String deletePortfolio;
}
