package com.services.hiportservices.model.compliance;

import com.services.hiportservices.model.Approvable;
import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "comp_portfolio_type")
public class PortfolioType extends Approvable {
    @Id
    @Column(name = "portfolio_type")
    private int portfolioType;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "isDelete")
    private boolean delete;
}
