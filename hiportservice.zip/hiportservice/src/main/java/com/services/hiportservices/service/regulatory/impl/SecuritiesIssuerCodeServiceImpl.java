package com.services.hiportservices.service.regulatory.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.securitiesissuercode.*;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.mapper.RegulatoryDataChangeMapper;
import com.services.hiportservices.mapper.SecuritiesIssuerCodeMapper;
import com.services.hiportservices.model.regulatory.DataNotFound;
import com.services.hiportservices.model.regulatory.RegulatoryDataChange;
import com.services.hiportservices.model.regulatory.SecuritiesIssuerCode;
import com.services.hiportservices.repository.regulatory.DataNotFoundRepository;
import com.services.hiportservices.repository.regulatory.SecuritiesIssuerCodeRepository;
import com.services.hiportservices.service.regulatory.RegulatoryDataChangeService;
import com.services.hiportservices.service.regulatory.SecuritiesIssuerCodeService;
import com.services.hiportservices.utils.regulatory.JsonUtil;
import com.services.hiportservices.utils.regulatory.ValidationData;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Errors;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.ISSUER_CODE_TABLE;
import static com.services.hiportservices.enums.ApprovalStatus.Approved;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.HttpMethod.PUT;

@Service
@Slf4j
@RequiredArgsConstructor
public class SecuritiesIssuerCodeServiceImpl implements SecuritiesIssuerCodeService {

    private static final String CREATE_APPROVE_URL = "/api/regulatory/issuer-code/create/approve";
    private static final String UPDATE_APPROVE_URL = "/api/regulatory/issuer-code/update/approve";

    private static final String ID_NOT_FOUND = "Securities Issuer Code not found with id: ";
    private static final String UNKNOWN_EXTERNAL_CODE = "Unknown External Code";

    private final SecuritiesIssuerCodeRepository securitiesIssuerCodeRepository;
    private final ObjectMapper objectMapper;
    private final ValidationData validationData;
    private final RegulatoryDataChangeService regulatoryDataChangeService;
    private final RegulatoryDataChangeMapper dataChangeMapper;
    private final SecuritiesIssuerCodeMapper securitiesIssuerCodeMapper;
    private final DataNotFoundRepository dataNotFoundRepository;

    @Override
    public boolean isExternalCodeAlreadyExists(String externalCode) {
        log.info("Check the existing Issuer Code with the external code: {}", externalCode);
        return securitiesIssuerCodeRepository.existsByExternalCode2(externalCode);
    }

    @Transactional
    @Override
    public synchronized SecuritiesIssuerCodeResponse uploadData(UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start upload data Issuer Code: {}, {}", uploadSecuritiesIssuerCodeListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadSecuritiesIssuerCodeDataRequest issuerCodeDataRequest : uploadSecuritiesIssuerCodeListRequest.getUploadIssuerCodeDataListRequest()) {
            List<String> validationErrors = new ArrayList<>();
            SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = null;
            try {

                // TODO: validate object issuerCodeDataRequest
                // Ketika create data baru, maka semua akan wajib diupload
                // Tapi ketika update, data yang tidak diupdate akan jadi string kosong
                Errors errors = validationData.validateObject(issuerCodeDataRequest);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                securitiesIssuerCodeDTO = securitiesIssuerCodeMapper.fromUploadRequestToDTO(issuerCodeDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                            !securitiesIssuerCodeDTO.getExternalCode().isEmpty() ? securitiesIssuerCodeDTO.getExternalCode() : UNKNOWN_EXTERNAL_CODE,
                            validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    Optional<SecuritiesIssuerCode> securitiesIssuerCodeOptional = securitiesIssuerCodeRepository.findByExternalCode2(issuerCodeDataRequest.getExternalCode2());

                    if (securitiesIssuerCodeOptional.isPresent()) {
                        handleExistingIssuerCode(securitiesIssuerCodeOptional.get(), securitiesIssuerCodeDTO, regulatoryDataChangeDTO);
                    } else {
                        handleNewIssuerCode(securitiesIssuerCodeDTO, regulatoryDataChangeDTO);
                    }
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(securitiesIssuerCodeDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new SecuritiesIssuerCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesIssuerCodeResponse createApprove(ApproveSecuritiesIssuerCodeRequest approveRequest, String approveIPAddress) {
        log.info("Start create approve Issuer Code: {}, {}", approveRequest, approveIPAddress);
        String approveId = approveRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveRequest.getDataChangeId());
            securitiesIssuerCodeDTO = objectMapper.readValue(
                    dataChange.getJsonDataAfter(),
                    SecuritiesIssuerCodeDTO.class
            );

            /* validate whether the code already exists */
            validationExternalCodeAlreadyExists(securitiesIssuerCodeDTO.getExternalCode(), validationErrors);

            if (!validationErrors.isEmpty()) {
                regulatoryDataChangeService.setApprovalStatusIsRejected(dataChange, validationErrors);
                totalDataFailed++;
            } else {
                LocalDateTime approveDate = LocalDateTime.now();

                SecuritiesIssuerCode securitiesIssuerCode = SecuritiesIssuerCode.builder()
                        .approvalStatus(Approved)
                        .approverId(approveId)
                        .approveDate(approveDate)
                        .approveIPAddress(approveIPAddress)
                        .inputerId(dataChange.getInputerId())
                        .inputDate(dataChange.getInputDate())
                        .inputIPAddress(dataChange.getInputIPAddress())
                        .externalCode2(securitiesIssuerCodeDTO.getExternalCode().trim())
                        .currency(securitiesIssuerCodeDTO.getCurrency().trim())
                        .issuerLKPBU(securitiesIssuerCodeDTO.getIssuerLKPBU().trim())
                        .issuerLBABK(securitiesIssuerCodeDTO.getIssuerLBABK().trim())
                        .build();

                SecuritiesIssuerCode save = securitiesIssuerCodeRepository.save(securitiesIssuerCode);

                dataChange.setApproverId(approveId);
                dataChange.setApproveDate(approveDate);
                dataChange.setApproveIPAddress(approveIPAddress);
                dataChange.setEntityId(save.getId().toString());
                dataChange.setJsonDataAfter(
                        JsonUtil.cleanedEntityDataFromApprovalData(
                                objectMapper.writeValueAsString(save)
                        )
                );
                dataChange.setDescription("Success create approve with id: " + save.getId());
                regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

                /* Get all data not found by FLAG_TABLE and code. The code can be filled with data 1 or data 2 (data source) */
                List<DataNotFound> dataNotFoundList = dataNotFoundRepository.findAllByFlagTableAndCode(
                        ISSUER_CODE_TABLE, save.getExternalCode2()
                );

                if (!dataNotFoundList.isEmpty()) {
                    dataNotFoundList.forEach(dataNotFound -> dataNotFound.setStatus(Boolean.TRUE));
                    dataNotFoundRepository.saveAll(dataNotFoundList);
                }

                totalDataSuccess++;
            }
        } catch (Exception e) {
            handleGeneralError(securitiesIssuerCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesIssuerCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesIssuerCodeResponse updateApprove(ApproveSecuritiesIssuerCodeRequest approveRequest, String approveIPAddress) {
        log.info("Start update approve Issuer Code: {}, {}", approveRequest, approveIPAddress);
        String approveId = approveRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveRequest.getDataChangeId());

            securitiesIssuerCodeDTO = objectMapper.readValue(
                    dataChange.getJsonDataAfter(), SecuritiesIssuerCodeDTO.class
            );

            SecuritiesIssuerCode securitiesIssuerCode = securitiesIssuerCodeRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            if (!securitiesIssuerCodeDTO.getCurrency().isEmpty()) {
                securitiesIssuerCode.setCurrency(securitiesIssuerCodeDTO.getCurrency().trim());
            }

            if (!securitiesIssuerCodeDTO.getIssuerLKPBU().isEmpty()) {
                securitiesIssuerCode.setIssuerLKPBU(securitiesIssuerCodeDTO.getIssuerLKPBU().trim());
            }

            if (!securitiesIssuerCodeDTO.getIssuerLBABK().isEmpty()) {
                securitiesIssuerCode.setIssuerLBABK(securitiesIssuerCodeDTO.getIssuerLBABK().trim());
            }

            LocalDateTime approveDate = LocalDateTime.now();

            securitiesIssuerCode.setApprovalStatus(Approved);
            securitiesIssuerCode.setApproverId(approveId);
            securitiesIssuerCode.setApproveIPAddress(approveIPAddress);
            securitiesIssuerCode.setInputerId(dataChange.getInputerId());
            securitiesIssuerCode.setInputIPAddress(dataChange.getInputIPAddress());
            securitiesIssuerCode.setInputDate(dataChange.getInputDate());

            SecuritiesIssuerCode save = securitiesIssuerCodeRepository.save(securitiesIssuerCode);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(approveDate);
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setJsonDataAfter(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(save)
                    )
            );
            dataChange.setDescription("Success update approve with id: " + save.getId());
            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(securitiesIssuerCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesIssuerCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesIssuerCodeResponse deleteById(DeleteSecuritiesIssuerCodeRequest deleteSecuritiesIssuerCodeRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        log.info("Start delete Issuer Code by id: {}, {}", deleteSecuritiesIssuerCodeRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = null;

        try {
            SecuritiesIssuerCode securitiesIssuerCode = securitiesIssuerCodeRepository.findById(deleteSecuritiesIssuerCodeRequest.getId())
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + deleteSecuritiesIssuerCodeRequest.getId()));

            securitiesIssuerCodeDTO = securitiesIssuerCodeMapper.toDTO(securitiesIssuerCode);

            regulatoryDataChangeDTO.setEntityId(securitiesIssuerCode.getId().toString());
            regulatoryDataChangeDTO.setJsonDataBefore(
                    JsonUtil.cleanedEntityDataFromApprovalData(
                            objectMapper.writeValueAsString(securitiesIssuerCode)
                    )
            );
            regulatoryDataChangeDTO.setJsonDataAfter("");
            RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
            regulatoryDataChangeService.createChangeActionDelete(regulatoryDataChange, SecuritiesIssuerCode.class);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(securitiesIssuerCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesIssuerCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Transactional
    @Override
    public synchronized SecuritiesIssuerCodeResponse deleteApprove(ApproveSecuritiesIssuerCodeRequest approveSecuritiesIssuerCodeRequest, String approveIPAddress) {
        log.info("Delete approve Issuer Code: {}, {}", approveSecuritiesIssuerCodeRequest, approveIPAddress);
        String approveId = approveSecuritiesIssuerCodeRequest.getApproverId();
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        List<String> validationErrors = new ArrayList<>();
        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = null;

        try {
            RegulatoryDataChange dataChange = regulatoryDataChangeService.getById(approveSecuritiesIssuerCodeRequest.getDataChangeId());

            SecuritiesIssuerCode securitiesIssuerCode = securitiesIssuerCodeRepository.findById(Long.valueOf(dataChange.getEntityId()))
                    .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + dataChange.getEntityId()));

            securitiesIssuerCodeDTO = securitiesIssuerCodeMapper.toDTO(securitiesIssuerCode);

            dataChange.setApproverId(approveId);
            dataChange.setApproveDate(LocalDateTime.now());
            dataChange.setApproveIPAddress(approveIPAddress);
            dataChange.setDescription("Success delete approve with id: " + securitiesIssuerCode.getId());

            regulatoryDataChangeService.setApprovalStatusIsApproved(dataChange);

            /* delete entity */
            securitiesIssuerCodeRepository.delete(securitiesIssuerCode);
            totalDataSuccess++;
        } catch (Exception e) {
            handleGeneralError(securitiesIssuerCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
        return new SecuritiesIssuerCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public SecuritiesIssuerCodeDTO getById(Long id) {
        log.info("Start get Issuer Code by id: {}", id);
        SecuritiesIssuerCode securitiesIssuerCode = securitiesIssuerCodeRepository.findById(id)
                .orElseThrow(() -> new DataNotFoundHandleException(ID_NOT_FOUND + id));
        return securitiesIssuerCodeMapper.toDTO(securitiesIssuerCode);
    }

    @Override
    public SecuritiesIssuerCodeDTO getByExternalCode(String externalCode) {
        log.info("Start get Issuer Code by external code: {}", externalCode);
        SecuritiesIssuerCode securitiesIssuerCode = securitiesIssuerCodeRepository.findByExternalCode2(externalCode)
                .orElseThrow(() -> new DataNotFoundHandleException("Issuer Code not found with external code: " + externalCode));
        return securitiesIssuerCodeMapper.toDTO(securitiesIssuerCode);
    }

    @Override
    public List<SecuritiesIssuerCodeDTO> getAll() {
        log.info("Start get all Issuer Code");
        List<SecuritiesIssuerCode> all = securitiesIssuerCodeRepository.findAll();
        return securitiesIssuerCodeMapper.toDTOList(all);
    }

    private void handleGeneralError(SecuritiesIssuerCodeDTO dto, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("An unexpected error occurred: {}", e.getMessage(), e);
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        dto != null && !dto.getExternalCode().isEmpty() ? dto.getExternalCode() : UNKNOWN_EXTERNAL_CODE,
                        validationErrors)
        );
    }

    private void validationExternalCodeAlreadyExists(String externalCode, List<String> validationErrors) {
        if (isExternalCodeAlreadyExists(externalCode)) {
            validationErrors.add("Securities Issuer Code is already taken with external code: " + externalCode);
        }
    }

    private void handleNewIssuerCode(SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(POST.name());
        regulatoryDataChangeDTO.setEndpoint(CREATE_APPROVE_URL);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(securitiesIssuerCodeDTO)
                )
        );
        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory Data Change add: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionAdd(regulatoryDataChange, SecuritiesIssuerCode.class);
    }

    private void handleExistingIssuerCode(SecuritiesIssuerCode securitiesIssuerCode, SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) throws JsonProcessingException {
        regulatoryDataChangeDTO.setMethodHttp(PUT.name());
        regulatoryDataChangeDTO.setEndpoint(UPDATE_APPROVE_URL);

        regulatoryDataChangeDTO.setEntityId(securitiesIssuerCode.getId().toString());
        regulatoryDataChangeDTO.setJsonDataBefore(
                JsonUtil.cleanedEntityDataFromApprovalData(
                        objectMapper.writeValueAsString(securitiesIssuerCode)
                )
        );

        SecuritiesIssuerCodeDTO temp = SecuritiesIssuerCodeDTO.builder()
                .externalCode(securitiesIssuerCode.getExternalCode2())
                .currency(
                        !securitiesIssuerCodeDTO.getCurrency().isEmpty()
                                ? securitiesIssuerCodeDTO.getCurrency()
                                : securitiesIssuerCode.getCurrency()
                )
                .issuerLKPBU(
                        !securitiesIssuerCodeDTO.getIssuerLKPBU().isEmpty()
                                ? securitiesIssuerCodeDTO.getIssuerLKPBU()
                                : securitiesIssuerCode.getIssuerLKPBU()
                )
                .issuerLBABK(
                        !securitiesIssuerCodeDTO.getIssuerLBABK().isEmpty()
                                ? securitiesIssuerCodeDTO.getIssuerLBABK()
                                : securitiesIssuerCode.getIssuerLBABK()
                )
                .build();

        log.info("Temp: {}", temp);

        regulatoryDataChangeDTO.setJsonDataAfter(
                JsonUtil.cleanedId(
                        objectMapper.writeValueAsString(temp)
                )
        );

        RegulatoryDataChange regulatoryDataChange = dataChangeMapper.toModel(regulatoryDataChangeDTO);
        log.info("Regulatory data change edit: {}", regulatoryDataChange);
        regulatoryDataChangeService.createChangeActionEdit(regulatoryDataChange, SecuritiesIssuerCode.class);
    }

}
