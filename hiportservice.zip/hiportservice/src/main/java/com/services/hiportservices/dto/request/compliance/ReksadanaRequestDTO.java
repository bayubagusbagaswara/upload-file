package com.services.hiportservices.dto.request.compliance;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Id;

@Data
public class ReksadanaRequestDTO {
    private String code;
    private String name;
    private String address;
    private String email;
    private String manajerInvestasi;
    private String pic;
    private String externalCode;
    private String reksadanaType;
    private boolean syariah;
    private boolean conventional;
    private double tnabMinimum;
    private double percentageModal;
    private boolean delete;
}
