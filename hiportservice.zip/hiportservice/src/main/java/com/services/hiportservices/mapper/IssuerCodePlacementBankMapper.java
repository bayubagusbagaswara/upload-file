package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.issuercodeplacementbank.IssuerCodePlacementBankDTO;
import com.services.hiportservices.dto.regulatory.issuercodeplacementbank.UploadIssuerCodePlacementBankDataRequest;
import com.services.hiportservices.model.regulatory.IssuerCodePlacementBank;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface IssuerCodePlacementBankMapper {

    @Mapping(source = "id", target = "id")
    IssuerCodePlacementBankDTO toDTO(IssuerCodePlacementBank issuerCodePlacementBank);

    @Mapping(target = "id", ignore = true) // ignoring the ID field
    @Mapping(source = "code", target = "code", qualifiedByName = "nullToEmpty")
    @Mapping(source = "bankName", target = "bankName", qualifiedByName = "nullToEmpty")
    @Mapping(source = "bankType", target = "bankType", qualifiedByName = "nullToEmpty")
    @Mapping(source = "issuerGroup", target = "issuerGroup", qualifiedByName = "nullToEmpty")
    @Mapping(source = "issuerCountry", target = "issuerCountry", qualifiedByName = "nullToEmpty")
    @Mapping(source = "securityType", target = "securityType", qualifiedByName = "nullToEmpty")
    @Mapping(source = "effectTypeCode", target = "effectTypeCode", qualifiedByName = "nullToEmpty")
    @Mapping(source = "status", target = "status", qualifiedByName = "nullToEmpty")
    @Mapping(source = "currency", target = "currency", qualifiedByName = "nullToEmpty")
    IssuerCodePlacementBankDTO fromUploadRequestToDTO(UploadIssuerCodePlacementBankDataRequest issuerCodePlacementBankDataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    List<IssuerCodePlacementBankDTO> toDTOList(List<IssuerCodePlacementBank> all);
}
