package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.ownergroup.OwnerGroupDTO;
import com.services.hiportservices.dto.regulatory.ownergroup.UploadOwnerGroupDataRequest;
import com.services.hiportservices.model.regulatory.OwnerGroup;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OwnerGroupMapper {

    @Mapping(source = "id", target = "id")
    @Mapping(source = "SInvestCode", target = "sInvestCode")
    OwnerGroupDTO toDTO(OwnerGroup ownerGroup);

    @Mapping(target = "id", ignore = true) // Ignoring the ID field
    @Mapping(source = "SInvestCode", target = "sInvestCode", qualifiedByName = "nullToEmpty")
    OwnerGroupDTO fromUploadRequestToDTO(UploadOwnerGroupDataRequest dataRequest);

    @Named("nullToEmpty")
    default String nullToEmpty(String value) {
        return null == value ? "" : value;
    }

    List<OwnerGroupDTO> toDTOList(List<OwnerGroup> ownerGroupList);
}
