package com.services.hiportservices.dto.response;

import com.services.hiportservices.enums.ChangeAction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;

@Data
public class DataChangeResponseDto {
    private Long idDataChange;
    private ChangeAction action;
    private String entityId;
    private String inputDate;
    private String inputerId;
    private  String  entityClassName;
    private Object dataBefore;
    private Object dataAfter;
}
