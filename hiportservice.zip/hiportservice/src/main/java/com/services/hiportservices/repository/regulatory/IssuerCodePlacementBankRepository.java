package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.IssuerCodePlacementBank;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface IssuerCodePlacementBankRepository extends JpaRepository<IssuerCodePlacementBank, Long> {

    @Query(value = "FROM IssuerCodePlacementBank p WHERE p.code = :code")
    Optional<IssuerCodePlacementBank> findByCode(@Param("code") String code);

    boolean existsByCode(String code);

    Optional<IssuerCodePlacementBank> findByCodeContaining(String code);
}
