package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.SecuritiesIssuerCode;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SecuritiesIssuerCodeRepository extends JpaRepository<SecuritiesIssuerCode, Long> {

    @Query(value = "FROM SecuritiesIssuerCode s WHERE s.externalCode2 = :externalCode")
    Optional<SecuritiesIssuerCode> findByExternalCode2(@Param("externalCode") String externalCode);

    boolean existsByExternalCode2(String externalCode);

    Optional<SecuritiesIssuerCode> findByExternalCode2Containing(String externalCode);

}
