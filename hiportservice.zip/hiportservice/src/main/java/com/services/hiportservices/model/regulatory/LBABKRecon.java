package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "reg_lbabk_recon")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LBABKRecon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "created_date")
    private Instant createdDate;

    @Column(name = "data_source_id")
    private String dataSourceId;

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "data_source_period")
    private String dataSourcePeriod;

    @Column(name = "code")
    private String code;

    @Column(name = "csa_value")
    private String csaValue;

    @Column(name = "data_source_value")
    private String dataSourceValue;

    @Column(name = "description")
    private String description;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "flag_recon")
    private String flagRecon;

    @Column(name = "recon_type")
    private String reconType;

}
