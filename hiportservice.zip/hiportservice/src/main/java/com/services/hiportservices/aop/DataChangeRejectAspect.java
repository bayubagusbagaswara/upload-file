package com.services.hiportservices.aop;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.Approvable;
import com.services.hiportservices.model.DataChange;
import com.services.hiportservices.model.compliance.MasterKebijakanInvestasi;
import com.services.hiportservices.repository.DataChangeRepository;
import com.services.hiportservices.repository.compliance.MasterKebijakanInvestasiRepository;
import com.services.hiportservices.utils.UserIdUtil;
import org.apache.commons.lang.SerializationUtils;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Date;

@Aspect
@Component
public class DataChangeRejectAspect {

    Logger logger = LoggerFactory.getLogger(DataChangeApproveAspect.class);
    @Autowired
    ApplicationContext applicationContext;
    @Autowired
    private DataChangeRepository dataChangeRepository;

    @Pointcut("execution(* com.services.hiportservices.service.DataChangeService.doReject(..)) && args(dataChangeId)")
    public void dataChangeReject(Long dataChangeId) {
    }
    @AfterReturning(pointcut = "dataChangeReject(dataChangeId)", returning = "result")
    public void copyApprovedDataToMaster(Long dataChangeId, ResponseEntity<ResponseDto> result) {

        String className = result.getBody().getPayload().getClass().getSimpleName();
        String firstLetterLowercase = Character.toLowerCase(className.charAt(0)) + className.substring(1); // Ubah huruf pertama menjadi huruf kecil
        String repositoryName = firstLetterLowercase + "Repository"; // Buat nama repository

        // mencari repository berdasarkan nama
        JpaRepository<Object, String> repository = (JpaRepository<Object, String>) applicationContext.getBean(repositoryName);

        DataChange dataChange = dataChangeRepository.findById(dataChangeId).orElseThrow(()->new RuntimeException("No data!"));
        Approvable approvable = (Approvable) SerializationUtils.deserialize(dataChange.getChangedObject());
        approvable.setApprovalStatus(ApprovalStatus.Rejected);
        approvable.setApproveDate(new Date());
        approvable.setApproverId(UserIdUtil.getUser());
        repository.save(approvable);
        logger.info("Reject Data change");

    }
}
