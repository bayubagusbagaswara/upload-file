package com.services.hiportservices.utils.regulatory;

import com.services.hiportservices.model.regulatory.enumerator.OwnerIssuer;
import lombok.experimental.UtilityClass;

import java.util.Arrays;

@UtilityClass
public class EnumValidator {

    private static <T extends Enum<T>> boolean validateEnum(Class<T> enumClass, String value) {
        return Arrays.stream(enumClass.getEnumConstants())
                .noneMatch(enumConstant -> enumConstant.name().equalsIgnoreCase(value));
    }

    public static boolean validateEnumOwnerIssuer(String ownerIssuer) {
        return validateEnum(OwnerIssuer.class, ownerIssuer);
    }

}
