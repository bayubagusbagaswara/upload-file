package com.services.hiportservices.controller.regulatory;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.dto.regulatory.lkpbu.LKPBUProcessResponse;
import com.services.hiportservices.model.regulatory.LKPBU;
import com.services.hiportservices.service.regulatory.LKPBUDataSourceService;
import com.services.hiportservices.service.regulatory.LKPBUService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/api/regulatory/lkpbu")
@CrossOrigin(origins = "*", allowedHeaders = "*")
@Slf4j
@RequiredArgsConstructor
public class LKPBUController {

    private final LKPBUService lkpbuService;
    private final LKPBUDataSourceService dataSourceService;

    @GetMapping(path = "/read-insert")
    public ResponseEntity<ResponseDto<String>> readAndInsertToDB() {
        String status = dataSourceService.readAndInsertToDB();
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/process")
    public ResponseEntity<ResponseDto<LKPBUProcessResponse>> process(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        LKPBUProcessResponse process = lkpbuService.process(month, year);
        ResponseDto<LKPBUProcessResponse> response = ResponseDto.<LKPBUProcessResponse>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(process)
                .build();
        return ResponseEntity.ok(response);
    }

    @GetMapping(path = "/generate-txt")
    public ResponseEntity<ResponseDto<String>> generateTxtAndSaveToServer(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        String status = lkpbuService.generateTxtAndSaveToServer(month, year);
        ResponseDto<String> response = ResponseDto.<String>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();
        return ResponseEntity.ok(response);
    }

    // TODO: Apakah ini untuk response nya diubah menjadi LKPBU DTO?
    @GetMapping(path = "/all")
    public ResponseEntity<ResponseDto<List<LKPBU>>> getAll(
            @RequestParam("month") String month,
            @RequestParam("year") Integer year) {

        List<LKPBU> lkpbuList = lkpbuService.getAllByMonthAndYear(month, year);
        ResponseDto<List<LKPBU>> response = ResponseDto.<List<LKPBU>>builder()
                .code(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(lkpbuList)
                .build();
        return ResponseEntity.ok(response);
    }

    // get all data distinct by kode nasbah

}
