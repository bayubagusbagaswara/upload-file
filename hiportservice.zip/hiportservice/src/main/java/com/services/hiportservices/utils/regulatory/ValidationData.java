package com.services.hiportservices.utils.regulatory;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@Component
@RequiredArgsConstructor
public class ValidationData {

    private final Validator validator;

    public Errors validateObject(Object target) {
        Errors errors = new BeanPropertyBindingResult(target, target.getClass().getSimpleName());
        validator.validate(target, errors);
        return errors;
    }

    public Errors validateObjectGroup(Object target, Class<?> group) {
        Errors errors = new BeanPropertyBindingResult(target, target.getClass().getName());
        validator.validate(target, errors, group);
        return errors;
    }

    public <T> void validateObject(T target, Class<?> group) {
        Set<ConstraintViolation<T>> violations = validator.validate(target, group);
        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }
    }

    public <T> void validateObject(T target, Class<?> group) {
        Set<ConstraintViolation<T>> violations = validator.validate(target, group);
        if (!violations.isEmpty()) {
            throw new ConstraintViolationException(violations);
        }
    }

}
