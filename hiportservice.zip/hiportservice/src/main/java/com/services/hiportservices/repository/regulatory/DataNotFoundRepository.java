package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.DataNotFound;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DataNotFoundRepository extends JpaRepository<DataNotFound, Long> {

    // Notes: harus ada penanda apaka dia LBABK atau LKPBU
    // jika dia LBABK, mana ISIN mana ISSUER. Karena kita akan delete data not found ketika sudah ada di table maintenance
    // jika dia LKPBU, maka ISIN, mana GOLONGAN PEMILIKI dll

    List<DataNotFound> findAllByReportTypeAndFlagTableAndCode(String reportType, String flagTable, String effectCode);

    @Query(value = "FROM DataNotFound d WHERE d.month = :month AND d.year = :year AND d.status = :status")
    List<DataNotFound> findAllByMonthAndYearAndStatus(@Param("month") String month, @Param("year") Integer year, @Param("status") Boolean status);

    List<DataNotFound> findAllByFlagTableAndCode(
            String flagTable,
            String code
    );

    // Notes: tambahkan field Code, fungsinya adalah pengganti kodeEfek
    // Code ini akan digunakan sebagai WHERE untuk menghapus DATA NOT FOUND

}
