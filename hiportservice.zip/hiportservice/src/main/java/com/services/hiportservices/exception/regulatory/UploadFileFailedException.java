package com.services.hiportservices.exception.regulatory;

import org.springframework.http.HttpStatus;

public class UploadFileFailedException extends RuntimeException {

    private final HttpStatus httpStatus;
    private final String errorCode;


    public UploadFileFailedException(HttpStatus httpStatus, String errorCode) {
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
    }

    public UploadFileFailedException(String message, HttpStatus httpStatus, String errorCode) {
        super(message);
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
    }

    public UploadFileFailedException(String message, Throwable cause, HttpStatus httpStatus, String errorCode) {
        super(message, cause);
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public String getErrorCode() {
        return errorCode;
    }

}
