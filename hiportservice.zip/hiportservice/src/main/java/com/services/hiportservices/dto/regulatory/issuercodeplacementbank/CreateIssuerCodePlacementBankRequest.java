package com.services.hiportservices.dto.regulatory.issuercodeplacementbank;

import com.services.hiportservices.dto.regulatory.approval.InputIdentifierRequest;
import lombok.*;

/**
 * untuk create satuan
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateIssuerCodePlacementBankRequest extends InputIdentifierRequest {

    private String code; // kode

    private String bankName; // nama bank

    private String bankType; // jenis bank

    private String issuerGroup; // golongan penerbit

    private String issuerCountry; // negara penerbit

    private String securityType; // jenis surat berharga

    private String effectTypeCode; // kode tipe efek

    private String status;

    private String currency;

}
