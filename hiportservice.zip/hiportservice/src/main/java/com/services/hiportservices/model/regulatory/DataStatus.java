package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "reg_data_status")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DataStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "data_type", nullable = false)
    private String dataType; // Untuk membedakan antara LKPBU atau LBABK

    @Column(name = "total_data_success", nullable = false)
    private int totalDataSuccess;

    @Column(name = "total_data_failed", nullable = false)
    private int totalDataFailed;

    @Column(name = "remaining_data", nullable = false)
    private int remainingData;

    @Column(name = "last_updated", nullable = false)
    private LocalDateTime lastUpdated;

    public DataStatus(String dataType, int totalDataSuccess, int totalDataFailed, int remainingData) {
        this.dataType = dataType;
        this.totalDataSuccess = totalDataSuccess;
        this.totalDataFailed = totalDataFailed;
        this.remainingData = remainingData;
        this.lastUpdated = LocalDateTime.now(); // Automatically set the timestamp when updated
    }

}
