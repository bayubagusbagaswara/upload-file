package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.recon.LKPBUReconDTO;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.model.regulatory.LKPBURecon;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface LKPBUReconMapper {

    @Mapping(source = "code", target = "code")
    @Mapping(source = "reconType", target = "reconType")
    @Mapping(source = "csaValue", target = "csaValue")
    @Mapping(source = "dataSourceValue", target = "dataSourceValue")
    LKPBUReconDTO fromUpdateRequestToDTO(UpdateReconRequest reconRequest);

    @Mapping(source = "csaValue", target = "csaValue")
    @Mapping(source = "dataSourceValue", target = "dataSourceValue")
    LKPBUReconDTO toDTO(LKPBURecon lkpbuRecon);

}
