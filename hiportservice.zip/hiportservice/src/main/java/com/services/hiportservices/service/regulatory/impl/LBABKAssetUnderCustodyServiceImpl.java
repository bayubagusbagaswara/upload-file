package com.services.hiportservices.service.regulatory.impl;

import com.services.hiportservices.dto.regulatory.ContextDate;
import com.services.hiportservices.dto.regulatory.ErrorMessageDTO;
import com.services.hiportservices.dto.regulatory.GenerateTextFileResponse;
import com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant;
import com.services.hiportservices.dto.regulatory.lbabk.LBABKProcessResponse;
import com.services.hiportservices.exception.regulatory.DataNotFoundHandleException;
import com.services.hiportservices.exception.regulatory.GeneralHandleException;
import com.services.hiportservices.model.regulatory.ExchangeRate;
import com.services.hiportservices.model.regulatory.LBABKAssetUnderCustody;
import com.services.hiportservices.model.regulatory.LKPBU;
import com.services.hiportservices.model.regulatory.enumerator.TypeEffectEnum;
import com.services.hiportservices.repository.regulatory.ExchangeRateRepository;
import com.services.hiportservices.repository.regulatory.LBABKAssetUnderCustodyRepository;
import com.services.hiportservices.repository.regulatory.LKPBURepository;
import com.services.hiportservices.service.regulatory.LBABKAssetUnderCustodyService;
import com.services.hiportservices.utils.regulatory.BigDecimalUtil;
import com.services.hiportservices.utils.regulatory.DateUtil;
import com.services.hiportservices.utils.regulatory.ExtractEffectTypeCodeUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.CURRENCY_USD;
import static com.services.hiportservices.dto.regulatory.constant.ContentParameterConstant.UNKNOWN_CODE;

@Service
@Slf4j
@RequiredArgsConstructor
public class LBABKAssetUnderCustodyServiceImpl implements LBABKAssetUnderCustodyService {

    @Value("${file.path.lbabk-auc-report}")
    private String filePathDataAssetUnderCustody;

    private final LBABKAssetUnderCustodyRepository assetUnderCustodyRepository;
    private final ExchangeRateRepository exchangeRateRepository;
    private final LKPBURepository lkpbuRepository;
    private final DateUtil dateUtil;

    @Override
    public LBABKProcessResponse process(String month, Integer year) {
        log.info("Start process Asset Under Custody with month: {}, year: {}", month, year);

        ExchangeRate exchangeRate = exchangeRateRepository.findByCode(CURRENCY_USD)
                .orElseThrow(() -> new DataNotFoundHandleException("Exchange Rate not found with code: " + CURRENCY_USD));

        List<LKPBU> lkpbuList = lkpbuRepository.findAllByMonthAndYear(month, year);

        assetUnderCustodyRepository.deleteByMonthAndYear(month, year);

        Map<String, BigDecimal> stringBigDecimalMap = processTypeEffects(lkpbuList, exchangeRate.getRate());

        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();
        Instant now = Instant.now();

        for (Map.Entry<String, BigDecimal> entry : stringBigDecimalMap.entrySet()) {
            String typeEffect = null;
            try {
                typeEffect = entry.getKey();
                BigDecimal totalValue = entry.getValue();

                LBABKAssetUnderCustody assetUnderCustody = LBABKAssetUnderCustody.builder()
                        .createdDate(now)
                        .month(month)
                        .year(year)
                        .flagDetail("D01")
                        .componentCode("940102010000")
                        .typeEffectCode(typeEffect)
                        .typeEffectInformation("")
                        .totalValue(totalValue)
                        .build();

                assetUnderCustodyRepository.save(assetUnderCustody);

                totalDataSuccess++;
            } catch (Exception e) {
                List<String> validationErrors = new ArrayList<>();
                handleGeneralError(typeEffect, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }

        return new LBABKProcessResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    @Override
    public List<LBABKAssetUnderCustody> getAllByMonthAndYear(String month, Integer year) {
        return assetUnderCustodyRepository.findAllByMonthAndYear(month, year);
    }

    @Override
    public String generateTxtAndSaveToServer(String month, Integer year) {
        log.info("Start generate txt file {} Asset Under Custody with month: {}, year: {}", ContentParameterConstant.LBABK, month,  year);
        try {
            Instant now = Instant.now();

            List<LBABKAssetUnderCustody> assetUnderCustodyList = assetUnderCustodyRepository.findAll();
            log.info("Asset under custody list size: {}", assetUnderCustodyList.size());

            List<LBABKAssetUnderCustody> collect = assetUnderCustodyList.stream()
                    .filter(data -> data.getTotalValue().compareTo(BigDecimal.ZERO) > 0)
                    .collect(Collectors.toList());
            log.info("Collect size: {}", collect.size());

            GenerateTextFileResponse response = generateAndSaveTxtStatements(collect, now);

            return "Successfully created a Text File for Asset Under Custody with total data success: "
                    + response.getTotalDataSuccess()
                    + ", and total data failed: "
                    + response.getTotalDataFailed();
        } catch (Exception e) {
            log.error("Error when generate Text File Asset Under Custody: {}", e.getMessage(), e);
            throw new GeneralHandleException("Error when generate Text Final Asset Under Custody: " + e.getMessage());
        }
    }

    private GenerateTextFileResponse generateAndSaveTxtStatements(List<LBABKAssetUnderCustody> dataList, Instant instant) {
        log.info("Start generate and save txt statements with size: {}", dataList.size());
        int totalDataSuccess = 0;
        int totalDataFailed = 0;

        try {
            ContextDate contextDate = dateUtil.buildContextDate(instant);

            StringBuilder content = new StringBuilder();
            content
                    .append("H01").append("|")
                    .append("021001").append("|")
                    .append("BDMN2").append("|")
                    .append(contextDate.getLastDayOfPreviousMonth()).append("|")
                    .append("BKMAB").append("|")
                    .append("94M102").append("|")
                    .append("\n")
            ;

            for (LBABKAssetUnderCustody data : dataList) {
                content
                        .append(data.getFlagDetail()).append("|")
                        .append(data.getComponentCode()).append("|")
                        .append(ExtractEffectTypeCodeUtil.extractCode(data.getTypeEffectCode())).append("|")
                        .append(data.getTypeEffectInformation()).append("|")
                        .append(data.getTotalValue())
                        .append("\n")
                ;
            }

            /* create filename */
            String fileName = "AUC_"
                    + contextDate.getLastDayOfPreviousMonth().replace("-", "")
                    + ".txt";

            String filePath = filePathDataAssetUnderCustody + fileName;

            deleteExistingFile(filePath);

            saveTextFile(filePath, content.toString());

            totalDataSuccess++;
        } catch (Exception e) {
            log.error("Error when generateAndSaveTxtStatements: {}", e.getMessage(), e);
            totalDataFailed++;
        }

        return new GenerateTextFileResponse(totalDataSuccess, totalDataFailed);
    }

    private static void deleteExistingFile(String filePath) {
        Path path = Paths.get(filePath);
        if (Files.exists(path)) {
            try {
                Files.delete(path);
                log.info("File sebelumnya berhasil dihapus: {}", filePath);
            } catch (IOException e) {
                log.error("Gagal menghapus file: {}. Kesalahan: {}", filePath, e.getMessage(), e);
            }
        } else {
            log.info("File tidak ditemukan: {}", filePath);
        }
    }

    private static void saveTextFile(String filePath, String content) throws IOException {
        File file = new File(filePath);

        Path path = Paths.get(file.getParent());
        if (Files.notExists(path)) {
            Files.createDirectories(path);
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(content);
            log.info("File baru berhasil disimpan di: {}", filePath);
        } catch (IOException e) {
            log.info("Terjadi kesalahan saat menyimpan file: {}", e.getMessage());
        }
    }

    private void handleGeneralError(String data, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        validationErrors.add(e.getMessage());
        errorMessageDTOList.add(
                new ErrorMessageDTO(
                        data != null && !data.isEmpty() ? data : UNKNOWN_CODE,
                        validationErrors
                )
        );
    }

    private Map<String, BigDecimal> processTypeEffects(List<LKPBU> dataList, BigDecimal rate) {
        Map<String, String> typeEffectMap = Arrays.stream(TypeEffectEnum.values())
                .collect(Collectors.toMap(TypeEffectEnum::getCode, TypeEffectEnum::getFullTypeEffect));

        Map<String, BigDecimal> totalByTypeEffect = typeEffectMap.keySet().stream()
                .collect(Collectors.toMap(
                        typeEffectMap::get,
                        code -> dataList.stream()
                                .filter(data -> ExtractEffectTypeCodeUtil.extractCode(data.getTypeEffect()).equals(code))
                                .map(data -> {
                                    BigDecimal value = data.getPembayaranKupon();
                                    if (CURRENCY_USD.equals(data.getJenisValuta())) {
                                        return value.multiply(rate).setScale(2, RoundingMode.HALF_UP);
                                    }
                                    return value;
                                })
                                .reduce(BigDecimal.ZERO, BigDecimal::add),
                        (oldValue, newValue) -> oldValue,
                        LinkedHashMap::new
                ));

        typeEffectMap.forEach((code, fullTypeEffect) -> totalByTypeEffect.putIfAbsent(fullTypeEffect, BigDecimal.ZERO));

        return totalByTypeEffect;
    }

    @Override
    public String updateByTypeEffectCode(String typeEffectCode, String amount) {
        String code = ExtractEffectTypeCodeUtil.extractCode(typeEffectCode);
        LBABKAssetUnderCustody assetUnderCustody = assetUnderCustodyRepository.findByTypeEffectCode(code)
                .orElseThrow(() -> new DataNotFoundHandleException("Asset Under Custody not found with type effect code: " + code));

        BigDecimal bigDecimal = BigDecimalUtil.parseBigDecimal(amount);
        assetUnderCustody.setTotalValue(bigDecimal);

        return "Successfully update asset under custody with type effect code: " + code;
    }

}
