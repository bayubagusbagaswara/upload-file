package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LKPBUDataSource;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface LKPBUDataSourceRepository extends JpaRepository<LKPBUDataSource, Long> {

    List<LKPBUDataSource> findAllByMonthAndYear(String month, Integer year);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM LKPBUDataSource l WHERE l.month = :month AND l.year = :year")
    void deleteByMonthAndYear(@Param("month") String monthName, @Param("year") Integer year);

    @Query(value = "SELECT *\n" +
            "FROM (\n" +
            "    SELECT *, ROW_NUMBER() OVER (PARTITION BY data_1 ORDER BY id) AS row_num\n" +
            "    FROM reg_lkpbu_data_source\n" +
            "    WHERE month = :month\n" +
            "      AND year = :year\n" +
            ") AS subquery\n" +
            "WHERE row_num = 1;", nativeQuery = true)
    List<LKPBUDataSource> findAllDistinctPortfolioCode(@Param("month") String monthName, @Param("year") Integer year);


    @Query(value = "SELECT *\n" +
            "FROM (\n" +
            "    SELECT *, ROW_NUMBER() OVER (PARTITION BY data_2 ORDER BY id) AS row_num\n" +
            "    FROM reg_lkpbu_data_source\n" +
            "    WHERE month = :month\n" +
            "      AND year = :year\n" +
            ") AS subquery\n" +
            "WHERE row_num = 1;", nativeQuery = true)
    List<LKPBUDataSource> findAllDistinctSecurityCode(@Param("month") String monthName, @Param("year") Integer year);

    @Query(value = "FROM LKPBUDataSource l WHERE l.data1 = :data1")
    List<LKPBUDataSource> findAllByData1(@Param("data1") String data1);

    @Query(value = "FROM LKPBUDataSource l WHERE l.data2 = :data2")
    List<LKPBUDataSource> findAllByData2(@Param("data2") String data2);

}
