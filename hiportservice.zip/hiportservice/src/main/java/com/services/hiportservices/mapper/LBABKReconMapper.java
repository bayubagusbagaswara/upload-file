package com.services.hiportservices.mapper;

import com.services.hiportservices.dto.regulatory.recon.LBABKReconDTO;
import com.services.hiportservices.dto.regulatory.recon.UpdateReconRequest;
import com.services.hiportservices.model.regulatory.LBABKRecon;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface LBABKReconMapper {

    @Mapping(source = "code", target = "code")
    @Mapping(source = "reconType", target = "reconType")
    @Mapping(source = "csaValue", target = "csaValue")
    @Mapping(source = "dataSourceValue", target = "dataSourceValue")
    LBABKReconDTO fromUpdateRequestToDTO(UpdateReconRequest reconRequest);

    @Mapping(source = "csaValue", target = "csaValue")
    @Mapping(source = "dataSourceValue", target = "dataSourceValue")
    LBABKReconDTO toDTO(LBABKRecon lbabkRecon);

}
