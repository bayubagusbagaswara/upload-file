package com.services.hiportservices.repository.emonitoring;

import com.services.hiportservices.model.emonitoring.OrchidXd11;
import com.services.hiportservices.model.emonitoring.OrchidXd15;
import com.services.hiportservices.model.emonitoring.OrchidXdAktif;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

public interface OrchidXdActiveRepository extends JpaRepository<OrchidXdAktif, Long> {

    List<OrchidXdAktif> findAllByPortfolioCode(String portofolio);

    List<OrchidXdAktif> findAllByProcessDate(Date tanggal);

    OrchidXdAktif findByProcessDateAndReksadanaCode(Date tanggal, String code);

    @Query(value="SELECT * FROM ORCHIDAKTIF WHERE PROCESSDATE = :date and ( PORTFOLIOCODE= :reksadanaCode or  REKSADANA_CODE= :reksadanaCode)", nativeQuery = true)
    OrchidXdAktif searchDataAt(
            @Param("date") String date,
            @Param("reksadanaCode") String reksadanaCode);



    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDAKTIF WHERE PROCESSDATE = :tgl and REKSADANA_CODE = :rekCode", nativeQuery = true)
    void deleteOrchidAktifByCode(@Param("tgl") Date tgl,
                          @Param("rekCode") String rekCode);

    @Transactional
    @Modifying
    @Query(value = "DELETE ORCHIDAKTIF WHERE PROCESSDATE = :tgl", nativeQuery = true)
    void deleteAllOrchidAktif(@Param("tgl") Date tgl);

}
