package com.services.hiportservices.dto.regulatory.issuercodeplacementbank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IssuerCodePlacementBankDTO {

    private Long id;

    private String code; // kode

    private String bankName; // nama bank

    private String bankType; // jenis bank

    private String issuerGroup; // golongan penerbit

    private String issuerCountry; // negara penerbit

    private String securityType; // jenis surat berharga

    private String effectTypeCode; // kode tipe efek

    private String status;

    private String currency;

}
