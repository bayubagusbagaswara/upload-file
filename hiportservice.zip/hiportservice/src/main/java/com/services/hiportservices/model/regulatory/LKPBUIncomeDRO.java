package com.services.hiportservices.model.regulatory;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;

@Entity
@Table(name = "reg_lkpbu_income_dro")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LKPBUIncomeDRO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "transaction_date")
    private LocalDate transactionDate; // Tanggal

    @Column(name = "month")
    private String month;

    @Column(name = "year")
    private Integer year;

    @Column(name = "portfolio_code")
    private String portfolioCode;

    @Column(name = "jenis")
    private String jenis; // Jenis

    @Column(name = "security_code")
    private String securityCode;

    @Column(name = "nominal")
    private BigDecimal nominal;

    @Column(name = "type")
    private String type;

    @Column(name = "system")
    private String system;

    @Column(name = "customer_type")
    private String customerType;

    @Column(name = "status_client")
    private String statusClient;

    @Column(name = "data_1")
    private String data1;

}
