package com.services.hiportservices.repository.regulatory;

import com.services.hiportservices.model.regulatory.LKPBUIncome;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface LKPBUIncomeRepository extends JpaRepository<LKPBUIncome, Long> {

    List<LKPBUIncome> findAllByMonthAndYear(String month, Integer year);

    @Transactional
    @Modifying
    @Query(value = "DELETE FROM LKPBUIncome l WHERE l.month = :month AND l.year = :year")
    void deleteByMonthAndYear(@Param("month") String monthName,
                              @Param("year") Integer year);

    @Query(value = "FROM LKPBUIncome l WHERE l.dataConcat = :dataConcat AND l.month = :month AND l.year = :year")
    Optional<LKPBUIncome> findByDataConcatAndMonthAndYear(
            @Param("dataConcat") String concatData1And2,
            @Param("month") String month,
            @Param("year") Integer year);
}
