package com.services.hiportservices.service.regulatory;

import com.services.hiportservices.dto.regulatory.RegulatoryDataChangeDTO;
import com.services.hiportservices.dto.regulatory.insurancepensionfund.*;

import java.util.List;

public interface InsurancePensionFundService {

    boolean isPortfolioCodeAlreadyExists(String portfolioCode);

    InsurancePensionFundResponse uploadData(UploadInsurancePensionFundListRequest uploadInsurancePensionFundListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    InsurancePensionFundResponse createApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress);

    InsurancePensionFundResponse updateApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress);

    InsurancePensionFundResponse deleteById(DeleteInsurancePensionFundRequest deleteInsurancePensionFundRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO);

    InsurancePensionFundResponse deleteApprove(ApproveInsurancePensionFundRequest approveInsurancePensionFundRequest, String approveIPAddress);

    InsurancePensionFundDTO getById(Long id);

    InsurancePensionFundDTO getByPortfolioCode(String portfolioCode);

    List<InsurancePensionFundDTO> getAll();
}
