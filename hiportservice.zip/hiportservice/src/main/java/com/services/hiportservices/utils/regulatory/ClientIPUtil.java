    package com.services.hiportservices.utils.regulatory;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;

@UtilityClass
@Slf4j
public class ClientIPUtil {

    public String getClientIP(HttpServletRequest servletRequest) {
        String clientIP = servletRequest.getHeader("X-Forwarded-For");
        if (clientIP == null || clientIP.isEmpty()) {
            clientIP = servletRequest.getHeader("X-Real-IP");
        }
        if (clientIP == null || clientIP.isEmpty()) {
            clientIP = servletRequest.getRemoteAddr();
        }
        log.info("Client IP Address: {}", clientIP);
        return clientIP;
    }

}
