package com.services.hiportservices.service;

import com.services.hiportservices.dto.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.*;

@Service
public class SecurityMasterService {

    public ResponseEntity<ResponseDto> getSecurityMaster() throws ClassNotFoundException, SQLException {
        Class.forName("com.dstglobalsolutions.dro.jdbc.openaccess.OpenAccessDriver");
        Connection con = DriverManager.getConnection("jdbc:DRO://10.197.31.137:29996;ServerDataSource=HIPORTDSN;USER=SSNC;PASSWORD=HIPORT04");
        Statement stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT CODE, EXTERNALCODE1, CATEGORY, NAME FROM SECURITY ORDER BY CATEGORY, EXTERNALCODE1");
        while (rs.next()){
            System.out.println(rs.getString("CODE"));
        }
        return ResponseEntity.ok(new ResponseDto().builder().code(HttpStatus.OK.toString()).message("Berhasil update data Expense").payload("").build());
    }
}
