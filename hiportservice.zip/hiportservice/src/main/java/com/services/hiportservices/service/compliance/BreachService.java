package com.services.hiportservices.service.compliance;

import com.services.hiportservices.dto.ResponseDto;
import com.services.hiportservices.enums.ApprovalStatus;
import com.services.hiportservices.model.compliance.*;
import com.services.hiportservices.model.emonitoring.OrchidXd14;
import com.services.hiportservices.repository.compliance.*;
import com.services.hiportservices.repository.emonitoring.OrchidXd14Repository;
import com.services.hiportservices.utils.UserIdUtil;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.sound.midi.Soundbank;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class BreachService {

    @Autowired
    EntityManager entityManager;
    @Autowired
    BreachReportRepository breachReportRepository;
    @Autowired
    BreachAfiliasiRepository breachAfiliasiRepository;
    @Autowired
    BreachKebijakanInvestasiRepository breachKebijakanInvestasiRepository;
    @Autowired
    BreachKepemilikanEfekRepository breachKepemilikanEfekRepository;
    @Autowired
    BreachIssuerRepository breachIssuerRepository;
    @Autowired
    BreachModalRepository breachModalRepository;
    @Autowired
    BreachNilaiPasarWajarRepository breachNilaiPasarWajarRepository;
    @Autowired
    BreachPUPRepository breachPUPRepository;
    @Autowired
    BreachRdTypeAndSecTypeRepository breachRdTypeAndSecTypeRepository;
    @Autowired
    BreachTNABMinimumRepository breachTNABMinimumRepository;
    @Autowired
    TemporaryXD14Repository temporaryXD14Repository;
    @Autowired
    OrchidXd14Repository orchidXd14Repository;
    @Autowired
    PortfolioTypeRepository portfolioTypeRepository;
    @Autowired
    DanaKelolahanRecorRepository danaKelolahanRecorRepository;
    @Autowired
    BreachAktifPasifRepository breachAktifPasifRepository;


    SimpleDateFormat formatFront = new SimpleDateFormat("yyyy-MM-dd");

    public ResponseEntity<ResponseDto> checkPortfolio(String date) {
        ResponseDto responseDto =new ResponseDto();
        List<Map<String, Object>> unregisteredPortfolioList = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                    "SELECT DISTINCT p.external_code as PortfolioCodeDB, xd.displayPortfolio as PortfolioCodeXD14, p.issuer " +
                            "FROM ORCHIDXD14 xd " +
                            "LEFT JOIN comp_portfolio p " +
                            "ON p.external_code = xd.displayPortfolio and p.approval_status = 'Approved' and  p.isDelete = 0 " +
                            "WHERE xd.Tanggal = '" + date + "' and p.code is null " +
                    "UNION " +
                            "SELECT DISTINCT p.external_code as PortfolioCodeDB, xd.displayPortfolio as PortfolioCodeXD14, p.issuer " +
                            "FROM comp_xd14_kpd xd " +
                            "LEFT JOIN comp_portfolio p " +
                            "ON p.external_code = xd.displayPortfolio and p.approval_status = 'Approved' and  p.isDelete = 0 " +
                            "WHERE xd.Tanggal = '" + date + "' and p.code is null ");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("portfolioCodeDB", data[0]);
                eachColumn.put("portfolioCodeXD14", data[1]);
                eachColumn.put("issuer", data[2]);

                unregisteredPortfolioList.add(eachColumn);
            }

        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(unregisteredPortfolioList);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public ResponseEntity<ResponseDto> checkMappingPortfolio(String date) {
        ResponseDto responseDto =new ResponseDto();
        List<Map<String, Object>> unmappedPortfolioList = new ArrayList<>();
        try {
            Query query = entityManager.createNativeQuery(
                                "SELECT  pk.reksadana_code as reksadanaCode, xd.Kode as externalCode, " +
                                "xd.displayPortfolio as PortfolioCodeXD14, p.external_code as PortfolioCodeDB, xd.TIPE as portfolioType " +
                                "FROM ORCHIDXD14 xd " +
                                "LEFT JOIN comp_portfolio p " +
                                "ON xd.displayPortfolio = p.external_code and p.approval_status = 'Approved' and p.isDelete = 'false' " +
                                "LEFT JOIN comp_mapping_portfolio pk " +
                                "ON p.code = pk.portfolio_code and xd.Kode = pk.rd_external_code and pk.approval_status = 'Approved' " +
                                "WHERE xd.Tanggal = '" + date + "' and p.external_code is null " +
                        "UNION " + 
                                "SELECT  pk.reksadana_code as reksadanaCode, xd.Kode as externalCode, " +
                                "xd.displayPortfolio as PortfolioCodeXD14, p.external_code as PortfolioCodeDB, xd.TIPE as portfolioType " +
                                "FROM comp_xd14_kpd xd " +
                                "LEFT JOIN comp_portfolio p " +
                                "ON xd.displayPortfolio = p.external_code and p.approval_status = 'Approved' and p.isDelete = 'false' " +
                                "LEFT JOIN comp_mapping_portfolio pk " +
                                "ON p.code = pk.portfolio_code and xd.Kode = pk.rd_external_code and pk.approval_status = 'Approved' " +
                                "WHERE xd.Tanggal = '" + date + "' and p.external_code is null");

            List<Object[]> dataList = query.getResultList();

            for (Object[] data : dataList) {
                Map<String, Object> eachColumn = new HashMap<>();
                eachColumn.put("reksadanaCode", data[0]);
                eachColumn.put("externalCode", data[1]);
                eachColumn.put("portfolioCodeXD14", data[2]);
                eachColumn.put("portfolioCodeDB", data[3]);
                eachColumn.put("portfolioType", data[4]);

                unmappedPortfolioList.add(eachColumn);
            }

        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }
        responseDto.setCode(HttpStatus.OK.toString());
        responseDto.setMessage("OK");
        responseDto.setPayload(unmappedPortfolioList);
        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    @Transactional
    public ResponseEntity<ResponseDto> processComplianceReport(String stringDate, String action) {
        ResponseDto responseDto = new ResponseDto();
        try {
            Query getDate = entityManager.createNativeQuery("SELECT Top(2) tanggal FROM ORCHIDXD14 WHERE TANGGAL <= '"+ stringDate +"' GROUP BY Tanggal ORDER BY Tanggal DESC");
            List<Timestamp> dateList = (List<Timestamp>) getDate.getResultList();
            Timestamp timeStamp = null;
            for (Timestamp data : dateList) {
                timeStamp = data;
            }
            String pastDate = new SimpleDateFormat("yyyy-MM-dd").format(timeStamp);

            System.out.println("MASUK: BreachDate " + stringDate + " and pastDate " + pastDate + " and " + action);

            Date tanggal = formatFront.parse(stringDate);
            List<BreachReport> breachReportList = new ArrayList<>();

            if (action.equalsIgnoreCase("0")){
                insertNewXD14(tanggal);

                Query queryDanaKelolaan = entityManager.createNativeQuery("EXEC BreachDanaKelolaan '"+stringDate+"'");
                Query queryAfiliasi = entityManager.createNativeQuery("EXEC BreachAfiliasi '"+stringDate+"'");
                Query queryDifferenceType = entityManager.createNativeQuery("EXEC BreachDifferenceType '"+stringDate+"'");
                Query queryKinv = entityManager.createNativeQuery("EXEC BreachKebijakanInvest '"+stringDate+"'");
                Query queryKepemilikanEfek = entityManager.createNativeQuery("EXEC BreachKepemilikanEfek '"+stringDate+"'");
                Query queryIssuer = entityManager.createNativeQuery("EXEC BreachKepemilikanEfekIssuer '"+stringDate+"'");
                Query queryModal = entityManager.createNativeQuery("EXEC BreachModalDisetor '"+stringDate+"'");
                Query queryNilaiPasar = entityManager.createNativeQuery("EXEC BreachNilaiPasarWajar '"+stringDate+"'");
                Query queryPup = entityManager.createNativeQuery("EXEC BreachPup '"+stringDate+"'");
                Query queryAktifPasif = entityManager.createNativeQuery("EXEC BreachAktifPasif @BreachDate = '" +stringDate+ "', @PastDate = '" +pastDate+ "'");
                Query queryReport = entityManager.createNativeQuery("EXEC BreachReport @BreachDate = '" +stringDate+ "', @PastDate = '" +pastDate+ "'");

                queryDanaKelolaan.executeUpdate();
                queryAfiliasi.executeUpdate();
                queryDifferenceType.executeUpdate();
                queryKinv.executeUpdate();
                queryKepemilikanEfek.executeUpdate();
                queryIssuer.executeUpdate();
                queryModal.executeUpdate();
                queryNilaiPasar.executeUpdate();
                queryPup.executeUpdate();
                queryAktifPasif.executeUpdate();
                queryReport.executeUpdate();

                calculateDaysTotalDanaKelolahan(stringDate, tanggal);

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("1")){
                Query queryKepemilikanEfek = entityManager.createNativeQuery("EXEC BreachKepemilikanEfek '"+stringDate+"'");
                queryKepemilikanEfek.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("2")){
                insertNewXD14(formatFront.parse(stringDate));
                Query queryKinv = entityManager.createNativeQuery("EXEC BreachKebijakanInvest '"+stringDate+"'");
                queryKinv.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("3")){
                Query queryDifferenceType = entityManager.createNativeQuery("EXEC BreachDifferenceType '"+stringDate+"'");
                queryDifferenceType.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("4")){
                Query queryIssuer = entityManager.createNativeQuery("EXEC BreachKepemilikanEfekIssuer '"+stringDate+"'");
                queryIssuer.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("5")){
                Query queryAktifPasif = entityManager.createNativeQuery("EXEC BreachAktifPasif @BreachDate = '" +stringDate+ "', @PastDate = '" +pastDate+ "'");
                queryAktifPasif.executeUpdate();

                Query queryReport = entityManager.createNativeQuery("EXEC BreachReport @BreachDate = '" +stringDate+ "', @PastDate = '" +pastDate+ "'");
                queryReport.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("6")){
                Query queryModal = entityManager.createNativeQuery("EXEC BreachModalDisetor '"+stringDate+"'");
                queryModal.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("7")){
                Query queryAfiliasi = entityManager.createNativeQuery("EXEC BreachAfiliasi '"+stringDate+"'");
                queryAfiliasi.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("8")){
                Query queryDanaKelolaan = entityManager.createNativeQuery("EXEC BreachDanaKelolaan '"+stringDate+"'");
                queryDanaKelolaan.executeUpdate();

                calculateDaysTotalDanaKelolahan(stringDate, tanggal);

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("9")){
                Query queryPup = entityManager.createNativeQuery("EXEC BreachPup '"+stringDate+"'");
                queryPup.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            } else if (action.equalsIgnoreCase("10")){
                Query queryNilaiPasar = entityManager.createNativeQuery("EXEC BreachNilaiPasarWajar '"+stringDate+"'");
                queryNilaiPasar.executeUpdate();

                breachReportList = breachReportRepository.searchAllBreachReportAt(stringDate);
            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");
            responseDto.setPayload(breachReportList);
        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    public void calculateDaysTotalDanaKelolahan(String stringDate, Date tanggal){

        //Buat Perhitungan jumlah hari dana kelolahan
        List<DanaKelolahanRecord> danaKelolahanRecordList = new ArrayList<>();
        double tnabMinReksadana = 10000000000d;
        List<BreachTNABMinimum> breachTNABMinimumList = breachTNABMinimumRepository.searchDataByDateAndTnabMinAndBreach(
                stringDate, tnabMinReksadana, "Breach");
        for (BreachTNABMinimum breachTNABMinimum : breachTNABMinimumList){
            DanaKelolahanRecord danaKelolahanRecord = danaKelolahanRecorRepository.searchDataByReksadanaCodeAndExternalCode(
                    breachTNABMinimum.getReksadanaCode(), breachTNABMinimum.getRdExternalCode());
            if (danaKelolahanRecord == null){
                danaKelolahanRecord = new DanaKelolahanRecord();
                danaKelolahanRecord.setBreachStarted(tanggal);
                danaKelolahanRecord.setChangesDate(tanggal);
                danaKelolahanRecord.setPreviousDaysTotal(0);
                danaKelolahanRecord.setDaysTotal(1);
                danaKelolahanRecord.setPreviousJumlahDana(0);
            } else {
//                System.out.println("Dana Kelolahan -> Date now: " + tanggal + " and changeDate: " + danaKelolahanRecord.getChangesDate());
                if(!tanggal.equals(danaKelolahanRecord.getChangesDate()) && tanggal.after(danaKelolahanRecord.getChangesDate()) && !tanggal.before(danaKelolahanRecord.getChangesDate())){
                    double previousJumlahDana = danaKelolahanRecord.getJumlahDana();
                    int previousDaysTotal = danaKelolahanRecord.getDaysTotal();
                    danaKelolahanRecord.setPreviousJumlahDana(previousJumlahDana);
                    danaKelolahanRecord.setPreviousDaysTotal(previousDaysTotal);
                    danaKelolahanRecord.setDaysTotal(previousDaysTotal + 1);
                    danaKelolahanRecord.setChangesDate(tanggal);
                }
            }
            danaKelolahanRecord.setReksadanaCode(breachTNABMinimum.getReksadanaCode());
            danaKelolahanRecord.setRdExternalCode(breachTNABMinimum.getReksadanaName());
            danaKelolahanRecord.setJumlahDana(breachTNABMinimum.getNabAktif());
            danaKelolahanRecordList.add(danaKelolahanRecord);
        }
        danaKelolahanRecorRepository.saveAll(danaKelolahanRecordList);

        //After Save Dana Kelolahan record -> Check data to update data that not breach (RESTART TOTAL DAYS BREACH)
        List<DanaKelolahanRecord> danaKelolahanRecords = danaKelolahanRecorRepository.searchAllDanaKelolahanNotInDate(stringDate);
        for(DanaKelolahanRecord record : danaKelolahanRecords){
            if (!record.getChangesDate().equals(tanggal) && !tanggal.before(record.getChangesDate())){
                record.setPreviousJumlahDana(0);
                record.setDaysTotal(0);
                record.setPreviousDaysTotal(0);
                record.setChangesDate(tanggal);
                record.setBreachEnded(tanggal);
                danaKelolahanRecorRepository.save(record);

            }
        }
    }

    public ResponseEntity<ResponseDto> getBreachReport(String date, String action) {
        ResponseDto responseDto = new ResponseDto();
        try {
            if (action.equalsIgnoreCase("0")){
                List<BreachReport> breachReportList = breachReportRepository.searchAllBreachReportAt(date);
                responseDto.setPayload(breachReportList);

            } else if (action.equalsIgnoreCase("1")){
                List<BreachKepemilikanEfek> breachKepemilikanEfekList = breachKepemilikanEfekRepository.searchDataAt(date);
                responseDto.setPayload(breachKepemilikanEfekList);

            } else if (action.equalsIgnoreCase("2")){
                List<BreachKebijakanInvestasi> breachKebijakanInvestasiList = breachKebijakanInvestasiRepository.searchDataAt(date);
                responseDto.setPayload(breachKebijakanInvestasiList);

            } else if (action.equalsIgnoreCase("3")){
                List<BreachRdTypeAndSecType> breachRdTypeAndSecTypeList = breachRdTypeAndSecTypeRepository.searchDataAt(date);
                responseDto.setPayload(breachRdTypeAndSecTypeList);

            } else if (action.equalsIgnoreCase("4")){
                List<BreachIssuer> breachIssuerList = breachIssuerRepository.searchDataAt(date);
                responseDto.setPayload(breachIssuerList);

            } else if (action.equalsIgnoreCase("5")){
                List<BreachAktifPasif> breachAktifPasif = breachAktifPasifRepository.searchAllBreachAktifPasifAt(date);
                responseDto.setPayload(breachAktifPasif);

            } else if (action.equalsIgnoreCase("6")){
                List<BreachModal> breachModalList = breachModalRepository.searchDataAt(date);
                responseDto.setPayload(breachModalList);

            } else if (action.equalsIgnoreCase("7")){
                List<BreachAfiliasi> breachAfiliasiList = breachAfiliasiRepository.searchDataAt(date);
                responseDto.setPayload(breachAfiliasiList);

            } else if (action.equalsIgnoreCase("8")){ //Minimum Dana Kelolahan
                List<Map<String, Object>> breachDanaKelolahan = new ArrayList<>();
                Query query = entityManager.createNativeQuery("SELECT br.reksadana_code, br.rd_external_code, br.NAB_ORCHID_AKTIF, " +
                        "br.tnab_minimum, br.breach, dk.days_total, dk.breach_started, br.data_date " +
                        "FROM comp_breach_tnab br " +
                        "LEFT JOIN comp_dana_kelolahan_record dk " +
                        "ON br.reksadana_code = dk.reksadana_code AND dk.days_total <> 0 " +
                        "WHERE br.data_date = '"+date+"'");

                List<Object[]> dataList = query.getResultList();
                for (Object[] data : dataList) {
                    Map<String, Object> eachColumn = new HashMap<>();

                    eachColumn.put("reksadanaCode", data[0]);
                    eachColumn.put("rdExternalCode", data[1]);
                    eachColumn.put("nabAktif", data[2]);
                    eachColumn.put("tnabMin", data[3]);

                    if (data[4] == null || data[4] == ""){
                        eachColumn.put("breach", "-");
                    } else {
                        eachColumn.put("breach", data[4]);
                    }
                    if (data[5] == null || data[5] == ""){
                        eachColumn.put("daysTotal", "-");
                    } else {
                        eachColumn.put("daysTotal", data[5]);
                    }

                    eachColumn.put("breachStarted", data[6]);
                    eachColumn.put("date", data[7]);

                    breachDanaKelolahan.add(eachColumn);
                }
                responseDto.setPayload(breachDanaKelolahan);

            } else if (action.equalsIgnoreCase("9")){
                List<BreachPUP> breachPUPList = breachPUPRepository.searchDataAt(date);
                responseDto.setPayload(breachPUPList);

            } else if (action.equalsIgnoreCase("10")){
                List<BreachNilaiPasarWajar> breachNilaiPasarWajarList = breachNilaiPasarWajarRepository.searchDataAt(date);
                responseDto.setPayload(breachNilaiPasarWajarList);

            }

            responseDto.setCode(HttpStatus.OK.toString());
            responseDto.setMessage("OK");

        }catch (Exception e){
            responseDto.setCode(HttpStatus.BAD_REQUEST.toString());
            responseDto.setMessage("FAILED");
            responseDto.setPayload(e.getMessage());
            e.printStackTrace();
        }

        return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);
    }

    private void truncate(){
        try {
            Query sql = entityManager.createNativeQuery("truncate TABLE comp_xd14_temp");
            sql.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void insertNewXD14(Date tanggal) {
        System.out.println("Tanggal: " + tanggal);
        List<OrchidXd14> orchidXd14List = orchidXd14Repository.findAllByTanggal(tanggal);
        List<PortfolioType> portfolioTypeList = portfolioTypeRepository.searchByDescription("fix");
        truncate();
        for (OrchidXd14 orchidXd14 : orchidXd14List){
            TemporaryXD14 temporaryXD14 = new TemporaryXD14();
            temporaryXD14.setDateProc(orchidXd14.getDateProc());
            temporaryXD14.setStatProc(orchidXd14.getStatProc());
            temporaryXD14.setTanggal(orchidXd14.getTanggal());
            temporaryXD14.setKode(orchidXd14.getKode());
            temporaryXD14.setPortofolio(orchidXd14.getPortofolio());

            //Logic
            String kode = orchidXd14.getKode();
            String reksadanaType = kode.substring(5,7);

            String tipe = orchidXd14.getTipe();
            Date dueDate = orchidXd14.getTjTempo();

            Long days = 0L;
            if (dueDate != null) {
                Long different = dueDate.getTime() - tanggal.getTime();
                days = TimeUnit.DAYS.convert(different, TimeUnit.MILLISECONDS);
            }

            if((reksadanaType.equalsIgnoreCase("mm") || kode.equals("MG002MXCSEDAMA00")) && days < 365){
                System.out.println("===================== "+ tipe + " - " + orchidXd14.getKode() + " - " + orchidXd14.getDsplyPorto() + " - " + days + " =======================");
                for (PortfolioType portfolioType : portfolioTypeList){
                    String pfType = String.valueOf(portfolioType.getPortfolioType());
                    if (pfType.trim().equalsIgnoreCase(tipe.trim())){
                        System.out.println("pfType : " + pfType.trim());
                        System.out.println("---------------------------------------------------");
                        System.out.println("Reksadana: " + orchidXd14.getKode() + " Portfolio: " + orchidXd14.getDsplyPorto());
                        System.out.println("Beda Jatuh Tempo: " + days.toString() + " -> berubah tipe dari: " + tipe + " ke 11");
                        tipe = "11";
                    }
                }
            }

            temporaryXD14.setTipe(tipe);

            temporaryXD14.setNilaiBeli(orchidXd14.getNilaiBeli());
            temporaryXD14.setJumlah(orchidXd14.getJumlah());
            temporaryXD14.setTjTempo(orchidXd14.getTjTempo());
            temporaryXD14.setNilai(orchidXd14.getNilai());
            temporaryXD14.setTotal(orchidXd14.getTotal());
            temporaryXD14.setPersenAsset(orchidXd14.getPersenAsset());
            temporaryXD14.setBunga(orchidXd14.getBunga());
            temporaryXD14.setSecurityCode(orchidXd14.getSecurityCode());
            temporaryXD14.setSectype(orchidXd14.getSectype());
            temporaryXD14.setDsplyPorto(orchidXd14.getDsplyPorto());
            temporaryXD14.setCounter(orchidXd14.getCounter());
            temporaryXD14.setSectype(orchidXd14.getSectype());
            temporaryXD14.setReportGroup(orchidXd14.getReportGroup());
            temporaryXD14.setNav(orchidXd14.getNav());
            temporaryXD14.setCounter(orchidXd14.getCounter());
            temporaryXD14.setDsplyPorto(orchidXd14.getDsplyPorto());
            temporaryXD14.setIssuerCode(orchidXd14.getIssuerCode());
            temporaryXD14.setReksadanaCode(orchidXd14.getReksadanaCode());

            temporaryXD14Repository.save(temporaryXD14);
        }
    }
}
