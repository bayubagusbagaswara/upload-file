# Regulatory Notes

1. Kita bikin constant untuk nama-name header nya (LKBPU & LBABK)
2. Bikin mock data untuk LKBPU
3. Bikin mock data untuk LBABK
4. Ambil semua data LKBPU, harusnya berdasarlkan bulan dan tahun


# Data LKPBU

- Flag Detail
- Kode Komponen
- Golongan
- Sandi Perusahaan Asuransi/Reasuransi/Dana Pensiun *)
- Nama Perusahaan Asuransi/Reasuransi/Dana Pensiun *)
- Kode Efek
- Jenis
- Nomor Bilyet/Nomor Seri *)
- Nama Surat Berharga *)
- Lembar/Unit *)
- Interest Rate/Kupon *)
- Keterangan **)
- Dana Jaminan/Investasi *)
- Jenis Valuta
- Nilai Valuta Asal
- Tanggal Penerbitan
- Jatuh Tempo
- Golongan 
- Sandi Penerbit
- Nama Penerbit
- Negara Asal
- Pembayaran Kupon/Deviden/Bunga/Diskonto

# Data LBABK Sheet 1

- Flag Detail
- Kode Komponen
- Tanggal Transaksi
- Kode Jenis Efek
- Keterangan Jenis Efek
- Kode ISIN
- Kode Efek
- Nama Efek
- Kode Issuer
- Nama Issuer
- Kode Mata Uang
- Penyelesaian Transaksi Beli - Frekuensi
- Penyelesaian Transaksi Beli - Volume (Unit)
- Penyelesaian Transaksi Beli - Nilai
- % Penyelesaian Transaksi Beli - Investor Indonesia
- % Penyelesaian Transaksi Beli - Investor Asing
- % Penyelesaian Transaksi Beli - Konfirmasi Investor Tepat Waktu

- Penyelesaian Transaksi Jual - Frekuensi
- Penyelesaian Transaksi Jual - Volume (Unit)
- Penyelesaian Transaksi Jual - Nilai
- % Penyelesaian Transaksi Jual - Investor Indonesia
- % Penyelesaian Transaksi Jual - Investor Asing
- % Penyelesaian Transaksi Jual - Konfirmasi Investor Tepat Waktu

# DATA LBABK Sheet 2

- Flag Detail
- Kode Komponen
- Kode Tipe Efek
- Keterangan Tipe Efek
- Nilai (Rupiah)

# File Upload - Data Source

- ekstensi file nya apa aja, apakah CSV atau Excel
- Ada 3 file data source
- Apa parameter buat narik data dari Hiport? Harusnya parameter tersebut juga digunakan saat ngambil data dari data source yang sudah tersimpan di table

# Maintenance 
- ISIN Code
- ISSUER Code
- Bank
- Asuransi

# Data Source
- CUSACT
- Deposito
- LKPBUV

# Maintenance

- Asuransi dan Dana Pensiun --> dibikin upload file (InsurancePensionFund)
- ClosingRate (Exchange Rate) --> dibikin create satuan
- Golongan Pemilik --> dibikin upload file (Owner Group)
- Kode ISIN Efek --> dibikin upload file (Securities ISIN Code)
- Kode Issuer dan Placement Bank --> dibikin upload file (Issuer Code Placement Bank)
- Kode Issuer Efek --> dibikin upload file (Securities Issuer Code)

# Maintenance Name
- InsurancePensionFund
- ExchangeRate
- OwnerGroup
- SecuritiesISINCode
- IssuerCodePlacementBank
- SecuritiesIssuerCode

1. Maintenance Exchange Rate (OTW)
- kurang logic service impl

2. Owner Group
- kurang logic service impl
- `portfolioCode` is unique, can be used to update data

3. Securities ISIN Code (DONE)
- `externalCode2` is unique, can be used to update data

4. Securities Issuer Code (DONE)
- `externalCode2` is unique, can be used to update data

5. Issuer Code Placement Bank
- belum starting
- `code` is unique, can be used to update data

6. Asuransi dan Dana Pensiun
- belum starting
- `portfolioCode` is unique, can be used to update data

# Sample Code for Insert or Update
```java
@Transactional
    @Override
    public String createMultiple(CreateBankCodeListRequest createBankCodeListRequest) {
        int totalDataSuccess = 0;
        int totalDataFailed = 0;

        for (CreateBankCodeRequest createBankCodeRequest : createBankCodeListRequest.getCreateBankCodeRequestList()) {
            try {
                // Check if the entity exists by code
                if (createBankCodeRequest.getCode() != null) {
                    Optional<BankCode> existingBankCode = bankCodeRepository.findByCode(createBankCodeRequest.getCode());

                    if (existingBankCode.isPresent()) {
                        // Update the existing entity
                        BankCode bankCode = existingBankCode.get();

                        // save
                    } else {
                        // create baru save entity
                        // tidak perlu ada logic disini
                    }
                } else {
                    // Create new entity
                    BankCode bankCode = BankCode.builder()
                            .code(createBankCodeRequest.getCode())
                            .name(createBankCodeRequest.getName())
                            .build();
                    bankCodeRepository.save(bankCode);
                }
                totalDataSuccess++;
            } catch (Exception e) {
                totalDataFailed++;
            }
        }
        return "Total data success: " + totalDataSuccess + ", and total data failed: " + totalDataFailed;
    }
```

# Simulation Output Data is txt
- how to implement data list from table to the txt file
- how to auto download and saving to path

# Data Source
- 3 data 

# Generate TXT File then save to the Sever
- done

# Download TXT File
- done

# Service apa yang menggunakan Month Year yang dikirimkan dari depan?

# Data Source LKPBU
- Ada 2 data source: LKPBU Income dan LKPBU Hiport
- Dari dua file tersebut ada key matching nya

# 4 September Plan
1. Success read and insert LKPBU Income
2. Success read and insert LKPBU Hiport (include recon and inject income value) 
3. Success read and insert LKPBU Hiport, tapi belum melakukan recon dan income
4. Failed read and insert LKPBU Income, karena masih ada data dengan format yg salah

# 11 September
1. Pastikan data-data field di table not_found itu general
2. Tambahkan logic set Status = TRUE di masing-masing MAINTENANCE

# Summary


```java

List<Data> dataList = Arrays.asList(
        new Data(1, "11(TIME DEPOSIT)", "IDR", 12000),
        new Data(2, "1 (EQUITY)", "IDR", 15000),
        new Data(3, "3 (GOVERMENT BANK)", "IDR", 22000),
        new Data(4, "11(TIME DEPOSIT)", "USD", 250),
        new Data(5, "11(TIME DEPOSIT)", "USD", 100.5),
        new Data(6, "11(TIME DEPOSIT)", "IDR", 12000)
);


@Service
public class DataService {

    @Autowired
    private SummaryDataRepository summaryDataRepository;

    // Kurs USD to IDR (contoh rate dalam BigDecimal)
    private static final BigDecimal USD_TO_IDR_RATE = new BigDecimal("15000");

    public void processAndSaveData(List<Data> dataList) {
        // Kelompokkan berdasarkan typeEffect dan hitung total value setelah konversi
        Map<String, BigDecimal> totalByTypeEffect = dataList.stream()
                .collect(Collectors.groupingBy(
                        Data::getTypeEffect,
                        Collectors.reducing(
                                BigDecimal.ZERO,
                                data -> {
                                    BigDecimal value = BigDecimal.valueOf(data.getValue());
                                    // Konversi USD ke IDR sebelum dijumlahkan
                                    if ("USD".equals(data.getCurrency())) {
                                        return value.multiply(USD_TO_IDR_RATE).setScale(2, RoundingMode.HALF_UP);
                                    } else {
                                        return value;
                                    }
                                },
                                BigDecimal::add
                        )
                ));
        
        // Tambahkan Mutual Fund dengan totalValue 0 jika belum ada di hasil pengelompokan
        totalByTypeEffect.putIfAbsent("Mutual Fund", BigDecimal.ZERO);

        // Simpan hasilnya ke dalam tabel summary_data
        totalByTypeEffect.forEach((typeEffect, totalValue) -> {
            SummaryData summaryData = new SummaryData(typeEffect, totalValue);
            summaryDataRepository.save(summaryData);
        });
    }
}

Map<String, BigDecimal> totalByTypeEffect = dataList.parallelStream()
        .collect(Collectors.groupingBy(
                Data::getTypeEffect,
                Collectors.reducing(
                        BigDecimal.ZERO,
                        data -> {
                            BigDecimal value = BigDecimal.valueOf(data.getValue());
                            if ("USD".equals(data.getCurrency())) {
                                return value.multiply(USD_TO_IDR_RATE).setScale(2, RoundingMode.HALF_UP);
                            } else {
                                return value;
                            }
                        },
                        BigDecimal::add
                )
        ));
```

# 18 September 
```java
      private void validateInsurancePensionFundV2(LKPBUDataSource dataSave, String validationType) {
    String data1 = dataSave.getData1();
    log.info("Start validate {} with portfolio code: {}", validationType, data1);

    Optional<InsurancePensionFund> insurancePensionFundOptional = insurancePensionFundRepository.findByPortfolioCode(data1);

    if (insurancePensionFundOptional.isPresent()) {
        InsurancePensionFund insurancePensionFund = insurancePensionFundOptional.get();

        String dataSourceValue;
        String csaValue;
        String description;
        String flagRecon;

        if (validationType.equals("Insurance Company Code")) {
            dataSourceValue = dataSave.getSandiPerusahaanAsuransi();
            csaValue = insurancePensionFund.getInsurancePensionFundReference();
            description = createDescriptionRecon(REFERENSI_DAPEN_ASURANSI, csaValue, dataSourceValue);
            flagRecon = REFERENSI_DAPEN_ASURANSI_LKPBU.getName();
        } else if (validationType.equals("Investment Guarantee Fund")) {
            dataSourceValue = "0".concat(dataSave.getDanaJaminan());
            csaValue = insurancePensionFund.getGuaranteeFund();
            description = createDescriptionRecon(DANA_JAMINAN, csaValue, dataSourceValue);
            flagRecon = DANA_JAMINAN_LKPBU.getName();
        } else {
            throw new IllegalArgumentException("Unknown validation type: " + validationType);
        }

        if (!csaValue.equalsIgnoreCase(dataSourceValue)) {
            LKPBURecon lkpbuRecon = LKPBURecon.builder()
                    .createdDate(Instant.now())
                    .month(dataSave.getMonth())
                    .year(dataSave.getYear())
                    .dataSourcePeriod(dataSave.getMonth() + " " + dataSave.getYear())
                    .dataSourceId(dataSave.getId().toString())
                    .code(data1)
                    .csaValue(csaValue)
                    .dataSourceValue(dataSourceValue)
                    .description(description)
                    .status(Boolean.FALSE)
                    .flagRecon(flagRecon)
                    .build();
            lkpbuReconRepository.save(lkpbuRecon);
            dataSourceRepository.save(dataSave);
        }

    } else {
        log.info("{} not found with portfolio code: {}", validationType, data1);
        DataNotFound dataNotFound = DataNotFound.builder()
                .createdDate(Instant.now())
                .month(dataSave.getMonth())
                .year(dataSave.getYear())
                .dataSourcePeriod(dataSave.getMonth() + " " + dataSave.getYear())
                .code(data1)
                .description(createDescriptionDataNotFoundUsingData1(validationType, INSURANCE_PENSION_FUND_TABLE, data1))
                .status(Boolean.FALSE)
                .reportType(LKPBU)
                .flagTable(INSURANCE_PENSION_FUND.getName()) // ganti dengan table di constant
                .build();
        dataNotFoundRepository.save(dataNotFound);
    }
}

```

# Flow Type Effect

```java 
 // Method untuk mengekstrak kode dari string type effect
    private String extractCode(String typeEffect) {
        return typeEffect.split(" ")[0]; // Ambil bagian pertama sebelum spasi (misal 50 atau 11)
    }

    public Map<String, BigDecimal> processTypeEffects(List<LKPBUSampleData> dataList, Map<String, BigDecimal> exchangeRates) {
        // Daftar type effect yang Anda miliki
        List<String> typeEffects = Arrays.asList("50 (Mutual Fund)", "1 (Equity)", "2 (Government)", "11 (Time Deposit)");

        // Mengambil hanya kodenya dari type effect
        List<String> typeEffectCodes = typeEffects.stream()
                .map(this::extractCode)
                .collect(Collectors.toList());

        // Mengumpulkan nilai berdasarkan type effect code dan memastikan nilai 0 jika tidak ada di data list
        Map<String, BigDecimal> totalByTypeEffect = typeEffectCodes.stream()
                .collect(Collectors.toMap(
                        code -> code, // key: code dari type effect
                        code -> dataList.stream()
                                .filter(data -> extractCode(data.getTypeEffect()).equals(code)) // filter sesuai code
                                .map(LKPBUSampleData::getValue) // ambil value dari data yang cocok
                                .reduce(BigDecimal.ZERO, BigDecimal::add), // jumlahkan nilai, default 0 jika tidak ada
                        (oldValue, newValue) -> oldValue, // jika ada duplikasi key, gunakan value lama
                        LinkedHashMap::new // memastikan urutan sesuai dengan urutan input
                ));

        // Pastikan ada nilai 0 untuk type effect yang tidak ada di data
        typeEffectCodes.forEach(code -> totalByTypeEffect.putIfAbsent(code, BigDecimal.ZERO));

        return totalByTypeEffect;
    }

    public static void main(String[] args) {
        // Contoh penggunaan
        TypeEffectProcessor processor = new TypeEffectProcessor();
        List<LKPBUSampleData> dataList = Arrays.asList(
                new LKPBUSampleData("50 (Mutual Fund)", new BigDecimal("100000")),
                new LKPBUSampleData("11 (Time Deposit)", new BigDecimal("500000"))
        );

        Map<String, BigDecimal> result = processor.processTypeEffects(dataList, null);
        result.forEach((code, totalValue) -> System.out.println("Code: " + code + ", Total Value: " + totalValue));
    }
```

# Flow Type Effect 2

```java 
   // Method untuk mengekstrak kode dari string type effect
    private String extractCode(String typeEffect) {
        return typeEffect.split(" ")[0]; // Ambil bagian pertama sebelum spasi (misal 50 atau 11)
    }

    public Map<String, BigDecimal> processTypeEffects(List<LKPBUSampleData> dataList, List<String> typeEffects) {
        // Mengambil hanya kodenya dari type effect
        Map<String, String> typeEffectMap = typeEffects.stream()
                .collect(Collectors.toMap(this::extractCode, typeEffect -> typeEffect));

        // Mengumpulkan nilai berdasarkan type effect code dan memastikan nilai 0 jika tidak ada di data list
        Map<String, BigDecimal> totalByTypeEffect = typeEffectMap.keySet().stream()
                .collect(Collectors.toMap(
                        code -> typeEffectMap.get(code), // key: type effect full format seperti "50 (Mutual Fund)"
                        typeEffect -> dataList.stream()
                                .filter(data -> extractCode(data.getTypeEffect()).equals(extractCode(typeEffect))) // filter sesuai code
                                .map(LKPBUSampleData::getValue) // ambil value dari data yang cocok
                                .reduce(BigDecimal.ZERO, BigDecimal::add), // jumlahkan nilai, default 0 jika tidak ada
                        (oldValue, newValue) -> oldValue, // jika ada duplikasi key, gunakan value lama
                        LinkedHashMap::new // memastikan urutan sesuai dengan urutan input
                ));

        // Pastikan ada nilai 0 untuk type effect yang tidak ada di data
        typeEffectMap.forEach((code, fullTypeEffect) -> totalByTypeEffect.putIfAbsent(fullTypeEffect, BigDecimal.ZERO));

        return totalByTypeEffect;
    }

    public static void main(String[] args) {
        // Contoh penggunaan
        TypeEffectProcessor processor = new TypeEffectProcessor();
        
        // List dari data yang akan diolah (dari database atau lainnya)
        List<LKPBUSampleData> dataList = Arrays.asList(
                new LKPBUSampleData("50 (Mutual Fund)", new BigDecimal("100000")),
                new LKPBUSampleData("11 (Time Deposit)", new BigDecimal("500000"))
        );

        // Daftar type effect yang akan digunakan untuk proses penyimpanan
        List<String> typeEffects = Arrays.asList("50 (Mutual Fund)", "1 (Equity)", "2 (Government)", "11 (Time Deposit)");

        // Proses grouping berdasarkan type effect dan menghitung total nilai
        Map<String, BigDecimal> result = processor.processTypeEffects(dataList, typeEffects);

        // Menyimpan ke database atau menampilkan hasil
        result.forEach((fullTypeEffect, totalValue) -> {
            System.out.println("Type Effect: " + fullTypeEffect + ", Total Value: " + totalValue);
            // Logika untuk menyimpan ke database bisa ditambahkan di sini
        });
    }
```

# Flow Type Effect 3

```java 
 // Method untuk mengekstrak kode dari string type effect
    private String extractCode(String typeEffect) {
        return typeEffect.split(" ")[0]; // Ambil bagian pertama sebelum spasi (misal 50 atau 11)
    }

    public Map<String, BigDecimal> processTypeEffects(List<LKPBUSampleData> dataList) {
        // Menggunakan enum untuk type effects
        Map<String, String> typeEffectMap = Arrays.stream(TypeEffectEnum.values())
                .collect(Collectors.toMap(TypeEffectEnum::getCode, TypeEffectEnum::getFullTypeEffect));

        // Mengumpulkan nilai berdasarkan type effect code dan memastikan nilai 0 jika tidak ada di data list
        Map<String, BigDecimal> totalByTypeEffect = typeEffectMap.keySet().stream()
                .collect(Collectors.toMap(
                        code -> typeEffectMap.get(code), // key: type effect full format seperti "50 (Mutual Fund)"
                        typeEffect -> dataList.stream()
                                .filter(data -> extractCode(data.getTypeEffect()).equals(code)) // filter sesuai code
                                .map(LKPBUSampleData::getValue) // ambil value dari data yang cocok
                                .reduce(BigDecimal.ZERO, BigDecimal::add), // jumlahkan nilai, default 0 jika tidak ada
                        (oldValue, newValue) -> oldValue, // jika ada duplikasi key, gunakan value lama
                        LinkedHashMap::new // memastikan urutan sesuai dengan urutan input
                ));

        // Pastikan ada nilai 0 untuk type effect yang tidak ada di data
        typeEffectMap.forEach((code, fullTypeEffect) -> totalByTypeEffect.putIfAbsent(fullTypeEffect, BigDecimal.ZERO));

        return totalByTypeEffect;
    }

    public static void main(String[] args) {
        // Contoh penggunaan
        TypeEffectProcessor processor = new TypeEffectProcessor();
        
        // List dari data yang akan diolah (dari database atau lainnya)
        List<LKPBUSampleData> dataList = Arrays.asList(
                new LKPBUSampleData("50 (Mutual Fund)", new BigDecimal("100000")),
                new LKPBUSampleData("11 (Time Deposit)", new BigDecimal("500000"))
        );

        // Proses grouping berdasarkan type effect dan menghitung total nilai
        Map<String, BigDecimal> result = processor.processTypeEffects(dataList);

        // Menyimpan ke database atau menampilkan hasil
        result.forEach((fullTypeEffect, totalValue) -> {
            System.out.println("Type Effect: " + fullTypeEffect + ", Total Value: " + totalValue);
            // Logika untuk menyimpan ke database bisa ditambahkan di sini
        });
    }
```

# Calculate LBABK Sell and Buy Result
```java
   private String getStringSubtractResult(BigDecimal settlementBuyResult) {
        String formattedResult;

        if (settlementBuyResult.compareTo(BigDecimal.ZERO) < 0) {
            formattedResult = "(" + settlementBuyResult.abs().toPlainString() + ")";
        } else {
            formattedResult = settlementBuyResult.toPlainString();
        }
        return formattedResult;
    }
```

# Notes LKPBU per 24 September 2024
- Data source LKPBU itu tidak ada `month` dan `year`.
- Sehingga di table LKPBUDataSource dan LKPBU tidak ada field `month` dan `year`
- Karena sifat data LKPBU adalah update jika ada perubahan atas key `data1` concat `data2`
- Sehingga saat proses insert data ke LKPBUDataSource, maka kita perlu menambah hasil column untuk concat `data1` dan `data2`
- Prosesnya mirip insert/update
- Ini akan impact ketika generate report `Asset Under Custody`.
- Saat ini untuk mengambil data dari LKPBU, kita menggunakan `findAllByMonthAndYear`
- Jadi kita ubah menjadi `findAll` saja
- Lalu kita grouping berdasarkan `kodeTipeEfek`
- Bagian yg ada perubahan adalah: model, service LKPBUDataSourceService, LKPBUService, AssetUnderCustodyService
- perubahan ada pada methodnya yg tidak menggunakan `month` dan `year`

# Result of Meeting
- Pengecekan Dana Jaminan adalah paling atas. Jika kolom N nya adalah kosong, maka tidak akan dilakukan recon terhadap 3 column (dana jaminan, sandi perusahaan, golongan pemilik)
- dana jaminan (kolom N), ngikatnya di transaksi, contohnya 11BINS
- reconnya hanya sekali, tidak recon 13ribu data.
- Karena set nya udah dari Hiport untuk dana jaminan
- Kode Nasabah (portfolio code): recon dana jaminan, sandi perusahaan asuransi, golongan pemilik. Akan ke-recon jika kolom N keisi
- Kode Barang (security code): recon isin code. ada 600 data yang akan ke-recon, bukan 13.000 data

# Notes

```java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import javax.validation.Validator;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class SecuritiesIssuerCodeService {

    @Autowired
    private Validator validator;

    @Autowired
    private SecuritiesIssuerCodeRepository securitiesIssuerCodeRepository;

    @Autowired
    private ValidationData validationData;

    public synchronized SecuritiesIssuerCodeResponse uploadData(
            UploadSecuritiesIssuerCodeListRequest uploadSecuritiesIssuerCodeListRequest, 
            RegulatoryDataChangeDTO regulatoryDataChangeDTO,
            boolean isUpdate) {

        log.info("Start upload data Issuer Code: {}, {}", uploadSecuritiesIssuerCodeListRequest, regulatoryDataChangeDTO);
        int totalDataSuccess = 0;
        int totalDataFailed = 0;
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

        for (UploadSecuritiesIssuerCodeDataRequest issuerCodeDataRequest : uploadSecuritiesIssuerCodeListRequest.getUploadIssuerCodeDataListRequest()) {
            List<String> validationErrors = new ArrayList<>();
            SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO = null;
            try {
                // Grup validasi tergantung pada operasi Add atau Update
                Class<?> validationGroup = isUpdate ? UpdateValidationGroup.class : AddValidationGroup.class;

                // Validasi input
                Errors errors = validationData.validateObject(issuerCodeDataRequest, validationGroup);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }

                // Map request ke DTO
                securitiesIssuerCodeDTO = securitiesIssuerCodeMapper.fromUploadRequestToDTO(issuerCodeDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                            !securitiesIssuerCodeDTO.getExternalCode().isEmpty() ? securitiesIssuerCodeDTO.getExternalCode() : UNKNOWN_EXTERNAL_CODE,
                            validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    // Logika untuk add atau update
                    if (isUpdate) {
                        handleUpdateIssuerCode(issuerCodeDataRequest, securitiesIssuerCodeDTO, regulatoryDataChangeDTO);
                    } else {
                        handleNewIssuerCode(securitiesIssuerCodeDTO, regulatoryDataChangeDTO);
                    }
                    totalDataSuccess++;
                }
            } catch (Exception e) {
                handleGeneralError(securitiesIssuerCodeDTO, e, validationErrors, errorMessageDTOList);
                totalDataFailed++;
            }
        }
        return new SecuritiesIssuerCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
    }

    // Method untuk menangani data baru (Add)
    private void handleNewIssuerCode(SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        // Logika untuk handle data baru
        SecuritiesIssuerCode entity = securitiesIssuerCodeMapper.toEntity(securitiesIssuerCodeDTO);
        securitiesIssuerCodeRepository.save(entity);
    }

    // Method untuk menangani update data
    private void handleUpdateIssuerCode(UploadSecuritiesIssuerCodeDataRequest issuerCodeDataRequest, 
                                        SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO, 
                                        RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
        // Logika untuk handle update
        Optional<SecuritiesIssuerCode> optionalIssuerCode = securitiesIssuerCodeRepository.findByExternalCode2(issuerCodeDataRequest.getExternalCode2());
        if (optionalIssuerCode.isPresent()) {
            SecuritiesIssuerCode existingIssuerCode = optionalIssuerCode.get();
            securitiesIssuerCodeMapper.updateEntity(existingIssuerCode, securitiesIssuerCodeDTO);
            securitiesIssuerCodeRepository.save(existingIssuerCode);
        } else {
            throw new RuntimeException("Issuer code not found for update.");
        }
    }

    // Method untuk menangani general error
    private void handleGeneralError(SecuritiesIssuerCodeDTO securitiesIssuerCodeDTO, Exception e, List<String> validationErrors, List<ErrorMessageDTO> errorMessageDTOList) {
        log.error("Error processing issuer code: {}", securitiesIssuerCodeDTO.getExternalCode(), e);
        validationErrors.add("General error occurred: " + e.getMessage());
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(
                securitiesIssuerCodeDTO != null && !securitiesIssuerCodeDTO.getExternalCode().isEmpty() ? securitiesIssuerCodeDTO.getExternalCode() : UNKNOWN_EXTERNAL_CODE,
                validationErrors);
        errorMessageDTOList.add(errorMessageDTO);
    }
}

```

# Update Validation Maintenance

```java
public synchronized SecuritiesISINCodeResponse uploadData(UploadSecuritiesISINCodeListRequest uploadSecuritiesISINCodeListRequest, RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
    log.info("Start upload data ISIN Code: {}, {}", uploadSecuritiesISINCodeListRequest, regulatoryDataChangeDTO);
    int totalDataSuccess = 0;
    int totalDataFailed = 0;
    List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

    for (UploadSecuritiesISINCodeDataRequest isinCodeDataRequest : uploadSecuritiesISINCodeListRequest.getUploadSecuritiesISINCodeDataRequestList()) {
        List<String> validationErrors = new ArrayList<>();
        SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

        try {
            // Tentukan apakah ini operasi Add atau Update
            Optional<SecuritiesISINCode> existingISINCode = securitiesISINCodeRepository.findByExternalCode(isinCodeDataRequest.getExternalCode2());

            if (existingISINCode.isPresent()) {
                // Validasi untuk update
                Errors errors = validationData.validateObject(isinCodeDataRequest, UpdateValidationGroup.class);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }
                securitiesISINCodeDTO = securitiesISINCodeMapper.fromUploadRequestToDTO(isinCodeDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(securitiesISINCodeDTO.getExternalCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    // Handle existing ISIN Code
                    handleExistingISINCode(existingISINCode.get(), securitiesISINCodeDTO, regulatoryDataChangeDTO);
                    totalDataSuccess++;
                }
            } else {
                // Validasi untuk create
                Errors errors = validationData.validateObject(isinCodeDataRequest, AddValidationGroup.class);
                if (errors.hasErrors()) {
                    errors.getAllErrors().forEach(error -> validationErrors.add(error.getDefaultMessage()));
                }
                securitiesISINCodeDTO = securitiesISINCodeMapper.fromUploadRequestToDTO(isinCodeDataRequest);

                if (!validationErrors.isEmpty()) {
                    ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO(securitiesISINCodeDTO.getExternalCode(), validationErrors);
                    errorMessageDTOList.add(errorMessageDTO);
                    totalDataFailed++;
                } else {
                    // Handle new ISIN Code
                    handleNewISINCode(securitiesISINCodeDTO, regulatoryDataChangeDTO);
                    totalDataSuccess++;
                }
            }
        } catch (Exception e) {
            handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
    }

    return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
}

```

```java 
public synchronized SecuritiesISINCodeResponse uploadData(
        UploadSecuritiesISINCodeListRequest uploadSecuritiesISINCodeListRequest,
        RegulatoryDataChangeDTO regulatoryDataChangeDTO) {
    
    log.info("Start upload data ISIN Code: {}, {}", uploadSecuritiesISINCodeListRequest, regulatoryDataChangeDTO);
    int totalDataSuccess = 0;
    int totalDataFailed = 0;
    List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<>();

    for (UploadSecuritiesISINCodeDataRequest isinCodeDataRequest : uploadSecuritiesISINCodeListRequest.getUploadSecuritiesISINCodeDataRequestList()) {
        List<String> validationErrors = new ArrayList<>();
        SecuritiesISINCodeDTO securitiesISINCodeDTO = null;

        try {
            // Check if the ISIN code already exists
            Optional<SecuritiesISINCode> existingISINCode = securitiesISINCodeRepository.findByExternalCode(isinCodeDataRequest.getExternalCode2());

            // Determine if this is an update or add operation
            if (existingISINCode.isPresent()) {
                // Validate for update
                validator.validate(isinCodeDataRequest, UpdateValidationGroup.class);
                securitiesISINCodeDTO = securitiesISINCodeMapper.fromUploadRequestToDTO(isinCodeDataRequest);
                
                // Handle existing ISIN Code
                handleExistingISINCode(existingISINCode.get(), securitiesISINCodeDTO, regulatoryDataChangeDTO);
            } else {
                // Validate for create
                validator.validate(isinCodeDataRequest, AddValidationGroup.class);
                securitiesISINCodeDTO = securitiesISINCodeMapper.fromUploadRequestToDTO(isinCodeDataRequest);
                
                // Handle new ISIN Code
                handleNewISINCode(securitiesISINCodeDTO, regulatoryDataChangeDTO);
            }
            totalDataSuccess++;
        } catch (ConstraintViolationException e) {
            // Collect validation errors
            for (ConstraintViolation<?> violation : e.getConstraintViolations()) {
                validationErrors.add(violation.getMessage());
            }
            errorMessageDTOList.add(new ErrorMessageDTO(securitiesISINCodeDTO != null ? securitiesISINCodeDTO.getExternalCode() : "Unknown", validationErrors));
            totalDataFailed++;
        } catch (Exception e) {
            handleGeneralError(securitiesISINCodeDTO, e, validationErrors, errorMessageDTOList);
            totalDataFailed++;
        }
    }

    return new SecuritiesISINCodeResponse(totalDataSuccess, totalDataFailed, errorMessageDTOList);
}

```