package com.services.billingservice.utils;

import java.lang.reflect.Field;
import java.util.*;

public class ReflectionUtil {

    public static List<Field> getAllFields(Object object) {
        List<Field> fields = new ArrayList<>();
        Class<?> clazz = object.getClass();
        while (clazz != null) {
            fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
            clazz = clazz.getSuperclass();
        }
        return fields;
    }

    public static Map<String, Object> getAllFieldValues(Object obj) throws IllegalAccessException {
        Map<String, Object> fieldValues = new HashMap<>();
        if (obj != null) {
            Class<?> clazz = obj.getClass();
            for (Field field : clazz.getDeclaredFields()) {
                field.setAccessible(true); // Make private fields accessible
                fieldValues.put(field.getName(), field.get(obj));
            }
        }
        return fieldValues;
    }
}
