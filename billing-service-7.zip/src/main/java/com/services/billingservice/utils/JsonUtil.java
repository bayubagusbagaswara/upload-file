package com.services.billingservice.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.experimental.UtilityClass;

import java.util.Iterator;
import java.util.Map;

@UtilityClass
public class JsonUtil {

    private final ObjectMapper objectMapper = new ObjectMapper();

    public static String cleanedJsonData(String jsonDataFull) throws JsonProcessingException {
        JsonNode jsonNode = objectMapper.readTree(jsonDataFull);

        ((ObjectNode) jsonNode).remove("dataChangeId");
        ((ObjectNode) jsonNode).remove("approvalStatus");
        ((ObjectNode) jsonNode).remove("inputerId");
        ((ObjectNode) jsonNode).remove("inputerIPAddress");
        ((ObjectNode) jsonNode).remove("inputDate");
        ((ObjectNode) jsonNode).remove("approverId");
        ((ObjectNode) jsonNode).remove("approverIPAddress");
        ((ObjectNode) jsonNode).remove("approveDate");

        return objectMapper.writeValueAsString(jsonNode);
    }

    public static String cleanedJsonDataUpdate(String jsonDataFull) throws JsonProcessingException {
        JsonNode jsonNode = objectMapper.readTree(jsonDataFull);

        if (jsonNode.isObject()) {
            Iterator<Map.Entry<String, JsonNode>> fields = getEntryIterator((ObjectNode) jsonNode);
            while (fields.hasNext()) {
                Map.Entry<String, JsonNode> entry = fields.next();
                if (entry.getValue().isTextual() && entry.getValue().asText().isEmpty()) {
                    fields.remove();
                }
            }
        }

        return objectMapper.writeValueAsString(jsonNode);
    }

    private static Iterator<Map.Entry<String, JsonNode>> getEntryIterator(ObjectNode jsonNode) {

        // Remove the "id" property
        jsonNode.remove("id");
        jsonNode.remove("code");
        jsonNode.remove("customerCode"); // for customer data cannot be updated
        jsonNode.remove("subCode"); // for customer data cannot be updated
        jsonNode.remove("feeCode"); // for fee parameter data cannot be updated
        jsonNode.remove("feeName"); // for fee parameter data cannot be updated
        jsonNode.remove("dataChangeId");
        jsonNode.remove("approvalStatus");
        jsonNode.remove("inputerId");
        jsonNode.remove("inputerIPAddress");
        jsonNode.remove("inputDate");
        jsonNode.remove("approverId");
        jsonNode.remove("approverIPAddress");
        jsonNode.remove("approveDate");

        // Remove properties with empty string values
        return jsonNode.fields();
    }
}
