package com.services.billingservice.utils;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class FieldUtil {
    public FieldUtil() {
    }

    public static List<String> getObjectFieldName(Object parent) {
        List<String> result = new ArrayList<>();
        java.lang.reflect.Field[] allFields = parent.getClass().getDeclaredFields();
        for (java.lang.reflect.Field field : allFields) {
            try {
                result.add(field.getName());
            } catch (Exception e) {
                return new ArrayList<>();
            }
        }
        return result;
    }

    public static List<String> getAllFieldName(Field[] allFields) {
        List<String> result = new ArrayList<>();
        for (java.lang.reflect.Field field : allFields) {
            try {
                result.add(field.getName());
            } catch (Exception e) {
                return new ArrayList<>();
            }
        }
        return result;
    }
}
