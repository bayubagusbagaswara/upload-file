package com.services.billingservice.utils.OpenCsv;

public class CsvBean {
}
