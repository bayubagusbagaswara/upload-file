package com.services.billingservice.utils;

import java.math.BigDecimal;

public class Main {

    public static void main(String[] args) {
        BigDecimal bigDecimal = new BigDecimal("0.0030000");
        BigDecimal bigDecimal1 = new BigDecimal("0.0250000");
        BigDecimal bigDecimal2 = new BigDecimal("100000.00");

        System.out.println(removeTrailingZeros(bigDecimal));
        System.out.println(removeTrailingZeros(bigDecimal1));
        System.out.println(removeTrailingZeros(bigDecimal2));
    }

    static String removeTrailingZeros(BigDecimal bigDecimal) {
        String stringRepresentation = bigDecimal.toPlainString(); // Use toPlainString() first

        System.out.println("After toPlainString(): " + stringRepresentation); // Verify

        // Check for ".0" and remove if unnecessary
        if (stringRepresentation.endsWith(".0")) {
            stringRepresentation = stringRepresentation.substring(0, stringRepresentation.length() - 2);
        }

        return stringRepresentation;
    }

}
