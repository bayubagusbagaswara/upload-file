package com.services.billingservice.utils;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.IOException;

@Slf4j
public class FileUtil {
    protected static final String PATH_SEPARATOR = "\\";
    protected static final String REPLACE_SEPARATOR = "\\\\";

    public static String createFile (String folderPath, final String fileName) throws IOException {
        folderPath = folderPath.replaceAll("[\\\\/]+", REPLACE_SEPARATOR)
                .replaceAll("[\\\\/]+$", "");
        final String fullPath = folderPath + PATH_SEPARATOR + fileName;
        File folder = new File(folderPath);
        File file = new File(folder, fileName);

        // Create the folder if it doesn't exist
        if (!folder.exists()) {
            folder.mkdirs(); // Creates all necessary parent directories as well
        }

        // Create the file
        if (!file.exists()) {
            file.createNewFile();
            log.info("File {} created successfully!", fullPath);
        } else {
            log.info("File {} already exists!", fullPath);
        }
        return fullPath;
    }
}
