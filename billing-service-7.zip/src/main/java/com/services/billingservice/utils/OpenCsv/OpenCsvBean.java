package com.services.billingservice.utils.OpenCsv;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import org.modelmapper.ModelMapper;

import java.io.FileWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import static com.services.billingservice.utils.FileUtil.createFile;

public class OpenCsvBean<S, D> {
    private final ModelMapper modelMapper = new ModelMapper();

    /**
     * @param pathStr
     *  Ex: "D:\csv\twoColumn.csv"
     * @param simplePositionBeanClass
     *  Ex: SimplePositionBean.class
     * @return
     * @throws Exception
     */
    public List<CsvBean> simplePositionBeanRead(final String pathStr, final Class simplePositionBeanClass) throws Exception {
        Path path = Paths.get(pathStr);
        return beanBuilderRead(path, simplePositionBeanClass);
    }

    /**
     * @param pathStr
     *  Ex: "D:\csv\namedColumn.csv"
     * @param namedColumnBean
     * Ex: NamedColumnBean.class
     * @return
     * @throws Exception
     */
    public List<CsvBean> namedColumnBeanRead(final String pathStr, final Class namedColumnBean) throws Exception {
        Path path = Paths.get(pathStr);
        return beanBuilderRead(path, namedColumnBean);
    }

    /**
     * @param folderPath
     * Ex : D:\folder
     * @param fileName
     * Ex : file.csv
     * @param listObject
     * Ex : List<Entity>, List<DTO>
     * @param clazz
     * Must create Bean Object that extend with CsvBean with getter, setter, and constructor
     * @return
     * @throws Exception
     */
    public String writeCsvFromBean(final String folderPath, final String fileName,
                                   final List<S> listObject,
                                   final Class<? extends CsvBean> clazz) throws Exception {
        List<CsvBean> listData = listObject.stream()
                .map((m) -> modelMapper.map(m, clazz))
                .collect(Collectors.toList());

        final String fullPath = createFile(folderPath, fileName);
        Path path = Paths.get(fullPath);
        return writeCsvFromBean(path, listData);
    }

    public List<CsvBean> beanBuilderRead(final Path path, final Class<? extends CsvBean> clazz) throws Exception {
        CsvTransfer csvTransfer = new CsvTransfer();
        try (Reader reader = Files.newBufferedReader(path)) {
            CsvToBean<CsvBean> cb = new CsvToBeanBuilder<CsvBean>(reader)
                    .withType(clazz)
                    .build();

            csvTransfer.setCsvList(cb.parse());
        }

        return csvTransfer.getCsvList();
    }

    public List<D> csvStringBuilderRead(final String csvString, final Class clazz) {
        StringReader stringReader = new StringReader(csvString);
        CSVReader csvReader = new CSVReaderBuilder(stringReader).build();
        List<D> arrayList= new CsvToBeanBuilder<S>(csvReader)
                .withType(clazz)
                .withIgnoreLeadingWhiteSpace(true)
                .withSkipLines(1)// Skip the header line
                .build()
                .parse();
        return arrayList;
    }

    public String writeCsvFromBean(final Path path, final List<CsvBean> listData) throws Exception {
        try (Writer writer = new FileWriter(path.toString())) {
            StatefulBeanToCsv<CsvBean> sbc = new StatefulBeanToCsvBuilder<CsvBean>(writer)
                    .withQuotechar(CSVWriter.NO_QUOTE_CHARACTER)
                    .withSeparator(CSVWriter.DEFAULT_SEPARATOR)
                    .build();

            sbc.write(listData);
        }
//        return OpenCsvHelpers.readFile(path);
        return "Success Write CSV";
    }
}
