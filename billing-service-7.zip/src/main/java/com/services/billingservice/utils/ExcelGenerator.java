package com.services.billingservice.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.modelmapper.ModelMapper;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.services.billingservice.utils.FieldUtil.getAllFieldName;
import static com.services.billingservice.utils.ReflectionUtil.getAllFieldValues;

@Slf4j
public class ExcelGenerator<D> {
    private String sheetName;
    private Class<D> ojectClass;
    private List<D> objectList;
    private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private ModelMapper modelMapper;

    public static final Integer MAX_ROWS_PER_SHEET = 999999;

    public ExcelGenerator(List<D> objectList, Class<D> ojectClass, String sheetName) {
        this.objectList = objectList;
        this.sheetName = sheetName;
        this.ojectClass = ojectClass;
        workbook = new XSSFWorkbook();
    }
    private void writeHeader() {
        Integer sheetCount = objectList.size() / MAX_ROWS_PER_SHEET;
        if (objectList.size() % MAX_ROWS_PER_SHEET > 0) sheetCount += 1;

        for (int i=1;i <= sheetCount;i++) {
            sheet = workbook.createSheet(sheetName + "_" + i);
            Row row = sheet.createRow(0);
            CellStyle style = workbook.createCellStyle();
            XSSFFont font = workbook.createFont();
            font.setBold(true);
            font.setFontHeight(16);
            style.setFont(font);

            Integer columnCount = 0;
            for (String fieldName : getAllFieldName(ojectClass.getDeclaredFields())) {
                createCell(row, columnCount, fieldName, style);
                columnCount++;
            }

            write();
        }
    }
    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
        if (valueOfCell == null) return;
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (valueOfCell instanceof Integer) {
            cell.setCellValue((Integer) valueOfCell);
        } else if (valueOfCell instanceof Long) {
            cell.setCellValue((Long) valueOfCell);
        } else if (valueOfCell instanceof Double) {
            cell.setCellValue((Double) valueOfCell);
        } else if (valueOfCell instanceof BigDecimal) {
            cell.setCellValue(((BigDecimal) valueOfCell).toPlainString());
        } else if (valueOfCell instanceof String) {
            cell.setCellValue((String) valueOfCell);
        } else if (valueOfCell instanceof LocalDate) {
            cell.setCellValue((LocalDate) valueOfCell);
        } else if (valueOfCell instanceof LocalDateTime) {
            cell.setCellValue((LocalDateTime) valueOfCell);
        } else if (valueOfCell instanceof Date) {
            cell.setCellValue((Date) valueOfCell);
        } else if (valueOfCell instanceof Instant) {
            cell.setCellValue(Date.from((Instant) valueOfCell));
        } else if (valueOfCell instanceof Boolean) {
            cell.setCellValue((Boolean) valueOfCell);
        } else {
            cell.setCellValue(valueOfCell.toString());
        }
        cell.setCellStyle(style);
    }
    private void write() {
        Integer printedRows = 0;
        int rowCount = 1;
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(14);
        style.setFont(font);
        for (D record: objectList) {
            Row row = sheet.createRow(rowCount++);
            try {
                Map<String, Object> fieldValuesMap = getAllFieldValues(record);
                int columnCount = 0;
                for (String fieldName : getAllFieldName(ojectClass.getDeclaredFields())) {
                    createCell(row, columnCount++, fieldValuesMap.get(fieldName), style);
                    columnCount++;
                }
            } catch (Exception e) {
                log.error(e.getMessage());
                continue;
            } finally {
                printedRows++;
            }
        }
    }

    /**
     * How To Use :
     * @Controller
     * public class ExampleController {
     *
     *     @GetMapping("/export-to-excel")
     *     public void exportIntoExcelFile(HttpServletResponse response) throws IOException {
     *         response.setContentType("application/octet-stream");
     *         DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
     *         String currentDateTime = dateFormatter.format(new Date());
     *
     *         String headerKey = "Content-Disposition";
     *         String headerValue = "attachment; filename=student" + currentDateTime + ".xlsx";
     *         response.setHeader(headerKey, headerValue);
     *
     *         List<SfValRgDaily> sfValRgDailyList = rgDailyService.getAllRetailByAidAndTypeAndCurrencyAndPeriod(aid, typeRetail, currency, date);
     *         ExcelGenerator<SfValRgDaily> excelGenerator = new ExcelGenerator<>(sfValRgDailyList, SfValRgDaily.class, "Test");
     *         try {
     *             excelGenerator.generateExcelFile(resp);
     *         } catch (IOException e) {
     *             throw new RuntimeException(e);
     *         }
     *     }
     * }
     */
    public void generateExcelFile(HttpServletResponse response) throws IOException {
        writeHeader();
        write();
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }
}
