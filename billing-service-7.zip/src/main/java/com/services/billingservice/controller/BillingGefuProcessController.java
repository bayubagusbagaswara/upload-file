package com.services.billingservice.controller;

import com.services.billingservice.dto.ResponseDTO;
import com.services.billingservice.dto.connectionparameter.CreateBillingGefuDTO;
import com.services.billingservice.dto.connectionparameter.CustomerCodeDTO;
import com.services.billingservice.dto.core.*;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingGefuProcessDetail;
import com.services.billingservice.model.BillingGefuProcessHistory;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLOutput;
import java.util.List;

import static com.services.billingservice.enums.BillingCategory.CORE;
import static com.services.billingservice.enums.BillingType.*;

@Slf4j
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(path = "/api/billing/core")
@RequiredArgsConstructor
public class BillingGefuProcessController {

    private final BillingGefuGeneratorService gefuGeneratorService;


    @PostMapping(path = "/create-gefu")
    public ResponseEntity<ResponseDTO<String>> createBillingGefu(@RequestBody CreateBillingGefuDTO dto) {

        for (CustomerCodeDTO customer : dto.getCustomers()) {
            String sts = gefuGeneratorService.createGefu(dto.getCategory(), dto.getMonth(),
                    dto.getYear(), customer.getCode(), dto.getUserId());
            System.out.println(sts);

        }

        String status = "OK";//gefuGeneratorService.createGefu(type, year, userid);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PostMapping(path = "/approve-gefu")
    public ResponseEntity<ResponseDTO<String>> approveAndSendBillingGefu(@RequestParam("historyId") long historyid,
                                                                         @RequestParam("approverId") String approverId) {

        boolean sendStatus = gefuGeneratorService.approveAndSendGefu(historyid, approverId);

        String status = "OK";//gefuGeneratorService.createGefu(type, year, userid);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @PostMapping(path = "/reject-gefu")
    public ResponseEntity<ResponseDTO<String>> rejectBillingGefu(@RequestParam("historyId") long historyid,
                                                                 @RequestParam("approverId") String approverId) {

        gefuGeneratorService.rejectGefu(historyid, approverId);

        String status = "OK";//gefuGeneratorService.createGefu(type, year, userid);
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list-gefu")
    public ResponseEntity<ResponseDTO<List<BillingGefuProcessHistory>>> gefuHistoryList(@RequestParam("category") String category,
                                                           @RequestParam("month") String month,
                                                           @RequestParam("year") int year,
                                                           @RequestParam("customerCode") String customerCode) {

        ResponseDTO<List<BillingGefuProcessHistory>> response = ResponseDTO.<List<BillingGefuProcessHistory>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(gefuGeneratorService.gefuHistoryList(category, month, year, customerCode))
                .build();

        return ResponseEntity.ok().body(response);
    }


    @PostMapping(path = "/check-response")
    public ResponseEntity<ResponseDTO<String>> readBillingGefu() {

        gefuGeneratorService.readGefuResponse();

        String status = "OK";
        ResponseDTO<String> response = ResponseDTO.<String>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(status)
                .build();

        return ResponseEntity.ok().body(response);
    }

    @GetMapping(path = "/list-gefu-detail")
    public ResponseEntity<ResponseDTO<List<BillingGefuProcessDetail>>> gefuDetailList(@RequestParam("id") long id) {

        ResponseDTO<List<BillingGefuProcessDetail>> response = ResponseDTO.<List<BillingGefuProcessDetail>>builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.getReasonPhrase())
                .payload(gefuGeneratorService.gefuDetailList(id))
                .build();

        return ResponseEntity.ok().body(response);
    }
}
