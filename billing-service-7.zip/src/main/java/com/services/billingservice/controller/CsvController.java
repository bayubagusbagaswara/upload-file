package com.services.billingservice.controller;

import com.services.billingservice.service.DataExportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
@RequestMapping(path = "/api/csv")
@RequiredArgsConstructor
@Slf4j
public class CsvController {

    private final DataExportService dataExportService;

    @GetMapping(path = "/export-data")
    public ResponseEntity<byte[]> exportData() throws IOException {
        byte[] csvData = dataExportService.exportDataToCsv();

        // set response headers for content type and filename
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.attachment()
                .filename("data.csv")
                .build());

        return new ResponseEntity<>(csvData, headers, HttpStatus.OK);
    }

    @GetMapping("/export-excel")
    public ResponseEntity<byte[]> exportDataToExcel() throws IOException {
        byte[] excelData = dataExportService.exportDataToExcel();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDisposition(ContentDisposition.attachment()
                .filename("Fee_Parameter.xlsx").build());

        return new ResponseEntity<>(excelData, headers, HttpStatus.OK);
    }
}
