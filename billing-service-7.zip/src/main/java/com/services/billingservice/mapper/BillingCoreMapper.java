package com.services.billingservice.mapper;

import com.services.billingservice.dto.core.BillingCoreDTO;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.utils.ConvertBigDecimalUtil;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * TODO: Kita check dan pastikan data dari Entity itu sama dengan data DTO
 */
@Component
public class BillingCoreMapper {

    public BillingCoreDTO mapToDTO(BillingCore billingCore) {
        return BillingCoreDTO.builder()
                .createdAt(billingCore.getCreatedAt())
                .updatedAt(billingCore.getUpdatedAt())
                .approvalStatus(billingCore.getApprovalStatus().getStatus())
                .billingStatus(billingCore.getBillingStatus().getStatus())
                .customerCode(billingCore.getCustomerCode())
                .subCode(billingCore.getSubCode())
                .customerName(billingCore.getCustomerName())
                .month(billingCore.getMonth())
                .year(String.valueOf(billingCore.getYear()))
                .billingNumber(billingCore.getBillingNumber())
                .billingPeriod(billingCore.getBillingPeriod())
                .billingStatementDate(billingCore.getBillingStatementDate())
                .billingPaymentDueDate(billingCore.getBillingPaymentDueDate())
                .billingCategory(billingCore.getBillingCategory())
                .billingType(billingCore.getBillingType())
                .billingTemplate(billingCore.getBillingTemplate())
                .investmentManagementCode(billingCore.getInvestmentManagementCode())
                .investmentManagementName(billingCore.getInvestmentManagementName())
                .investmentManagementAddress1(billingCore.getInvestmentManagementAddress1())
                .investmentManagementAddress2(billingCore.getInvestmentManagementAddress2())
                .investmentManagementAddress3(billingCore.getInvestmentManagementAddress3())
                .investmentManagementAddress4(billingCore.getInvestmentManagementAddress4())
                .investmentManagementUniqueKey(billingCore.getInvestmentManagementUniqueKey())
                .investmentManagementEmail(billingCore.getInvestmentManagementEmail())
                .accountName(billingCore.getAccountName())
                .account(billingCore.getAccount())
                .accountCostCenterDebit(billingCore.getAccountCostCenterDebit())
                .currency(billingCore.getCurrency())
                .transactionHandlingValueFrequency(String.valueOf(billingCore.getTransactionHandlingValueFrequency()))
                .transactionHandlingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTransactionHandlingFee()))
                .transactionHandlingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTransactionHandlingAmountDue()))
                .safekeepingValueFrequency(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingValueFrequency()))
                .safekeepingFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingFee()))
                .safekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSafekeepingAmountDue()))
                .subTotal(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSubTotal()))
                .vatFee(billingCore.getVatFee().stripTrailingZeros().toPlainString())
                .vatAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getVatAmountDue()))
                .totalAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getTotalAmountDue()))
                .journalCreditTo(billingCore.getSafekeepingJournal())
                .kseiSafekeepingAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiSafekeepingAmountDue()))
                .kseiTransactionValueFrequency(String.valueOf(billingCore.getKseiTransactionValueFrequency()))
                .kseiTransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiTransactionFee()))
                .kseiTransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getKseiTransactionAmountDue()))
                .bis4TransactionValueFrequency(String.valueOf(billingCore.getBis4TransactionValueFrequency()))
                .bis4TransactionFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getBis4TransactionFee()))
                .bis4TransactionAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getBis4TransactionAmountDue()))
                .safekeepingFeeJournal(billingCore.getSafekeepingJournal())
                .transactionHandlingJournal(billingCore.getTransactionHandlingJournal())
                .administrationSetUpItem(String.valueOf(billingCore.getAdministrationSetUpItem()))
                .administrationSetUpFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getAdministrationSetUpFee()))
                .administrationSetUpAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getAdministrationSetUpAmountDue()))
                .signingRepresentationItem(String.valueOf(billingCore.getSigningRepresentationItem()))
                .signingRepresentationFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSigningRepresentationFee()))
                .signingRepresentationAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSigningRepresentationAmountDue()))
                .securityAgentItem(String.valueOf(billingCore.getSecurityAgentItem()))
                .securityAgentFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSecurityAgentFee()))
                .securityAgentAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getSecurityAgentAmountDue()))
                .transactionHandlingItem(String.valueOf(billingCore.getTransactionHandlingItem()))
                .safekeepingItem(String.valueOf(billingCore.getSafekeepingItem()))
                .otherItem(String.valueOf(billingCore.getOtherItem()))
                .otherFee(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getOtherFee()))
                .otherAmountDue(ConvertBigDecimalUtil.formattedBigDecimalToString(billingCore.getOtherAmountDue()))
                .id(billingCore.getId())
                .build();
    }

    public List<BillingCoreDTO> mapToDTOList(List<BillingCore> billingCoreList) {
        return billingCoreList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

}
