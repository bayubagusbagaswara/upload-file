package com.services.billingservice.model;

import com.services.billingservice.model.base.Approvable;
import lombok.*;
import lombok.experimental.SuperBuilder;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Model for Kurs Rate USD
 */
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "exchange_rate")
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class ExchangeRate extends Approvable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "date")
    private LocalDate date;

    @Column(name = "currency")
    private String currency;

    @Column(name = "value")
    private BigDecimal value;
}
