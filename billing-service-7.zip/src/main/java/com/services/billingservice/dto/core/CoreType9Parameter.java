package com.services.billingservice.dto.core;

import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.model.SkTransaction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreType9Parameter {

    private List<SkTransaction> skTransactionList;

    private BigDecimal customerSafekeepingFee;

    private BigDecimal transactionHandlingFee;

    private List<SfValRgMonthly> sfValRgMonthlies;

    private BigDecimal vatFee;
}
