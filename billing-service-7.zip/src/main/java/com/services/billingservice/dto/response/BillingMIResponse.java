package com.services.billingservice.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BillingMIResponse {


    String id;

    String code;

    String name;

    String email;

    String alamat1;

    String alamat2;

    String alamat3;

    String alamat4;
}
