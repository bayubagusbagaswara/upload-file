package com.services.billingservice.dto.core;

import com.services.billingservice.model.SfValCrowdFunding;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreType11Parameter {

    private List<SfValCrowdFunding> sfValCrowdFundingList;

    private BigDecimal customerMinimumFee;

    private BigDecimal customerSafekeepingFee;

    private BigDecimal transactionHandlingFee;

    private BigDecimal vatFee;

}
