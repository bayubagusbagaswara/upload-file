package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.persistence.Column;
import java.math.BigDecimal;

/**
 * kita samakan dengan data BillingRetail
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingRetailDTO extends BillingRetailBaseDTO {

    private Long id;
    private String safekeepingFR;
    private String safekeepingSR;
    private String safekeepingST;
    private String safekeepingORI;
    private String safekeepingSBR;
    private String safekeepingPBS;
    private String safekeepingCorporateBond;

    private String totalAmountDue;

    private String safekeepingValueFrequency;
    private String safekeepingFee;
    private String safekeepingAmountDue;

    private String transactionSettlementValueFrequency;
    private String transactionSettlementFee;
    private String transactionSettlementAmountDue;

    private String adHocReportValueFrequency;
    private String adHocReportFee;
    private String adHocReportAmountDue;

    private String thirdPartyValueFrequency;
    private String thirdPartyFee;
    private String thirdPartyAmountDue;

    private String vatFee;
    private String vatAmountDue;

    private String subTotalAmountDue;

    private String transactionHandlingValueFrequency;
    private String transactionHandlingFee;
    private String transactionHandlingAmountDue;

    private String transactionHandlingInternalValueFrequency;
    private String transactionHandlingInternalFee;
    private String transactionHandlingInternalAmountDue;

    private String transferValueFrequency;
    private String transferFee;
    private String transferAmountDue;

    private String account;
    private String accountName;
}
