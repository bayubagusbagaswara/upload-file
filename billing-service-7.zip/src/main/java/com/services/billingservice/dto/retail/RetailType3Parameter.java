package com.services.billingservice.dto.retail;

import com.services.billingservice.model.RetailTransaction;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailType3Parameter {


    private List<RetailTransaction> retailTransactionList;

    private BigDecimal safekeepingValueFrequency;

    private BigDecimal safekeepingAmountDue;

    private BigDecimal customerSafekeepingFee;

    private BigDecimal customerTransactionHandlingFee;

    private BigDecimal vatFee;

    private BigDecimal settlementMinimum;

    private BigDecimal transactionHandlingInternalUSD;
}
