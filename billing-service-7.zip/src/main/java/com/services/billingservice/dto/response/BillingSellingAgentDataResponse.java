package com.services.billingservice.dto.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

public class BillingSellingAgentDataResponse {
    private long id;

    private String billingSellingAgentCode;

    private String billingSellingAgentName;

    private String billingSellingAgentGl;

    private String billingSellingAgentGlname;

    private String billingSellingAgentAccount;

    private String billingSellingAgentAccountName;

    private String billingSellingAgentEmail;

    private String billingSellingAgentAlamat;

    private String billingSellingAgentDesc;
}
