package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.time.Instant;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BillingRetailListProcessDTO {
    private String month;
    private Integer year;
    private Instant createdAt;
}
