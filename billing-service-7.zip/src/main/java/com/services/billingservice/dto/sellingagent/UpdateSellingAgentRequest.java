package com.services.billingservice.dto.sellingagent;

import com.services.billingservice.dto.approval.InputIdentifierRequest;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateSellingAgentRequest extends InputIdentifierRequest {

    private Long id;

    private String code;

    private String name;

}
