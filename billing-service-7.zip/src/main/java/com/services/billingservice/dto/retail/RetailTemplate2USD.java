package com.services.billingservice.dto.retail;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailTemplate2USD {

    private BigDecimal safekeepingValueFrequency;
    private BigDecimal safekeepingFee;
    private BigDecimal safekeepingAmountDue;

    private Integer transactionSettlementValueFrequency;
    private BigDecimal transactionSettlementFee;
    private BigDecimal transactionSettlementAmountDue;

    private Integer adHocReportValueFrequency;
    private BigDecimal adHocReportFee;
    private BigDecimal adHocReportAmountDue;

    private Integer thirdPartyValueFrequency;
    private BigDecimal thirdPartyFee;
    private BigDecimal thirdPartyAmountDue;

    private BigDecimal subTotal;

    private BigDecimal vatFee;
    private BigDecimal vatAmountDue;

    private BigDecimal totalAmountDue;

}
