package com.services.billingservice.dto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * IIG - type 8
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreTemplate6 {

    private Integer administrationSetUpItem;
    private BigDecimal administrationSetUpFee;
    private BigDecimal administrationSetUpAmountDue;

    private Integer signingRepresentationItem;
    private BigDecimal signingRepresentationFee;
    private BigDecimal signingRepresentationAmountDue;

    private Integer securityAgentItem;
    private BigDecimal securityAgentFee;
    private BigDecimal securityAgentAmountDue;

    private Integer transactionHandlingItem;
    private BigDecimal transactionHandlingFee;
    private BigDecimal transactionHandlingAmountDue;

    private Integer safekeepingItem;
    private BigDecimal safekeepingFee;
    private BigDecimal safekeepingAmountDueUSD;

    private Integer otherItem;
    private BigDecimal otherFee;
    private BigDecimal otherAmountDue;

    private BigDecimal subTotal;

    private BigDecimal vatAmountDueUSD;

    private BigDecimal totalAmountDue;

}
