package com.services.billingservice.bean;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvDate;
import com.services.billingservice.utils.OpenCsv.CsvBean;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailMonthlyHoldingBean extends CsvBean {

    @CsvBindByName(column = "id")
//    @CsvBindByPosition(position = 0)
    private Long id;

    @CsvBindByName(column = "batch")
//    @CsvBindByPosition(position = 1)
    private Integer batch;

    @CsvDate(value = "yyyy-MM-dd")
    @CsvBindByName(column = "date")
//    @CsvBindByPosition(position = 2)
    private LocalDate date;

    @CsvBindByName(column = "year")
    private Integer year;

    @CsvBindByName(column = "month")
    private String month; // February

    @CsvBindByName(column = "aid")
    private String aid; // or portfolio code

    @CsvBindByName(column = "Security Name")
    private String securityName;

    @CsvBindByName(column = "Face Value")
    private BigDecimal faceValue;

    @CsvBindByName(column = "Market Price")
    private String marketPrice;

    @CsvBindByName(column = "Market Value")
    private BigDecimal marketValue; // is faceValue * marketPrice

    @CsvBindByName(column = "Estimation Safekeeping Fee")
    private BigDecimal estimationSafekeepingFee;
}
