package com.services.billingservice.bean;

import com.opencsv.bean.CsvBindByName;
import com.opencsv.bean.CsvDate;
import com.services.billingservice.utils.OpenCsv.CsvBean;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RetailCsaHoldingBean extends CsvBean {
    @CsvBindByName(column = "Id")
//    @CsvBindByPosition(position = 0)
    private Long id;

    //    @CsvBindByPosition(position = 1)
    @CsvBindByName(column = "Year")
    private Integer year;

    @CsvBindByName(column = "Month")
//    @CsvBindByPosition(position = 2)
    private String month; // February

    @CsvDate(value = "yyyy-MM-dd")
    @CsvBindByName(column = "Date")
    private LocalDate asOf;

    @CsvBindByName(column = "Aid")
    private String aid; // or portfolio code

    @CsvBindByName(column = "Selling Agent")
    private String sellingAgent;

    @CsvBindByName(column = "Security Group")
    private String securityGroup;

    @CsvBindByName(column = "Security Code")
    private String securityCode;

    @CsvBindByName(column = "Currency")
    private String currency;

    @CsvBindByName(column = "Name")
    private String name;

    @CsvBindByName(column = "Balance")
    private BigDecimal balance;

    @CsvBindByName(column = "Cif Number")
    private String cifNumber;

    @CsvBindByName(column = "Fee")
    private BigDecimal Fee;
}
