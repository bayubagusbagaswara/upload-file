package com.services.billingservice.repository;

import com.services.billingservice.model.RetailTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RetailTransactionRepository extends JpaRepository<RetailTransaction, Long> {

    // find all by selling agent & month & year & currency
    @Query(value = "SELECT * FROM rekap_data_transaksi " +
            "WHERE selling_agent = :sellingAgent " +
            "AND month = :monthName " +
            "AND year = :year " +
            "AND currency = :currency", nativeQuery = true)
    List<RetailTransaction> findAllBySellingAgentAndMonthAndYearAndCurrency(
            @Param("sellingAgent") String sellingAgent,
            @Param("monthName") String monthName,
            @Param("year") Integer year,
            @Param("currency") String currency
    );

    @Procedure(procedureName = "sp_rekap_data_transaksi")
    void execSPRekapDataTransaksi();

}
