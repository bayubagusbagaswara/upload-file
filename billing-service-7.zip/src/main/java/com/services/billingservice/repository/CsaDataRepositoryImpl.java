package com.services.billingservice.repository;

import com.services.billingservice.bean.RetailCsaHoldingBean;
import com.services.billingservice.model.RekapAccountBalance;
import com.services.billingservice.service.RekapAccountBalanceService;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.OpenCsv.OpenCsvBean;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@Slf4j
@RequiredArgsConstructor
public class CsaDataRepositoryImpl implements CsaDataRepository {
    @Value("${file.path.holding.data.csa}")
    private String folderPath;
    private static final String REKAP_ACCOUNT_BALANCE = "REKAP_ACCOUNT_BALANCE";
    private static final String CSV_EXT = ".csv";
    private static final String UNDERSCORE_SEPARATOR = "_";
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;
    @Autowired
    private RekapAccountBalanceService rekapAccountBalanceService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public void executeQuerySpRekapAccountBalance() {
        try {
            retailAccountBalanceRepository.execSPAccountBalance();

            final Map<String, String> monthMinus1 = convertDateUtil.getMonthMinus1();
            final String monthName = monthMinus1.get("monthName");
            final String monthValue = monthMinus1.get("monthValue");
            final int year = Integer.parseInt(monthMinus1.get("year"));
            if (rekapAccountBalanceService.existsRekapAccountBalance(year, monthName)) {
                final String fileName = REKAP_ACCOUNT_BALANCE + UNDERSCORE_SEPARATOR + year + monthValue + CSV_EXT;
                List<RekapAccountBalance> rekapAccountBalances = rekapAccountBalanceService.findByYearAndMonthOrderByIdAsc(year, monthName);
                OpenCsvBean<RekapAccountBalance, RetailCsaHoldingBean> openCsvBean = new OpenCsvBean<>();
                openCsvBean.writeCsvFromBean(folderPath, fileName, rekapAccountBalances, RetailCsaHoldingBean.class);
            }

            log.info("Stored procedure executed successfully");
        } catch (Exception e) {
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }

    @Override
    public void executeQuerySpRekapRekapDataTransaksi() {
        try {
            retailTransactionRepository.execSPRekapDataTransaksi();
            log.info("Stored procedure executed successfully");
        } catch (Exception e) {
            log.error("Error executing stored procedure: {}", e.getMessage());
        }
    }
}
