package com.services.billingservice.repository;

import com.services.billingservice.dto.connectionparameter.ConnectionParameterDTO;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.ConnectionParameter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BillingConnectionParameterRepository  extends JpaRepository<ConnectionParameter, String> {

    @Query(value = "SELECT * FROM rb_connection_parameter " +
            " Order by id asc", nativeQuery = true)
    List<ConnectionParameter> findAll();

}
