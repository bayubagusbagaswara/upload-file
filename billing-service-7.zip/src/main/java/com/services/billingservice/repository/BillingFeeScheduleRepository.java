package com.services.billingservice.repository;

import com.services.billingservice.model.BillingFeeSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;


@Repository
public interface BillingFeeScheduleRepository extends JpaRepository<BillingFeeSchedule, Long> {
    @Query(value = "SELECT * FROM billing_fee_schedule WHERE id = :id", nativeQuery = true)
    Optional<BillingFeeSchedule> findById(@Param("id") String id);

    @Query(value = "SELECT * FROM billing_fee_schedule", nativeQuery = true)
    List<BillingFeeSchedule> findAll();

    // checking with fee schedule
    // BigDecimal getFeeValueAndCheckingFeeSchedule(@Param("value") BigDecimal value);

    @Query(value = "select case when :amount <= 0 then 0 else fee_amount end as fee_amount " +
            "from billing_fee_schedule " +
            "where :amount >= fee_schedule_min " +
            "and :amount < fee_schedule_max", nativeQuery = true)
    double checkFeeScheduleAndGetFeeValue(@Param("amount") BigDecimal amount);
}
