package com.services.billingservice.service;

public interface CsaDataService {

    String executeQuerySP();

}
