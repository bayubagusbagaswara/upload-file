package com.services.billingservice.service.impl;

import com.services.billingservice.model.RekapAccountBalance;
import com.services.billingservice.repository.RekapAccountBalanceRepository;
import com.services.billingservice.service.RekapAccountBalanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RekapAccountBalanceServiceImpl implements RekapAccountBalanceService {
    @Autowired
    private RekapAccountBalanceRepository rekapAccountBalanceRepository;
    private static final String REKAP_ACCOUNT_BALANCE = "REKAP_ACCOUNT_BALANCE";

    @Override
    public Boolean existsRekapAccountBalance(final Integer year, final String monthName) {
        if (rekapAccountBalanceRepository.existsTableByName(REKAP_ACCOUNT_BALANCE).equals(0)) return false;
        if (!rekapAccountBalanceRepository.existsByYearAndMonth(year, monthName)) return false;
        return true;
    }

    @Override
    public List<RekapAccountBalance> findByYearAndMonthOrderByIdAsc (final Integer year, final String monthName) {
        return rekapAccountBalanceRepository.findByYearAndMonthOrderByIdAsc(year, monthName);
    }
}
