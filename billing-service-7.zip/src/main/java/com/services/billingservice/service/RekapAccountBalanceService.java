package com.services.billingservice.service;

import com.services.billingservice.model.RekapAccountBalance;
import org.springframework.stereotype.Service;

import java.util.List;

public interface RekapAccountBalanceService {
    Boolean existsRekapAccountBalance(final Integer year, final String monthName);

    List<RekapAccountBalance> findByYearAndMonthOrderByIdAsc (final Integer year, final String monthName);
}
