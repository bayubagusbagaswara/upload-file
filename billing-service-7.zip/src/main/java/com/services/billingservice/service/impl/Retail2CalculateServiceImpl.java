package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.retail.RetailTemplate2IDR;
import com.services.billingservice.dto.retail.RetailTemplate2USD;
import com.services.billingservice.dto.retail.RetailType2Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.Retail2QueryResultDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.model.RetailTransaction;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.repository.RetailTransactionRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.Currency.USD;
import static com.services.billingservice.enums.FeeParameter.*;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail2CalculateServiceImpl implements Retail2CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final BillingNumberService billingNumberService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start calculate Billing Retail type 2 with request '{}'", request);

        /* initialize data response */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(Instant.now());
        LocalDate dateOfMonthYear = convertDateUtil.getFirstDateOfMonthYear(contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());

        /* get data fee parameters */
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());
        BigDecimal adHocReportFee = feeParameterService.getValueByName(AD_HOC_REPORT.getValue());
        BigDecimal thirdPartyFee = feeParameterService.getValueByName(THIRD_PARTY.getValue());

        /* get all data customer Retail Type 2 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data retail account balance */
                List<Object[]> objects = retailAccountBalanceRepository.getRetailDataBySellingAgentAndCurrency(
                        customer.getSellingAgent(), customer.getCurrency(), dateOfMonthYear);

                Retail2QueryResultDTO retail2QueryResultDTO = mapToDTO(objects);
                BigDecimal safekeepingValueFrequency = retail2QueryResultDTO != null ? retail2QueryResultDTO.getLastBalance() : BigDecimal.ZERO;
                BigDecimal safekeepingAmountDue = retail2QueryResultDTO != null ? retail2QueryResultDTO.getSumFee() : BigDecimal.ZERO;

                /* get data retail transaction */
                List<RetailTransaction> retailTransactionList = retailTransactionRepository.findAllBySellingAgentAndMonthAndYearAndCurrency(
                        customer.getSellingAgent(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1(), customer.getCurrency());

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingRetail> existingBillingRetail = billingRetailRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingRetail.isPresent() || Boolean.TRUE.equals(!existingBillingRetail.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingRetail.ifPresent(this::deleteExistingBillingRetail);

                    /* create billing retail */
                    BillingRetail billingRetail = createBillingRetail(contextDate, customer, investmentManagementDTO);

                    /* create retail type 2 parameter */
                    RetailType2Parameter retailType2Parameter = new RetailType2Parameter(
                            retailTransactionList, safekeepingValueFrequency, customer.getCustomerSafekeepingFee(),
                            safekeepingAmountDue, customer.getCustomerTransactionHandling(),
                            adHocReportFee, thirdPartyFee, vatFee);

                    if (IDR.getValue().equalsIgnoreCase(customer.getCurrency())) {
                        /* calculation IDR */
                        RetailTemplate2IDR retailTemplate2IDR = calculationIDR(retailType2Parameter);

                        /* update billing core data to include calculated values */
                        updateBillingRetailForRetailTemplate2IDR(billingRetail, retailTemplate2IDR);
                    } else if (USD.getValue().equalsIgnoreCase(customer.getCurrency())) {
                        /* calculation USD */
                        RetailTemplate2USD retailTemplate2USD = calculationUSD(retailType2Parameter);

                        /* update billing core data to include calculated values */
                        updateBillingRetailForRetailTemplate2USD(billingRetail, retailTemplate2USD);
                    }

                    /* create a billing number then set it to the billing core */
                    String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                    billingRetail.setBillingNumber(number);

                    /* save to the database */
                    billingRetailRepository.save(billingRetail);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingRetailForRetailTemplate2USD(BillingRetail billingRetail, RetailTemplate2USD retailTemplate2USD) {
        billingRetail.setSafekeepingValueFrequency(retailTemplate2USD.getSafekeepingValueFrequency());
        billingRetail.setSafekeepingFee(retailTemplate2USD.getSafekeepingFee());
        billingRetail.setSafekeepingAmountDue(retailTemplate2USD.getSafekeepingAmountDue());

        billingRetail.setTransactionSettlementValueFrequency(retailTemplate2USD.getTransactionSettlementValueFrequency());
        billingRetail.setTransactionSettlementFee(retailTemplate2USD.getTransactionSettlementFee());
        billingRetail.setTransactionSettlementAmountDue(retailTemplate2USD.getTransactionSettlementAmountDue());

        billingRetail.setAdHocReportValueFrequency(retailTemplate2USD.getAdHocReportValueFrequency());
        billingRetail.setAdHocReportFee(retailTemplate2USD.getAdHocReportFee());
        billingRetail.setAdHocReportAmountDue(retailTemplate2USD.getAdHocReportAmountDue());

        billingRetail.setThirdPartyValueFrequency(retailTemplate2USD.getThirdPartyValueFrequency());
        billingRetail.setThirdPartyFee(retailTemplate2USD.getThirdPartyFee());
        billingRetail.setThirdPartyAmountDue(retailTemplate2USD.getThirdPartyAmountDue());

        billingRetail.setSubTotalAmountDue(retailTemplate2USD.getSubTotal());
        billingRetail.setVatFee(retailTemplate2USD.getVatFee());
        billingRetail.setVatAmountDue(retailTemplate2USD.getVatAmountDue());
        log.info("USD: {}", retailTemplate2USD.getVatAmountDue());

        billingRetail.setTotalAmountDue(retailTemplate2USD.getTotalAmountDue());
    }

    private void updateBillingRetailForRetailTemplate2IDR(BillingRetail billingRetail, RetailTemplate2IDR retailTemplate2IDR) {
        billingRetail.setSafekeepingValueFrequency(retailTemplate2IDR.getSafekeepingValueFrequency());
        billingRetail.setSafekeepingFee(retailTemplate2IDR.getSafekeepingFee());
        billingRetail.setSafekeepingAmountDue(retailTemplate2IDR.getSafekeepingAmountDue());

        billingRetail.setTransactionSettlementValueFrequency(retailTemplate2IDR.getTransactionSettlementValueFrequency());
        billingRetail.setTransactionSettlementFee(retailTemplate2IDR.getTransactionSettlementFee());
        billingRetail.setTransactionSettlementAmountDue(retailTemplate2IDR.getTransactionSettlementAmountDue());

        billingRetail.setAdHocReportValueFrequency(retailTemplate2IDR.getAdHocReportValueFrequency());
        billingRetail.setAdHocReportFee(retailTemplate2IDR.getAdHocReportFee());
        billingRetail.setAdHocReportAmountDue(retailTemplate2IDR.getAdHocReportAmountDue());

        billingRetail.setThirdPartyValueFrequency(retailTemplate2IDR.getThirdPartyValueFrequency());
        billingRetail.setThirdPartyFee(retailTemplate2IDR.getThirdPartyFee());
        billingRetail.setThirdPartyAmountDue(retailTemplate2IDR.getThirdPartyAmountDue());

        billingRetail.setSubTotalAmountDue(retailTemplate2IDR.getSubTotal());
        billingRetail.setVatFee(retailTemplate2IDR.getVatFee());
        billingRetail.setVatAmountDue(retailTemplate2IDR.getVatAmountDue());

        billingRetail.setTotalAmountDue(retailTemplate2IDR.getTotalAmountDue());
    }

    private RetailTemplate2IDR calculationIDR(RetailType2Parameter param) {
        Integer transactionSettlementValueFrequency = calculateTransactionSettlementValueFrequency(param.getRetailTransactionList());
        BigDecimal transactionSettlementAmountDue = calculateTransactionSettlementAmountDue(transactionSettlementValueFrequency, param.getCustomerTransactionHandlingFee());
        Integer adHocReportValueFrequency = 0;
        BigDecimal adHocReportAmountDue = BigDecimal.ZERO;
        Integer thirdPartyValueFrequency = calculateThirdPartyValueFrequency(transactionSettlementValueFrequency);
        BigDecimal thirdPartyAmountDue = calculateThirdPartyAmountDue(thirdPartyValueFrequency, param.getThirdPartyFee());
        BigDecimal subTotal = calculateSubTotal(param.getSafekeepingAmountDue(), transactionSettlementAmountDue, adHocReportAmountDue, thirdPartyAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(subTotal, param.getVatFee());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue);

        return RetailTemplate2IDR.builder()
                .safekeepingValueFrequency(param.getSafekeepingValueFrequency())
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(param.getSafekeepingAmountDue())
                .transactionSettlementValueFrequency(transactionSettlementValueFrequency)
                .transactionSettlementFee(param.getCustomerTransactionHandlingFee())
                .transactionSettlementAmountDue(transactionSettlementAmountDue)
                .adHocReportValueFrequency(adHocReportValueFrequency)
                .adHocReportFee(param.getAdHocReportFee())
                .adHocReportAmountDue(adHocReportAmountDue)
                .thirdPartyValueFrequency(thirdPartyValueFrequency)
                .thirdPartyFee(param.getThirdPartyFee())
                .thirdPartyAmountDue(thirdPartyAmountDue)
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private RetailTemplate2USD calculationUSD(RetailType2Parameter param) {
        Integer transactionSettlementValueFrequency = calculateTransactionSettlementValueFrequency(param.getRetailTransactionList());
        BigDecimal transactionSettlementAmountDue = calculateTransactionSettlementAmountDueUSD(transactionSettlementValueFrequency, param.getCustomerTransactionHandlingFee());
        Integer adHocReportValueFrequency = 0;
        BigDecimal adHocReportAmountDue = BigDecimal.ZERO;
        Integer thirdPartyValueFrequency = 0;
        BigDecimal thirdPartyAmountDue = calculateThirdPartyAmountDueUSD(thirdPartyValueFrequency, param.getThirdPartyFee());
        BigDecimal subTotal = calculateSubTotalUSD(param.getSafekeepingAmountDue(), transactionSettlementAmountDue, adHocReportAmountDue, thirdPartyAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDueUSD(subTotal, param.getVatFee());
        BigDecimal totalAmountDue = calculateTotalAmountDueUSD(subTotal, vatAmountDue);

        log.info("Calculation VAT Amount Due: {}", vatAmountDue);
        return RetailTemplate2USD.builder()
                .safekeepingValueFrequency(param.getSafekeepingValueFrequency())
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(param.getSafekeepingAmountDue())
                .transactionSettlementValueFrequency(transactionSettlementValueFrequency)
                .transactionSettlementFee(param.getCustomerTransactionHandlingFee())
                .transactionSettlementAmountDue(transactionSettlementAmountDue)
                .adHocReportValueFrequency(adHocReportValueFrequency)
                .adHocReportFee(param.getAdHocReportFee())
                .adHocReportAmountDue(adHocReportAmountDue)
                .thirdPartyValueFrequency(thirdPartyValueFrequency)
                .thirdPartyFee(param.getThirdPartyFee())
                .thirdPartyAmountDue(thirdPartyAmountDue)
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private static Integer calculateTransactionSettlementValueFrequency(List<RetailTransaction> retailTransactionList) {
        int totalTransactionSettlement = retailTransactionList.size();
        log.info("[Retail Type 2] Total transaction settlement: {}", totalTransactionSettlement);
        return totalTransactionSettlement;
    }

    private static BigDecimal calculateTransactionSettlementAmountDue(Integer transactionSettlementValueFrequency, BigDecimal transactionSettlementFee) {
        log.info("Settlement Fee : {}", transactionSettlementFee);
        BigDecimal transactionSettlementAmountDue = new BigDecimal(transactionSettlementValueFrequency)
                .multiply(transactionSettlementFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Transaction settlement amount due: {}", transactionSettlementAmountDue);
        return transactionSettlementAmountDue;
    }

    private static Integer calculateThirdPartyValueFrequency(Integer transactionSettlementValueFrequency) {
        log.info("[Retail Type 2] Third party value frequency: {}", transactionSettlementValueFrequency);
        return transactionSettlementValueFrequency;
    }

    private static BigDecimal calculateThirdPartyAmountDue(Integer thirdPartyValueFrequency, BigDecimal thirdPartyFee) {
        BigDecimal thirdPartyAmountDue = new BigDecimal(thirdPartyValueFrequency)
                .multiply(thirdPartyFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Third party amount due: {}", thirdPartyAmountDue);
        return thirdPartyAmountDue;
    }

    private static BigDecimal calculateSubTotal(BigDecimal safekeepingAmountDue, BigDecimal transactionSettlementAmountDue, BigDecimal adHocReportAmountDue, BigDecimal thirdPartyAmountDue) {
        BigDecimal subTotal = safekeepingAmountDue
                .add(transactionSettlementAmountDue)
                .add(adHocReportAmountDue)
                .add(thirdPartyAmountDue)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Sub total: {}", subTotal);
        return subTotal;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] VAT amount due: {}", subTotal);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Total amount due: {}", totalAmountDue);
        return totalAmountDue;
    }

    private static BigDecimal calculateTransactionSettlementAmountDueUSD(Integer transactionSettlementValueFrequency, BigDecimal transactionSettlementFeeUSD) {
        BigDecimal settlementAmountDueUSD = new BigDecimal(transactionSettlementValueFrequency)
                .multiply(transactionSettlementFeeUSD)
                .divide(new BigDecimal(100), 0, BigDecimal.ROUND_HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);

        log.info("[Retail Type 2] Settlement amount due: {}", settlementAmountDueUSD);
        return settlementAmountDueUSD;
    }

    private static BigDecimal calculateThirdPartyAmountDueUSD(Integer thirdPartyValueFrequency, BigDecimal thirdPartyFee) {
        BigDecimal thirdPartyAmountDueUSD = new BigDecimal(thirdPartyValueFrequency)
                .multiply(thirdPartyFee)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Third Party amount due USD: {}", thirdPartyAmountDueUSD);
        return thirdPartyAmountDueUSD;
    }

    private static BigDecimal calculateSubTotalUSD(BigDecimal safekeepingAmountDue, BigDecimal transactionSettlementAmountDue, BigDecimal adHocReportAmountDue, BigDecimal thirdPartyAmountDue) {
        BigDecimal subTotalUSD = safekeepingAmountDue
                .add(transactionSettlementAmountDue)
                .add(adHocReportAmountDue)
                .add(thirdPartyAmountDue)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Sub total USD: {}", subTotalUSD);
        return subTotalUSD;
    }


    private static BigDecimal calculateVATAmountDueUSD(BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDueUSD = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] VAT amount due USD: {}", vatAmountDueUSD);
        return vatAmountDueUSD;
    }

    private static BigDecimal calculateTotalAmountDueUSD(BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDueUSD = subTotal.add(vatAmountDue)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Total amount due USD: {}", totalAmountDueUSD);
        return totalAmountDueUSD;
    }

    private static List<Retail2QueryResultDTO> mapToDTOList(List<Object[]> result) {
        return result.stream()
                .map(data -> {
                    BigDecimal valueLastBalance = data[3] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[3]);
                    BigDecimal valueSumFee = data[4] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[4]);
                    return Retail2QueryResultDTO.builder()
                                    .year((Integer) data[0])
                                    .month((String) data[1])
                                    .sellingAgent((String) data[2])
                                    .lastBalance(valueLastBalance)
                                    .sumFee(valueSumFee)
                                    .build();
                })
                .collect(Collectors.toList());
    }

    private static Retail2QueryResultDTO mapToDTO(List<Object[]> result) {
        Double lastBalance = (Double) result.get(0)[3];
        Double sumFee = (Double) result.get(0)[4];

        BigDecimal valueLastBalance = lastBalance == null ? BigDecimal.ZERO : BigDecimal.valueOf(lastBalance);
        BigDecimal valueSumFee = sumFee == null ? BigDecimal.ZERO : BigDecimal.valueOf(sumFee);

        return result.isEmpty() ? null : Retail2QueryResultDTO.builder()
                .year((Integer) result.get(0)[0])
                .month((String) result.get(0)[1])
                .sellingAgent((String) result.get(0)[2])
                .lastBalance(valueLastBalance)
                .sumFee(valueSumFee.setScale(2, RoundingMode.HALF_UP))
                .build();
    }

    private void deleteExistingBillingRetail(BillingRetail existBillingRetail) {
        String billingNumber = existBillingRetail.getBillingNumber();
        billingRetailRepository.delete(existBillingRetail);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

    private BillingRetail createBillingRetail(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO) {  // set default field
        return BillingRetail.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .safekeepingFee(customer.getCustomerSafekeepingFee())
                .build();
    }

}
