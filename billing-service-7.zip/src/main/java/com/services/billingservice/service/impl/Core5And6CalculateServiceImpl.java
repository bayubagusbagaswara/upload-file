package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.core.CoreTemplate1;
import com.services.billingservice.dto.core.CoreTemplate4;
import com.services.billingservice.dto.core.CoreType5And6Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.*;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValRgDaily;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_1;
import static com.services.billingservice.enums.BillingTemplate.CORE_TEMPLATE_4;
import static com.services.billingservice.enums.FeeParameter.BI_SSSS;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Core5And6CalculateServiceImpl implements Core5And6CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final SkTranService skTransactionService;
    private final SfValRgDailyService sfValRgDailyService;
    private final KseiSafeService kseiSafekeepingFeeService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start core billing calculation type 5 and 6 with a data request: {}", request);

        /* initialize response data */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get data fee parameters */
        BigDecimal kseiTransactionFee = feeParameterService.getValueByName(KSEI.getValue());
        BigDecimal bis4TransactionFee = feeParameterService.getValueByName(BI_SSSS.getValue());
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());

        /* get all customer Core Type 3 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data sk transaction */
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get data RG Daily */
                List<SfValRgDaily> sfValRgDailyList = sfValRgDailyService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get data KSEI safekeeping fee */
                BigDecimal kseiSafekeepingFeeAmount = kseiSafekeepingFeeService.calculateAmountFeeByKseiSafeCodeAndMonthAndYear(customer.getKseiSafeCode(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingCore> existingBillingCore = billingCoreRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingCore.isPresent() || Boolean.TRUE.equals(!existingBillingCore.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingCore.ifPresent(this::deleteExistingBillingCore);

                    /* create parameter for type 5 and 6 */
                    CoreType5And6Parameter coreType5And6Parameter = new CoreType5And6Parameter(
                            customer.getCustomerSafekeepingFee(), kseiSafekeepingFeeAmount, kseiTransactionFee, bis4TransactionFee, sfValRgDailyList, skTransactionList, vatFee);

                    /* create billing core */
                    BillingCore billingCore = createBillingCore(contextDate, customer, investmentManagementDTO);

                    /* check template for billing 5 and 6 with npwp or without npwp */
                    if (CORE_TEMPLATE_1.getValue().equalsIgnoreCase(customer.getBillingTemplate())) {
                        /* calculate billing without NPWP */
                        CoreTemplate1 coreTemplate1 = calculateWithoutNPWP(coreType5And6Parameter);

                        /* update billing core data to include calculated values */
                        updateBillingCoreForTemplate1(billingCore, coreTemplate1);
                    } else if (CORE_TEMPLATE_4.getValue().equalsIgnoreCase(customer.getBillingTemplate())) {
                        /* calculate billing with NPWP */
                        CoreTemplate4 coreTemplate4 = calculateWithNPWP(coreType5And6Parameter);

                        /* update billing core data to include calculated values */
                        updateBillingCoreForTemplate4(billingCore, coreTemplate4);
                    }

                    /* create a billing number then set it to the billing core */
                    String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                    billingCore.setBillingNumber(number);

                    /* save to the database */
                    billingCoreRepository.save(billingCore);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingCoreForTemplate4(BillingCore billingCore, CoreTemplate4 coreTemplate4) {
        billingCore.setSafekeepingValueFrequency(coreTemplate4.getSafekeepingValueFrequency());
        billingCore.setSafekeepingFee(coreTemplate4.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate4.getSafekeepingAmountDue());
        billingCore.setBis4TransactionValueFrequency(coreTemplate4.getBis4TransactionValueFrequency());
        billingCore.setBis4TransactionFee(coreTemplate4.getBis4TransactionFee());
        billingCore.setBis4TransactionAmountDue(coreTemplate4.getBis4TransactionAmountDue());
        billingCore.setSubTotal(coreTemplate4.getSubTotal());
        billingCore.setVatFee(coreTemplate4.getVatFee());
        billingCore.setVatAmountDue(coreTemplate4.getVatAmountDue());
        billingCore.setKseiTransactionValueFrequency(coreTemplate4.getKseiTransactionValueFrequency());
        billingCore.setKseiTransactionFee(coreTemplate4.getKseiTransactionFee());
        billingCore.setKseiTransactionAmountDue(coreTemplate4.getKseiTransactionAmountDue());
        billingCore.setKseiSafekeepingAmountDue(coreTemplate4.getKseiSafekeepingAmountDue());
        billingCore.setTotalAmountDue(coreTemplate4.getTotalAmountDue());
    }

    private void updateBillingCoreForTemplate1(BillingCore billingCore, CoreTemplate1 coreTemplate1) {
        billingCore.setSafekeepingValueFrequency(coreTemplate1.getSafekeepingValueFrequency());
        billingCore.setSafekeepingFee(coreTemplate1.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate1.getSafekeepingAmountDue());
        billingCore.setKseiTransactionValueFrequency(coreTemplate1.getKseiTransactionValueFrequency());
        billingCore.setKseiTransactionFee(coreTemplate1.getKseiTransactionFee());
        billingCore.setKseiTransactionAmountDue(coreTemplate1.getKseiTransactionAmountDue());
        billingCore.setBis4TransactionValueFrequency(coreTemplate1.getBis4TransactionValueFrequency());
        billingCore.setBis4TransactionFee(coreTemplate1.getBis4TransactionFee());
        billingCore.setBis4TransactionAmountDue(coreTemplate1.getBis4TransactionAmountDue());
        billingCore.setKseiSafekeepingAmountDue(coreTemplate1.getKseiSafekeepingAmountDue());
        billingCore.setTotalAmountDue(coreTemplate1.getTotalAmountDue());
    }

    private BillingCore createBillingCore(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO) {
        return BillingCore.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .build();
    }

    private static BigDecimal calculateSafekeepingValueFrequency(List<SfValRgDaily> sfValRgDailyList) {
        List<SfValRgDaily> latestEntries = sfValRgDailyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgDailyList.stream()
                        .map(SfValRgDaily::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());
        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgDaily::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("Safekeeping value frequency: {}", safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(List<SfValRgDaily> sfValRgDailyList) {
        BigDecimal safekeepingAmountDue = sfValRgDailyList.stream()
                .map(SfValRgDaily::getEstimationSafekeepingFee)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("Safekeeping amount due: {}", safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueWithoutNPWP(BigDecimal safekeepingAmountDue, BigDecimal kseiAmountFee) {
        BigDecimal totalAmountDue = safekeepingAmountDue.add(kseiAmountFee);
        log.info("Total amount due without NPWP: {}", totalAmountDue);
        return totalAmountDue;
    }

    private CoreTemplate1 calculateWithoutNPWP(CoreType5And6Parameter param) {
        int[] filteredTransactionsType = skTransactionService.filterTransactionsType(param.getSkTransactionList());
        int transactionCBESTTotal = filteredTransactionsType[0];
        int transactionBISSSSTotal = filteredTransactionsType[1];

        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(param.getSfValRgDailyList());
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(param.getSfValRgDailyList());
        BigDecimal kseiTransactionAmountDue = calculateKseiTransactionAmountDue(transactionCBESTTotal, param.getKseiTransactionFee());
        BigDecimal bis4TransactionAmountDue = calculateBis4TransactionAmountDue(transactionBISSSSTotal, param.getBis4TransactionFee());
        BigDecimal totalAmountDue = calculateTotalAmountDueWithoutNPWP(safekeepingAmountDue, param.getKseiSafekeepingFeeAmount());

        return CoreTemplate1.builder()
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .kseiTransactionValueFrequency(transactionCBESTTotal)
                .kseiTransactionFee(param.getKseiTransactionFee())
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .bis4TransactionValueFrequency(transactionBISSSSTotal)
                .bis4TransactionFee(param.getBis4TransactionFee())
                .bis4TransactionAmountDue(bis4TransactionAmountDue)
                .kseiSafekeepingAmountDue(param.getKseiSafekeepingFeeAmount())
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private static BigDecimal calculateKseiTransactionAmountDue(Integer transactionCBESTTotal, BigDecimal kseiTransactionFee) {
        BigDecimal kseiTransactionAmountDue = new BigDecimal(transactionCBESTTotal)
                .multiply(kseiTransactionFee).setScale(0, RoundingMode.HALF_UP);
        log.info("KSEI transaction amount due: {}", kseiTransactionAmountDue);
        return kseiTransactionAmountDue;
    }

    private static BigDecimal calculateBis4TransactionAmountDue(int transactionBISSSSTotal, BigDecimal bis4TransactionFee) {
        BigDecimal bis4TransactionAmountDue = new BigDecimal(transactionBISSSSTotal)
                .multiply(bis4TransactionFee).setScale(0, RoundingMode.HALF_UP);
        log.info("BI-SSSS transaction amount due: {}", bis4TransactionAmountDue);
        return bis4TransactionAmountDue;
    }

    private static BigDecimal calculateSubTotalAmountDue(BigDecimal safekeepingAmountDue, BigDecimal bis4TransactionAmountDue) {
        BigDecimal subTotalAmountDue = safekeepingAmountDue.add(bis4TransactionAmountDue);
        log.info("Sub total amount due: {}", subTotalAmountDue);
        return subTotalAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal vatFee, BigDecimal subTotalAmountDue) {
        BigDecimal vatAmountDue = subTotalAmountDue
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("VAT amount due: {}", vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDueWithNPWP(BigDecimal subTotalAmountDue, BigDecimal vatAmountDue, BigDecimal kseiTransactionAmountDue, BigDecimal kseiAmountFee) {
        BigDecimal totalAmountDue = subTotalAmountDue
                .add(vatAmountDue)
                .add(kseiTransactionAmountDue)
                .add(kseiAmountFee);
        log.info("Total amount due with NPWP: {}", totalAmountDue);
        return totalAmountDue;
    }

    private CoreTemplate4 calculateWithNPWP(CoreType5And6Parameter param) {
        int[] filteredTransactionsType = skTransactionService.filterTransactionsType(param.getSkTransactionList());
        int transactionCBESTTotal = filteredTransactionsType[0];
        int transactionBISSSSTotal = filteredTransactionsType[1];

        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(param.getSfValRgDailyList());
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(param.getSfValRgDailyList());
        BigDecimal kseiTransactionAmountDue = calculateKseiTransactionAmountDue(transactionCBESTTotal, param.getKseiTransactionFee());
        BigDecimal bis4TransactionAmountDue = calculateBis4TransactionAmountDue(transactionBISSSSTotal, param.getBis4TransactionFee());
        BigDecimal subTotalAmountDue = calculateSubTotalAmountDue(safekeepingAmountDue, bis4TransactionAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(param.getVatFee(), subTotalAmountDue);
        BigDecimal totalAmountDue = calculateTotalAmountDueWithNPWP(subTotalAmountDue, vatAmountDue, kseiTransactionAmountDue, param.getKseiSafekeepingFeeAmount());

        return CoreTemplate4.builder()
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .bis4TransactionValueFrequency(transactionBISSSSTotal)
                .bis4TransactionFee(param.getBis4TransactionFee())
                .bis4TransactionAmountDue(bis4TransactionAmountDue)
                .subTotal(subTotalAmountDue)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .kseiTransactionValueFrequency(transactionCBESTTotal)
                .kseiTransactionFee(param.getKseiTransactionFee())
                .kseiTransactionAmountDue(kseiTransactionAmountDue)
                .kseiSafekeepingAmountDue(param.getKseiSafekeepingFeeAmount())
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private void deleteExistingBillingCore(BillingCore existBillingCore) {
        String billingNumber = existBillingCore.getBillingNumber();
        billingCoreRepository.delete(existBillingCore);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

}
