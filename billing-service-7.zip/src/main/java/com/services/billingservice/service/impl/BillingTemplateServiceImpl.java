package com.services.billingservice.service.impl;

import com.services.billingservice.dto.BillingTemplateDTO;
import com.services.billingservice.dto.request.BillingTemplateRequest;
import com.services.billingservice.exception.DataNotFoundException;
import com.services.billingservice.model.BillingTemplate;
import com.services.billingservice.repository.BillingTemplateRepository;
import com.services.billingservice.service.BillingTemplateService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class BillingTemplateServiceImpl implements BillingTemplateService {

    private final BillingTemplateRepository billingTemplateRepository;

    @Override
    public BillingTemplateDTO create(BillingTemplateRequest request) {
        BillingTemplate billingTemplate = BillingTemplate.builder()
                .templateName(request.getTemplateName())
                .category(request.getTemplateCategory())
                .type(request.getTemplateType())
                .desc(request.getDesc())
                .build();
        BillingTemplate dataSaved = billingTemplateRepository.save(billingTemplate);
        return mapToDTO(dataSaved);
    }

    @Override
    public BillingTemplateDTO getById(String id) {
        BillingTemplate billingTemplate = billingTemplateRepository.findById(Long.valueOf(id))
                .orElseThrow(()-> new DataNotFoundException("Billing Template not found with id: " + id));
        return mapToDTO(billingTemplate);
    }

    @Override
    public List<BillingTemplateDTO> getAll() {
        List<BillingTemplate>billingTemplates = billingTemplateRepository.findAll();
        return mapToDTOList(billingTemplates);
    }

    @Override
    public List<String> getAllSubCode() {
        return billingTemplateRepository.findAllSubCode();
    }

    @Override
    public BillingTemplateDTO updateById(String id, BillingTemplateRequest request) {
       BillingTemplate billingTemplate = billingTemplateRepository.findById(Long.valueOf(id))
               .orElseThrow(() -> new DataNotFoundException("Billing Template not found with id: " + id));

       if (!request.getTemplateName().isEmpty()) {
           billingTemplate.setTemplateName(request.getTemplateName());
       }

       if (!request.getTemplateType().isEmpty()) {
           billingTemplate.setType(request.getTemplateType());
       }

       if (!request.getTemplateCategory().isEmpty()) {
           billingTemplate.setCategory(request.getTemplateCategory());
       }

       if (!request.getDesc().isEmpty()) {
           billingTemplate.setDesc(request.getDesc());
       }

       BillingTemplate dataSaved = billingTemplateRepository.save(billingTemplate);
       return mapToDTO(dataSaved);
    }

    @Override
    public List<BillingTemplateDTO> getByType(String type) {
        List<BillingTemplate> billingTemplateList = billingTemplateRepository.findAllByType(type);
        return mapToDTOList(billingTemplateList);
    }

    @Override
    public List<BillingTemplateDTO> getByCategoryAndTypeAndSubCode(String category, String type, String subCode, String currency) {
        List<BillingTemplate> billingTemplateList = billingTemplateRepository.findAllByCategoryAndTypeAndSubCode(category, type, subCode, currency);
        return mapToDTOList(billingTemplateList);
    }

    @Override
    public String delete(String id) {
        BillingTemplate billingTemplate = billingTemplateRepository.findById(Long.valueOf(id))
                .orElseThrow(() -> new DataNotFoundException("Billing Template not found with id: " + id));
        billingTemplateRepository.delete(billingTemplate);
        return "Successfully delete Billing Template with id: " + id;
    }

    @Override
    public boolean isExistsByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(String category, String type, String currency, String subCode, String templateName) {
        return billingTemplateRepository.existsByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(category, type, currency, subCode, templateName);
    }

    @Override
    public BillingTemplateDTO getByCategoryAndTypeAndCurrencyAndSubCodeAndTemplateName(
            String category, String type, String currency, String subCode, String templateName) {
        BillingTemplate billingTemplate = billingTemplateRepository.findByCategoryAndTypAndCurrencyAndSubCodeAndTemplateName(category, type, currency, subCode, templateName)
                .orElseThrow(() -> new DataNotFoundException("Billing Template not found with category: " + category + ", type: " + type + ", currency: " + currency + ", sub code: " + subCode + ", and template name: " + templateName));
        return mapToDTO(billingTemplate);
    }

    private BillingTemplateDTO mapToDTO(BillingTemplate billingTemplate) {
        return BillingTemplateDTO.builder()
                .id(String.valueOf(billingTemplate.getId()))
                .templateName(billingTemplate.getTemplateName())
                .templateType(billingTemplate.getType())
                .templateCategory(billingTemplate.getCategory())
                .currency(billingTemplate.getCurrency())
                .subCode(billingTemplate.getSubCode())
                .desc(billingTemplate.getDesc())
                .subCode(billingTemplate.getSubCode())
                .build();
    }

    private List<BillingTemplateDTO> mapToDTOList(List<BillingTemplate> billingTemplateList) {
        return billingTemplateList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

}
