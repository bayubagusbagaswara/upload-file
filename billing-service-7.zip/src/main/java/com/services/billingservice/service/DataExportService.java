package com.services.billingservice.service;

import com.opencsv.CSVWriter;
import com.services.billingservice.dto.BillingFeeParamDTO;
import com.services.billingservice.dto.feeparameter.FeeParameterDTO;
import com.services.billingservice.mapper.FeeParameterMapper;
import com.services.billingservice.model.BillingFeeParam;
import com.services.billingservice.repository.BillingFeeParamRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataExportService {

    private final BillingFeeParamRepository feeParameterRepository;
    private final FeeParameterMapper feeParameterMapper;

    public byte[] exportDataToCsv() throws IOException {
        // Fetch data from the database
        List<BillingFeeParam> billingFeeParamList = feeParameterRepository.findAll(); // Modify based on your query criteria

        // Generate CSV content
        String csvContent = generateCsvContent(billingFeeParamList);

        // Convert CSV content to byte array for response
        return csvContent.getBytes();
    }

    private String generateCsvContent(List<BillingFeeParam> dataList) {
        StringWriter csvWriter = new StringWriter();
        try (CSVWriter writer = new CSVWriter(csvWriter)) {

            // Write header row (assuming field names match your entity properties)
            String[] headerArray = new String[]{"Field1", "Field2", "..."}; // Replace with actual field names
            writer.writeNext(headerArray);

            // Write data rows for each entity
            for (BillingFeeParam entity : dataList) {
                String[] dataArray = new String[]{
                        String.valueOf(entity.getFeeCode()), String.valueOf(entity.getFeeName()), "..."}; // ...
                writer.writeNext(dataArray);
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Handle potential exceptions during CSV writing
        }

        return csvWriter.toString();
    }

    private void writeCsvToFile(String fileName, String csvContent) throws IOException {
        try (Writer writer = new FileWriter(fileName)) {
            writer.write(csvContent);
        }
    }

    public byte[] exportDataToExcel() throws IOException {
        // Fetch data from the database
        List<BillingFeeParam> dataList = feeParameterRepository.findAll(); // Modify based on your query criteria

        List<FeeParameterDTO> feeParameterDTOList = feeParameterMapper.mapToDTOList(dataList);

        // Create a new Excel workbook
        XSSFWorkbook workbook = new XSSFWorkbook();

        // Create a new worksheet
        Sheet sheet = workbook.createSheet("Data Export");

        // Build the Excel content (rows and cells)
        populateExcelSheet(sheet, feeParameterDTOList);

        // Convert workbook to a byte array for response
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        return outputStream.toByteArray();
    }

    private void populateExcelSheet(Sheet sheet, List<FeeParameterDTO> dataList) {
        // Write header row
        int rowNum = 0;
        Row headerRow = sheet.createRow(rowNum++);
        headerRow.createCell(0).setCellValue("Fee Code");
        headerRow.createCell(1).setCellValue("Fee Name");
        headerRow.createCell(2).setCellValue("Fee Value");
        headerRow.createCell(3).setCellValue("Description"); // ... add other header cells

        // Write data rows for each entity
        for (FeeParameterDTO entity : dataList) {
            Row dataRow = sheet.createRow(rowNum++);
            dataRow.createCell(0).setCellValue(String.valueOf(entity.getFeeCode()));
            dataRow.createCell(1).setCellValue(String.valueOf(entity.getFeeName()));
            dataRow.createCell(2).setCellValue(String.valueOf(entity.getFeeValue()));
            dataRow.createCell(3).setCellValue(String.valueOf(entity.getFeeDescription()));
        }
    }

}
