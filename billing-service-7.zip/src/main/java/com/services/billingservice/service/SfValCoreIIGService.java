package com.services.billingservice.service;

import com.services.billingservice.dto.request.CreateSfValCoreIIGRequest;
import com.services.billingservice.model.SfValCoreIIG;

import java.util.List;

public interface SfValCoreIIGService {

    String create(CreateSfValCoreIIGRequest request);

    List<SfValCoreIIG> getAll();

    List<SfValCoreIIG> getAllByCustomerCode(String customerCode);

    // parameter date harus November 2023
    List<SfValCoreIIG> getAllByAidAndMonthAndYear(String aid, String monthName, Integer year);

    String deleteAll();
}
