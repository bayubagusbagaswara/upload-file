package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.retail.RetailTemplate4IDR;
import com.services.billingservice.dto.retail.RetailType4Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.RetailCalculateRequest;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.billingservice.enums.FeeParameter.FEE_TRANSFER;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail4CalculateServiceImpl implements Retail4CalculateService {

    private final BillingRetailRepository billingRetailRepository;
    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final BillingNumberService billingNumberService;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start calculate Billing Retail type 3 with request '{}'", request);

        /* initialize data response */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(Instant.now());

        /* get data parameters*/
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());
        BigDecimal transferFee = feeParameterService.getValueByName(FEE_TRANSFER.getValue());

        /* get all data customer Retail Type 4 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingRetail> existingBillingRetail = billingRetailRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingRetail.isPresent() || Boolean.TRUE.equals(!existingBillingRetail.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingRetail.ifPresent(this::deleteExistingBillingRetail);

                    /* create billing retail */
                    BillingRetail billingRetail = createBillingRetail(contextDate, customer, investmentManagementDTO);

                    /* create retail type 4 parameter */
                    RetailType4Parameter retailType4Parameter = new RetailType4Parameter(
                            customer.getCustomerSafekeepingFee(), vatFee, transferFee);

                    /* calculation billing */
                    RetailTemplate4IDR retailTemplate4IDR = calculationIDR(retailType4Parameter);

                    /* update billing core data to include calculated values */
                    updateBillingRetailForRetailTemplate4IDR(billingRetail, retailTemplate4IDR);

                    /* create a billing number then set it to the billing core */
                    String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                    billingRetail.setBillingNumber(number);

                    /* save to the database */
                    billingRetailRepository.save(billingRetail);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingRetailForRetailTemplate4IDR(BillingRetail billingRetail, RetailTemplate4IDR retailTemplate4IDR) {
        billingRetail.setSafekeepingValueFrequency(retailTemplate4IDR.getSafekeepingValueFrequency());
        billingRetail.setSafekeepingFee(retailTemplate4IDR.getSafekeepingFee());
        billingRetail.setSafekeepingAmountDue(retailTemplate4IDR.getSafekeepingAmountDue());

        billingRetail.setVatFee(retailTemplate4IDR.getVatFee());
        billingRetail.setVatAmountDue(retailTemplate4IDR.getVatAmountDue());
        billingRetail.setSubTotalAmountDue(retailTemplate4IDR.getSubTotal());

        billingRetail.setTransferValueFrequency(retailTemplate4IDR.getTransferValueFrequency());
        billingRetail.setTransferFee(retailTemplate4IDR.getTransferFee());
        billingRetail.setTransferAmountDue(retailTemplate4IDR.getTransferAmountDue());

        billingRetail.setTotalAmountDue(retailTemplate4IDR.getTotalAmountDue());
    }

    private void deleteExistingBillingRetail(BillingRetail existBillingRetail) {
        String billingNumber = existBillingRetail.getBillingNumber();
        billingRetailRepository.delete(existBillingRetail);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

    private BillingRetail createBillingRetail(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO) {  // set default field
        return BillingRetail.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .safekeepingFee(customer.getCustomerSafekeepingFee())
                .build();
    }

    private RetailTemplate4IDR calculationIDR(RetailType4Parameter param) {
        BigDecimal safekeepingValueFrequency = BigDecimal.ZERO;
        BigDecimal safekeepingAmountDue = BigDecimal.ZERO;
        BigDecimal vatAmountDue = BigDecimal.ZERO;
        BigDecimal subTotal = safekeepingAmountDue.add(vatAmountDue);
        Integer transferValueFrequency = 0;
        BigDecimal transferAmountDue = BigDecimal.ZERO;
        BigDecimal totalAmountDue = BigDecimal.ZERO;

        return RetailTemplate4IDR.builder()
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .subTotal(subTotal)
                .transferValueFrequency(transferValueFrequency)
                .transferFee(param.getTransferFee())
                .transferAmountDue(transferAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

}
