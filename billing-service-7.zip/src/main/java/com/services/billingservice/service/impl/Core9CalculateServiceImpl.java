package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.core.CoreCalculateRequest;
import com.services.billingservice.dto.core.CoreTemplate3;
import com.services.billingservice.dto.core.CoreType9Parameter;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.model.BillingCore;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.SfValRgMonthly;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingCoreRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.FeeParameter.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class Core9CalculateServiceImpl implements Core9CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final SkTranService skTransactionService;
    private final SfValRgMonthlyService sfValRgMonthlyService;
    private final BillingNumberService billingNumberService;
    private final BillingCoreRepository billingCoreRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(CoreCalculateRequest request) {
        log.info("Start core billing calculation type 9 with a data request: {}", request);

        /* initialize response data */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        Instant dateNow = Instant.now();
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get data parameters */
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());

        /* get all customer Core Type 9 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data sk transaction */
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get data rg monthly */
                List<SfValRgMonthly> sfValRgMonthlyList = sfValRgMonthlyService.getAllByAidAndMonthAndYear(customerCode, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingCore> existingBillingCore = billingCoreRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingCore.isPresent() || Boolean.TRUE.equals(!existingBillingCore.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingCore.ifPresent(this::deleteExistingBillingCore);

                    /* create billing core */
                    BillingCore billingCore = buildBillingCore(contextDate, customer, investmentManagementDTO);

                    /* create parameter core type 9 */
                    CoreType9Parameter coreType9Parameter = new CoreType9Parameter(
                            skTransactionList, customer.getCustomerSafekeepingFee(), customer.getCustomerTransactionHandling(),
                            sfValRgMonthlyList, vatFee);

                    /* calculation billing */
                    CoreTemplate3 coreTemplate3 = calculationResult(coreType9Parameter);

                    /* update billing core data to include calculated values */
                    updateBillingCoreForCoreTemplate3(billingCore, coreTemplate3);

                    /* create a billing number then set it to the billing core */
                    String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                    billingCore.setBillingNumber(number);

                    /* save to the database */
                    billingCoreRepository.save(billingCore);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private static Integer calculateTransactionHandlingValueFrequency(List<SkTransaction> skTransactionList) {
        int totalTransactionHandling = skTransactionList.size();
        log.info("[Core Type 9] Total transaction handling: {}", totalTransactionHandling);
        return totalTransactionHandling;
    }

    private static BigDecimal calculateTransactionHandlingAmountDue(Integer transactionHandlingValueFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = transactionHandlingFee.multiply(new BigDecimal(transactionHandlingValueFrequency).setScale(0, RoundingMode.HALF_UP));
        log.info("[Core Type 9] Transaction handling amount due: {}", transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private static BigDecimal calculateSafekeepingValueFrequency(List<SfValRgMonthly> sfValRgMonthlyList) {
        List<SfValRgMonthly> latestEntries = sfValRgMonthlyList.stream()
                .filter(entry -> entry.getDate().equals(sfValRgMonthlyList.stream()
                        .map(SfValRgMonthly::getDate)
                        .max(Comparator.naturalOrder())
                        .orElse(null)))
                .collect(Collectors.toList());

        BigDecimal safekeepingValueFrequency = latestEntries.stream()
                .map(SfValRgMonthly::getMarketValue)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 9] Safekeeping value frequency: {}", safekeepingValueFrequency);
        return safekeepingValueFrequency;
    }

    private static BigDecimal calculateSafekeepingAmountDue(BigDecimal safekeepingValueFrequency, BigDecimal customerSafekeepingFee) {
        BigDecimal safeKeepingAfterDivide100Percentage = customerSafekeepingFee
                .divide(new BigDecimal(100), 4, RoundingMode.HALF_UP);

        BigDecimal safekeepingAmountDue = safekeepingValueFrequency
                .multiply(safeKeepingAfterDivide100Percentage)
                .divide(new BigDecimal(12), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);

        log.info("[Core Type 9] Safekeeping amount due: {}", safekeepingAmountDue);
        return safekeepingAmountDue;
    }

    private static BigDecimal calculateSubTotalAmountDue(BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotalAmountDue = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Core Type 9] Sub total amount due: {}", subTotalAmountDue);
        return subTotalAmountDue;
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal subTotalAmountDue, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotalAmountDue.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Core Type 9] VAT amount due: {}", vatAmountDue);
        return vatAmountDue;
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotalAmountDue, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotalAmountDue.add(vatAmountDue);
        log.info("[Core Type 9] Total amount due: {}", totalAmountDue);
        return totalAmountDue;
    }

    private CoreTemplate3 calculationResult(CoreType9Parameter param) {
        Integer transactionHandlingValueFrequency = calculateTransactionHandlingValueFrequency(param.getSkTransactionList());
        BigDecimal transactionHandlingAmountDue = calculateTransactionHandlingAmountDue(transactionHandlingValueFrequency, param.getTransactionHandlingFee());
        BigDecimal safekeepingValueFrequency = calculateSafekeepingValueFrequency(param.getSfValRgMonthlies());
        BigDecimal safekeepingAmountDue = calculateSafekeepingAmountDue(safekeepingValueFrequency, param.getCustomerSafekeepingFee());
        BigDecimal subTotalAmountDue = calculateSubTotalAmountDue(transactionHandlingAmountDue, safekeepingAmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(subTotalAmountDue, param.getVatFee());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotalAmountDue, vatAmountDue);

        return CoreTemplate3.builder()
                .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                .transactionHandlingFee(param.getTransactionHandlingFee())
                .transactionHandlingAmountDue(transactionHandlingAmountDue)
                .safekeepingValueFrequency(safekeepingValueFrequency)
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(safekeepingAmountDue)
                .subTotal(subTotalAmountDue)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private BillingCore buildBillingCore(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO) {
        return BillingCore.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .gefuCreated(false)
                .paid(false)
                .build();
    }

    private void updateBillingCoreForCoreTemplate3(BillingCore billingCore, CoreTemplate3 coreTemplate3) {
        billingCore.setTransactionHandlingValueFrequency(coreTemplate3.getTransactionHandlingValueFrequency());
        billingCore.setTransactionHandlingFee(coreTemplate3.getTransactionHandlingFee());
        billingCore.setTransactionHandlingAmountDue(coreTemplate3.getTransactionHandlingAmountDue());
        billingCore.setSafekeepingValueFrequency(coreTemplate3.getSafekeepingValueFrequency());
        billingCore.setSafekeepingFee(coreTemplate3.getSafekeepingFee());
        billingCore.setSafekeepingAmountDue(coreTemplate3.getSafekeepingAmountDue());
        billingCore.setSubTotal(coreTemplate3.getSubTotal());
        billingCore.setVatFee(coreTemplate3.getVatFee());
        billingCore.setVatAmountDue(coreTemplate3.getVatAmountDue());
        billingCore.setTotalAmountDue(coreTemplate3.getTotalAmountDue());
    }

    private void deleteExistingBillingCore(BillingCore existBillingCore) {
        String billingNumber = existBillingCore.getBillingNumber();
        billingCoreRepository.delete(existBillingCore);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

}
