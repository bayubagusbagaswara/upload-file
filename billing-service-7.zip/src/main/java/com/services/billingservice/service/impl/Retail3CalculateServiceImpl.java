package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.dto.retail.*;
import com.services.billingservice.enums.ApprovalStatus;
import com.services.billingservice.enums.BillingStatus;
import com.services.billingservice.enums.FeeParameter;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingRetail;
import com.services.billingservice.model.RetailTransaction;
import com.services.billingservice.repository.BillingRetailRepository;
import com.services.billingservice.repository.RetailAccountBalanceRepository;
import com.services.billingservice.repository.RetailTransactionRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import com.services.billingservice.utils.StringUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.services.billingservice.enums.Currency.IDR;
import static com.services.billingservice.enums.Currency.USD;

@Slf4j
@Service
@RequiredArgsConstructor
public class Retail3CalculateServiceImpl implements Retail3CalculateService {

    private final BillingCustomerService customerService;
    private final BillingFeeParameterService feeParameterService;
    private final BillingNumberService billingNumberService;
    private final RetailAccountBalanceRepository retailAccountBalanceRepository;
    private final RetailTransactionRepository retailTransactionRepository;
    private final BillingRetailRepository billingRetailRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(RetailCalculateRequest request) {
        log.info("Start calculate Billing Retail type 3 with request '{}'", request);

        /* initialize data response */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* initialize data request */
        String categoryUpperCase = request.getCategory().toUpperCase();
        String typeUpperCase = StringUtil.replaceBlanksWithUnderscores(request.getType());

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(Instant.now());
        LocalDate dateOfMonthYear = convertDateUtil.getFirstDateOfMonthYear(contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());

        /* get data fee parameters */
        BigDecimal vatFee = feeParameterService.getValueByName(FeeParameter.VAT.getValue());
        BigDecimal transactionHandlingInternalUSDFee = feeParameterService.getValueByName(FeeParameter.TRANSACTION_HANDLING_INTERNAL_CTBC_USD.getValue());
        BigDecimal settlementMinimum = feeParameterService.getValueByName(FeeParameter.SETTLEMENT_MINIMUM_CTBC_USD.getValue());

        /* get all data customer Retail Type 3 */
        List<BillingCustomer> customerList = customerService.getAllByBillingCategoryAndBillingType(categoryUpperCase, typeUpperCase);

        for (BillingCustomer customer : customerList) {
            try {
                String customerCode = customer.getCustomerCode();

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data retail account balance */
                List<Object[]> objects = retailAccountBalanceRepository.getRetailDataBySellingAgentAndCurrency(
                        customer.getSellingAgent(), customer.getCurrency(), dateOfMonthYear);

                Retail2QueryResultDTO retail2QueryResultDTO = mapToDTO(objects);
                BigDecimal safekeepingValueFrequency = null != retail2QueryResultDTO ? retail2QueryResultDTO.getLastBalance() : BigDecimal.ZERO;
                BigDecimal safekeepingAmountDue = null != retail2QueryResultDTO ? retail2QueryResultDTO.getSumFee() : BigDecimal.ZERO;

                /* get data retail transaction */
                List<RetailTransaction> retailTransactionList = retailTransactionRepository.findAllBySellingAgentAndMonthAndYearAndCurrency(
                        customer.getSellingAgent(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1(), customer.getCurrency());

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingRetail> existingBillingRetail = billingRetailRepository.findByCustomerCodeAndSubCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(
                        customerCode, customer.getSubCode(), customer.getBillingCategory(), customer.getBillingType(), contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingRetail.isPresent() || Boolean.TRUE.equals(!existingBillingRetail.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingRetail.ifPresent(this::deleteExistingBillingRetail);

                    /* create billing retail */
                    BillingRetail billingRetail = createBillingRetail(contextDate, customer, investmentManagementDTO);

                    /* create retail type 3 parameter */
                    RetailType3Parameter retailType3Parameter = new RetailType3Parameter(
                            retailTransactionList, safekeepingValueFrequency, safekeepingAmountDue,
                            customer.getCustomerSafekeepingFee(), customer.getCustomerTransactionHandling(),
                            vatFee, settlementMinimum, transactionHandlingInternalUSDFee);

                    if (IDR.getValue().equalsIgnoreCase(customer.getCurrency())) {
                        /* calculation IDR */
                        RetailTemplate3IDR retailTemplate3IDR = calculationIDR(retailType3Parameter);

                        /* update billing core data to include calculated values */
                        updateBillingRetailForRetailTemplate3IDR(billingRetail, retailTemplate3IDR);
                    } else if (USD.getValue().equalsIgnoreCase(customer.getCurrency())) {
                        /* calculation USD */
                        RetailTemplate3USD retailTemplate3USD = calculationUSD(retailType3Parameter);

                        /* update billing core data to include calculated values */
                        updateBillingRetailForRetailTemplate3USD(billingRetail, retailTemplate3USD);
                    }

                    /* create a billing number then set it to the billing core */
                    String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameNow(), contextDate.getYearNow());
                    billingRetail.setBillingNumber(number);

                    /* save to the database */
                    billingRetailRepository.save(billingRetail);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                handleGeneralError(customer.getCustomerCode(), e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successfully calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private void updateBillingRetailForRetailTemplate3USD(BillingRetail billingRetail, RetailTemplate3USD retailTemplate3USD) {
        billingRetail.setTransactionHandlingValueFrequency(retailTemplate3USD.getTransactionHandlingValueFrequency());
        billingRetail.setTransactionHandlingFee(retailTemplate3USD.getTransactionHandlingFee());
        billingRetail.setTransactionHandlingAmountDue(retailTemplate3USD.getTransactionHandlingAmountDue());

        billingRetail.setTransactionHandlingInternalValueFrequency(retailTemplate3USD.getTransactionHandlingInternalValueFrequency());
        billingRetail.setTransactionHandlingInternalFee(retailTemplate3USD.getTransactionHandlingInternalFee());
        billingRetail.setTransactionHandlingInternalAmountDue(retailTemplate3USD.getTransactionHandlingInternalAmountDue());

        billingRetail.setSafekeepingValueFrequency(retailTemplate3USD.getSafekeepingValueFrequency());
        billingRetail.setSafekeepingFee(retailTemplate3USD.getSafekeepingFee());
        billingRetail.setSafekeepingAmountDue(retailTemplate3USD.getSafekeepingAmountDue());

        billingRetail.setSubTotalAmountDue(retailTemplate3USD.getSubTotal());

        billingRetail.setVatFee(retailTemplate3USD.getVatFee());
        billingRetail.setVatAmountDue(retailTemplate3USD.getVatAmountDue());

        billingRetail.setTotalAmountDue(retailTemplate3USD.getTotalAmountDue());
    }

    private void updateBillingRetailForRetailTemplate3IDR(BillingRetail billingRetail, RetailTemplate3IDR retailTemplate3IDR) {
        billingRetail.setSafekeepingValueFrequency(retailTemplate3IDR.getSafekeepingValueFrequency());
        billingRetail.setSafekeepingFee(retailTemplate3IDR.getSafekeepingFee());
        billingRetail.setSafekeepingAmountDue(retailTemplate3IDR.getSafekeepingAmountDue());

        billingRetail.setTransactionHandlingValueFrequency(retailTemplate3IDR.getTransactionHandlingValueFrequency());
        billingRetail.setTransactionHandlingFee(retailTemplate3IDR.getTransactionHandlingFee());
        billingRetail.setTransactionHandlingAmountDue(retailTemplate3IDR.getTransactionHandlingAmountDue());

        billingRetail.setSubTotalAmountDue(retailTemplate3IDR.getSubTotal());

        billingRetail.setVatFee(retailTemplate3IDR.getVatFee());
        billingRetail.setVatAmountDue(retailTemplate3IDR.getVatAmountDue());

        billingRetail.setTotalAmountDue(retailTemplate3IDR.getTotalAmountDue());
    }

    private int[] calculateTransactionHandlingFrequencyAll(List<RetailTransaction> retailTransactionList, BigDecimal settlementMinimum) {
        int transactionValueFrequency = 0;
        int transactionValueFrequencyInternal = 0;
        for (RetailTransaction retailTransaction : retailTransactionList) {
            BigDecimal nominal = retailTransaction.getNominal().isEmpty() ? BigDecimal.ZERO : new BigDecimal(retailTransaction.getNominal());
            log.info("[Retail 3] Nominal : {}", nominal);

            // Check if nominal is below 200,000
            if (nominal.compareTo(settlementMinimum) < 0) {
                transactionValueFrequencyInternal++;
            } else {
                transactionValueFrequency++;
            }
        }

        return new int[] {transactionValueFrequency, transactionValueFrequencyInternal};
    }

    private BigDecimal calculateSubTotal(BigDecimal transactionHandlingAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotal = transactionHandlingAmountDue.add(safekeepingAmountDue);
        log.info("[Retail Type 3] Sub total: {}", subTotal);
        return subTotal;
    }

    private BigDecimal calculateVATAmountDue(BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 3] VAT amount due: {}", vatAmountDue);
        return vatAmountDue;
    }

    private BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue);
        log.info("[Retail Type 3] Total amount due: {}", totalAmountDue);
        return totalAmountDue;
    }

    private static List<Retail2QueryResultDTO> mapToDTOList(List<Object[]> result) {
        return result.stream()
                .map(data -> {
                    BigDecimal valueLastBalance = data[3] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[3]);
                    BigDecimal valueSumFee = data[4] == null ? BigDecimal.ZERO : new BigDecimal((Double) data[4]);
                    return Retail2QueryResultDTO.builder()
                            .year((Integer) data[0])
                            .month((String) data[1])
                            .sellingAgent((String) data[2])
                            .lastBalance(valueLastBalance)
                            .sumFee(valueSumFee)
                            .build();
                })
                .collect(Collectors.toList());
    }

    private static Retail2QueryResultDTO mapToDTO(List<Object[]> result) {
        // handle null pointer for lastBalance and sumFee
        BigDecimal valueLastBalance = result.get(0)[3] == null ? BigDecimal.ZERO : BigDecimal.valueOf((Double) result.get(0)[3]);
        BigDecimal valueSumFee = result.get(0)[4] == null ? BigDecimal.ZERO : BigDecimal.valueOf((Double) result.get(0)[4]);

        return result.isEmpty() ? null : Retail2QueryResultDTO.builder()
                .year((Integer) result.get(0)[0])
                .month((String) result.get(0)[1])
                .sellingAgent((String) result.get(0)[2])
                .lastBalance(valueLastBalance)
                .sumFee(valueSumFee.setScale(2, RoundingMode.HALF_UP))
                .build();
    }


    private BigDecimal calculateTransactionHandlingAmountDueUSD(int transactionHandlingValueFrequency, BigDecimal transactionHandlingFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingValueFrequency)
                .multiply(transactionHandlingFee)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 3] Transaction handling amount due: {}", transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private BigDecimal calculateTransactionHandlingInternalAmountDueUSD(int transactionHandlingInternalValueFrequency, BigDecimal transactionHandlingInternalUSDFee) {
        BigDecimal transactionHandlingAmountDue = new BigDecimal(transactionHandlingInternalValueFrequency)
                .multiply(transactionHandlingInternalUSDFee)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 3 ] Transaction handling internal amount due: {}", transactionHandlingAmountDue);
        return transactionHandlingAmountDue;
    }

    private BigDecimal calculateSubTotalUSD(BigDecimal transactionHandlingAmountDue, BigDecimal transactionHandlingInternalAmountDue, BigDecimal safekeepingAmountDue) {
        BigDecimal subTotal = transactionHandlingAmountDue
                .add(transactionHandlingInternalAmountDue)
                .add(safekeepingAmountDue);
        log.info("[Retail Type 3] Sub total: {}", subTotal);
        return subTotal;
    }

    private BigDecimal calculateVATAmountDueUSD(BigDecimal subTotal, BigDecimal vatFee) {
        BigDecimal vatAmountDue = subTotal
                .multiply(vatFee)
                .divide(new BigDecimal(100), 2, RoundingMode.HALF_UP)
                .setScale(2, RoundingMode.HALF_UP);
        log.info("[Retail Type 3] VAT amount due: {}", vatAmountDue);
        return vatAmountDue;
    }

    private BigDecimal calculateTotalAmountDueUSD(BigDecimal subTotal, BigDecimal vatAmountDue) {
        BigDecimal totalAmountDue = subTotal.add(vatAmountDue);
        log.info("[Retail Type 3] Total amount due: ", totalAmountDue);
        return totalAmountDue;
    }

    private void deleteExistingBillingRetail(BillingRetail existBillingRetail) {
        String billingNumber = existBillingRetail.getBillingNumber();
        billingRetailRepository.delete(existBillingRetail);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> errorMessageList, String customerCode, String message) {
        List<String> stringList = new ArrayList<>();
        stringList.add(message);
        errorMessageList.add(new BillingCalculationErrorMessageDTO(customerCode, stringList));
    }

    private BillingRetail createBillingRetail(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO) {  // set default field
        return BillingRetail.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .paid(false)
                .gefuCreated(false)
                .safekeepingFee(customer.getCustomerSafekeepingFee())
                .build();
    }

    private RetailTemplate3IDR calculationIDR(RetailType3Parameter param) {
        Integer transactionSettlementValueFrequency = calculateTransactionSettlementValueFrequency(param.getRetailTransactionList());
        BigDecimal transactionSettlementAmountDue = calculateTransactionSettlementAmountDue(transactionSettlementValueFrequency, param.getCustomerTransactionHandlingFee());
        BigDecimal subTotal = calculateSubTotal(transactionSettlementAmountDue, param.getSafekeepingAmountDue());
        BigDecimal vatAmountDue = calculateVATAmountDue(subTotal, param.getVatFee());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue);

        return RetailTemplate3IDR.builder()
                .safekeepingValueFrequency(param.getSafekeepingValueFrequency())
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(param.getSafekeepingAmountDue())
                .transactionHandlingValueFrequency(transactionSettlementValueFrequency)
                .transactionHandlingFee(param.getCustomerTransactionHandlingFee())
                .transactionHandlingAmountDue(transactionSettlementAmountDue)
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private RetailTemplate3USD calculationUSD(RetailType3Parameter param) {
        int[] transactionHandlingFrequencyAll = calculateTransactionHandlingFrequencyAll(param.getRetailTransactionList(), param.getSettlementMinimum());
        Integer transactionHandlingValueFrequency = transactionHandlingFrequencyAll[0];
        BigDecimal transactionHandlingAmountDue = calculateTransactionHandlingAmountDueUSD(transactionHandlingValueFrequency, param.getCustomerTransactionHandlingFee());

        Integer transactionHandlingInternalValueFrequency = transactionHandlingFrequencyAll[1];
        BigDecimal transactionHandlingInternalAmountDue = calculateTransactionHandlingInternalAmountDueUSD(transactionHandlingInternalValueFrequency, param.getTransactionHandlingInternalUSD());

        BigDecimal subTotal = calculateSubTotalUSD(transactionHandlingAmountDue, transactionHandlingInternalAmountDue, param.getSafekeepingAmountDue());
        BigDecimal vatAmountDue = calculateVATAmountDueUSD(subTotal, param.getVatFee());
        BigDecimal totalAmountDue = calculateTotalAmountDueUSD(subTotal, vatAmountDue);

        return RetailTemplate3USD.builder()
                .transactionHandlingValueFrequency(transactionHandlingValueFrequency)
                .transactionHandlingFee(param.getCustomerTransactionHandlingFee())
                .transactionHandlingAmountDue(transactionHandlingAmountDue)
                .transactionHandlingInternalValueFrequency(transactionHandlingInternalValueFrequency)
                .transactionHandlingInternalFee(param.getTransactionHandlingInternalUSD())
                .transactionHandlingInternalAmountDue(transactionHandlingInternalAmountDue)
                .safekeepingValueFrequency(param.getSafekeepingValueFrequency())
                .safekeepingFee(param.getCustomerSafekeepingFee())
                .safekeepingAmountDue(param.getSafekeepingAmountDue())
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private Integer calculateTransactionSettlementValueFrequency(List<RetailTransaction> retailTransactionList) {
        int totalTransactionSettlement = retailTransactionList.size();
        log.info("[Retail Type 2] Total transaction settlement: {}", totalTransactionSettlement);
        return totalTransactionSettlement;
    }

    private BigDecimal calculateTransactionSettlementAmountDue(Integer transactionSettlementValueFrequency, BigDecimal transactionSettlementFee) {
        log.info("Settlement Fee : {}", transactionSettlementFee);
        BigDecimal transactionSettlementAmountDue = new BigDecimal(transactionSettlementValueFrequency)
                .multiply(transactionSettlementFee)
                .setScale(0, RoundingMode.HALF_UP);
        log.info("[Retail Type 2] Transaction settlement amount due: {}", transactionSettlementAmountDue);
        return transactionSettlementAmountDue;
    }

}
