package com.services.billingservice.service.impl;

import com.services.billingservice.dto.billing.BillingCalculationErrorMessageDTO;
import com.services.billingservice.dto.billing.BillingCalculationResponse;
import com.services.billingservice.dto.billing.BillingContextDate;
import com.services.billingservice.dto.fund.*;
import com.services.billingservice.dto.mi.InvestmentManagementDTO;
import com.services.billingservice.enums.*;
import com.services.billingservice.model.BillingCustomer;
import com.services.billingservice.model.BillingFund;
import com.services.billingservice.model.SkTransaction;
import com.services.billingservice.repository.BillingFundRepository;
import com.services.billingservice.service.*;
import com.services.billingservice.utils.ConvertDateUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.services.billingservice.enums.BillingCategory.FUND;
import static com.services.billingservice.enums.BillingType.TYPE_1;
import static com.services.billingservice.enums.FeeParameter.BI_SSSS;
import static com.services.billingservice.enums.FeeParameter.KSEI;
import static com.services.billingservice.enums.FeeParameter.VAT;

@Service
@Slf4j
@RequiredArgsConstructor
public class FundCalculateServiceImpl implements FundCalculateService {

    private final BillingCustomerService customerService;
    private final SkTranService skTransactionService;
    private final BillingFeeParameterService feeParameterService;
    private final BillingNumberService billingNumberService;
    private final BillingFundRepository billingFundRepository;
    private final BillingMIService investmentManagementService;
    private final ConvertDateUtil convertDateUtil;

    @Override
    public String calculate(List<FeeReportRequest> feeReportRequests, String monthYear) {
        log.info("Start calculate Billing Fund with request size: {}", feeReportRequests.size());

        /* initialize billing variable */
        Instant dateNow = Instant.now();
        String billingCategory = FUND.getValue();
        String billingType = TYPE_1.getValue();

        /* initialize response */
        Integer totalDataSuccess = 0;
        Integer totalDataFailed = 0;
        List<BillingCalculationErrorMessageDTO> errorMessageList = new ArrayList<>();

        /* generate billing context date */
        BillingContextDate contextDate = convertDateUtil.getBillingContextDate(dateNow);

        /* get all data fee parameter */
        BigDecimal bis4TransactionFee = feeParameterService.getValueByName(BI_SSSS.getValue());
        BigDecimal kseiTransactionFee = feeParameterService.getValueByName(KSEI.getValue());
        BigDecimal vatFee = feeParameterService.getValueByName(VAT.getValue());

        /* start calculation */
        for (FeeReportRequest feeReportRequest : feeReportRequests) {
            String aid = feeReportRequest.getPortfolioCode();
            BigDecimal customerFee = feeReportRequest.getCustomerFee();
            try {
                /* get data customer by aid */
                BillingCustomer customer = customerService.getByCustomerCodeAndSubCodeAndBillingCategoryAndBillingType(aid, "", billingCategory, billingType);

                /* get data investment management */
                InvestmentManagementDTO investmentManagementDTO = investmentManagementService.getByCode(customer.getMiCode());

                /* get data sk transaction */
                List<SkTransaction> skTransactionList = skTransactionService.getAllByAidAndMonthAndYear(aid, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* get billing data to check whether the data is in the database or not */
                Optional<BillingFund> existingBillingFund = billingFundRepository.findByCustomerCodeAndBillingCategoryAndBillingTypeAndMonthAndYear(aid, billingCategory, billingType, contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());

                /* check paid status. if it is FALSE, it can be regenerated */
                if (!existingBillingFund.isPresent() || Boolean.TRUE.equals(!existingBillingFund.get().getPaid())) {

                    /* delete billing data if it exists in the database */
                    existingBillingFund.ifPresent(this::deleteExistingBillingFund);

                    /* create billing fund */
                    BillingFund billingFund = createBillingFund(contextDate, customer, investmentManagementDTO);

                    /* create fund parameter */
                    BillingFundParameter billingFundParameter = new BillingFundParameter(
                            customerFee, skTransactionList, customer.getCustomerSafekeepingFee(),
                            bis4TransactionFee, kseiTransactionFee, vatFee);

                    /* calculation billing */
                    FundTemplate1 fundTemplate1 = calculationFund(billingFundParameter);

                    /* update billing core data to include calculated values */
                    updateBillingFundForFundTemplate(billingFund, fundTemplate1);

                    /* create a billing number then set it to the billing core */
                    String number = billingNumberService.generateSingleNumber(contextDate.getMonthNameMinus1(), contextDate.getYearMinus1());
                    billingFund.setBillingNumber(number);

                    /* save to the database */
                    billingFundRepository.save(billingFund);
                    billingNumberService.saveSingleNumber(number);
                    totalDataSuccess++;
                } else {
                    addErrorMessage(errorMessageList, customer.getCustomerCode(), "Billing already paid for period " + contextDate.getMonthNameMinus1() + " " + contextDate.getYearMinus1());
                    totalDataFailed++;
                }
            } catch (Exception e) {
                log.error("Error processing customer code {}: {}", aid, e.getMessage(), e);
                handleGeneralError(aid, e, errorMessageList);
                totalDataFailed++;
            }
        }
        log.info("Total successful calculations: {}, total failed calculations: {}", totalDataSuccess, totalDataFailed);
        BillingCalculationResponse billingCalculationResponse = new BillingCalculationResponse(totalDataSuccess, totalDataFailed, errorMessageList);
        return "Total successful calculations: " + billingCalculationResponse.getTotalDataSuccess() + ", total failed calculations: " + billingCalculationResponse.getTotalDataFailed();
    }

    private static BigDecimal calculateAccrualCustodialFee(BigDecimal customerFee) {
        return customerFee
                .divide(BigDecimal.valueOf(1.11), 4, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateBis4AmountDue(int transactionBISSSSTotal, BigDecimal bis4TransactionFee) {
        return new BigDecimal(transactionBISSSSTotal)
                .multiply(bis4TransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateSubTotal(BigDecimal accrualCustodialFee, BigDecimal bis4AmountDue) {
        return accrualCustodialFee.add(bis4AmountDue).setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateVATAmountDue(BigDecimal subTotal, BigDecimal vatFee) {
        return subTotal.multiply(vatFee)
                .divide(new BigDecimal(100), 0, RoundingMode.HALF_UP)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateKSEIAmountDue(int transactionCBESTTotal, BigDecimal kseiTransactionFee) {
        return new BigDecimal(transactionCBESTTotal)
                .multiply(kseiTransactionFee)
                .setScale(0, RoundingMode.HALF_UP);
    }

    private static BigDecimal calculateTotalAmountDue(BigDecimal subTotal, BigDecimal vatAmountDue, BigDecimal kseiAmountDue) {
        return subTotal.add(vatAmountDue).add(kseiAmountDue).setScale(0, RoundingMode.HALF_UP);
    }

    private void handleGeneralError(String customerCode, Exception e, List<BillingCalculationErrorMessageDTO> errorMessageList) {
        addErrorMessage(errorMessageList, customerCode, e.getMessage());
    }

    private void addErrorMessage(List<BillingCalculationErrorMessageDTO> calculationErrorMessages, String customerCode, String message) {
        List<String> errorMessages = new ArrayList<>();
        errorMessages.add(message);
        calculationErrorMessages.add(new BillingCalculationErrorMessageDTO(customerCode, errorMessages));
    }

    private void deleteExistingBillingFund(BillingFund existBillingFund) {
        String billingNumber = existBillingFund.getBillingNumber();
        billingFundRepository.delete(existBillingFund);
        billingNumberService.deleteByBillingNumber(billingNumber);
    }

    private BillingFund createBillingFund(BillingContextDate contextDate, BillingCustomer customer, InvestmentManagementDTO investmentManagementDTO) {
        return BillingFund.builder()
                .createdAt(contextDate.getDateNow())
                .updatedAt(contextDate.getDateNow())
                .approvalStatus(ApprovalStatus.Pending)
                .billingStatus(BillingStatus.Generated)
                .customerCode(customer.getCustomerCode())
                .subCode(customer.getSubCode())
                .customerName(customer.getCustomerName())
                .month(contextDate.getMonthNameMinus1())
                .year(contextDate.getYearMinus1())
                .billingPeriod(contextDate.getBillingPeriod())
                .billingStatementDate(ConvertDateUtil.convertInstantToString(contextDate.getDateNow()))
                .billingPaymentDueDate(ConvertDateUtil.convertInstantToStringPlus14Days(contextDate.getDateNow()))
                .billingCategory(customer.getBillingCategory())
                .billingType(customer.getBillingType())
                .billingTemplate(customer.getBillingTemplate())
                .investmentManagementCode(investmentManagementDTO.getCode())
                .investmentManagementName(investmentManagementDTO.getName())
                .investmentManagementAddress1(investmentManagementDTO.getAddress1())
                .investmentManagementAddress2(investmentManagementDTO.getAddress2())
                .investmentManagementAddress3(investmentManagementDTO.getAddress3())
                .investmentManagementAddress4(investmentManagementDTO.getAddress4())
                .investmentManagementEmail(investmentManagementDTO.getEmail())
                .investmentManagementUniqueKey(investmentManagementDTO.getUniqueKey())
                .account(customer.getAccount())
                .accountName(customer.getAccountName())
                .currency(customer.getCurrency())
                .gefuCreated(false)
                .paid(false)
                .build();
    }

    private FundTemplate1 calculationFund(BillingFundParameter param) {
        int[] filteredTransactionsType = skTransactionService.filterTransactionsType(param.getSkTransactionList());
        int transactionCBESTTotal = filteredTransactionsType[0];
        int transactionBISSSSTotal = filteredTransactionsType[1];

        BigDecimal accrualCustodialFee = calculateAccrualCustodialFee(param.getCustomerFee());
        BigDecimal bis4AmountDue = calculateBis4AmountDue(transactionBISSSSTotal, param.getBis4TransactionFee());
        BigDecimal subTotal = calculateSubTotal(accrualCustodialFee, bis4AmountDue);
        BigDecimal vatAmountDue = calculateVATAmountDue(subTotal, param.getVatFee());
        BigDecimal kseiAmountDue = calculateKSEIAmountDue(transactionCBESTTotal, param.getKseiTransactionFee());
        BigDecimal totalAmountDue = calculateTotalAmountDue(subTotal, vatAmountDue, kseiAmountDue);

        return FundTemplate1.builder()
                .accrualCustodialValueFrequency(param.getCustomerFee())
                .accrualCustodialSafekeepingFee(param.getCustomerSafekeepingFee())
                .accrualCustodialFee(accrualCustodialFee)
                .bis4TransactionValueFrequency(transactionBISSSSTotal)
                .bis4TransactionFee(param.getBis4TransactionFee())
                .bis4TransactionAmountDue(bis4AmountDue)
                .subTotal(subTotal)
                .vatFee(param.getVatFee())
                .vatAmountDue(vatAmountDue)
                .kseiTransactionValueFrequency(transactionCBESTTotal)
                .kseiTransactionFee(param.getKseiTransactionFee())
                .kseiTransactionAmountDue(kseiAmountDue)
                .totalAmountDue(totalAmountDue)
                .build();
    }

    private void updateBillingFundForFundTemplate(BillingFund billingFund, FundTemplate1 fundTemplate1) {
        billingFund.setAccrualCustodialValueFrequency(fundTemplate1.getAccrualCustodialValueFrequency());
        billingFund.setAccrualCustodialSafekeepingFee(fundTemplate1.getAccrualCustodialSafekeepingFee());
        billingFund.setAccrualCustodialFee(fundTemplate1.getAccrualCustodialFee());

        billingFund.setBis4TransactionValueFrequency(fundTemplate1.getBis4TransactionValueFrequency());
        billingFund.setBis4TransactionFee(fundTemplate1.getBis4TransactionFee());
        billingFund.setBis4TransactionAmountDue(fundTemplate1.getBis4TransactionAmountDue());

        billingFund.setSubTotal(fundTemplate1.getSubTotal());
        billingFund.setVatFee(fundTemplate1.getVatFee());
        billingFund.setVatAmountDue(fundTemplate1.getVatAmountDue());

        billingFund.setKseiTransactionValueFrequency(fundTemplate1.getKseiTransactionValueFrequency());
        billingFund.setKseiTransactionFee(fundTemplate1.getKseiTransactionFee());
        billingFund.setKseiTransactionAmountDue(fundTemplate1.getKseiTransactionAmountDue());

        billingFund.setTotalAmountDue(fundTemplate1.getTotalAmountDue());
    }

}
